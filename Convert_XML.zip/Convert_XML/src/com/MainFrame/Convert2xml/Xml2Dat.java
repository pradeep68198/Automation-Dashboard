package com.MainFrame.Convert2xml;

import com.MainFrame.Convert2xml.convert.XmlToMainframe;
import com.MainFrame.Convert2xml.util.XmlUtils;

import org.w3c.dom.Document;


public class Xml2Dat
{
    
    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage:\txml2dat <xmlDataFileName> <copybookFileName>");
            System.err.println();
            System.err.println("Output will be printed to stdout; you can redirect it to a file with \" > <outputFileName>");
            return;
        }
        
        Document sourceFileXml = XmlUtils.fileToDom(args[0]);
        Document copyBookXml = XmlUtils.fileToDom(args[1]);

        String resultString = new XmlToMainframe().convert(sourceFileXml, copyBookXml);
        System.out.println(resultString);
    }
}

