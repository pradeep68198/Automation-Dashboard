
package com.MainFrame.Convert2xml.convert;

import java.util.Hashtable;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;



public class XmlToMainframe {

  private Hashtable keyValuePairs = new Hashtable();

  public String convert(Document sourceDocument, Document copyBookXml) {
    HashtableToMainframe hashtableToMainframe = new HashtableToMainframe();
    Element documentElement = sourceDocument.getDocumentElement();
    StringBuilder sb = new StringBuilder();
    NodeList childNodes = documentElement.getChildNodes();
    Node elementNode;
    String xpath;
    String sep = "";
    
    Element element;// = (Element) documentElement.getFirstChild();
    
    for (int i = 0; i < childNodes.getLength(); i++) { 
    	elementNode = childNodes.item(i);
    	if (elementNode instanceof Element) {
    		element = (Element) elementNode;
		    xpath = "/" + documentElement.getTagName() +
		        "/" + element.getTagName();
		    
		    keyValuePairs.clear();
		    convertNode(element, xpath);
		    
		    //FileUtils.writeFile(keyValuePairs.toString(), "hashtable.txt", false);
			sb.append(sep).append(hashtableToMainframe.convert(keyValuePairs, copyBookXml));
			sep = "\n";
    	}
    }
    return sb.toString();
  }

  private void convertNode(Element element, String xpath) {
    NodeList nodeList = element.getChildNodes();
    Hashtable childHash = new Hashtable(nodeList.getLength(), 1);
    int index = 0;
    for (int i = 0; i < nodeList.getLength(); i++) {
      org.w3c.dom.Node childNode = nodeList.item(i);
      if (childNode.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
        Element childElement = (Element) childNode;
        String childElementName = childElement.getTagName();
        if (childHash.containsKey(childElementName)) {
          index = Integer.parseInt(childHash.get(childElementName).toString()) +
              1;
          childHash.put(childElementName, index + "");
        }
        else {
          childHash.put(childElementName, "0");
        }
        childElement.setAttribute("index", index + "");
      }
      else if (childNode.getNodeType() == org.w3c.dom.Node.TEXT_NODE) {
        keyValuePairs.put(xpath, childNode.getNodeValue());
      }
    }
    for (int i = 0; i < nodeList.getLength(); i++) {
      org.w3c.dom.Node childNode = nodeList.item(i);

      if (childNode.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
        Element childElement = (Element) childNode;
        String childElementName = childElement.getTagName();
        if (!childHash.get(childElementName).equals("0")) {
          convertNode(childElement,
                      xpath + "/" + childElementName + "[" +
                      childElement.getAttribute("index") + "]");
        }
        else {
          convertNode(childElement, xpath + "/" + childElementName);
        }
      }
    }
  }

}