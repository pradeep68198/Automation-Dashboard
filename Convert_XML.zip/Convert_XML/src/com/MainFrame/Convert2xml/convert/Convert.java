
package com.MainFrame.Convert2xml.convert;

import com.MainFrame.Convert2xml.util.FileUtils;
import com.MainFrame.Convert2xml.util.XmlUtils;

import org.w3c.dom.Document;



public class Convert {
  public static void main(String[] args) {
    Document copyBookXml = XmlUtils.fileToDom(args[1]);
    Document sourceDocument = XmlUtils.fileToDom(args[0]);
    // params 1) XML source document 2) Copybook as XML
    String result = new XmlToMainframe().convert(sourceDocument, copyBookXml);
    FileUtils.writeFile(result, "mfresult.txt", false);
  }
}