

package com.MainFrame.Convert2xml.convert;

import java.util.Hashtable;

import com.MainFrame.Convert2xml.def.Cb2xmlConstants;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;



public class HashtableToMainframe {

  private Hashtable keyValuePairs = null;

  private StringBuffer getRepeatedChars(char charToRepeat, int count) {
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < count; i++) {
      sb.append(charToRepeat);
    }
    return sb;
  }

  public String convert(Hashtable keyAndValuePairs, Document copyBookXml) {
    this.keyValuePairs = keyAndValuePairs;
    Element documentElement = copyBookXml.getDocumentElement();
    //Element element = (Element) documentElement.getFirstChild();
    Element element = Utils.getFirstElement(documentElement);
    String documentTagName = documentElement.getTagName();
    String tagName = element.getAttribute(Cb2xmlConstants.NAME);
    String xpath = "/" + documentTagName + "/" + tagName;
    return convertNode(element, xpath).deleteCharAt(0).toString();
  }

  private StringBuffer convertNode(Element element, String xpath) {
    StringBuffer segment = new StringBuffer();
    segment.append('0');
    int position = Integer.parseInt(element.getAttribute(Cb2xmlConstants.POSITION));
    int length = Integer.parseInt(element.getAttribute(Cb2xmlConstants.STORAGE_LENGTH));
    boolean numeric = Cb2xmlConstants.TRUE.equalsIgnoreCase(element.getAttribute(Cb2xmlConstants.NUMERIC));
    int childElementCount = 0;
    NodeList nodeList = element.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      org.w3c.dom.Node node = nodeList.item(i);
      if (node.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
        Element childElement = (Element) node;
        if (!childElement.getAttribute(Cb2xmlConstants.LEVEL).equals("88")) {
          String childElementName = childElement.getAttribute(Cb2xmlConstants.NAME);
          childElementCount++;
          int childPosition = Integer.parseInt(childElement.getAttribute(
              Cb2xmlConstants.POSITION));
          StringBuffer tempBuffer = null;
          if (childElement.hasAttribute(Cb2xmlConstants.OCCURS)) {
            tempBuffer = new StringBuffer();
            tempBuffer.append('0');
            int childOccurs = Integer.parseInt(childElement.getAttribute(
                Cb2xmlConstants.OCCURS));
            //int childLength = Integer.parseInt(childElement.getAttribute(
            //    "length"));
           // int singleChildLength = childLength / childOccurs;
            for (int j = 0; j < childOccurs; j++) {
              StringBuffer occursBuffer = convertNode(childElement,
                  xpath + "/" + childElementName + "[" + j + "]");
              if (occursBuffer.charAt(0) == '1') {
                tempBuffer.setCharAt(0, '1');
              }
              occursBuffer.deleteCharAt(0);
              tempBuffer.append(occursBuffer);
            }
          }
          else {
            tempBuffer = convertNode(childElement,
                                     xpath + "/" + childElementName);
          }
          if (childElement.hasAttribute(Cb2xmlConstants.REDEFINES) &&
              tempBuffer.charAt(0) == '1') {
            tempBuffer.deleteCharAt(0);
            int replacePosition = childPosition - position;
            segment.replace(replacePosition,
                            replacePosition + tempBuffer.length(),
                            tempBuffer.toString());
          }
          else {
            if (tempBuffer.charAt(0) == '1') {
              segment.setCharAt(0, '1');
            }
            tempBuffer.deleteCharAt(0);
            segment.append(tempBuffer);
          }
        }
      }
    }
    if (childElementCount == 0) {
      if (keyValuePairs.containsKey(xpath)) {
        segment.setCharAt(0, '1');
        
        Object obj = keyValuePairs.get(xpath);
        String s = obj==null ? "" : obj.toString();
        if (s.length() < length) {
        	if (numeric) {
        		if (s.startsWith("-")) {
        			segment	.append('-')
        					.append(getRepeatedChars('0', length-s.length()))
        					.append(s);
        		} else {
        			if (s.startsWith("+")) {
        				s = s.substring(1);
        			}
        			segment	.append(getRepeatedChars('0', length-s.length()))
        					.append(s);
        		}
        	} else {
        		segment	.append(s)
        				.append(getRepeatedChars(' ', length-s.length()));
        	}
        } else if (s.length() < length) {
        	segment.append( s.substring(0, length));
        } else {
        	segment.append(s);
        }
      }
      else {
        if (element.hasAttribute(Cb2xmlConstants.VALUE)) {
          segment.append(element.getAttribute(Cb2xmlConstants.VALUE));
        }
//        else if (element.hasAttribute("spaces")) {
//          segment.append(getRepeatedChars(' ', length));
//        }
        else if (element.hasAttribute("zeros")) {
          segment.append(getRepeatedChars('0', length));
        } else {
          segment.append(getRepeatedChars(' ', length));
        }
      }
    }
    return segment;
  }

}