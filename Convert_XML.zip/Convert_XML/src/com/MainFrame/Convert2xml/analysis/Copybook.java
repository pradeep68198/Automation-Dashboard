/**
 * 
 */
package com.MainFrame.Convert2xml.analysis;

import com.MainFrame.Convert2xml.def.ICopybook;
import com.MainFrame.Convert2xml.def.IItemBase;


public class Copybook extends BaseItem implements ICopybook {

	final String filename, dialect;
	
	/**
	 * 
	 */
	public Copybook(String filename, String dialect) {
		super(200);
		
		this.filename = filename;
		this.dialect = dialect;
	}

	
	@Override
	public String getFilename() {
		return filename;
	}

	@Override
	public String getDialect() {
		return dialect;
	}

	
	@Override
	public IItemBase getParent() {
		return null;
	}

}
