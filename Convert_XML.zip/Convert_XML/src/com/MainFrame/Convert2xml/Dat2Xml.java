package com.MainFrame.Convert2xml;

import com.MainFrame.Convert2xml.convert.MainframeToXml;
import com.MainFrame.Convert2xml.util.FileUtils;
import com.MainFrame.Convert2xml.util.XmlUtils;

import org.w3c.dom.Document;


public class Dat2Xml
{
    
    public static void main(String[] args)
    {
        if (args.length != 2) {
            System.err.println("Usage:\tdat2xml <dataFileName> <xmlCopybookFileName>");
            System.err.println();
            System.err.println("Output will be printed to stdout; you can redirect it to a file with \" > <outputFileName>");
            return;
        }
        
        final String dataFileName = args[0];
        final String copybookFileName = args[1];
        
        String sourceFileContents= FileUtils.readFile(dataFileName).toString();
        Document copyBookXml = XmlUtils.fileToDom(copybookFileName);

        // params 1) XML source document 2) Copybook as XML
        Document resultDocument = new MainframeToXml().convert(sourceFileContents, copyBookXml);
        final StringBuffer resultBuffer = XmlUtils.domToString(resultDocument);
        String resultString = resultBuffer.toString();
        System.out.println(resultString);
      }
}

