

package com.MainFrame.Convert2xml;

import java.io.PushbackReader;

import com.MainFrame.Convert2xml.sablecc.lexer.Lexer;


public class DebugLexer extends Lexer {

	private StringBuffer buffer = new StringBuffer();
	
	public StringBuffer getBuffer() {
		return buffer;
	}
	
	public DebugLexer(PushbackReader reader) {
		super(reader);
	}

	protected void filter() {
		buffer.append(token.getText());
	    System.out.println(token.getClass() +
                ", state : " + state.id() +
                ", text : [" + token.getText() + "]");		
	}
}