

package com.MainFrame.Convert2xml.sablecc.lexer;

import java.io.*;

@SuppressWarnings("serial")
public interface IPushbackReader
{
    public int read() throws IOException;
    public void unread(int c) throws IOException;
}
