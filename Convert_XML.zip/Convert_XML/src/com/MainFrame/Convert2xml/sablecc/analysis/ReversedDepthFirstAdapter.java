

package com.MainFrame.Convert2xml.sablecc.analysis;

import java.util.*;
import com.MainFrame.Convert2xml.sablecc.node.*;

public class ReversedDepthFirstAdapter extends AnalysisAdapter
{
    public void inStart(Start node)
    {
        defaultIn(node);
    }

    public void outStart(Start node)
    {
        defaultOut(node);
    }

    public void defaultIn(@SuppressWarnings("unused") Node node)
    {
        // Do nothing
    }

    public void defaultOut(@SuppressWarnings("unused") Node node)
    {
        // Do nothing
    }

    @Override
    public void caseStart(Start node)
    {
        inStart(node);
        node.getEOF().apply(this);
        node.getPRecordDescription().apply(this);
        outStart(node);
    }

    public void inARecordDescription(ARecordDescription node)
    {
        defaultIn(node);
    }

    public void outARecordDescription(ARecordDescription node)
    {
        defaultOut(node);
    }

    @Override
    public void caseARecordDescription(ARecordDescription node)
    {
        inARecordDescription(node);
        if(node.getDot() != null)
        {
            node.getDot().apply(this);
        }
        if(node.getGroupItem() != null)
        {
            node.getGroupItem().apply(this);
        }
        outARecordDescription(node);
    }

    public void inASingleGroupItem(ASingleGroupItem node)
    {
        defaultIn(node);
    }

    public void outASingleGroupItem(ASingleGroupItem node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASingleGroupItem(ASingleGroupItem node)
    {
        inASingleGroupItem(node);
        if(node.getElementaryItem() != null)
        {
            node.getElementaryItem().apply(this);
        }
        outASingleGroupItem(node);
    }

    public void inASequenceGroupItem(ASequenceGroupItem node)
    {
        defaultIn(node);
    }

    public void outASequenceGroupItem(ASequenceGroupItem node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASequenceGroupItem(ASequenceGroupItem node)
    {
        inASequenceGroupItem(node);
        if(node.getElementaryItem() != null)
        {
            node.getElementaryItem().apply(this);
        }
        if(node.getDot() != null)
        {
            node.getDot().apply(this);
        }
        if(node.getGroupItem() != null)
        {
            node.getGroupItem().apply(this);
        }
        outASequenceGroupItem(node);
    }

    public void inAItemElementaryItem(AItemElementaryItem node)
    {
        defaultIn(node);
    }

    public void outAItemElementaryItem(AItemElementaryItem node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAItemElementaryItem(AItemElementaryItem node)
    {
        inAItemElementaryItem(node);
        if(node.getItem() != null)
        {
            node.getItem().apply(this);
        }
        outAItemElementaryItem(node);
    }

    public void inARenamesItemElementaryItem(ARenamesItemElementaryItem node)
    {
        defaultIn(node);
    }

    public void outARenamesItemElementaryItem(ARenamesItemElementaryItem node)
    {
        defaultOut(node);
    }

    @Override
    public void caseARenamesItemElementaryItem(ARenamesItemElementaryItem node)
    {
        inARenamesItemElementaryItem(node);
        if(node.getRenamesItem() != null)
        {
            node.getRenamesItem().apply(this);
        }
        outARenamesItemElementaryItem(node);
    }

    public void inAValueItemElementaryItem(AValueItemElementaryItem node)
    {
        defaultIn(node);
    }

    public void outAValueItemElementaryItem(AValueItemElementaryItem node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAValueItemElementaryItem(AValueItemElementaryItem node)
    {
        inAValueItemElementaryItem(node);
        if(node.getValueItem() != null)
        {
            node.getValueItem().apply(this);
        }
        outAValueItemElementaryItem(node);
    }

    public void inAItem(AItem node)
    {
        defaultIn(node);
    }

    public void outAItem(AItem node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAItem(AItem node)
    {
        inAItem(node);
        if(node.getClauseSequence() != null)
        {
            node.getClauseSequence().apply(this);
        }
        if(node.getRedefinesClause() != null)
        {
            node.getRedefinesClause().apply(this);
        }
        if(node.getDataNameOrFiller() != null)
        {
            node.getDataNameOrFiller().apply(this);
        }
        if(node.getNumberNot88() != null)
        {
            node.getNumberNot88().apply(this);
        }
        outAItem(node);
    }

    public void inADataNameDataNameOrFiller(ADataNameDataNameOrFiller node)
    {
        defaultIn(node);
    }

    public void outADataNameDataNameOrFiller(ADataNameDataNameOrFiller node)
    {
        defaultOut(node);
    }

    @Override
    public void caseADataNameDataNameOrFiller(ADataNameDataNameOrFiller node)
    {
        inADataNameDataNameOrFiller(node);
        if(node.getDataName() != null)
        {
            node.getDataName().apply(this);
        }
        outADataNameDataNameOrFiller(node);
    }

    public void inAFillerDataNameOrFiller(AFillerDataNameOrFiller node)
    {
        defaultIn(node);
    }

    public void outAFillerDataNameOrFiller(AFillerDataNameOrFiller node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAFillerDataNameOrFiller(AFillerDataNameOrFiller node)
    {
        inAFillerDataNameOrFiller(node);
        if(node.getFiller() != null)
        {
            node.getFiller().apply(this);
        }
        outAFillerDataNameOrFiller(node);
    }

    public void inARedefinesClause(ARedefinesClause node)
    {
        defaultIn(node);
    }

    public void outARedefinesClause(ARedefinesClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseARedefinesClause(ARedefinesClause node)
    {
        inARedefinesClause(node);
        if(node.getDataName() != null)
        {
            node.getDataName().apply(this);
        }
        if(node.getRedefines() != null)
        {
            node.getRedefines().apply(this);
        }
        outARedefinesClause(node);
    }

    public void inASingleClauseSequence(ASingleClauseSequence node)
    {
        defaultIn(node);
    }

    public void outASingleClauseSequence(ASingleClauseSequence node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASingleClauseSequence(ASingleClauseSequence node)
    {
        inASingleClauseSequence(node);
        if(node.getClause() != null)
        {
            node.getClause().apply(this);
        }
        outASingleClauseSequence(node);
    }

    public void inASequenceClauseSequence(ASequenceClauseSequence node)
    {
        defaultIn(node);
    }

    public void outASequenceClauseSequence(ASequenceClauseSequence node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASequenceClauseSequence(ASequenceClauseSequence node)
    {
        inASequenceClauseSequence(node);
        if(node.getClause() != null)
        {
            node.getClause().apply(this);
        }
        if(node.getClauseSequence() != null)
        {
            node.getClauseSequence().apply(this);
        }
        outASequenceClauseSequence(node);
    }

    public void inABlankWhenZeroClauseClause(ABlankWhenZeroClauseClause node)
    {
        defaultIn(node);
    }

    public void outABlankWhenZeroClauseClause(ABlankWhenZeroClauseClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseABlankWhenZeroClauseClause(ABlankWhenZeroClauseClause node)
    {
        inABlankWhenZeroClauseClause(node);
        if(node.getBlankWhenZeroClause() != null)
        {
            node.getBlankWhenZeroClause().apply(this);
        }
        outABlankWhenZeroClauseClause(node);
    }

    public void inADateFormatClauseClause(ADateFormatClauseClause node)
    {
        defaultIn(node);
    }

    public void outADateFormatClauseClause(ADateFormatClauseClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseADateFormatClauseClause(ADateFormatClauseClause node)
    {
        inADateFormatClauseClause(node);
        if(node.getDateFormatClause() != null)
        {
            node.getDateFormatClause().apply(this);
        }
        outADateFormatClauseClause(node);
    }

    public void inAExternalClauseClause(AExternalClauseClause node)
    {
        defaultIn(node);
    }

    public void outAExternalClauseClause(AExternalClauseClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAExternalClauseClause(AExternalClauseClause node)
    {
        inAExternalClauseClause(node);
        if(node.getExternalClause() != null)
        {
            node.getExternalClause().apply(this);
        }
        outAExternalClauseClause(node);
    }

    public void inAGlobalClauseClause(AGlobalClauseClause node)
    {
        defaultIn(node);
    }

    public void outAGlobalClauseClause(AGlobalClauseClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAGlobalClauseClause(AGlobalClauseClause node)
    {
        inAGlobalClauseClause(node);
        if(node.getGlobalClause() != null)
        {
            node.getGlobalClause().apply(this);
        }
        outAGlobalClauseClause(node);
    }

    public void inAJustifiedClauseClause(AJustifiedClauseClause node)
    {
        defaultIn(node);
    }

    public void outAJustifiedClauseClause(AJustifiedClauseClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAJustifiedClauseClause(AJustifiedClauseClause node)
    {
        inAJustifiedClauseClause(node);
        if(node.getJustifiedClause() != null)
        {
            node.getJustifiedClause().apply(this);
        }
        outAJustifiedClauseClause(node);
    }

    public void inAOccursClauseClause(AOccursClauseClause node)
    {
        defaultIn(node);
    }

    public void outAOccursClauseClause(AOccursClauseClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAOccursClauseClause(AOccursClauseClause node)
    {
        inAOccursClauseClause(node);
        if(node.getOccursClause() != null)
        {
            node.getOccursClause().apply(this);
        }
        outAOccursClauseClause(node);
    }

    public void inAPictureClauseClause(APictureClauseClause node)
    {
        defaultIn(node);
    }

    public void outAPictureClauseClause(APictureClauseClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAPictureClauseClause(APictureClauseClause node)
    {
        inAPictureClauseClause(node);
        if(node.getPictureClause() != null)
        {
            node.getPictureClause().apply(this);
        }
        outAPictureClauseClause(node);
    }

    public void inASignClauseClause(ASignClauseClause node)
    {
        defaultIn(node);
    }

    public void outASignClauseClause(ASignClauseClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASignClauseClause(ASignClauseClause node)
    {
        inASignClauseClause(node);
        if(node.getSignClause() != null)
        {
            node.getSignClause().apply(this);
        }
        outASignClauseClause(node);
    }

    public void inASynchronizedClauseClause(ASynchronizedClauseClause node)
    {
        defaultIn(node);
    }

    public void outASynchronizedClauseClause(ASynchronizedClauseClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASynchronizedClauseClause(ASynchronizedClauseClause node)
    {
        inASynchronizedClauseClause(node);
        if(node.getSynchronizedClause() != null)
        {
            node.getSynchronizedClause().apply(this);
        }
        outASynchronizedClauseClause(node);
    }

    public void inAUsageClauseClause(AUsageClauseClause node)
    {
        defaultIn(node);
    }

    public void outAUsageClauseClause(AUsageClauseClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAUsageClauseClause(AUsageClauseClause node)
    {
        inAUsageClauseClause(node);
        if(node.getUsageClause() != null)
        {
            node.getUsageClause().apply(this);
        }
        outAUsageClauseClause(node);
    }

    public void inAValueClauseClause(AValueClauseClause node)
    {
        defaultIn(node);
    }

    public void outAValueClauseClause(AValueClauseClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAValueClauseClause(AValueClauseClause node)
    {
        inAValueClauseClause(node);
        if(node.getValueClause() != null)
        {
            node.getValueClause().apply(this);
        }
        outAValueClauseClause(node);
    }

    public void inABlankWhenZeroClause(ABlankWhenZeroClause node)
    {
        defaultIn(node);
    }

    public void outABlankWhenZeroClause(ABlankWhenZeroClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseABlankWhenZeroClause(ABlankWhenZeroClause node)
    {
        inABlankWhenZeroClause(node);
        if(node.getZeros() != null)
        {
            node.getZeros().apply(this);
        }
        if(node.getWhen() != null)
        {
            node.getWhen().apply(this);
        }
        if(node.getBlank() != null)
        {
            node.getBlank().apply(this);
        }
        outABlankWhenZeroClause(node);
    }

    public void inADateFormatClause(ADateFormatClause node)
    {
        defaultIn(node);
    }

    public void outADateFormatClause(ADateFormatClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseADateFormatClause(ADateFormatClause node)
    {
        inADateFormatClause(node);
        if(node.getDataName() != null)
        {
            node.getDataName().apply(this);
        }
        if(node.getIs() != null)
        {
            node.getIs().apply(this);
        }
        if(node.getFormat() != null)
        {
            node.getFormat().apply(this);
        }
        if(node.getDate() != null)
        {
            node.getDate().apply(this);
        }
        outADateFormatClause(node);
    }

    public void inAExternalClause(AExternalClause node)
    {
        defaultIn(node);
    }

    public void outAExternalClause(AExternalClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAExternalClause(AExternalClause node)
    {
        inAExternalClause(node);
        if(node.getExternal() != null)
        {
            node.getExternal().apply(this);
        }
        outAExternalClause(node);
    }

    public void inAGlobalClause(AGlobalClause node)
    {
        defaultIn(node);
    }

    public void outAGlobalClause(AGlobalClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAGlobalClause(AGlobalClause node)
    {
        inAGlobalClause(node);
        if(node.getGlobal() != null)
        {
            node.getGlobal().apply(this);
        }
        outAGlobalClause(node);
    }

    public void inAJustifiedClause(AJustifiedClause node)
    {
        defaultIn(node);
    }

    public void outAJustifiedClause(AJustifiedClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAJustifiedClause(AJustifiedClause node)
    {
        inAJustifiedClause(node);
        if(node.getRight() != null)
        {
            node.getRight().apply(this);
        }
        if(node.getJustified() != null)
        {
            node.getJustified().apply(this);
        }
        outAJustifiedClause(node);
    }

    public void inAOccursClause(AOccursClause node)
    {
        defaultIn(node);
    }

    public void outAOccursClause(AOccursClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAOccursClause(AOccursClause node)
    {
        inAOccursClause(node);
        {
            List<PIndexedByPhrase> copy = new ArrayList<PIndexedByPhrase>(node.getIndexedByPhrase());
            Collections.reverse(copy);
            for(PIndexedByPhrase e : copy)
            {
                e.apply(this);
            }
        }
        {
            List<PAscendingOrDescendingKeyPhrase> copy = new ArrayList<PAscendingOrDescendingKeyPhrase>(node.getAscendingOrDescendingKeyPhrase());
            Collections.reverse(copy);
            for(PAscendingOrDescendingKeyPhrase e : copy)
            {
                e.apply(this);
            }
        }
        if(node.getOccursFixedOrVariable() != null)
        {
            node.getOccursFixedOrVariable().apply(this);
        }
        outAOccursClause(node);
    }

    public void inAFixedOccursFixedOrVariable(AFixedOccursFixedOrVariable node)
    {
        defaultIn(node);
    }

    public void outAFixedOccursFixedOrVariable(AFixedOccursFixedOrVariable node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAFixedOccursFixedOrVariable(AFixedOccursFixedOrVariable node)
    {
        inAFixedOccursFixedOrVariable(node);
        if(node.getTimes() != null)
        {
            node.getTimes().apply(this);
        }
        if(node.getNumber() != null)
        {
            node.getNumber().apply(this);
        }
        if(node.getOccurs() != null)
        {
            node.getOccurs().apply(this);
        }
        outAFixedOccursFixedOrVariable(node);
    }

    public void inAVariableOccursFixedOrVariable(AVariableOccursFixedOrVariable node)
    {
        defaultIn(node);
    }

    public void outAVariableOccursFixedOrVariable(AVariableOccursFixedOrVariable node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAVariableOccursFixedOrVariable(AVariableOccursFixedOrVariable node)
    {
        inAVariableOccursFixedOrVariable(node);
        if(node.getDataName() != null)
        {
            node.getDataName().apply(this);
        }
        if(node.getOn() != null)
        {
            node.getOn().apply(this);
        }
        if(node.getDepending() != null)
        {
            node.getDepending().apply(this);
        }
        if(node.getTimes() != null)
        {
            node.getTimes().apply(this);
        }
        if(node.getNumber() != null)
        {
            node.getNumber().apply(this);
        }
        if(node.getOccursTo() != null)
        {
            node.getOccursTo().apply(this);
        }
        if(node.getOccurs() != null)
        {
            node.getOccurs().apply(this);
        }
        outAVariableOccursFixedOrVariable(node);
    }

    public void inAOccursTo(AOccursTo node)
    {
        defaultIn(node);
    }

    public void outAOccursTo(AOccursTo node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAOccursTo(AOccursTo node)
    {
        inAOccursTo(node);
        if(node.getTo() != null)
        {
            node.getTo().apply(this);
        }
        if(node.getNumber() != null)
        {
            node.getNumber().apply(this);
        }
        outAOccursTo(node);
    }

    public void inAAscendingOrDescendingKeyPhrase(AAscendingOrDescendingKeyPhrase node)
    {
        defaultIn(node);
    }

    public void outAAscendingOrDescendingKeyPhrase(AAscendingOrDescendingKeyPhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAAscendingOrDescendingKeyPhrase(AAscendingOrDescendingKeyPhrase node)
    {
        inAAscendingOrDescendingKeyPhrase(node);
        {
            List<TDataName> copy = new ArrayList<TDataName>(node.getDataName());
            Collections.reverse(copy);
            for(TDataName e : copy)
            {
                e.apply(this);
            }
        }
        if(node.getIs() != null)
        {
            node.getIs().apply(this);
        }
        if(node.getKey() != null)
        {
            node.getKey().apply(this);
        }
        if(node.getAscendingOrDescending() != null)
        {
            node.getAscendingOrDescending().apply(this);
        }
        outAAscendingOrDescendingKeyPhrase(node);
    }

    public void inAAscendingAscendingOrDescending(AAscendingAscendingOrDescending node)
    {
        defaultIn(node);
    }

    public void outAAscendingAscendingOrDescending(AAscendingAscendingOrDescending node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAAscendingAscendingOrDescending(AAscendingAscendingOrDescending node)
    {
        inAAscendingAscendingOrDescending(node);
        if(node.getAscending() != null)
        {
            node.getAscending().apply(this);
        }
        outAAscendingAscendingOrDescending(node);
    }

    public void inADescendingAscendingOrDescending(ADescendingAscendingOrDescending node)
    {
        defaultIn(node);
    }

    public void outADescendingAscendingOrDescending(ADescendingAscendingOrDescending node)
    {
        defaultOut(node);
    }

    @Override
    public void caseADescendingAscendingOrDescending(ADescendingAscendingOrDescending node)
    {
        inADescendingAscendingOrDescending(node);
        if(node.getDescending() != null)
        {
            node.getDescending().apply(this);
        }
        outADescendingAscendingOrDescending(node);
    }

    public void inAIndexedByPhrase(AIndexedByPhrase node)
    {
        defaultIn(node);
    }

    public void outAIndexedByPhrase(AIndexedByPhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAIndexedByPhrase(AIndexedByPhrase node)
    {
        inAIndexedByPhrase(node);
        {
            List<TDataName> copy = new ArrayList<TDataName>(node.getDataName());
            Collections.reverse(copy);
            for(TDataName e : copy)
            {
                e.apply(this);
            }
        }
        if(node.getBy() != null)
        {
            node.getBy().apply(this);
        }
        if(node.getIndexed() != null)
        {
            node.getIndexed().apply(this);
        }
        outAIndexedByPhrase(node);
    }

    public void inAPictureClause(APictureClause node)
    {
        defaultIn(node);
    }

    public void outAPictureClause(APictureClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAPictureClause(APictureClause node)
    {
        inAPictureClause(node);
        if(node.getCharacterString() != null)
        {
            node.getCharacterString().apply(this);
        }
        if(node.getIs() != null)
        {
            node.getIs().apply(this);
        }
        if(node.getPicture() != null)
        {
            node.getPicture().apply(this);
        }
        outAPictureClause(node);
    }

    public void inASignClause(ASignClause node)
    {
        defaultIn(node);
    }

    public void outASignClause(ASignClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASignClause(ASignClause node)
    {
        inASignClause(node);
        if(node.getSeparateCharacter() != null)
        {
            node.getSeparateCharacter().apply(this);
        }
        if(node.getLeadingOrTrailing() != null)
        {
            node.getLeadingOrTrailing().apply(this);
        }
        if(node.getSignIs() != null)
        {
            node.getSignIs().apply(this);
        }
        outASignClause(node);
    }

    public void inASignIs(ASignIs node)
    {
        defaultIn(node);
    }

    public void outASignIs(ASignIs node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASignIs(ASignIs node)
    {
        inASignIs(node);
        if(node.getIs() != null)
        {
            node.getIs().apply(this);
        }
        if(node.getSign() != null)
        {
            node.getSign().apply(this);
        }
        outASignIs(node);
    }

    public void inALeadingLeadingOrTrailing(ALeadingLeadingOrTrailing node)
    {
        defaultIn(node);
    }

    public void outALeadingLeadingOrTrailing(ALeadingLeadingOrTrailing node)
    {
        defaultOut(node);
    }

    @Override
    public void caseALeadingLeadingOrTrailing(ALeadingLeadingOrTrailing node)
    {
        inALeadingLeadingOrTrailing(node);
        if(node.getLeading() != null)
        {
            node.getLeading().apply(this);
        }
        outALeadingLeadingOrTrailing(node);
    }

    public void inATrailingLeadingOrTrailing(ATrailingLeadingOrTrailing node)
    {
        defaultIn(node);
    }

    public void outATrailingLeadingOrTrailing(ATrailingLeadingOrTrailing node)
    {
        defaultOut(node);
    }

    @Override
    public void caseATrailingLeadingOrTrailing(ATrailingLeadingOrTrailing node)
    {
        inATrailingLeadingOrTrailing(node);
        if(node.getTrailing() != null)
        {
            node.getTrailing().apply(this);
        }
        outATrailingLeadingOrTrailing(node);
    }

    public void inASeparateCharacter(ASeparateCharacter node)
    {
        defaultIn(node);
    }

    public void outASeparateCharacter(ASeparateCharacter node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASeparateCharacter(ASeparateCharacter node)
    {
        inASeparateCharacter(node);
        if(node.getCharacter() != null)
        {
            node.getCharacter().apply(this);
        }
        if(node.getSeparate() != null)
        {
            node.getSeparate().apply(this);
        }
        outASeparateCharacter(node);
    }

    public void inASynchronizedClause(ASynchronizedClause node)
    {
        defaultIn(node);
    }

    public void outASynchronizedClause(ASynchronizedClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASynchronizedClause(ASynchronizedClause node)
    {
        inASynchronizedClause(node);
        if(node.getLeftOrRight() != null)
        {
            node.getLeftOrRight().apply(this);
        }
        if(node.getSynchronized() != null)
        {
            node.getSynchronized().apply(this);
        }
        outASynchronizedClause(node);
    }

    public void inALeftLeftOrRight(ALeftLeftOrRight node)
    {
        defaultIn(node);
    }

    public void outALeftLeftOrRight(ALeftLeftOrRight node)
    {
        defaultOut(node);
    }

    @Override
    public void caseALeftLeftOrRight(ALeftLeftOrRight node)
    {
        inALeftLeftOrRight(node);
        if(node.getLeft() != null)
        {
            node.getLeft().apply(this);
        }
        outALeftLeftOrRight(node);
    }

    public void inARightLeftOrRight(ARightLeftOrRight node)
    {
        defaultIn(node);
    }

    public void outARightLeftOrRight(ARightLeftOrRight node)
    {
        defaultOut(node);
    }

    @Override
    public void caseARightLeftOrRight(ARightLeftOrRight node)
    {
        inARightLeftOrRight(node);
        if(node.getRight() != null)
        {
            node.getRight().apply(this);
        }
        outARightLeftOrRight(node);
    }

    public void inAUsageClause(AUsageClause node)
    {
        defaultIn(node);
    }

    public void outAUsageClause(AUsageClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAUsageClause(AUsageClause node)
    {
        inAUsageClause(node);
        if(node.getUsagePhrase() != null)
        {
            node.getUsagePhrase().apply(this);
        }
        if(node.getUsageIs() != null)
        {
            node.getUsageIs().apply(this);
        }
        outAUsageClause(node);
    }

    public void inAUsageIs(AUsageIs node)
    {
        defaultIn(node);
    }

    public void outAUsageIs(AUsageIs node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAUsageIs(AUsageIs node)
    {
        inAUsageIs(node);
        if(node.getIs() != null)
        {
            node.getIs().apply(this);
        }
        if(node.getUsage() != null)
        {
            node.getUsage().apply(this);
        }
        outAUsageIs(node);
    }

    public void inABinaryUsagePhrase(ABinaryUsagePhrase node)
    {
        defaultIn(node);
    }

    public void outABinaryUsagePhrase(ABinaryUsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseABinaryUsagePhrase(ABinaryUsagePhrase node)
    {
        inABinaryUsagePhrase(node);
        if(node.getNative() != null)
        {
            node.getNative().apply(this);
        }
        if(node.getBinary() != null)
        {
            node.getBinary().apply(this);
        }
        outABinaryUsagePhrase(node);
    }

    public void inACompUsagePhrase(ACompUsagePhrase node)
    {
        defaultIn(node);
    }

    public void outACompUsagePhrase(ACompUsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseACompUsagePhrase(ACompUsagePhrase node)
    {
        inACompUsagePhrase(node);
        if(node.getComp() != null)
        {
            node.getComp().apply(this);
        }
        outACompUsagePhrase(node);
    }

    public void inAComp1UsagePhrase(AComp1UsagePhrase node)
    {
        defaultIn(node);
    }

    public void outAComp1UsagePhrase(AComp1UsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAComp1UsagePhrase(AComp1UsagePhrase node)
    {
        inAComp1UsagePhrase(node);
        if(node.getNative() != null)
        {
            node.getNative().apply(this);
        }
        if(node.getComp1() != null)
        {
            node.getComp1().apply(this);
        }
        outAComp1UsagePhrase(node);
    }

    public void inAComp2UsagePhrase(AComp2UsagePhrase node)
    {
        defaultIn(node);
    }

    public void outAComp2UsagePhrase(AComp2UsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAComp2UsagePhrase(AComp2UsagePhrase node)
    {
        inAComp2UsagePhrase(node);
        if(node.getNative() != null)
        {
            node.getNative().apply(this);
        }
        if(node.getComp2() != null)
        {
            node.getComp2().apply(this);
        }
        outAComp2UsagePhrase(node);
    }

    public void inAComp3UsagePhrase(AComp3UsagePhrase node)
    {
        defaultIn(node);
    }

    public void outAComp3UsagePhrase(AComp3UsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAComp3UsagePhrase(AComp3UsagePhrase node)
    {
        inAComp3UsagePhrase(node);
        if(node.getComp3() != null)
        {
            node.getComp3().apply(this);
        }
        outAComp3UsagePhrase(node);
    }

    public void inAComp4UsagePhrase(AComp4UsagePhrase node)
    {
        defaultIn(node);
    }

    public void outAComp4UsagePhrase(AComp4UsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAComp4UsagePhrase(AComp4UsagePhrase node)
    {
        inAComp4UsagePhrase(node);
        if(node.getNative() != null)
        {
            node.getNative().apply(this);
        }
        if(node.getComp4() != null)
        {
            node.getComp4().apply(this);
        }
        outAComp4UsagePhrase(node);
    }

    public void inAComp5UsagePhrase(AComp5UsagePhrase node)
    {
        defaultIn(node);
    }

    public void outAComp5UsagePhrase(AComp5UsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAComp5UsagePhrase(AComp5UsagePhrase node)
    {
        inAComp5UsagePhrase(node);
        if(node.getComp5() != null)
        {
            node.getComp5().apply(this);
        }
        outAComp5UsagePhrase(node);
    }

    public void inAComp6UsagePhrase(AComp6UsagePhrase node)
    {
        defaultIn(node);
    }

    public void outAComp6UsagePhrase(AComp6UsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAComp6UsagePhrase(AComp6UsagePhrase node)
    {
        inAComp6UsagePhrase(node);
        if(node.getComp6() != null)
        {
            node.getComp6().apply(this);
        }
        outAComp6UsagePhrase(node);
    }

    public void inADisplayUsagePhrase(ADisplayUsagePhrase node)
    {
        defaultIn(node);
    }

    public void outADisplayUsagePhrase(ADisplayUsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseADisplayUsagePhrase(ADisplayUsagePhrase node)
    {
        inADisplayUsagePhrase(node);
        if(node.getNative() != null)
        {
            node.getNative().apply(this);
        }
        if(node.getDisplay() != null)
        {
            node.getDisplay().apply(this);
        }
        outADisplayUsagePhrase(node);
    }

    public void inADisplay1UsagePhrase(ADisplay1UsagePhrase node)
    {
        defaultIn(node);
    }

    public void outADisplay1UsagePhrase(ADisplay1UsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseADisplay1UsagePhrase(ADisplay1UsagePhrase node)
    {
        inADisplay1UsagePhrase(node);
        if(node.getNative() != null)
        {
            node.getNative().apply(this);
        }
        if(node.getDisplay1() != null)
        {
            node.getDisplay1().apply(this);
        }
        outADisplay1UsagePhrase(node);
    }

    public void inAIndexUsagePhrase(AIndexUsagePhrase node)
    {
        defaultIn(node);
    }

    public void outAIndexUsagePhrase(AIndexUsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAIndexUsagePhrase(AIndexUsagePhrase node)
    {
        inAIndexUsagePhrase(node);
        if(node.getIndex() != null)
        {
            node.getIndex().apply(this);
        }
        outAIndexUsagePhrase(node);
    }

    public void inANationalUsagePhrase(ANationalUsagePhrase node)
    {
        defaultIn(node);
    }

    public void outANationalUsagePhrase(ANationalUsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseANationalUsagePhrase(ANationalUsagePhrase node)
    {
        inANationalUsagePhrase(node);
        if(node.getNational() != null)
        {
            node.getNational().apply(this);
        }
        outANationalUsagePhrase(node);
    }

    public void inAObjectReferencePhraseUsagePhrase(AObjectReferencePhraseUsagePhrase node)
    {
        defaultIn(node);
    }

    public void outAObjectReferencePhraseUsagePhrase(AObjectReferencePhraseUsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAObjectReferencePhraseUsagePhrase(AObjectReferencePhraseUsagePhrase node)
    {
        inAObjectReferencePhraseUsagePhrase(node);
        if(node.getObjectReferencePhrase() != null)
        {
            node.getObjectReferencePhrase().apply(this);
        }
        outAObjectReferencePhraseUsagePhrase(node);
    }

    public void inAPackedDecimalUsagePhrase(APackedDecimalUsagePhrase node)
    {
        defaultIn(node);
    }

    public void outAPackedDecimalUsagePhrase(APackedDecimalUsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAPackedDecimalUsagePhrase(APackedDecimalUsagePhrase node)
    {
        inAPackedDecimalUsagePhrase(node);
        if(node.getPackedDecimal() != null)
        {
            node.getPackedDecimal().apply(this);
        }
        outAPackedDecimalUsagePhrase(node);
    }

    public void inAPointerUsagePhrase(APointerUsagePhrase node)
    {
        defaultIn(node);
    }

    public void outAPointerUsagePhrase(APointerUsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAPointerUsagePhrase(APointerUsagePhrase node)
    {
        inAPointerUsagePhrase(node);
        if(node.getPointer() != null)
        {
            node.getPointer().apply(this);
        }
        outAPointerUsagePhrase(node);
    }

    public void inAProcedurePointerUsagePhrase(AProcedurePointerUsagePhrase node)
    {
        defaultIn(node);
    }

    public void outAProcedurePointerUsagePhrase(AProcedurePointerUsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAProcedurePointerUsagePhrase(AProcedurePointerUsagePhrase node)
    {
        inAProcedurePointerUsagePhrase(node);
        if(node.getProcedurePointer() != null)
        {
            node.getProcedurePointer().apply(this);
        }
        outAProcedurePointerUsagePhrase(node);
    }

    public void inAFunctionPointerUsagePhrase(AFunctionPointerUsagePhrase node)
    {
        defaultIn(node);
    }

    public void outAFunctionPointerUsagePhrase(AFunctionPointerUsagePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAFunctionPointerUsagePhrase(AFunctionPointerUsagePhrase node)
    {
        inAFunctionPointerUsagePhrase(node);
        if(node.getFunctionPointer() != null)
        {
            node.getFunctionPointer().apply(this);
        }
        outAFunctionPointerUsagePhrase(node);
    }

    public void inAObjectReferencePhrase(AObjectReferencePhrase node)
    {
        defaultIn(node);
    }

    public void outAObjectReferencePhrase(AObjectReferencePhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAObjectReferencePhrase(AObjectReferencePhrase node)
    {
        inAObjectReferencePhrase(node);
        if(node.getDataName() != null)
        {
            node.getDataName().apply(this);
        }
        if(node.getReference() != null)
        {
            node.getReference().apply(this);
        }
        if(node.getObject() != null)
        {
            node.getObject().apply(this);
        }
        outAObjectReferencePhrase(node);
    }

    public void inARenamesItem(ARenamesItem node)
    {
        defaultIn(node);
    }

    public void outARenamesItem(ARenamesItem node)
    {
        defaultOut(node);
    }

    @Override
    public void caseARenamesItem(ARenamesItem node)
    {
        inARenamesItem(node);
        if(node.getThroughPhrase() != null)
        {
            node.getThroughPhrase().apply(this);
        }
        if(node.getRenameFrom() != null)
        {
            node.getRenameFrom().apply(this);
        }
        if(node.getRenames() != null)
        {
            node.getRenames().apply(this);
        }
        if(node.getRenameTo() != null)
        {
            node.getRenameTo().apply(this);
        }
        if(node.getNumberNot88() != null)
        {
            node.getNumberNot88().apply(this);
        }
        outARenamesItem(node);
    }

    public void inAThroughPhrase(AThroughPhrase node)
    {
        defaultIn(node);
    }

    public void outAThroughPhrase(AThroughPhrase node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAThroughPhrase(AThroughPhrase node)
    {
        inAThroughPhrase(node);
        if(node.getDataName() != null)
        {
            node.getDataName().apply(this);
        }
        if(node.getThrough() != null)
        {
            node.getThrough().apply(this);
        }
        outAThroughPhrase(node);
    }

    public void inAValueClause(AValueClause node)
    {
        defaultIn(node);
    }

    public void outAValueClause(AValueClause node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAValueClause(AValueClause node)
    {
        inAValueClause(node);
        if(node.getLiteral() != null)
        {
            node.getLiteral().apply(this);
        }
        if(node.getAll() != null)
        {
            node.getAll().apply(this);
        }
        if(node.getIs() != null)
        {
            node.getIs().apply(this);
        }
        if(node.getValue() != null)
        {
            node.getValue().apply(this);
        }
        outAValueClause(node);
    }

    public void inAValueItem(AValueItem node)
    {
        defaultIn(node);
    }

    public void outAValueItem(AValueItem node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAValueItem(AValueItem node)
    {
        inAValueItem(node);
        if(node.getLiteralSequence() != null)
        {
            node.getLiteralSequence().apply(this);
        }
        if(node.getValueOrValues() != null)
        {
            node.getValueOrValues().apply(this);
        }
        if(node.getDataName() != null)
        {
            node.getDataName().apply(this);
        }
        if(node.getNumber88() != null)
        {
            node.getNumber88().apply(this);
        }
        outAValueItem(node);
    }

    public void inAValueValueOrValues(AValueValueOrValues node)
    {
        defaultIn(node);
    }

    public void outAValueValueOrValues(AValueValueOrValues node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAValueValueOrValues(AValueValueOrValues node)
    {
        inAValueValueOrValues(node);
        if(node.getIs() != null)
        {
            node.getIs().apply(this);
        }
        if(node.getValue() != null)
        {
            node.getValue().apply(this);
        }
        outAValueValueOrValues(node);
    }

    public void inAValuesValueOrValues(AValuesValueOrValues node)
    {
        defaultIn(node);
    }

    public void outAValuesValueOrValues(AValuesValueOrValues node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAValuesValueOrValues(AValuesValueOrValues node)
    {
        inAValuesValueOrValues(node);
        if(node.getAre() != null)
        {
            node.getAre().apply(this);
        }
        if(node.getValues() != null)
        {
            node.getValues().apply(this);
        }
        outAValuesValueOrValues(node);
    }

    public void inASingleLiteralSequence(ASingleLiteralSequence node)
    {
        defaultIn(node);
    }

    public void outASingleLiteralSequence(ASingleLiteralSequence node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASingleLiteralSequence(ASingleLiteralSequence node)
    {
        inASingleLiteralSequence(node);
        if(node.getLiteral() != null)
        {
            node.getLiteral().apply(this);
        }
        if(node.getAll() != null)
        {
            node.getAll().apply(this);
        }
        outASingleLiteralSequence(node);
    }

    public void inASequenceLiteralSequence(ASequenceLiteralSequence node)
    {
        defaultIn(node);
    }

    public void outASequenceLiteralSequence(ASequenceLiteralSequence node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASequenceLiteralSequence(ASequenceLiteralSequence node)
    {
        inASequenceLiteralSequence(node);
        if(node.getLiteral() != null)
        {
            node.getLiteral().apply(this);
        }
        if(node.getComma() != null)
        {
            node.getComma().apply(this);
        }
        if(node.getLiteralSequence() != null)
        {
            node.getLiteralSequence().apply(this);
        }
        outASequenceLiteralSequence(node);
    }

    public void inAThroughSingleLiteralSequence(AThroughSingleLiteralSequence node)
    {
        defaultIn(node);
    }

    public void outAThroughSingleLiteralSequence(AThroughSingleLiteralSequence node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAThroughSingleLiteralSequence(AThroughSingleLiteralSequence node)
    {
        inAThroughSingleLiteralSequence(node);
        if(node.getTo() != null)
        {
            node.getTo().apply(this);
        }
        if(node.getThrough() != null)
        {
            node.getThrough().apply(this);
        }
        if(node.getFrom() != null)
        {
            node.getFrom().apply(this);
        }
        outAThroughSingleLiteralSequence(node);
    }

    public void inAThroughSequenceLiteralSequence(AThroughSequenceLiteralSequence node)
    {
        defaultIn(node);
    }

    public void outAThroughSequenceLiteralSequence(AThroughSequenceLiteralSequence node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAThroughSequenceLiteralSequence(AThroughSequenceLiteralSequence node)
    {
        inAThroughSequenceLiteralSequence(node);
        if(node.getTo() != null)
        {
            node.getTo().apply(this);
        }
        if(node.getThrough() != null)
        {
            node.getThrough().apply(this);
        }
        if(node.getFrom() != null)
        {
            node.getFrom().apply(this);
        }
        if(node.getComma() != null)
        {
            node.getComma().apply(this);
        }
        if(node.getLiteralSequence() != null)
        {
            node.getLiteralSequence().apply(this);
        }
        outAThroughSequenceLiteralSequence(node);
    }

    public void inAZerosLiteral(AZerosLiteral node)
    {
        defaultIn(node);
    }

    public void outAZerosLiteral(AZerosLiteral node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAZerosLiteral(AZerosLiteral node)
    {
        inAZerosLiteral(node);
        if(node.getZeros() != null)
        {
            node.getZeros().apply(this);
        }
        outAZerosLiteral(node);
    }

    public void inASpacesLiteral(ASpacesLiteral node)
    {
        defaultIn(node);
    }

    public void outASpacesLiteral(ASpacesLiteral node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASpacesLiteral(ASpacesLiteral node)
    {
        inASpacesLiteral(node);
        if(node.getSpaces() != null)
        {
            node.getSpaces().apply(this);
        }
        outASpacesLiteral(node);
    }

    public void inAHighValuesLiteral(AHighValuesLiteral node)
    {
        defaultIn(node);
    }

    public void outAHighValuesLiteral(AHighValuesLiteral node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAHighValuesLiteral(AHighValuesLiteral node)
    {
        inAHighValuesLiteral(node);
        if(node.getHighValues() != null)
        {
            node.getHighValues().apply(this);
        }
        outAHighValuesLiteral(node);
    }

    public void inALowValuesLiteral(ALowValuesLiteral node)
    {
        defaultIn(node);
    }

    public void outALowValuesLiteral(ALowValuesLiteral node)
    {
        defaultOut(node);
    }

    @Override
    public void caseALowValuesLiteral(ALowValuesLiteral node)
    {
        inALowValuesLiteral(node);
        if(node.getLowValues() != null)
        {
            node.getLowValues().apply(this);
        }
        outALowValuesLiteral(node);
    }

    public void inAQuotesLiteral(AQuotesLiteral node)
    {
        defaultIn(node);
    }

    public void outAQuotesLiteral(AQuotesLiteral node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAQuotesLiteral(AQuotesLiteral node)
    {
        inAQuotesLiteral(node);
        if(node.getQuotes() != null)
        {
            node.getQuotes().apply(this);
        }
        outAQuotesLiteral(node);
    }

    public void inANullsLiteral(ANullsLiteral node)
    {
        defaultIn(node);
    }

    public void outANullsLiteral(ANullsLiteral node)
    {
        defaultOut(node);
    }

    @Override
    public void caseANullsLiteral(ANullsLiteral node)
    {
        inANullsLiteral(node);
        if(node.getNulls() != null)
        {
            node.getNulls().apply(this);
        }
        outANullsLiteral(node);
    }

    public void inANumberLiteral(ANumberLiteral node)
    {
        defaultIn(node);
    }

    public void outANumberLiteral(ANumberLiteral node)
    {
        defaultOut(node);
    }

    @Override
    public void caseANumberLiteral(ANumberLiteral node)
    {
        inANumberLiteral(node);
        if(node.getNumber() != null)
        {
            node.getNumber().apply(this);
        }
        outANumberLiteral(node);
    }

    public void inANumericLiteralLiteral(ANumericLiteralLiteral node)
    {
        defaultIn(node);
    }

    public void outANumericLiteralLiteral(ANumericLiteralLiteral node)
    {
        defaultOut(node);
    }

    @Override
    public void caseANumericLiteralLiteral(ANumericLiteralLiteral node)
    {
        inANumericLiteralLiteral(node);
        if(node.getNumericLiteral() != null)
        {
            node.getNumericLiteral().apply(this);
        }
        outANumericLiteralLiteral(node);
    }

    public void inAAlphanumericLiteralLiteral(AAlphanumericLiteralLiteral node)
    {
        defaultIn(node);
    }

    public void outAAlphanumericLiteralLiteral(AAlphanumericLiteralLiteral node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAAlphanumericLiteralLiteral(AAlphanumericLiteralLiteral node)
    {
        inAAlphanumericLiteralLiteral(node);
        if(node.getAlphanumericLiteral() != null)
        {
            node.getAlphanumericLiteral().apply(this);
        }
        outAAlphanumericLiteralLiteral(node);
    }

    public void inASingleCharacterString(ASingleCharacterString node)
    {
        defaultIn(node);
    }

    public void outASingleCharacterString(ASingleCharacterString node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASingleCharacterString(ASingleCharacterString node)
    {
        inASingleCharacterString(node);
        if(node.getCharacterSubstring() != null)
        {
            node.getCharacterSubstring().apply(this);
        }
        outASingleCharacterString(node);
    }

    public void inASequenceCharacterString(ASequenceCharacterString node)
    {
        defaultIn(node);
    }

    public void outASequenceCharacterString(ASequenceCharacterString node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASequenceCharacterString(ASequenceCharacterString node)
    {
        inASequenceCharacterString(node);
        if(node.getCharacterSubstring() != null)
        {
            node.getCharacterSubstring().apply(this);
        }
        if(node.getCharacterString() != null)
        {
            node.getCharacterString().apply(this);
        }
        outASequenceCharacterString(node);
    }

    public void inADataNameCharacterSubstring(ADataNameCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outADataNameCharacterSubstring(ADataNameCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseADataNameCharacterSubstring(ADataNameCharacterSubstring node)
    {
        inADataNameCharacterSubstring(node);
        if(node.getDataName() != null)
        {
            node.getDataName().apply(this);
        }
        outADataNameCharacterSubstring(node);
    }

    public void inAPlusCharacterSubstring(APlusCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outAPlusCharacterSubstring(APlusCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAPlusCharacterSubstring(APlusCharacterSubstring node)
    {
        inAPlusCharacterSubstring(node);
        if(node.getPlus() != null)
        {
            node.getPlus().apply(this);
        }
        outAPlusCharacterSubstring(node);
    }

    public void inAMinusCharacterSubstring(AMinusCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outAMinusCharacterSubstring(AMinusCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAMinusCharacterSubstring(AMinusCharacterSubstring node)
    {
        inAMinusCharacterSubstring(node);
        if(node.getMinus() != null)
        {
            node.getMinus().apply(this);
        }
        outAMinusCharacterSubstring(node);
    }

    public void inAStarCharacterSubstring(AStarCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outAStarCharacterSubstring(AStarCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseAStarCharacterSubstring(AStarCharacterSubstring node)
    {
        inAStarCharacterSubstring(node);
        if(node.getStar() != null)
        {
            node.getStar().apply(this);
        }
        outAStarCharacterSubstring(node);
    }

    public void inASlashCharacterSubstring(ASlashCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outASlashCharacterSubstring(ASlashCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseASlashCharacterSubstring(ASlashCharacterSubstring node)
    {
        inASlashCharacterSubstring(node);
        if(node.getSlash() != null)
        {
            node.getSlash().apply(this);
        }
        outASlashCharacterSubstring(node);
    }

    public void inADollarCharacterSubstring(ADollarCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outADollarCharacterSubstring(ADollarCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseADollarCharacterSubstring(ADollarCharacterSubstring node)
    {
        inADollarCharacterSubstring(node);
        if(node.getDollar() != null)
        {
            node.getDollar().apply(this);
        }
        outADollarCharacterSubstring(node);
    }

    public void inACommaCharacterSubstring(ACommaCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outACommaCharacterSubstring(ACommaCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseACommaCharacterSubstring(ACommaCharacterSubstring node)
    {
        inACommaCharacterSubstring(node);
        if(node.getComma() != null)
        {
            node.getComma().apply(this);
        }
        outACommaCharacterSubstring(node);
    }

    public void inANumberCharacterSubstring(ANumberCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outANumberCharacterSubstring(ANumberCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseANumberCharacterSubstring(ANumberCharacterSubstring node)
    {
        inANumberCharacterSubstring(node);
        if(node.getNumberNot88() != null)
        {
            node.getNumberNot88().apply(this);
        }
        outANumberCharacterSubstring(node);
    }

    public void inANumericLiteralCharacterSubstring(ANumericLiteralCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outANumericLiteralCharacterSubstring(ANumericLiteralCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseANumericLiteralCharacterSubstring(ANumericLiteralCharacterSubstring node)
    {
        inANumericLiteralCharacterSubstring(node);
        if(node.getNumericLiteral() != null)
        {
            node.getNumericLiteral().apply(this);
        }
        outANumericLiteralCharacterSubstring(node);
    }

    public void inABracketedNumberCharacterSubstring(ABracketedNumberCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outABracketedNumberCharacterSubstring(ABracketedNumberCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseABracketedNumberCharacterSubstring(ABracketedNumberCharacterSubstring node)
    {
        inABracketedNumberCharacterSubstring(node);
        if(node.getBracketedNumber() != null)
        {
            node.getBracketedNumber().apply(this);
        }
        outABracketedNumberCharacterSubstring(node);
    }

    public void inADotMinusCharacterSubstring(ADotMinusCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outADotMinusCharacterSubstring(ADotMinusCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseADotMinusCharacterSubstring(ADotMinusCharacterSubstring node)
    {
        inADotMinusCharacterSubstring(node);
        if(node.getDotMinus() != null)
        {
            node.getDotMinus().apply(this);
        }
        outADotMinusCharacterSubstring(node);
    }

    public void inADotPlusCharacterSubstring(ADotPlusCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outADotPlusCharacterSubstring(ADotPlusCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseADotPlusCharacterSubstring(ADotPlusCharacterSubstring node)
    {
        inADotPlusCharacterSubstring(node);
        if(node.getDotPlus() != null)
        {
            node.getDotPlus().apply(this);
        }
        outADotPlusCharacterSubstring(node);
    }

    public void inADotZeeCharacterSubstring(ADotZeeCharacterSubstring node)
    {
        defaultIn(node);
    }

    public void outADotZeeCharacterSubstring(ADotZeeCharacterSubstring node)
    {
        defaultOut(node);
    }

    @Override
    public void caseADotZeeCharacterSubstring(ADotZeeCharacterSubstring node)
    {
        inADotZeeCharacterSubstring(node);
        if(node.getDotZee() != null)
        {
            node.getDotZee().apply(this);
        }
        outADotZeeCharacterSubstring(node);
    }

    public void inABracketedNumber(ABracketedNumber node)
    {
        defaultIn(node);
    }

    public void outABracketedNumber(ABracketedNumber node)
    {
        defaultOut(node);
    }

    @Override
    public void caseABracketedNumber(ABracketedNumber node)
    {
        inABracketedNumber(node);
        if(node.getRparen() != null)
        {
            node.getRparen().apply(this);
        }
        if(node.getNumber() != null)
        {
            node.getNumber().apply(this);
        }
        if(node.getLparen() != null)
        {
            node.getLparen().apply(this);
        }
        outABracketedNumber(node);
    }

    public void inANumberNot88Number(ANumberNot88Number node)
    {
        defaultIn(node);
    }

    public void outANumberNot88Number(ANumberNot88Number node)
    {
        defaultOut(node);
    }

    @Override
    public void caseANumberNot88Number(ANumberNot88Number node)
    {
        inANumberNot88Number(node);
        if(node.getNumberNot88() != null)
        {
            node.getNumberNot88().apply(this);
        }
        outANumberNot88Number(node);
    }

    public void inANumber88Number(ANumber88Number node)
    {
        defaultIn(node);
    }

    public void outANumber88Number(ANumber88Number node)
    {
        defaultOut(node);
    }

    @Override
    public void caseANumber88Number(ANumber88Number node)
    {
        inANumber88Number(node);
        if(node.getNumber88() != null)
        {
            node.getNumber88().apply(this);
        }
        outANumber88Number(node);
    }
}
