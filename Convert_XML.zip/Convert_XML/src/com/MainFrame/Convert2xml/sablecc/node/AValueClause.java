

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AValueClause extends PValueClause
{
    private TValue _value_;
    private TIs _is_;
    private TAll _all_;
    private PLiteral _literal_;

    public AValueClause()
    {
        // Constructor
    }

    public AValueClause(
        @SuppressWarnings("hiding") TValue _value_,
        @SuppressWarnings("hiding") TIs _is_,
        @SuppressWarnings("hiding") TAll _all_,
        @SuppressWarnings("hiding") PLiteral _literal_)
    {
        // Constructor
        setValue(_value_);

        setIs(_is_);

        setAll(_all_);

        setLiteral(_literal_);

    }

    @Override
    public Object clone()
    {
        return new AValueClause(
            cloneNode(this._value_),
            cloneNode(this._is_),
            cloneNode(this._all_),
            cloneNode(this._literal_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAValueClause(this);
    }

    public TValue getValue()
    {
        return this._value_;
    }

    public void setValue(TValue node)
    {
        if(this._value_ != null)
        {
            this._value_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._value_ = node;
    }

    public TIs getIs()
    {
        return this._is_;
    }

    public void setIs(TIs node)
    {
        if(this._is_ != null)
        {
            this._is_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._is_ = node;
    }

    public TAll getAll()
    {
        return this._all_;
    }

    public void setAll(TAll node)
    {
        if(this._all_ != null)
        {
            this._all_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._all_ = node;
    }

    public PLiteral getLiteral()
    {
        return this._literal_;
    }

    public void setLiteral(PLiteral node)
    {
        if(this._literal_ != null)
        {
            this._literal_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._literal_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._value_)
            + toString(this._is_)
            + toString(this._all_)
            + toString(this._literal_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._value_ == child)
        {
            this._value_ = null;
            return;
        }

        if(this._is_ == child)
        {
            this._is_ = null;
            return;
        }

        if(this._all_ == child)
        {
            this._all_ = null;
            return;
        }

        if(this._literal_ == child)
        {
            this._literal_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._value_ == oldChild)
        {
            setValue((TValue) newChild);
            return;
        }

        if(this._is_ == oldChild)
        {
            setIs((TIs) newChild);
            return;
        }

        if(this._all_ == oldChild)
        {
            setAll((TAll) newChild);
            return;
        }

        if(this._literal_ == oldChild)
        {
            setLiteral((PLiteral) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
