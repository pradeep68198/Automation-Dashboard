

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AUsageClauseClause extends PClause
{
    private PUsageClause _usageClause_;

    public AUsageClauseClause()
    {
        // Constructor
    }

    public AUsageClauseClause(
        @SuppressWarnings("hiding") PUsageClause _usageClause_)
    {
        // Constructor
        setUsageClause(_usageClause_);

    }

    @Override
    public Object clone()
    {
        return new AUsageClauseClause(
            cloneNode(this._usageClause_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAUsageClauseClause(this);
    }

    public PUsageClause getUsageClause()
    {
        return this._usageClause_;
    }

    public void setUsageClause(PUsageClause node)
    {
        if(this._usageClause_ != null)
        {
            this._usageClause_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._usageClause_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._usageClause_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._usageClause_ == child)
        {
            this._usageClause_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._usageClause_ == oldChild)
        {
            setUsageClause((PUsageClause) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
