

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AJustifiedClause extends PJustifiedClause
{
    private TJustified _justified_;
    private TRight _right_;

    public AJustifiedClause()
    {
        // Constructor
    }

    public AJustifiedClause(
        @SuppressWarnings("hiding") TJustified _justified_,
        @SuppressWarnings("hiding") TRight _right_)
    {
        // Constructor
        setJustified(_justified_);

        setRight(_right_);

    }

    @Override
    public Object clone()
    {
        return new AJustifiedClause(
            cloneNode(this._justified_),
            cloneNode(this._right_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAJustifiedClause(this);
    }

    public TJustified getJustified()
    {
        return this._justified_;
    }

    public void setJustified(TJustified node)
    {
        if(this._justified_ != null)
        {
            this._justified_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._justified_ = node;
    }

    public TRight getRight()
    {
        return this._right_;
    }

    public void setRight(TRight node)
    {
        if(this._right_ != null)
        {
            this._right_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._right_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._justified_)
            + toString(this._right_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._justified_ == child)
        {
            this._justified_ = null;
            return;
        }

        if(this._right_ == child)
        {
            this._right_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._justified_ == oldChild)
        {
            setJustified((TJustified) newChild);
            return;
        }

        if(this._right_ == oldChild)
        {
            setRight((TRight) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
