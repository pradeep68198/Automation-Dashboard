

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ASingleClauseSequence extends PClauseSequence
{
    private PClause _clause_;

    public ASingleClauseSequence()
    {
        // Constructor
    }

    public ASingleClauseSequence(
        @SuppressWarnings("hiding") PClause _clause_)
    {
        // Constructor
        setClause(_clause_);

    }

    @Override
    public Object clone()
    {
        return new ASingleClauseSequence(
            cloneNode(this._clause_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseASingleClauseSequence(this);
    }

    public PClause getClause()
    {
        return this._clause_;
    }

    public void setClause(PClause node)
    {
        if(this._clause_ != null)
        {
            this._clause_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._clause_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._clause_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._clause_ == child)
        {
            this._clause_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._clause_ == oldChild)
        {
            setClause((PClause) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
