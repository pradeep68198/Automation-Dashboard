

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AHighValuesLiteral extends PLiteral
{
    private THighValues _highValues_;

    public AHighValuesLiteral()
    {
        // Constructor
    }

    public AHighValuesLiteral(
        @SuppressWarnings("hiding") THighValues _highValues_)
    {
        // Constructor
        setHighValues(_highValues_);

    }

    @Override
    public Object clone()
    {
        return new AHighValuesLiteral(
            cloneNode(this._highValues_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAHighValuesLiteral(this);
    }

    public THighValues getHighValues()
    {
        return this._highValues_;
    }

    public void setHighValues(THighValues node)
    {
        if(this._highValues_ != null)
        {
            this._highValues_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._highValues_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._highValues_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._highValues_ == child)
        {
            this._highValues_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._highValues_ == oldChild)
        {
            setHighValues((THighValues) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
