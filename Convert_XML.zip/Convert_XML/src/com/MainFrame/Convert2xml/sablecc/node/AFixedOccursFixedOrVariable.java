

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AFixedOccursFixedOrVariable extends POccursFixedOrVariable
{
    private TOccurs _occurs_;
    private PNumber _number_;
    private TTimes _times_;

    public AFixedOccursFixedOrVariable()
    {
        // Constructor
    }

    public AFixedOccursFixedOrVariable(
        @SuppressWarnings("hiding") TOccurs _occurs_,
        @SuppressWarnings("hiding") PNumber _number_,
        @SuppressWarnings("hiding") TTimes _times_)
    {
        // Constructor
        setOccurs(_occurs_);

        setNumber(_number_);

        setTimes(_times_);

    }

    @Override
    public Object clone()
    {
        return new AFixedOccursFixedOrVariable(
            cloneNode(this._occurs_),
            cloneNode(this._number_),
            cloneNode(this._times_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAFixedOccursFixedOrVariable(this);
    }

    public TOccurs getOccurs()
    {
        return this._occurs_;
    }

    public void setOccurs(TOccurs node)
    {
        if(this._occurs_ != null)
        {
            this._occurs_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._occurs_ = node;
    }

    public PNumber getNumber()
    {
        return this._number_;
    }

    public void setNumber(PNumber node)
    {
        if(this._number_ != null)
        {
            this._number_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._number_ = node;
    }

    public TTimes getTimes()
    {
        return this._times_;
    }

    public void setTimes(TTimes node)
    {
        if(this._times_ != null)
        {
            this._times_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._times_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._occurs_)
            + toString(this._number_)
            + toString(this._times_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._occurs_ == child)
        {
            this._occurs_ = null;
            return;
        }

        if(this._number_ == child)
        {
            this._number_ = null;
            return;
        }

        if(this._times_ == child)
        {
            this._times_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._occurs_ == oldChild)
        {
            setOccurs((TOccurs) newChild);
            return;
        }

        if(this._number_ == oldChild)
        {
            setNumber((PNumber) newChild);
            return;
        }

        if(this._times_ == oldChild)
        {
            setTimes((TTimes) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
