

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AComp6UsagePhrase extends PUsagePhrase
{
    private TComp6 _comp6_;

    public AComp6UsagePhrase()
    {
        // Constructor
    }

    public AComp6UsagePhrase(
        @SuppressWarnings("hiding") TComp6 _comp6_)
    {
        // Constructor
        setComp6(_comp6_);

    }

    @Override
    public Object clone()
    {
        return new AComp6UsagePhrase(
            cloneNode(this._comp6_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAComp6UsagePhrase(this);
    }

    public TComp6 getComp6()
    {
        return this._comp6_;
    }

    public void setComp6(TComp6 node)
    {
        if(this._comp6_ != null)
        {
            this._comp6_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._comp6_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._comp6_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._comp6_ == child)
        {
            this._comp6_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._comp6_ == oldChild)
        {
            setComp6((TComp6) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
