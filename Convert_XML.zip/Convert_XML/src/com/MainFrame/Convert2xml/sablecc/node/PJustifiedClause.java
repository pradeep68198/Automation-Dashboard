

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PJustifiedClause extends Node
{
    // Empty body
}
