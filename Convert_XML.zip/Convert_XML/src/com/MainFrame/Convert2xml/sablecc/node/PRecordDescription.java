

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PRecordDescription extends Node
{
    // Empty body
}
