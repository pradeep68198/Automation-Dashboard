

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PRenamesItem extends Node
{
    // Empty body
}
