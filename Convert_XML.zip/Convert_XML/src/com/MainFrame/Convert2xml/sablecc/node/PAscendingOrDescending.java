

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PAscendingOrDescending extends Node
{
    // Empty body
}
