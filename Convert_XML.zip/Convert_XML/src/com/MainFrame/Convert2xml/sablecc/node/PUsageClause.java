

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PUsageClause extends Node
{
    // Empty body
}
