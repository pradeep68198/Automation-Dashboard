

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ASlashCharacterSubstring extends PCharacterSubstring
{
    private TSlash _slash_;

    public ASlashCharacterSubstring()
    {
        // Constructor
    }

    public ASlashCharacterSubstring(
        @SuppressWarnings("hiding") TSlash _slash_)
    {
        // Constructor
        setSlash(_slash_);

    }

    @Override
    public Object clone()
    {
        return new ASlashCharacterSubstring(
            cloneNode(this._slash_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseASlashCharacterSubstring(this);
    }

    public TSlash getSlash()
    {
        return this._slash_;
    }

    public void setSlash(TSlash node)
    {
        if(this._slash_ != null)
        {
            this._slash_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._slash_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._slash_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._slash_ == child)
        {
            this._slash_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._slash_ == oldChild)
        {
            setSlash((TSlash) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
