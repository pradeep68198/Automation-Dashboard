

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PThroughPhrase extends Node
{
    // Empty body
}
