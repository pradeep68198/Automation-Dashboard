

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AValuesValueOrValues extends PValueOrValues
{
    private TValues _values_;
    private TAre _are_;

    public AValuesValueOrValues()
    {
        // Constructor
    }

    public AValuesValueOrValues(
        @SuppressWarnings("hiding") TValues _values_,
        @SuppressWarnings("hiding") TAre _are_)
    {
        // Constructor
        setValues(_values_);

        setAre(_are_);

    }

    @Override
    public Object clone()
    {
        return new AValuesValueOrValues(
            cloneNode(this._values_),
            cloneNode(this._are_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAValuesValueOrValues(this);
    }

    public TValues getValues()
    {
        return this._values_;
    }

    public void setValues(TValues node)
    {
        if(this._values_ != null)
        {
            this._values_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._values_ = node;
    }

    public TAre getAre()
    {
        return this._are_;
    }

    public void setAre(TAre node)
    {
        if(this._are_ != null)
        {
            this._are_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._are_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._values_)
            + toString(this._are_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._values_ == child)
        {
            this._values_ = null;
            return;
        }

        if(this._are_ == child)
        {
            this._are_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._values_ == oldChild)
        {
            setValues((TValues) newChild);
            return;
        }

        if(this._are_ == oldChild)
        {
            setAre((TAre) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
