

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PSignIs extends Node
{
    // Empty body
}
