

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PIndexedByPhrase extends Node
{
    // Empty body
}
