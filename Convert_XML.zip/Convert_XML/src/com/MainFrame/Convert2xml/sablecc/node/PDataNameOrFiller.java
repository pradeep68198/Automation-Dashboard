

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PDataNameOrFiller extends Node
{
    // Empty body
}
