

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class POccursTo extends Node
{
    // Empty body
}
