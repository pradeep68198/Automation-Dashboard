

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ALowValuesLiteral extends PLiteral
{
    private TLowValues _lowValues_;

    public ALowValuesLiteral()
    {
        // Constructor
    }

    public ALowValuesLiteral(
        @SuppressWarnings("hiding") TLowValues _lowValues_)
    {
        // Constructor
        setLowValues(_lowValues_);

    }

    @Override
    public Object clone()
    {
        return new ALowValuesLiteral(
            cloneNode(this._lowValues_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseALowValuesLiteral(this);
    }

    public TLowValues getLowValues()
    {
        return this._lowValues_;
    }

    public void setLowValues(TLowValues node)
    {
        if(this._lowValues_ != null)
        {
            this._lowValues_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._lowValues_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._lowValues_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._lowValues_ == child)
        {
            this._lowValues_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._lowValues_ == oldChild)
        {
            setLowValues((TLowValues) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
