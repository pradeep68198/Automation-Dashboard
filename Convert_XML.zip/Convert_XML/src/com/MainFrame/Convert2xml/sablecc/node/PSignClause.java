

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PSignClause extends Node
{
    // Empty body
}
