

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PDateFormatClause extends Node
{
    // Empty body
}
