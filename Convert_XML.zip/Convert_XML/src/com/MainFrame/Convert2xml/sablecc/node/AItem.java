

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AItem extends PItem
{
    private TNumberNot88 _numberNot88_;
    private PDataNameOrFiller _dataNameOrFiller_;
    private PRedefinesClause _redefinesClause_;
    private PClauseSequence _clauseSequence_;

    public AItem()
    {
        // Constructor
    }

    public AItem(
        @SuppressWarnings("hiding") TNumberNot88 _numberNot88_,
        @SuppressWarnings("hiding") PDataNameOrFiller _dataNameOrFiller_,
        @SuppressWarnings("hiding") PRedefinesClause _redefinesClause_,
        @SuppressWarnings("hiding") PClauseSequence _clauseSequence_)
    {
        // Constructor
        setNumberNot88(_numberNot88_);

        setDataNameOrFiller(_dataNameOrFiller_);

        setRedefinesClause(_redefinesClause_);

        setClauseSequence(_clauseSequence_);

    }

    @Override
    public Object clone()
    {
        return new AItem(
            cloneNode(this._numberNot88_),
            cloneNode(this._dataNameOrFiller_),
            cloneNode(this._redefinesClause_),
            cloneNode(this._clauseSequence_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAItem(this);
    }

    public TNumberNot88 getNumberNot88()
    {
        return this._numberNot88_;
    }

    public void setNumberNot88(TNumberNot88 node)
    {
        if(this._numberNot88_ != null)
        {
            this._numberNot88_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._numberNot88_ = node;
    }

    public PDataNameOrFiller getDataNameOrFiller()
    {
        return this._dataNameOrFiller_;
    }

    public void setDataNameOrFiller(PDataNameOrFiller node)
    {
        if(this._dataNameOrFiller_ != null)
        {
            this._dataNameOrFiller_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._dataNameOrFiller_ = node;
    }

    public PRedefinesClause getRedefinesClause()
    {
        return this._redefinesClause_;
    }

    public void setRedefinesClause(PRedefinesClause node)
    {
        if(this._redefinesClause_ != null)
        {
            this._redefinesClause_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._redefinesClause_ = node;
    }

    public PClauseSequence getClauseSequence()
    {
        return this._clauseSequence_;
    }

    public void setClauseSequence(PClauseSequence node)
    {
        if(this._clauseSequence_ != null)
        {
            this._clauseSequence_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._clauseSequence_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._numberNot88_)
            + toString(this._dataNameOrFiller_)
            + toString(this._redefinesClause_)
            + toString(this._clauseSequence_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._numberNot88_ == child)
        {
            this._numberNot88_ = null;
            return;
        }

        if(this._dataNameOrFiller_ == child)
        {
            this._dataNameOrFiller_ = null;
            return;
        }

        if(this._redefinesClause_ == child)
        {
            this._redefinesClause_ = null;
            return;
        }

        if(this._clauseSequence_ == child)
        {
            this._clauseSequence_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._numberNot88_ == oldChild)
        {
            setNumberNot88((TNumberNot88) newChild);
            return;
        }

        if(this._dataNameOrFiller_ == oldChild)
        {
            setDataNameOrFiller((PDataNameOrFiller) newChild);
            return;
        }

        if(this._redefinesClause_ == oldChild)
        {
            setRedefinesClause((PRedefinesClause) newChild);
            return;
        }

        if(this._clauseSequence_ == oldChild)
        {
            setClauseSequence((PClauseSequence) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
