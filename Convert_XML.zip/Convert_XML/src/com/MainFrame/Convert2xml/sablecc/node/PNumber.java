

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PNumber extends Node
{
    // Empty body
}
