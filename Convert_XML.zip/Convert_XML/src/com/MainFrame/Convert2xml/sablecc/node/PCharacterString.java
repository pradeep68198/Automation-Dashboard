

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PCharacterString extends Node
{
    // Empty body
}
