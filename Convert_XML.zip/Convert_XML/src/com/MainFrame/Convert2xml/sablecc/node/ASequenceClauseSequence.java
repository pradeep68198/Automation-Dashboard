

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ASequenceClauseSequence extends PClauseSequence
{
    private PClauseSequence _clauseSequence_;
    private PClause _clause_;

    public ASequenceClauseSequence()
    {
        // Constructor
    }

    public ASequenceClauseSequence(
        @SuppressWarnings("hiding") PClauseSequence _clauseSequence_,
        @SuppressWarnings("hiding") PClause _clause_)
    {
        // Constructor
        setClauseSequence(_clauseSequence_);

        setClause(_clause_);

    }

    @Override
    public Object clone()
    {
        return new ASequenceClauseSequence(
            cloneNode(this._clauseSequence_),
            cloneNode(this._clause_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseASequenceClauseSequence(this);
    }

    public PClauseSequence getClauseSequence()
    {
        return this._clauseSequence_;
    }

    public void setClauseSequence(PClauseSequence node)
    {
        if(this._clauseSequence_ != null)
        {
            this._clauseSequence_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._clauseSequence_ = node;
    }

    public PClause getClause()
    {
        return this._clause_;
    }

    public void setClause(PClause node)
    {
        if(this._clause_ != null)
        {
            this._clause_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._clause_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._clauseSequence_)
            + toString(this._clause_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._clauseSequence_ == child)
        {
            this._clauseSequence_ = null;
            return;
        }

        if(this._clause_ == child)
        {
            this._clause_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._clauseSequence_ == oldChild)
        {
            setClauseSequence((PClauseSequence) newChild);
            return;
        }

        if(this._clause_ == oldChild)
        {
            setClause((PClause) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
