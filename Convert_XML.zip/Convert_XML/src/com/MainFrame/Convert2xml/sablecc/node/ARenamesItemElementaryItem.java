

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ARenamesItemElementaryItem extends PElementaryItem
{
    private PRenamesItem _renamesItem_;

    public ARenamesItemElementaryItem()
    {
        // Constructor
    }

    public ARenamesItemElementaryItem(
        @SuppressWarnings("hiding") PRenamesItem _renamesItem_)
    {
        // Constructor
        setRenamesItem(_renamesItem_);

    }

    @Override
    public Object clone()
    {
        return new ARenamesItemElementaryItem(
            cloneNode(this._renamesItem_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseARenamesItemElementaryItem(this);
    }

    public PRenamesItem getRenamesItem()
    {
        return this._renamesItem_;
    }

    public void setRenamesItem(PRenamesItem node)
    {
        if(this._renamesItem_ != null)
        {
            this._renamesItem_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._renamesItem_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._renamesItem_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._renamesItem_ == child)
        {
            this._renamesItem_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._renamesItem_ == oldChild)
        {
            setRenamesItem((PRenamesItem) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
