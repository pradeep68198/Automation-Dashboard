

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AObjectReferencePhraseUsagePhrase extends PUsagePhrase
{
    private PObjectReferencePhrase _objectReferencePhrase_;

    public AObjectReferencePhraseUsagePhrase()
    {
        // Constructor
    }

    public AObjectReferencePhraseUsagePhrase(
        @SuppressWarnings("hiding") PObjectReferencePhrase _objectReferencePhrase_)
    {
        // Constructor
        setObjectReferencePhrase(_objectReferencePhrase_);

    }

    @Override
    public Object clone()
    {
        return new AObjectReferencePhraseUsagePhrase(
            cloneNode(this._objectReferencePhrase_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAObjectReferencePhraseUsagePhrase(this);
    }

    public PObjectReferencePhrase getObjectReferencePhrase()
    {
        return this._objectReferencePhrase_;
    }

    public void setObjectReferencePhrase(PObjectReferencePhrase node)
    {
        if(this._objectReferencePhrase_ != null)
        {
            this._objectReferencePhrase_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._objectReferencePhrase_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._objectReferencePhrase_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._objectReferencePhrase_ == child)
        {
            this._objectReferencePhrase_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._objectReferencePhrase_ == oldChild)
        {
            setObjectReferencePhrase((PObjectReferencePhrase) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
