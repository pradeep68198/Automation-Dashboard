

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AComp2UsagePhrase extends PUsagePhrase
{
    private TComp2 _comp2_;
    private TNative _native_;

    public AComp2UsagePhrase()
    {
        // Constructor
    }

    public AComp2UsagePhrase(
        @SuppressWarnings("hiding") TComp2 _comp2_,
        @SuppressWarnings("hiding") TNative _native_)
    {
        // Constructor
        setComp2(_comp2_);

        setNative(_native_);

    }

    @Override
    public Object clone()
    {
        return new AComp2UsagePhrase(
            cloneNode(this._comp2_),
            cloneNode(this._native_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAComp2UsagePhrase(this);
    }

    public TComp2 getComp2()
    {
        return this._comp2_;
    }

    public void setComp2(TComp2 node)
    {
        if(this._comp2_ != null)
        {
            this._comp2_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._comp2_ = node;
    }

    public TNative getNative()
    {
        return this._native_;
    }

    public void setNative(TNative node)
    {
        if(this._native_ != null)
        {
            this._native_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._native_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._comp2_)
            + toString(this._native_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._comp2_ == child)
        {
            this._comp2_ = null;
            return;
        }

        if(this._native_ == child)
        {
            this._native_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._comp2_ == oldChild)
        {
            setComp2((TComp2) newChild);
            return;
        }

        if(this._native_ == oldChild)
        {
            setNative((TNative) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
