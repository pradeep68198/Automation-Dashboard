

package com.MainFrame.Convert2xml.sablecc.node;

public interface Switchable
{
    void apply(Switch sw);
}
