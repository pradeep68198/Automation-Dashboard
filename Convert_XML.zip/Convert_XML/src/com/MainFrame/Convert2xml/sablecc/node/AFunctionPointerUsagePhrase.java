

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AFunctionPointerUsagePhrase extends PUsagePhrase
{
    private TFunctionPointer _functionPointer_;

    public AFunctionPointerUsagePhrase()
    {
        // Constructor
    }

    public AFunctionPointerUsagePhrase(
        @SuppressWarnings("hiding") TFunctionPointer _functionPointer_)
    {
        // Constructor
        setFunctionPointer(_functionPointer_);

    }

    @Override
    public Object clone()
    {
        return new AFunctionPointerUsagePhrase(
            cloneNode(this._functionPointer_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAFunctionPointerUsagePhrase(this);
    }

    public TFunctionPointer getFunctionPointer()
    {
        return this._functionPointer_;
    }

    public void setFunctionPointer(TFunctionPointer node)
    {
        if(this._functionPointer_ != null)
        {
            this._functionPointer_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._functionPointer_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._functionPointer_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._functionPointer_ == child)
        {
            this._functionPointer_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._functionPointer_ == oldChild)
        {
            setFunctionPointer((TFunctionPointer) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
