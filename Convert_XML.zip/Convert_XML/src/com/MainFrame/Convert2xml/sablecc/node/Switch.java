

package com.MainFrame.Convert2xml.sablecc.node;

public interface Switch
{
        // Empty body
}
