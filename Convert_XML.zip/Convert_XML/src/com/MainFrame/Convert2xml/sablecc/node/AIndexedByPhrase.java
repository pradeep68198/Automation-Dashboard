

package com.MainFrame.Convert2xml.sablecc.node;

import java.util.*;
import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AIndexedByPhrase extends PIndexedByPhrase
{
    private TIndexed _indexed_;
    private TBy _by_;
    private final LinkedList<TDataName> _dataName_ = new LinkedList<TDataName>();

    public AIndexedByPhrase()
    {
        // Constructor
    }

    public AIndexedByPhrase(
        @SuppressWarnings("hiding") TIndexed _indexed_,
        @SuppressWarnings("hiding") TBy _by_,
        @SuppressWarnings("hiding") List<?> _dataName_)
    {
        // Constructor
        setIndexed(_indexed_);

        setBy(_by_);

        setDataName(_dataName_);

    }

    @Override
    public Object clone()
    {
        return new AIndexedByPhrase(
            cloneNode(this._indexed_),
            cloneNode(this._by_),
            cloneList(this._dataName_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAIndexedByPhrase(this);
    }

    public TIndexed getIndexed()
    {
        return this._indexed_;
    }

    public void setIndexed(TIndexed node)
    {
        if(this._indexed_ != null)
        {
            this._indexed_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._indexed_ = node;
    }

    public TBy getBy()
    {
        return this._by_;
    }

    public void setBy(TBy node)
    {
        if(this._by_ != null)
        {
            this._by_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._by_ = node;
    }

    public LinkedList<TDataName> getDataName()
    {
        return this._dataName_;
    }

    public void setDataName(List<?> list)
    {
        for(TDataName e : this._dataName_)
        {
            e.parent(null);
        }
        this._dataName_.clear();

        for(Object obj_e : list)
        {
            TDataName e = (TDataName) obj_e;
            if(e.parent() != null)
            {
                e.parent().removeChild(e);
            }

            e.parent(this);
            this._dataName_.add(e);
        }
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._indexed_)
            + toString(this._by_)
            + toString(this._dataName_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._indexed_ == child)
        {
            this._indexed_ = null;
            return;
        }

        if(this._by_ == child)
        {
            this._by_ = null;
            return;
        }

        if(this._dataName_.remove(child))
        {
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._indexed_ == oldChild)
        {
            setIndexed((TIndexed) newChild);
            return;
        }

        if(this._by_ == oldChild)
        {
            setBy((TBy) newChild);
            return;
        }

        for(ListIterator<TDataName> i = this._dataName_.listIterator(); i.hasNext();)
        {
            if(i.next() == oldChild)
            {
                if(newChild != null)
                {
                    i.set((TDataName) newChild);
                    newChild.parent(this);
                    oldChild.parent(null);
                    return;
                }

                i.remove();
                oldChild.parent(null);
                return;
            }
        }

        throw new RuntimeException("Not a child.");
    }
}
