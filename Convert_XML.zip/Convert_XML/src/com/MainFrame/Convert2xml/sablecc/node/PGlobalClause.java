

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PGlobalClause extends Node
{
    // Empty body
}
