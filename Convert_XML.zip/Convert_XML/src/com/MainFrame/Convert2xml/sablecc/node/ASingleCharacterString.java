

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ASingleCharacterString extends PCharacterString
{
    private PCharacterSubstring _characterSubstring_;

    public ASingleCharacterString()
    {
        // Constructor
    }

    public ASingleCharacterString(
        @SuppressWarnings("hiding") PCharacterSubstring _characterSubstring_)
    {
        // Constructor
        setCharacterSubstring(_characterSubstring_);

    }

    @Override
    public Object clone()
    {
        return new ASingleCharacterString(
            cloneNode(this._characterSubstring_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseASingleCharacterString(this);
    }

    public PCharacterSubstring getCharacterSubstring()
    {
        return this._characterSubstring_;
    }

    public void setCharacterSubstring(PCharacterSubstring node)
    {
        if(this._characterSubstring_ != null)
        {
            this._characterSubstring_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._characterSubstring_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._characterSubstring_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._characterSubstring_ == child)
        {
            this._characterSubstring_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._characterSubstring_ == oldChild)
        {
            setCharacterSubstring((PCharacterSubstring) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
