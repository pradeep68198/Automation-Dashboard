

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ALeftLeftOrRight extends PLeftOrRight
{
    private TLeft _left_;

    public ALeftLeftOrRight()
    {
        // Constructor
    }

    public ALeftLeftOrRight(
        @SuppressWarnings("hiding") TLeft _left_)
    {
        // Constructor
        setLeft(_left_);

    }

    @Override
    public Object clone()
    {
        return new ALeftLeftOrRight(
            cloneNode(this._left_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseALeftLeftOrRight(this);
    }

    public TLeft getLeft()
    {
        return this._left_;
    }

    public void setLeft(TLeft node)
    {
        if(this._left_ != null)
        {
            this._left_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._left_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._left_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._left_ == child)
        {
            this._left_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._left_ == oldChild)
        {
            setLeft((TLeft) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
