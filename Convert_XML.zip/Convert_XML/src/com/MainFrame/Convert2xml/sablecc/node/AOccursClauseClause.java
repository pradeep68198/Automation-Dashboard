

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AOccursClauseClause extends PClause
{
    private POccursClause _occursClause_;

    public AOccursClauseClause()
    {
        // Constructor
    }

    public AOccursClauseClause(
        @SuppressWarnings("hiding") POccursClause _occursClause_)
    {
        // Constructor
        setOccursClause(_occursClause_);

    }

    @Override
    public Object clone()
    {
        return new AOccursClauseClause(
            cloneNode(this._occursClause_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAOccursClauseClause(this);
    }

    public POccursClause getOccursClause()
    {
        return this._occursClause_;
    }

    public void setOccursClause(POccursClause node)
    {
        if(this._occursClause_ != null)
        {
            this._occursClause_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._occursClause_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._occursClause_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._occursClause_ == child)
        {
            this._occursClause_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._occursClause_ == oldChild)
        {
            setOccursClause((POccursClause) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
