

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ADateFormatClause extends PDateFormatClause
{
    private TDate _date_;
    private TFormat _format_;
    private TIs _is_;
    private TDataName _dataName_;

    public ADateFormatClause()
    {
        // Constructor
    }

    public ADateFormatClause(
        @SuppressWarnings("hiding") TDate _date_,
        @SuppressWarnings("hiding") TFormat _format_,
        @SuppressWarnings("hiding") TIs _is_,
        @SuppressWarnings("hiding") TDataName _dataName_)
    {
        // Constructor
        setDate(_date_);

        setFormat(_format_);

        setIs(_is_);

        setDataName(_dataName_);

    }

    @Override
    public Object clone()
    {
        return new ADateFormatClause(
            cloneNode(this._date_),
            cloneNode(this._format_),
            cloneNode(this._is_),
            cloneNode(this._dataName_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseADateFormatClause(this);
    }

    public TDate getDate()
    {
        return this._date_;
    }

    public void setDate(TDate node)
    {
        if(this._date_ != null)
        {
            this._date_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._date_ = node;
    }

    public TFormat getFormat()
    {
        return this._format_;
    }

    public void setFormat(TFormat node)
    {
        if(this._format_ != null)
        {
            this._format_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._format_ = node;
    }

    public TIs getIs()
    {
        return this._is_;
    }

    public void setIs(TIs node)
    {
        if(this._is_ != null)
        {
            this._is_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._is_ = node;
    }

    public TDataName getDataName()
    {
        return this._dataName_;
    }

    public void setDataName(TDataName node)
    {
        if(this._dataName_ != null)
        {
            this._dataName_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._dataName_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._date_)
            + toString(this._format_)
            + toString(this._is_)
            + toString(this._dataName_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._date_ == child)
        {
            this._date_ = null;
            return;
        }

        if(this._format_ == child)
        {
            this._format_ = null;
            return;
        }

        if(this._is_ == child)
        {
            this._is_ = null;
            return;
        }

        if(this._dataName_ == child)
        {
            this._dataName_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._date_ == oldChild)
        {
            setDate((TDate) newChild);
            return;
        }

        if(this._format_ == oldChild)
        {
            setFormat((TFormat) newChild);
            return;
        }

        if(this._is_ == oldChild)
        {
            setIs((TIs) newChild);
            return;
        }

        if(this._dataName_ == oldChild)
        {
            setDataName((TDataName) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
