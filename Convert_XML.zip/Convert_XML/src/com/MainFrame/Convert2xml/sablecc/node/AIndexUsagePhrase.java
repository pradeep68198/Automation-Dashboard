

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AIndexUsagePhrase extends PUsagePhrase
{
    private TIndex _index_;

    public AIndexUsagePhrase()
    {
        // Constructor
    }

    public AIndexUsagePhrase(
        @SuppressWarnings("hiding") TIndex _index_)
    {
        // Constructor
        setIndex(_index_);

    }

    @Override
    public Object clone()
    {
        return new AIndexUsagePhrase(
            cloneNode(this._index_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAIndexUsagePhrase(this);
    }

    public TIndex getIndex()
    {
        return this._index_;
    }

    public void setIndex(TIndex node)
    {
        if(this._index_ != null)
        {
            this._index_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._index_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._index_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._index_ == child)
        {
            this._index_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._index_ == oldChild)
        {
            setIndex((TIndex) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
