

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ASignClause extends PSignClause
{
    private PSignIs _signIs_;
    private PLeadingOrTrailing _leadingOrTrailing_;
    private PSeparateCharacter _separateCharacter_;

    public ASignClause()
    {
        // Constructor
    }

    public ASignClause(
        @SuppressWarnings("hiding") PSignIs _signIs_,
        @SuppressWarnings("hiding") PLeadingOrTrailing _leadingOrTrailing_,
        @SuppressWarnings("hiding") PSeparateCharacter _separateCharacter_)
    {
        // Constructor
        setSignIs(_signIs_);

        setLeadingOrTrailing(_leadingOrTrailing_);

        setSeparateCharacter(_separateCharacter_);

    }

    @Override
    public Object clone()
    {
        return new ASignClause(
            cloneNode(this._signIs_),
            cloneNode(this._leadingOrTrailing_),
            cloneNode(this._separateCharacter_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseASignClause(this);
    }

    public PSignIs getSignIs()
    {
        return this._signIs_;
    }

    public void setSignIs(PSignIs node)
    {
        if(this._signIs_ != null)
        {
            this._signIs_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._signIs_ = node;
    }

    public PLeadingOrTrailing getLeadingOrTrailing()
    {
        return this._leadingOrTrailing_;
    }

    public void setLeadingOrTrailing(PLeadingOrTrailing node)
    {
        if(this._leadingOrTrailing_ != null)
        {
            this._leadingOrTrailing_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._leadingOrTrailing_ = node;
    }

    public PSeparateCharacter getSeparateCharacter()
    {
        return this._separateCharacter_;
    }

    public void setSeparateCharacter(PSeparateCharacter node)
    {
        if(this._separateCharacter_ != null)
        {
            this._separateCharacter_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._separateCharacter_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._signIs_)
            + toString(this._leadingOrTrailing_)
            + toString(this._separateCharacter_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._signIs_ == child)
        {
            this._signIs_ = null;
            return;
        }

        if(this._leadingOrTrailing_ == child)
        {
            this._leadingOrTrailing_ = null;
            return;
        }

        if(this._separateCharacter_ == child)
        {
            this._separateCharacter_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._signIs_ == oldChild)
        {
            setSignIs((PSignIs) newChild);
            return;
        }

        if(this._leadingOrTrailing_ == oldChild)
        {
            setLeadingOrTrailing((PLeadingOrTrailing) newChild);
            return;
        }

        if(this._separateCharacter_ == oldChild)
        {
            setSeparateCharacter((PSeparateCharacter) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
