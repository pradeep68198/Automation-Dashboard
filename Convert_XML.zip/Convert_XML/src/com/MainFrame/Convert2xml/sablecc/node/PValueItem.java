

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PValueItem extends Node
{
    // Empty body
}
