

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ANationalUsagePhrase extends PUsagePhrase
{
    private TNational _national_;

    public ANationalUsagePhrase()
    {
        // Constructor
    }

    public ANationalUsagePhrase(
        @SuppressWarnings("hiding") TNational _national_)
    {
        // Constructor
        setNational(_national_);

    }

    @Override
    public Object clone()
    {
        return new ANationalUsagePhrase(
            cloneNode(this._national_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseANationalUsagePhrase(this);
    }

    public TNational getNational()
    {
        return this._national_;
    }

    public void setNational(TNational node)
    {
        if(this._national_ != null)
        {
            this._national_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._national_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._national_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._national_ == child)
        {
            this._national_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._national_ == oldChild)
        {
            setNational((TNational) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
