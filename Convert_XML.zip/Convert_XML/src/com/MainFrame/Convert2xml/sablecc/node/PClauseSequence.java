

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PClauseSequence extends Node
{
    // Empty body
}
