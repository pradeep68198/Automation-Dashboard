

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AGlobalClauseClause extends PClause
{
    private PGlobalClause _globalClause_;

    public AGlobalClauseClause()
    {
        // Constructor
    }

    public AGlobalClauseClause(
        @SuppressWarnings("hiding") PGlobalClause _globalClause_)
    {
        // Constructor
        setGlobalClause(_globalClause_);

    }

    @Override
    public Object clone()
    {
        return new AGlobalClauseClause(
            cloneNode(this._globalClause_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAGlobalClauseClause(this);
    }

    public PGlobalClause getGlobalClause()
    {
        return this._globalClause_;
    }

    public void setGlobalClause(PGlobalClause node)
    {
        if(this._globalClause_ != null)
        {
            this._globalClause_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._globalClause_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._globalClause_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._globalClause_ == child)
        {
            this._globalClause_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._globalClause_ == oldChild)
        {
            setGlobalClause((PGlobalClause) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
