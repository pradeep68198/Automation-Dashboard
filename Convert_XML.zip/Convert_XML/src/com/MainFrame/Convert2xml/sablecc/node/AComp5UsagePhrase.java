

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AComp5UsagePhrase extends PUsagePhrase
{
    private TComp5 _comp5_;

    public AComp5UsagePhrase()
    {
        // Constructor
    }

    public AComp5UsagePhrase(
        @SuppressWarnings("hiding") TComp5 _comp5_)
    {
        // Constructor
        setComp5(_comp5_);

    }

    @Override
    public Object clone()
    {
        return new AComp5UsagePhrase(
            cloneNode(this._comp5_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAComp5UsagePhrase(this);
    }

    public TComp5 getComp5()
    {
        return this._comp5_;
    }

    public void setComp5(TComp5 node)
    {
        if(this._comp5_ != null)
        {
            this._comp5_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._comp5_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._comp5_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._comp5_ == child)
        {
            this._comp5_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._comp5_ == oldChild)
        {
            setComp5((TComp5) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
