

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PBlankWhenZeroClause extends Node
{
    // Empty body
}
