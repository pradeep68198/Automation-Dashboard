

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ASequenceLiteralSequence extends PLiteralSequence
{
    private PLiteralSequence _literalSequence_;
    private TComma _comma_;
    private PLiteral _literal_;

    public ASequenceLiteralSequence()
    {
        // Constructor
    }

    public ASequenceLiteralSequence(
        @SuppressWarnings("hiding") PLiteralSequence _literalSequence_,
        @SuppressWarnings("hiding") TComma _comma_,
        @SuppressWarnings("hiding") PLiteral _literal_)
    {
        // Constructor
        setLiteralSequence(_literalSequence_);

        setComma(_comma_);

        setLiteral(_literal_);

    }

    @Override
    public Object clone()
    {
        return new ASequenceLiteralSequence(
            cloneNode(this._literalSequence_),
            cloneNode(this._comma_),
            cloneNode(this._literal_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseASequenceLiteralSequence(this);
    }

    public PLiteralSequence getLiteralSequence()
    {
        return this._literalSequence_;
    }

    public void setLiteralSequence(PLiteralSequence node)
    {
        if(this._literalSequence_ != null)
        {
            this._literalSequence_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._literalSequence_ = node;
    }

    public TComma getComma()
    {
        return this._comma_;
    }

    public void setComma(TComma node)
    {
        if(this._comma_ != null)
        {
            this._comma_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._comma_ = node;
    }

    public PLiteral getLiteral()
    {
        return this._literal_;
    }

    public void setLiteral(PLiteral node)
    {
        if(this._literal_ != null)
        {
            this._literal_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._literal_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._literalSequence_)
            + toString(this._comma_)
            + toString(this._literal_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._literalSequence_ == child)
        {
            this._literalSequence_ = null;
            return;
        }

        if(this._comma_ == child)
        {
            this._comma_ = null;
            return;
        }

        if(this._literal_ == child)
        {
            this._literal_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._literalSequence_ == oldChild)
        {
            setLiteralSequence((PLiteralSequence) newChild);
            return;
        }

        if(this._comma_ == oldChild)
        {
            setComma((TComma) newChild);
            return;
        }

        if(this._literal_ == oldChild)
        {
            setLiteral((PLiteral) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
