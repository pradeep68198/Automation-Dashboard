

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AZerosLiteral extends PLiteral
{
    private TZeros _zeros_;

    public AZerosLiteral()
    {
        // Constructor
    }

    public AZerosLiteral(
        @SuppressWarnings("hiding") TZeros _zeros_)
    {
        // Constructor
        setZeros(_zeros_);

    }

    @Override
    public Object clone()
    {
        return new AZerosLiteral(
            cloneNode(this._zeros_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAZerosLiteral(this);
    }

    public TZeros getZeros()
    {
        return this._zeros_;
    }

    public void setZeros(TZeros node)
    {
        if(this._zeros_ != null)
        {
            this._zeros_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._zeros_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._zeros_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._zeros_ == child)
        {
            this._zeros_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._zeros_ == oldChild)
        {
            setZeros((TZeros) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
