

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PUsagePhrase extends Node
{
    // Empty body
}
