

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ABinaryUsagePhrase extends PUsagePhrase
{
    private TBinary _binary_;
    private TNative _native_;

    public ABinaryUsagePhrase()
    {
        // Constructor
    }

    public ABinaryUsagePhrase(
        @SuppressWarnings("hiding") TBinary _binary_,
        @SuppressWarnings("hiding") TNative _native_)
    {
        // Constructor
        setBinary(_binary_);

        setNative(_native_);

    }

    @Override
    public Object clone()
    {
        return new ABinaryUsagePhrase(
            cloneNode(this._binary_),
            cloneNode(this._native_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseABinaryUsagePhrase(this);
    }

    public TBinary getBinary()
    {
        return this._binary_;
    }

    public void setBinary(TBinary node)
    {
        if(this._binary_ != null)
        {
            this._binary_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._binary_ = node;
    }

    public TNative getNative()
    {
        return this._native_;
    }

    public void setNative(TNative node)
    {
        if(this._native_ != null)
        {
            this._native_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._native_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._binary_)
            + toString(this._native_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._binary_ == child)
        {
            this._binary_ = null;
            return;
        }

        if(this._native_ == child)
        {
            this._native_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._binary_ == oldChild)
        {
            setBinary((TBinary) newChild);
            return;
        }

        if(this._native_ == oldChild)
        {
            setNative((TNative) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
