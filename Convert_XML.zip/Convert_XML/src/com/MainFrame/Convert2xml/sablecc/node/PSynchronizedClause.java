

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PSynchronizedClause extends Node
{
    // Empty body
}
