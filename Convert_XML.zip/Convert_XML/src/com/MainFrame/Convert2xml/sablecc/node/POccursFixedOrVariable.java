

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class POccursFixedOrVariable extends Node
{
    // Empty body
}
