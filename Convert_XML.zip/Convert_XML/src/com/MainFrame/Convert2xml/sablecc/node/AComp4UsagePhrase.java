

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AComp4UsagePhrase extends PUsagePhrase
{
    private TComp4 _comp4_;
    private TNative _native_;

    public AComp4UsagePhrase()
    {
        // Constructor
    }

    public AComp4UsagePhrase(
        @SuppressWarnings("hiding") TComp4 _comp4_,
        @SuppressWarnings("hiding") TNative _native_)
    {
        // Constructor
        setComp4(_comp4_);

        setNative(_native_);

    }

    @Override
    public Object clone()
    {
        return new AComp4UsagePhrase(
            cloneNode(this._comp4_),
            cloneNode(this._native_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAComp4UsagePhrase(this);
    }

    public TComp4 getComp4()
    {
        return this._comp4_;
    }

    public void setComp4(TComp4 node)
    {
        if(this._comp4_ != null)
        {
            this._comp4_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._comp4_ = node;
    }

    public TNative getNative()
    {
        return this._native_;
    }

    public void setNative(TNative node)
    {
        if(this._native_ != null)
        {
            this._native_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._native_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._comp4_)
            + toString(this._native_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._comp4_ == child)
        {
            this._comp4_ = null;
            return;
        }

        if(this._native_ == child)
        {
            this._native_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._comp4_ == oldChild)
        {
            setComp4((TComp4) newChild);
            return;
        }

        if(this._native_ == oldChild)
        {
            setNative((TNative) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
