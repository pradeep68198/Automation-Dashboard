

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ASequenceCharacterString extends PCharacterString
{
    private PCharacterString _characterString_;
    private PCharacterSubstring _characterSubstring_;

    public ASequenceCharacterString()
    {
        // Constructor
    }

    public ASequenceCharacterString(
        @SuppressWarnings("hiding") PCharacterString _characterString_,
        @SuppressWarnings("hiding") PCharacterSubstring _characterSubstring_)
    {
        // Constructor
        setCharacterString(_characterString_);

        setCharacterSubstring(_characterSubstring_);

    }

    @Override
    public Object clone()
    {
        return new ASequenceCharacterString(
            cloneNode(this._characterString_),
            cloneNode(this._characterSubstring_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseASequenceCharacterString(this);
    }

    public PCharacterString getCharacterString()
    {
        return this._characterString_;
    }

    public void setCharacterString(PCharacterString node)
    {
        if(this._characterString_ != null)
        {
            this._characterString_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._characterString_ = node;
    }

    public PCharacterSubstring getCharacterSubstring()
    {
        return this._characterSubstring_;
    }

    public void setCharacterSubstring(PCharacterSubstring node)
    {
        if(this._characterSubstring_ != null)
        {
            this._characterSubstring_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._characterSubstring_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._characterString_)
            + toString(this._characterSubstring_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._characterString_ == child)
        {
            this._characterString_ = null;
            return;
        }

        if(this._characterSubstring_ == child)
        {
            this._characterSubstring_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._characterString_ == oldChild)
        {
            setCharacterString((PCharacterString) newChild);
            return;
        }

        if(this._characterSubstring_ == oldChild)
        {
            setCharacterSubstring((PCharacterSubstring) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
