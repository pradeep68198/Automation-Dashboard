

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ARenamesItem extends PRenamesItem
{
    private TNumberNot88 _numberNot88_;
    private TDataName _renameTo_;
    private TRenames _renames_;
    private TDataName _renameFrom_;
    private PThroughPhrase _throughPhrase_;

    public ARenamesItem()
    {
        // Constructor
    }

    public ARenamesItem(
        @SuppressWarnings("hiding") TNumberNot88 _numberNot88_,
        @SuppressWarnings("hiding") TDataName _renameTo_,
        @SuppressWarnings("hiding") TRenames _renames_,
        @SuppressWarnings("hiding") TDataName _renameFrom_,
        @SuppressWarnings("hiding") PThroughPhrase _throughPhrase_)
    {
        // Constructor
        setNumberNot88(_numberNot88_);

        setRenameTo(_renameTo_);

        setRenames(_renames_);

        setRenameFrom(_renameFrom_);

        setThroughPhrase(_throughPhrase_);

    }

    @Override
    public Object clone()
    {
        return new ARenamesItem(
            cloneNode(this._numberNot88_),
            cloneNode(this._renameTo_),
            cloneNode(this._renames_),
            cloneNode(this._renameFrom_),
            cloneNode(this._throughPhrase_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseARenamesItem(this);
    }

    public TNumberNot88 getNumberNot88()
    {
        return this._numberNot88_;
    }

    public void setNumberNot88(TNumberNot88 node)
    {
        if(this._numberNot88_ != null)
        {
            this._numberNot88_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._numberNot88_ = node;
    }

    public TDataName getRenameTo()
    {
        return this._renameTo_;
    }

    public void setRenameTo(TDataName node)
    {
        if(this._renameTo_ != null)
        {
            this._renameTo_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._renameTo_ = node;
    }

    public TRenames getRenames()
    {
        return this._renames_;
    }

    public void setRenames(TRenames node)
    {
        if(this._renames_ != null)
        {
            this._renames_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._renames_ = node;
    }

    public TDataName getRenameFrom()
    {
        return this._renameFrom_;
    }

    public void setRenameFrom(TDataName node)
    {
        if(this._renameFrom_ != null)
        {
            this._renameFrom_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._renameFrom_ = node;
    }

    public PThroughPhrase getThroughPhrase()
    {
        return this._throughPhrase_;
    }

    public void setThroughPhrase(PThroughPhrase node)
    {
        if(this._throughPhrase_ != null)
        {
            this._throughPhrase_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._throughPhrase_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._numberNot88_)
            + toString(this._renameTo_)
            + toString(this._renames_)
            + toString(this._renameFrom_)
            + toString(this._throughPhrase_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._numberNot88_ == child)
        {
            this._numberNot88_ = null;
            return;
        }

        if(this._renameTo_ == child)
        {
            this._renameTo_ = null;
            return;
        }

        if(this._renames_ == child)
        {
            this._renames_ = null;
            return;
        }

        if(this._renameFrom_ == child)
        {
            this._renameFrom_ = null;
            return;
        }

        if(this._throughPhrase_ == child)
        {
            this._throughPhrase_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._numberNot88_ == oldChild)
        {
            setNumberNot88((TNumberNot88) newChild);
            return;
        }

        if(this._renameTo_ == oldChild)
        {
            setRenameTo((TDataName) newChild);
            return;
        }

        if(this._renames_ == oldChild)
        {
            setRenames((TRenames) newChild);
            return;
        }

        if(this._renameFrom_ == oldChild)
        {
            setRenameFrom((TDataName) newChild);
            return;
        }

        if(this._throughPhrase_ == oldChild)
        {
            setThroughPhrase((PThroughPhrase) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
