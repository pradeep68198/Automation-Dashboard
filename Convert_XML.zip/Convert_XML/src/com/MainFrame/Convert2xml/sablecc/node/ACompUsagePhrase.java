

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ACompUsagePhrase extends PUsagePhrase
{
    private TComp _comp_;

    public ACompUsagePhrase()
    {
        // Constructor
    }

    public ACompUsagePhrase(
        @SuppressWarnings("hiding") TComp _comp_)
    {
        // Constructor
        setComp(_comp_);

    }

    @Override
    public Object clone()
    {
        return new ACompUsagePhrase(
            cloneNode(this._comp_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseACompUsagePhrase(this);
    }

    public TComp getComp()
    {
        return this._comp_;
    }

    public void setComp(TComp node)
    {
        if(this._comp_ != null)
        {
            this._comp_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._comp_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._comp_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._comp_ == child)
        {
            this._comp_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._comp_ == oldChild)
        {
            setComp((TComp) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
