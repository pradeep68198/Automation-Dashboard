

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PBracketedNumber extends Node
{
    // Empty body
}
