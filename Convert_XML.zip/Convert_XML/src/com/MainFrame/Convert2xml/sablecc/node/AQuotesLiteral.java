

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AQuotesLiteral extends PLiteral
{
    private TQuotes _quotes_;

    public AQuotesLiteral()
    {
        // Constructor
    }

    public AQuotesLiteral(
        @SuppressWarnings("hiding") TQuotes _quotes_)
    {
        // Constructor
        setQuotes(_quotes_);

    }

    @Override
    public Object clone()
    {
        return new AQuotesLiteral(
            cloneNode(this._quotes_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAQuotesLiteral(this);
    }

    public TQuotes getQuotes()
    {
        return this._quotes_;
    }

    public void setQuotes(TQuotes node)
    {
        if(this._quotes_ != null)
        {
            this._quotes_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._quotes_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._quotes_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._quotes_ == child)
        {
            this._quotes_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._quotes_ == oldChild)
        {
            setQuotes((TQuotes) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
