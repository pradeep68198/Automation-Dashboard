

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class TDollar extends Token
{
    public TDollar()
    {
        super.setText("$");
    }

    public TDollar(int line, int pos)
    {
        super.setText("$");
        setLine(line);
        setPos(pos);
    }

    @Override
    public Object clone()
    {
      return new TDollar(getLine(), getPos());
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseTDollar(this);
    }

    @Override
    public void setText(@SuppressWarnings("unused") String text)
    {
        throw new RuntimeException("Cannot change TDollar text.");
    }
}
