

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PItem extends Node
{
    // Empty body
}
