

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PLeadingOrTrailing extends Node
{
    // Empty body
}
