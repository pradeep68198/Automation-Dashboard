

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ADataNameDataNameOrFiller extends PDataNameOrFiller
{
    private TDataName _dataName_;

    public ADataNameDataNameOrFiller()
    {
        // Constructor
    }

    public ADataNameDataNameOrFiller(
        @SuppressWarnings("hiding") TDataName _dataName_)
    {
        // Constructor
        setDataName(_dataName_);

    }

    @Override
    public Object clone()
    {
        return new ADataNameDataNameOrFiller(
            cloneNode(this._dataName_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseADataNameDataNameOrFiller(this);
    }

    public TDataName getDataName()
    {
        return this._dataName_;
    }

    public void setDataName(TDataName node)
    {
        if(this._dataName_ != null)
        {
            this._dataName_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._dataName_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._dataName_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._dataName_ == child)
        {
            this._dataName_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._dataName_ == oldChild)
        {
            setDataName((TDataName) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
