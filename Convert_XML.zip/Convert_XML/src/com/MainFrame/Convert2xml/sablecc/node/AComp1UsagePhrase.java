

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AComp1UsagePhrase extends PUsagePhrase
{
    private TComp1 _comp1_;
    private TNative _native_;

    public AComp1UsagePhrase()
    {
        // Constructor
    }

    public AComp1UsagePhrase(
        @SuppressWarnings("hiding") TComp1 _comp1_,
        @SuppressWarnings("hiding") TNative _native_)
    {
        // Constructor
        setComp1(_comp1_);

        setNative(_native_);

    }

    @Override
    public Object clone()
    {
        return new AComp1UsagePhrase(
            cloneNode(this._comp1_),
            cloneNode(this._native_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAComp1UsagePhrase(this);
    }

    public TComp1 getComp1()
    {
        return this._comp1_;
    }

    public void setComp1(TComp1 node)
    {
        if(this._comp1_ != null)
        {
            this._comp1_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._comp1_ = node;
    }

    public TNative getNative()
    {
        return this._native_;
    }

    public void setNative(TNative node)
    {
        if(this._native_ != null)
        {
            this._native_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._native_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._comp1_)
            + toString(this._native_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._comp1_ == child)
        {
            this._comp1_ = null;
            return;
        }

        if(this._native_ == child)
        {
            this._native_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._comp1_ == oldChild)
        {
            setComp1((TComp1) newChild);
            return;
        }

        if(this._native_ == oldChild)
        {
            setNative((TNative) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
