

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PValueOrValues extends Node
{
    // Empty body
}
