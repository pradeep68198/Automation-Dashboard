

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AUsageIs extends PUsageIs
{
    private TUsage _usage_;
    private TIs _is_;

    public AUsageIs()
    {
        // Constructor
    }

    public AUsageIs(
        @SuppressWarnings("hiding") TUsage _usage_,
        @SuppressWarnings("hiding") TIs _is_)
    {
        // Constructor
        setUsage(_usage_);

        setIs(_is_);

    }

    @Override
    public Object clone()
    {
        return new AUsageIs(
            cloneNode(this._usage_),
            cloneNode(this._is_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAUsageIs(this);
    }

    public TUsage getUsage()
    {
        return this._usage_;
    }

    public void setUsage(TUsage node)
    {
        if(this._usage_ != null)
        {
            this._usage_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._usage_ = node;
    }

    public TIs getIs()
    {
        return this._is_;
    }

    public void setIs(TIs node)
    {
        if(this._is_ != null)
        {
            this._is_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._is_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._usage_)
            + toString(this._is_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._usage_ == child)
        {
            this._usage_ = null;
            return;
        }

        if(this._is_ == child)
        {
            this._is_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._usage_ == oldChild)
        {
            setUsage((TUsage) newChild);
            return;
        }

        if(this._is_ == oldChild)
        {
            setIs((TIs) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
