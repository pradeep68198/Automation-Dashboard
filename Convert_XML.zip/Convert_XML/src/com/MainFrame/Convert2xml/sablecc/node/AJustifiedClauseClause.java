

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AJustifiedClauseClause extends PClause
{
    private PJustifiedClause _justifiedClause_;

    public AJustifiedClauseClause()
    {
        // Constructor
    }

    public AJustifiedClauseClause(
        @SuppressWarnings("hiding") PJustifiedClause _justifiedClause_)
    {
        // Constructor
        setJustifiedClause(_justifiedClause_);

    }

    @Override
    public Object clone()
    {
        return new AJustifiedClauseClause(
            cloneNode(this._justifiedClause_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAJustifiedClauseClause(this);
    }

    public PJustifiedClause getJustifiedClause()
    {
        return this._justifiedClause_;
    }

    public void setJustifiedClause(PJustifiedClause node)
    {
        if(this._justifiedClause_ != null)
        {
            this._justifiedClause_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._justifiedClause_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._justifiedClause_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._justifiedClause_ == child)
        {
            this._justifiedClause_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._justifiedClause_ == oldChild)
        {
            setJustifiedClause((PJustifiedClause) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
