

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AFillerDataNameOrFiller extends PDataNameOrFiller
{
    private TFiller _filler_;

    public AFillerDataNameOrFiller()
    {
        // Constructor
    }

    public AFillerDataNameOrFiller(
        @SuppressWarnings("hiding") TFiller _filler_)
    {
        // Constructor
        setFiller(_filler_);

    }

    @Override
    public Object clone()
    {
        return new AFillerDataNameOrFiller(
            cloneNode(this._filler_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAFillerDataNameOrFiller(this);
    }

    public TFiller getFiller()
    {
        return this._filler_;
    }

    public void setFiller(TFiller node)
    {
        if(this._filler_ != null)
        {
            this._filler_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._filler_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._filler_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._filler_ == child)
        {
            this._filler_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._filler_ == oldChild)
        {
            setFiller((TFiller) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
