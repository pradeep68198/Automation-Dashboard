

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ASingleGroupItem extends PGroupItem
{
    private PElementaryItem _elementaryItem_;

    public ASingleGroupItem()
    {
        // Constructor
    }

    public ASingleGroupItem(
        @SuppressWarnings("hiding") PElementaryItem _elementaryItem_)
    {
        // Constructor
        setElementaryItem(_elementaryItem_);

    }

    @Override
    public Object clone()
    {
        return new ASingleGroupItem(
            cloneNode(this._elementaryItem_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseASingleGroupItem(this);
    }

    public PElementaryItem getElementaryItem()
    {
        return this._elementaryItem_;
    }

    public void setElementaryItem(PElementaryItem node)
    {
        if(this._elementaryItem_ != null)
        {
            this._elementaryItem_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._elementaryItem_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._elementaryItem_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._elementaryItem_ == child)
        {
            this._elementaryItem_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._elementaryItem_ == oldChild)
        {
            setElementaryItem((PElementaryItem) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
