

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AObjectReferencePhrase extends PObjectReferencePhrase
{
    private TObject _object_;
    private TReference _reference_;
    private TDataName _dataName_;

    public AObjectReferencePhrase()
    {
        // Constructor
    }

    public AObjectReferencePhrase(
        @SuppressWarnings("hiding") TObject _object_,
        @SuppressWarnings("hiding") TReference _reference_,
        @SuppressWarnings("hiding") TDataName _dataName_)
    {
        // Constructor
        setObject(_object_);

        setReference(_reference_);

        setDataName(_dataName_);

    }

    @Override
    public Object clone()
    {
        return new AObjectReferencePhrase(
            cloneNode(this._object_),
            cloneNode(this._reference_),
            cloneNode(this._dataName_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAObjectReferencePhrase(this);
    }

    public TObject getObject()
    {
        return this._object_;
    }

    public void setObject(TObject node)
    {
        if(this._object_ != null)
        {
            this._object_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._object_ = node;
    }

    public TReference getReference()
    {
        return this._reference_;
    }

    public void setReference(TReference node)
    {
        if(this._reference_ != null)
        {
            this._reference_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._reference_ = node;
    }

    public TDataName getDataName()
    {
        return this._dataName_;
    }

    public void setDataName(TDataName node)
    {
        if(this._dataName_ != null)
        {
            this._dataName_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._dataName_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._object_)
            + toString(this._reference_)
            + toString(this._dataName_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._object_ == child)
        {
            this._object_ = null;
            return;
        }

        if(this._reference_ == child)
        {
            this._reference_ = null;
            return;
        }

        if(this._dataName_ == child)
        {
            this._dataName_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._object_ == oldChild)
        {
            setObject((TObject) newChild);
            return;
        }

        if(this._reference_ == oldChild)
        {
            setReference((TReference) newChild);
            return;
        }

        if(this._dataName_ == oldChild)
        {
            setDataName((TDataName) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
