

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PLiteral extends Node
{
    // Empty body
}
