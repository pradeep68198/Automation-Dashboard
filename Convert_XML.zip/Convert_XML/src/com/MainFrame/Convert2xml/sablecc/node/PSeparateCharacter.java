

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PSeparateCharacter extends Node
{
    // Empty body
}
