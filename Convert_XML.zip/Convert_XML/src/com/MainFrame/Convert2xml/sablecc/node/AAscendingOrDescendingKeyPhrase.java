

package com.MainFrame.Convert2xml.sablecc.node;

import java.util.*;
import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AAscendingOrDescendingKeyPhrase extends PAscendingOrDescendingKeyPhrase
{
    private PAscendingOrDescending _ascendingOrDescending_;
    private TKey _key_;
    private TIs _is_;
    private final LinkedList<TDataName> _dataName_ = new LinkedList<TDataName>();

    public AAscendingOrDescendingKeyPhrase()
    {
        // Constructor
    }

    public AAscendingOrDescendingKeyPhrase(
        @SuppressWarnings("hiding") PAscendingOrDescending _ascendingOrDescending_,
        @SuppressWarnings("hiding") TKey _key_,
        @SuppressWarnings("hiding") TIs _is_,
        @SuppressWarnings("hiding") List<?> _dataName_)
    {
        // Constructor
        setAscendingOrDescending(_ascendingOrDescending_);

        setKey(_key_);

        setIs(_is_);

        setDataName(_dataName_);

    }

    @Override
    public Object clone()
    {
        return new AAscendingOrDescendingKeyPhrase(
            cloneNode(this._ascendingOrDescending_),
            cloneNode(this._key_),
            cloneNode(this._is_),
            cloneList(this._dataName_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAAscendingOrDescendingKeyPhrase(this);
    }

    public PAscendingOrDescending getAscendingOrDescending()
    {
        return this._ascendingOrDescending_;
    }

    public void setAscendingOrDescending(PAscendingOrDescending node)
    {
        if(this._ascendingOrDescending_ != null)
        {
            this._ascendingOrDescending_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._ascendingOrDescending_ = node;
    }

    public TKey getKey()
    {
        return this._key_;
    }

    public void setKey(TKey node)
    {
        if(this._key_ != null)
        {
            this._key_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._key_ = node;
    }

    public TIs getIs()
    {
        return this._is_;
    }

    public void setIs(TIs node)
    {
        if(this._is_ != null)
        {
            this._is_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._is_ = node;
    }

    public LinkedList<TDataName> getDataName()
    {
        return this._dataName_;
    }

    public void setDataName(List<?> list)
    {
        for(TDataName e : this._dataName_)
        {
            e.parent(null);
        }
        this._dataName_.clear();

        for(Object obj_e : list)
        {
            TDataName e = (TDataName) obj_e;
            if(e.parent() != null)
            {
                e.parent().removeChild(e);
            }

            e.parent(this);
            this._dataName_.add(e);
        }
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._ascendingOrDescending_)
            + toString(this._key_)
            + toString(this._is_)
            + toString(this._dataName_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._ascendingOrDescending_ == child)
        {
            this._ascendingOrDescending_ = null;
            return;
        }

        if(this._key_ == child)
        {
            this._key_ = null;
            return;
        }

        if(this._is_ == child)
        {
            this._is_ = null;
            return;
        }

        if(this._dataName_.remove(child))
        {
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._ascendingOrDescending_ == oldChild)
        {
            setAscendingOrDescending((PAscendingOrDescending) newChild);
            return;
        }

        if(this._key_ == oldChild)
        {
            setKey((TKey) newChild);
            return;
        }

        if(this._is_ == oldChild)
        {
            setIs((TIs) newChild);
            return;
        }

        for(ListIterator<TDataName> i = this._dataName_.listIterator(); i.hasNext();)
        {
            if(i.next() == oldChild)
            {
                if(newChild != null)
                {
                    i.set((TDataName) newChild);
                    newChild.parent(this);
                    oldChild.parent(null);
                    return;
                }

                i.remove();
                oldChild.parent(null);
                return;
            }
        }

        throw new RuntimeException("Not a child.");
    }
}
