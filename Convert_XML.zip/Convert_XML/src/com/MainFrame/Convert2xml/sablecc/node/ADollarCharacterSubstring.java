

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ADollarCharacterSubstring extends PCharacterSubstring
{
    private TDollar _dollar_;

    public ADollarCharacterSubstring()
    {
        // Constructor
    }

    public ADollarCharacterSubstring(
        @SuppressWarnings("hiding") TDollar _dollar_)
    {
        // Constructor
        setDollar(_dollar_);

    }

    @Override
    public Object clone()
    {
        return new ADollarCharacterSubstring(
            cloneNode(this._dollar_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseADollarCharacterSubstring(this);
    }

    public TDollar getDollar()
    {
        return this._dollar_;
    }

    public void setDollar(TDollar node)
    {
        if(this._dollar_ != null)
        {
            this._dollar_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._dollar_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._dollar_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._dollar_ == child)
        {
            this._dollar_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._dollar_ == oldChild)
        {
            setDollar((TDollar) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
