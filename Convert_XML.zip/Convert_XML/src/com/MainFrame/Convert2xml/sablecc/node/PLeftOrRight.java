

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PLeftOrRight extends Node
{
    // Empty body
}
