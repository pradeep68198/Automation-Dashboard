

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PElementaryItem extends Node
{
    // Empty body
}
