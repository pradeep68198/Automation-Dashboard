

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ADateFormatClauseClause extends PClause
{
    private PDateFormatClause _dateFormatClause_;

    public ADateFormatClauseClause()
    {
        // Constructor
    }

    public ADateFormatClauseClause(
        @SuppressWarnings("hiding") PDateFormatClause _dateFormatClause_)
    {
        // Constructor
        setDateFormatClause(_dateFormatClause_);

    }

    @Override
    public Object clone()
    {
        return new ADateFormatClauseClause(
            cloneNode(this._dateFormatClause_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseADateFormatClauseClause(this);
    }

    public PDateFormatClause getDateFormatClause()
    {
        return this._dateFormatClause_;
    }

    public void setDateFormatClause(PDateFormatClause node)
    {
        if(this._dateFormatClause_ != null)
        {
            this._dateFormatClause_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._dateFormatClause_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._dateFormatClause_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._dateFormatClause_ == child)
        {
            this._dateFormatClause_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._dateFormatClause_ == oldChild)
        {
            setDateFormatClause((PDateFormatClause) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
