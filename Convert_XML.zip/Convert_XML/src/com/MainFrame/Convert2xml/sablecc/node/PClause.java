

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PClause extends Node
{
    // Empty body
}
