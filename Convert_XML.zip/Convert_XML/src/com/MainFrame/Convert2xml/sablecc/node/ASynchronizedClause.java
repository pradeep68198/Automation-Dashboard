

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ASynchronizedClause extends PSynchronizedClause
{
    private TSynchronized _synchronized_;
    private PLeftOrRight _leftOrRight_;

    public ASynchronizedClause()
    {
        // Constructor
    }

    public ASynchronizedClause(
        @SuppressWarnings("hiding") TSynchronized _synchronized_,
        @SuppressWarnings("hiding") PLeftOrRight _leftOrRight_)
    {
        // Constructor
        setSynchronized(_synchronized_);

        setLeftOrRight(_leftOrRight_);

    }

    @Override
    public Object clone()
    {
        return new ASynchronizedClause(
            cloneNode(this._synchronized_),
            cloneNode(this._leftOrRight_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseASynchronizedClause(this);
    }

    public TSynchronized getSynchronized()
    {
        return this._synchronized_;
    }

    public void setSynchronized(TSynchronized node)
    {
        if(this._synchronized_ != null)
        {
            this._synchronized_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._synchronized_ = node;
    }

    public PLeftOrRight getLeftOrRight()
    {
        return this._leftOrRight_;
    }

    public void setLeftOrRight(PLeftOrRight node)
    {
        if(this._leftOrRight_ != null)
        {
            this._leftOrRight_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._leftOrRight_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._synchronized_)
            + toString(this._leftOrRight_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._synchronized_ == child)
        {
            this._synchronized_ = null;
            return;
        }

        if(this._leftOrRight_ == child)
        {
            this._leftOrRight_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._synchronized_ == oldChild)
        {
            setSynchronized((TSynchronized) newChild);
            return;
        }

        if(this._leftOrRight_ == oldChild)
        {
            setLeftOrRight((PLeftOrRight) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
