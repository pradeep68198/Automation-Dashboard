

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AExternalClause extends PExternalClause
{
    private TExternal _external_;

    public AExternalClause()
    {
        // Constructor
    }

    public AExternalClause(
        @SuppressWarnings("hiding") TExternal _external_)
    {
        // Constructor
        setExternal(_external_);

    }

    @Override
    public Object clone()
    {
        return new AExternalClause(
            cloneNode(this._external_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAExternalClause(this);
    }

    public TExternal getExternal()
    {
        return this._external_;
    }

    public void setExternal(TExternal node)
    {
        if(this._external_ != null)
        {
            this._external_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._external_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._external_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._external_ == child)
        {
            this._external_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._external_ == oldChild)
        {
            setExternal((TExternal) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
