

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AAscendingAscendingOrDescending extends PAscendingOrDescending
{
    private TAscending _ascending_;

    public AAscendingAscendingOrDescending()
    {
        // Constructor
    }

    public AAscendingAscendingOrDescending(
        @SuppressWarnings("hiding") TAscending _ascending_)
    {
        // Constructor
        setAscending(_ascending_);

    }

    @Override
    public Object clone()
    {
        return new AAscendingAscendingOrDescending(
            cloneNode(this._ascending_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAAscendingAscendingOrDescending(this);
    }

    public TAscending getAscending()
    {
        return this._ascending_;
    }

    public void setAscending(TAscending node)
    {
        if(this._ascending_ != null)
        {
            this._ascending_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._ascending_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._ascending_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._ascending_ == child)
        {
            this._ascending_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._ascending_ == oldChild)
        {
            setAscending((TAscending) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
