

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AValueClauseClause extends PClause
{
    private PValueClause _valueClause_;

    public AValueClauseClause()
    {
        // Constructor
    }

    public AValueClauseClause(
        @SuppressWarnings("hiding") PValueClause _valueClause_)
    {
        // Constructor
        setValueClause(_valueClause_);

    }

    @Override
    public Object clone()
    {
        return new AValueClauseClause(
            cloneNode(this._valueClause_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAValueClauseClause(this);
    }

    public PValueClause getValueClause()
    {
        return this._valueClause_;
    }

    public void setValueClause(PValueClause node)
    {
        if(this._valueClause_ != null)
        {
            this._valueClause_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._valueClause_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._valueClause_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._valueClause_ == child)
        {
            this._valueClause_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._valueClause_ == oldChild)
        {
            setValueClause((PValueClause) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
