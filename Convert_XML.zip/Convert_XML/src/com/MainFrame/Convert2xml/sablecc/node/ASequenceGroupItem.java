

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ASequenceGroupItem extends PGroupItem
{
    private PGroupItem _groupItem_;
    private TDot _dot_;
    private PElementaryItem _elementaryItem_;

    public ASequenceGroupItem()
    {
        // Constructor
    }

    public ASequenceGroupItem(
        @SuppressWarnings("hiding") PGroupItem _groupItem_,
        @SuppressWarnings("hiding") TDot _dot_,
        @SuppressWarnings("hiding") PElementaryItem _elementaryItem_)
    {
        // Constructor
        setGroupItem(_groupItem_);

        setDot(_dot_);

        setElementaryItem(_elementaryItem_);

    }

    @Override
    public Object clone()
    {
        return new ASequenceGroupItem(
            cloneNode(this._groupItem_),
            cloneNode(this._dot_),
            cloneNode(this._elementaryItem_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseASequenceGroupItem(this);
    }

    public PGroupItem getGroupItem()
    {
        return this._groupItem_;
    }

    public void setGroupItem(PGroupItem node)
    {
        if(this._groupItem_ != null)
        {
            this._groupItem_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._groupItem_ = node;
    }

    public TDot getDot()
    {
        return this._dot_;
    }

    public void setDot(TDot node)
    {
        if(this._dot_ != null)
        {
            this._dot_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._dot_ = node;
    }

    public PElementaryItem getElementaryItem()
    {
        return this._elementaryItem_;
    }

    public void setElementaryItem(PElementaryItem node)
    {
        if(this._elementaryItem_ != null)
        {
            this._elementaryItem_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._elementaryItem_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._groupItem_)
            + toString(this._dot_)
            + toString(this._elementaryItem_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._groupItem_ == child)
        {
            this._groupItem_ = null;
            return;
        }

        if(this._dot_ == child)
        {
            this._dot_ = null;
            return;
        }

        if(this._elementaryItem_ == child)
        {
            this._elementaryItem_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._groupItem_ == oldChild)
        {
            setGroupItem((PGroupItem) newChild);
            return;
        }

        if(this._dot_ == oldChild)
        {
            setDot((TDot) newChild);
            return;
        }

        if(this._elementaryItem_ == oldChild)
        {
            setElementaryItem((PElementaryItem) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
