

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PRedefinesClause extends Node
{
    // Empty body
}
