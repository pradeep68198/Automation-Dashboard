

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PPictureClause extends Node
{
    // Empty body
}
