

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AValueItem extends PValueItem
{
    private TNumber88 _number88_;
    private TDataName _dataName_;
    private PValueOrValues _valueOrValues_;
    private PLiteralSequence _literalSequence_;

    public AValueItem()
    {
        // Constructor
    }

    public AValueItem(
        @SuppressWarnings("hiding") TNumber88 _number88_,
        @SuppressWarnings("hiding") TDataName _dataName_,
        @SuppressWarnings("hiding") PValueOrValues _valueOrValues_,
        @SuppressWarnings("hiding") PLiteralSequence _literalSequence_)
    {
        // Constructor
        setNumber88(_number88_);

        setDataName(_dataName_);

        setValueOrValues(_valueOrValues_);

        setLiteralSequence(_literalSequence_);

    }

    @Override
    public Object clone()
    {
        return new AValueItem(
            cloneNode(this._number88_),
            cloneNode(this._dataName_),
            cloneNode(this._valueOrValues_),
            cloneNode(this._literalSequence_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAValueItem(this);
    }

    public TNumber88 getNumber88()
    {
        return this._number88_;
    }

    public void setNumber88(TNumber88 node)
    {
        if(this._number88_ != null)
        {
            this._number88_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._number88_ = node;
    }

    public TDataName getDataName()
    {
        return this._dataName_;
    }

    public void setDataName(TDataName node)
    {
        if(this._dataName_ != null)
        {
            this._dataName_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._dataName_ = node;
    }

    public PValueOrValues getValueOrValues()
    {
        return this._valueOrValues_;
    }

    public void setValueOrValues(PValueOrValues node)
    {
        if(this._valueOrValues_ != null)
        {
            this._valueOrValues_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._valueOrValues_ = node;
    }

    public PLiteralSequence getLiteralSequence()
    {
        return this._literalSequence_;
    }

    public void setLiteralSequence(PLiteralSequence node)
    {
        if(this._literalSequence_ != null)
        {
            this._literalSequence_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._literalSequence_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._number88_)
            + toString(this._dataName_)
            + toString(this._valueOrValues_)
            + toString(this._literalSequence_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._number88_ == child)
        {
            this._number88_ = null;
            return;
        }

        if(this._dataName_ == child)
        {
            this._dataName_ = null;
            return;
        }

        if(this._valueOrValues_ == child)
        {
            this._valueOrValues_ = null;
            return;
        }

        if(this._literalSequence_ == child)
        {
            this._literalSequence_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._number88_ == oldChild)
        {
            setNumber88((TNumber88) newChild);
            return;
        }

        if(this._dataName_ == oldChild)
        {
            setDataName((TDataName) newChild);
            return;
        }

        if(this._valueOrValues_ == oldChild)
        {
            setValueOrValues((PValueOrValues) newChild);
            return;
        }

        if(this._literalSequence_ == oldChild)
        {
            setLiteralSequence((PLiteralSequence) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
