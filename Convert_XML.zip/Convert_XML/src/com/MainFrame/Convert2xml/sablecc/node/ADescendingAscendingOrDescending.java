

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ADescendingAscendingOrDescending extends PAscendingOrDescending
{
    private TDescending _descending_;

    public ADescendingAscendingOrDescending()
    {
        // Constructor
    }

    public ADescendingAscendingOrDescending(
        @SuppressWarnings("hiding") TDescending _descending_)
    {
        // Constructor
        setDescending(_descending_);

    }

    @Override
    public Object clone()
    {
        return new ADescendingAscendingOrDescending(
            cloneNode(this._descending_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseADescendingAscendingOrDescending(this);
    }

    public TDescending getDescending()
    {
        return this._descending_;
    }

    public void setDescending(TDescending node)
    {
        if(this._descending_ != null)
        {
            this._descending_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._descending_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._descending_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._descending_ == child)
        {
            this._descending_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._descending_ == oldChild)
        {
            setDescending((TDescending) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
