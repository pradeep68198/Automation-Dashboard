

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PGroupItem extends Node
{
    // Empty body
}
