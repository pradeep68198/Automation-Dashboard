

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AVariableOccursFixedOrVariable extends POccursFixedOrVariable
{
    private TOccurs _occurs_;
    private POccursTo _occursTo_;
    private PNumber _number_;
    private TTimes _times_;
    private TDepending _depending_;
    private TOn _on_;
    private TDataName _dataName_;

    public AVariableOccursFixedOrVariable()
    {
        // Constructor
    }

    public AVariableOccursFixedOrVariable(
        @SuppressWarnings("hiding") TOccurs _occurs_,
        @SuppressWarnings("hiding") POccursTo _occursTo_,
        @SuppressWarnings("hiding") PNumber _number_,
        @SuppressWarnings("hiding") TTimes _times_,
        @SuppressWarnings("hiding") TDepending _depending_,
        @SuppressWarnings("hiding") TOn _on_,
        @SuppressWarnings("hiding") TDataName _dataName_)
    {
        // Constructor
        setOccurs(_occurs_);

        setOccursTo(_occursTo_);

        setNumber(_number_);

        setTimes(_times_);

        setDepending(_depending_);

        setOn(_on_);

        setDataName(_dataName_);

    }

    @Override
    public Object clone()
    {
        return new AVariableOccursFixedOrVariable(
            cloneNode(this._occurs_),
            cloneNode(this._occursTo_),
            cloneNode(this._number_),
            cloneNode(this._times_),
            cloneNode(this._depending_),
            cloneNode(this._on_),
            cloneNode(this._dataName_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAVariableOccursFixedOrVariable(this);
    }

    public TOccurs getOccurs()
    {
        return this._occurs_;
    }

    public void setOccurs(TOccurs node)
    {
        if(this._occurs_ != null)
        {
            this._occurs_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._occurs_ = node;
    }

    public POccursTo getOccursTo()
    {
        return this._occursTo_;
    }

    public void setOccursTo(POccursTo node)
    {
        if(this._occursTo_ != null)
        {
            this._occursTo_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._occursTo_ = node;
    }

    public PNumber getNumber()
    {
        return this._number_;
    }

    public void setNumber(PNumber node)
    {
        if(this._number_ != null)
        {
            this._number_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._number_ = node;
    }

    public TTimes getTimes()
    {
        return this._times_;
    }

    public void setTimes(TTimes node)
    {
        if(this._times_ != null)
        {
            this._times_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._times_ = node;
    }

    public TDepending getDepending()
    {
        return this._depending_;
    }

    public void setDepending(TDepending node)
    {
        if(this._depending_ != null)
        {
            this._depending_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._depending_ = node;
    }

    public TOn getOn()
    {
        return this._on_;
    }

    public void setOn(TOn node)
    {
        if(this._on_ != null)
        {
            this._on_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._on_ = node;
    }

    public TDataName getDataName()
    {
        return this._dataName_;
    }

    public void setDataName(TDataName node)
    {
        if(this._dataName_ != null)
        {
            this._dataName_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._dataName_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._occurs_)
            + toString(this._occursTo_)
            + toString(this._number_)
            + toString(this._times_)
            + toString(this._depending_)
            + toString(this._on_)
            + toString(this._dataName_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._occurs_ == child)
        {
            this._occurs_ = null;
            return;
        }

        if(this._occursTo_ == child)
        {
            this._occursTo_ = null;
            return;
        }

        if(this._number_ == child)
        {
            this._number_ = null;
            return;
        }

        if(this._times_ == child)
        {
            this._times_ = null;
            return;
        }

        if(this._depending_ == child)
        {
            this._depending_ = null;
            return;
        }

        if(this._on_ == child)
        {
            this._on_ = null;
            return;
        }

        if(this._dataName_ == child)
        {
            this._dataName_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._occurs_ == oldChild)
        {
            setOccurs((TOccurs) newChild);
            return;
        }

        if(this._occursTo_ == oldChild)
        {
            setOccursTo((POccursTo) newChild);
            return;
        }

        if(this._number_ == oldChild)
        {
            setNumber((PNumber) newChild);
            return;
        }

        if(this._times_ == oldChild)
        {
            setTimes((TTimes) newChild);
            return;
        }

        if(this._depending_ == oldChild)
        {
            setDepending((TDepending) newChild);
            return;
        }

        if(this._on_ == oldChild)
        {
            setOn((TOn) newChild);
            return;
        }

        if(this._dataName_ == oldChild)
        {
            setDataName((TDataName) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
