

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class AOccursTo extends POccursTo
{
    private PNumber _number_;
    private TTo _to_;

    public AOccursTo()
    {
        // Constructor
    }

    public AOccursTo(
        @SuppressWarnings("hiding") PNumber _number_,
        @SuppressWarnings("hiding") TTo _to_)
    {
        // Constructor
        setNumber(_number_);

        setTo(_to_);

    }

    @Override
    public Object clone()
    {
        return new AOccursTo(
            cloneNode(this._number_),
            cloneNode(this._to_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseAOccursTo(this);
    }

    public PNumber getNumber()
    {
        return this._number_;
    }

    public void setNumber(PNumber node)
    {
        if(this._number_ != null)
        {
            this._number_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._number_ = node;
    }

    public TTo getTo()
    {
        return this._to_;
    }

    public void setTo(TTo node)
    {
        if(this._to_ != null)
        {
            this._to_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._to_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._number_)
            + toString(this._to_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._number_ == child)
        {
            this._number_ = null;
            return;
        }

        if(this._to_ == child)
        {
            this._to_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._number_ == oldChild)
        {
            setNumber((PNumber) newChild);
            return;
        }

        if(this._to_ == oldChild)
        {
            setTo((TTo) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
