

package com.MainFrame.Convert2xml.sablecc.node;

public abstract class PUsageIs extends Node
{
    // Empty body
}
