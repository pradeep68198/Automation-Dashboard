

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ABlankWhenZeroClause extends PBlankWhenZeroClause
{
    private TBlank _blank_;
    private TWhen _when_;
    private TZeros _zeros_;

    public ABlankWhenZeroClause()
    {
        // Constructor
    }

    public ABlankWhenZeroClause(
        @SuppressWarnings("hiding") TBlank _blank_,
        @SuppressWarnings("hiding") TWhen _when_,
        @SuppressWarnings("hiding") TZeros _zeros_)
    {
        // Constructor
        setBlank(_blank_);

        setWhen(_when_);

        setZeros(_zeros_);

    }

    @Override
    public Object clone()
    {
        return new ABlankWhenZeroClause(
            cloneNode(this._blank_),
            cloneNode(this._when_),
            cloneNode(this._zeros_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseABlankWhenZeroClause(this);
    }

    public TBlank getBlank()
    {
        return this._blank_;
    }

    public void setBlank(TBlank node)
    {
        if(this._blank_ != null)
        {
            this._blank_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._blank_ = node;
    }

    public TWhen getWhen()
    {
        return this._when_;
    }

    public void setWhen(TWhen node)
    {
        if(this._when_ != null)
        {
            this._when_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._when_ = node;
    }

    public TZeros getZeros()
    {
        return this._zeros_;
    }

    public void setZeros(TZeros node)
    {
        if(this._zeros_ != null)
        {
            this._zeros_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._zeros_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._blank_)
            + toString(this._when_)
            + toString(this._zeros_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._blank_ == child)
        {
            this._blank_ = null;
            return;
        }

        if(this._when_ == child)
        {
            this._when_ = null;
            return;
        }

        if(this._zeros_ == child)
        {
            this._zeros_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._blank_ == oldChild)
        {
            setBlank((TBlank) newChild);
            return;
        }

        if(this._when_ == oldChild)
        {
            setWhen((TWhen) newChild);
            return;
        }

        if(this._zeros_ == oldChild)
        {
            setZeros((TZeros) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
