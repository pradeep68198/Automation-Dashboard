

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ASignIs extends PSignIs
{
    private TSign _sign_;
    private TIs _is_;

    public ASignIs()
    {
        // Constructor
    }

    public ASignIs(
        @SuppressWarnings("hiding") TSign _sign_,
        @SuppressWarnings("hiding") TIs _is_)
    {
        // Constructor
        setSign(_sign_);

        setIs(_is_);

    }

    @Override
    public Object clone()
    {
        return new ASignIs(
            cloneNode(this._sign_),
            cloneNode(this._is_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseASignIs(this);
    }

    public TSign getSign()
    {
        return this._sign_;
    }

    public void setSign(TSign node)
    {
        if(this._sign_ != null)
        {
            this._sign_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._sign_ = node;
    }

    public TIs getIs()
    {
        return this._is_;
    }

    public void setIs(TIs node)
    {
        if(this._is_ != null)
        {
            this._is_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._is_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._sign_)
            + toString(this._is_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._sign_ == child)
        {
            this._sign_ = null;
            return;
        }

        if(this._is_ == child)
        {
            this._is_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._sign_ == oldChild)
        {
            setSign((TSign) newChild);
            return;
        }

        if(this._is_ == oldChild)
        {
            setIs((TIs) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
