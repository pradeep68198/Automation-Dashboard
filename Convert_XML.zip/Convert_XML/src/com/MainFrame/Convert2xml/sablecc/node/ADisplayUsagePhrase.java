

package com.MainFrame.Convert2xml.sablecc.node;

import com.MainFrame.Convert2xml.sablecc.analysis.*;

@SuppressWarnings("nls")
public final class ADisplayUsagePhrase extends PUsagePhrase
{
    private TDisplay _display_;
    private TNative _native_;

    public ADisplayUsagePhrase()
    {
        // Constructor
    }

    public ADisplayUsagePhrase(
        @SuppressWarnings("hiding") TDisplay _display_,
        @SuppressWarnings("hiding") TNative _native_)
    {
        // Constructor
        setDisplay(_display_);

        setNative(_native_);

    }

    @Override
    public Object clone()
    {
        return new ADisplayUsagePhrase(
            cloneNode(this._display_),
            cloneNode(this._native_));
    }

    @Override
    public void apply(Switch sw)
    {
        ((Analysis) sw).caseADisplayUsagePhrase(this);
    }

    public TDisplay getDisplay()
    {
        return this._display_;
    }

    public void setDisplay(TDisplay node)
    {
        if(this._display_ != null)
        {
            this._display_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._display_ = node;
    }

    public TNative getNative()
    {
        return this._native_;
    }

    public void setNative(TNative node)
    {
        if(this._native_ != null)
        {
            this._native_.parent(null);
        }

        if(node != null)
        {
            if(node.parent() != null)
            {
                node.parent().removeChild(node);
            }

            node.parent(this);
        }

        this._native_ = node;
    }

    @Override
    public String toString()
    {
        return ""
            + toString(this._display_)
            + toString(this._native_);
    }

    @Override
    void removeChild(@SuppressWarnings("unused") Node child)
    {
        // Remove child
        if(this._display_ == child)
        {
            this._display_ = null;
            return;
        }

        if(this._native_ == child)
        {
            this._native_ = null;
            return;
        }

        throw new RuntimeException("Not a child.");
    }

    @Override
    void replaceChild(@SuppressWarnings("unused") Node oldChild, @SuppressWarnings("unused") Node newChild)
    {
        // Replace child
        if(this._display_ == oldChild)
        {
            setDisplay((TDisplay) newChild);
            return;
        }

        if(this._native_ == oldChild)
        {
            setNative((TNative) newChild);
            return;
        }

        throw new RuntimeException("Not a child.");
    }
}
