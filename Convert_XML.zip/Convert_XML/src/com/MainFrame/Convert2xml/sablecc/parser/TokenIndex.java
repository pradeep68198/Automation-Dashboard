
package com.MainFrame.Convert2xml.sablecc.parser;

import com.MainFrame.Convert2xml.sablecc.node.*;
import com.MainFrame.Convert2xml.sablecc.analysis.*;

class TokenIndex extends AnalysisAdapter
{
    int index;

    @Override
    public void caseTDot(@SuppressWarnings("unused") TDot node)
    {
        this.index = 0;
    }

    @Override
    public void caseTComma(@SuppressWarnings("unused") TComma node)
    {
        this.index = 1;
    }

    @Override
    public void caseTSlash(@SuppressWarnings("unused") TSlash node)
    {
        this.index = 2;
    }

    @Override
    public void caseTPlus(@SuppressWarnings("unused") TPlus node)
    {
        this.index = 3;
    }

    @Override
    public void caseTMinus(@SuppressWarnings("unused") TMinus node)
    {
        this.index = 4;
    }

    @Override
    public void caseTStar(@SuppressWarnings("unused") TStar node)
    {
        this.index = 5;
    }

    @Override
    public void caseTDollar(@SuppressWarnings("unused") TDollar node)
    {
        this.index = 6;
    }

    @Override
    public void caseTLparen(@SuppressWarnings("unused") TLparen node)
    {
        this.index = 7;
    }

    @Override
    public void caseTRparen(@SuppressWarnings("unused") TRparen node)
    {
        this.index = 8;
    }

    @Override
    public void caseTNumber88(@SuppressWarnings("unused") TNumber88 node)
    {
        this.index = 9;
    }

    @Override
    public void caseTNumberNot88(@SuppressWarnings("unused") TNumberNot88 node)
    {
        this.index = 10;
    }

    @Override
    public void caseTAlphanumericLiteral(@SuppressWarnings("unused") TAlphanumericLiteral node)
    {
        this.index = 11;
    }

    @Override
    public void caseTNumericLiteral(@SuppressWarnings("unused") TNumericLiteral node)
    {
        this.index = 12;
    }

    @Override
    public void caseTDotZee(@SuppressWarnings("unused") TDotZee node)
    {
        this.index = 13;
    }

    @Override
    public void caseTDotMinus(@SuppressWarnings("unused") TDotMinus node)
    {
        this.index = 14;
    }

    @Override
    public void caseTDotPlus(@SuppressWarnings("unused") TDotPlus node)
    {
        this.index = 15;
    }

    @Override
    public void caseTAll(@SuppressWarnings("unused") TAll node)
    {
        this.index = 16;
    }

    @Override
    public void caseTAre(@SuppressWarnings("unused") TAre node)
    {
        this.index = 17;
    }

    @Override
    public void caseTAscending(@SuppressWarnings("unused") TAscending node)
    {
        this.index = 18;
    }

    @Override
    public void caseTBinary(@SuppressWarnings("unused") TBinary node)
    {
        this.index = 19;
    }

    @Override
    public void caseTBlank(@SuppressWarnings("unused") TBlank node)
    {
        this.index = 20;
    }

    @Override
    public void caseTBy(@SuppressWarnings("unused") TBy node)
    {
        this.index = 21;
    }

    @Override
    public void caseTCharacter(@SuppressWarnings("unused") TCharacter node)
    {
        this.index = 22;
    }

    @Override
    public void caseTComp(@SuppressWarnings("unused") TComp node)
    {
        this.index = 23;
    }

    @Override
    public void caseTComp1(@SuppressWarnings("unused") TComp1 node)
    {
        this.index = 24;
    }

    @Override
    public void caseTComp2(@SuppressWarnings("unused") TComp2 node)
    {
        this.index = 25;
    }

    @Override
    public void caseTComp3(@SuppressWarnings("unused") TComp3 node)
    {
        this.index = 26;
    }

    @Override
    public void caseTComp4(@SuppressWarnings("unused") TComp4 node)
    {
        this.index = 27;
    }

    @Override
    public void caseTComp5(@SuppressWarnings("unused") TComp5 node)
    {
        this.index = 28;
    }

    @Override
    public void caseTComp6(@SuppressWarnings("unused") TComp6 node)
    {
        this.index = 29;
    }

    @Override
    public void caseTDate(@SuppressWarnings("unused") TDate node)
    {
        this.index = 30;
    }

    @Override
    public void caseTDepending(@SuppressWarnings("unused") TDepending node)
    {
        this.index = 31;
    }

    @Override
    public void caseTDescending(@SuppressWarnings("unused") TDescending node)
    {
        this.index = 32;
    }

    @Override
    public void caseTDisplay(@SuppressWarnings("unused") TDisplay node)
    {
        this.index = 33;
    }

    @Override
    public void caseTDisplay1(@SuppressWarnings("unused") TDisplay1 node)
    {
        this.index = 34;
    }

    @Override
    public void caseTExternal(@SuppressWarnings("unused") TExternal node)
    {
        this.index = 35;
    }

    @Override
    public void caseTFiller(@SuppressWarnings("unused") TFiller node)
    {
        this.index = 36;
    }

    @Override
    public void caseTFormat(@SuppressWarnings("unused") TFormat node)
    {
        this.index = 37;
    }

    @Override
    public void caseTFunctionPointer(@SuppressWarnings("unused") TFunctionPointer node)
    {
        this.index = 38;
    }

    @Override
    public void caseTGlobal(@SuppressWarnings("unused") TGlobal node)
    {
        this.index = 39;
    }

    @Override
    public void caseTHighValues(@SuppressWarnings("unused") THighValues node)
    {
        this.index = 40;
    }

    @Override
    public void caseTIndex(@SuppressWarnings("unused") TIndex node)
    {
        this.index = 41;
    }

    @Override
    public void caseTIndexed(@SuppressWarnings("unused") TIndexed node)
    {
        this.index = 42;
    }

    @Override
    public void caseTIs(@SuppressWarnings("unused") TIs node)
    {
        this.index = 43;
    }

    @Override
    public void caseTJustified(@SuppressWarnings("unused") TJustified node)
    {
        this.index = 44;
    }

    @Override
    public void caseTKey(@SuppressWarnings("unused") TKey node)
    {
        this.index = 45;
    }

    @Override
    public void caseTLeading(@SuppressWarnings("unused") TLeading node)
    {
        this.index = 46;
    }

    @Override
    public void caseTLeft(@SuppressWarnings("unused") TLeft node)
    {
        this.index = 47;
    }

    @Override
    public void caseTLowValues(@SuppressWarnings("unused") TLowValues node)
    {
        this.index = 48;
    }

    @Override
    public void caseTNational(@SuppressWarnings("unused") TNational node)
    {
        this.index = 49;
    }

    @Override
    public void caseTNative(@SuppressWarnings("unused") TNative node)
    {
        this.index = 50;
    }

    @Override
    public void caseTNulls(@SuppressWarnings("unused") TNulls node)
    {
        this.index = 51;
    }

    @Override
    public void caseTObject(@SuppressWarnings("unused") TObject node)
    {
        this.index = 52;
    }

    @Override
    public void caseTOccurs(@SuppressWarnings("unused") TOccurs node)
    {
        this.index = 53;
    }

    @Override
    public void caseTOn(@SuppressWarnings("unused") TOn node)
    {
        this.index = 54;
    }

    @Override
    public void caseTPackedDecimal(@SuppressWarnings("unused") TPackedDecimal node)
    {
        this.index = 55;
    }

    @Override
    public void caseTPicture(@SuppressWarnings("unused") TPicture node)
    {
        this.index = 56;
    }

    @Override
    public void caseTPointer(@SuppressWarnings("unused") TPointer node)
    {
        this.index = 57;
    }

    @Override
    public void caseTProcedurePointer(@SuppressWarnings("unused") TProcedurePointer node)
    {
        this.index = 58;
    }

    @Override
    public void caseTQuotes(@SuppressWarnings("unused") TQuotes node)
    {
        this.index = 59;
    }

    @Override
    public void caseTRedefines(@SuppressWarnings("unused") TRedefines node)
    {
        this.index = 60;
    }

    @Override
    public void caseTReference(@SuppressWarnings("unused") TReference node)
    {
        this.index = 61;
    }

    @Override
    public void caseTRenames(@SuppressWarnings("unused") TRenames node)
    {
        this.index = 62;
    }

    @Override
    public void caseTRight(@SuppressWarnings("unused") TRight node)
    {
        this.index = 63;
    }

    @Override
    public void caseTSeparate(@SuppressWarnings("unused") TSeparate node)
    {
        this.index = 64;
    }

    @Override
    public void caseTSign(@SuppressWarnings("unused") TSign node)
    {
        this.index = 65;
    }

    @Override
    public void caseTSpaces(@SuppressWarnings("unused") TSpaces node)
    {
        this.index = 66;
    }

    @Override
    public void caseTSynchronized(@SuppressWarnings("unused") TSynchronized node)
    {
        this.index = 67;
    }

    @Override
    public void caseTThrough(@SuppressWarnings("unused") TThrough node)
    {
        this.index = 68;
    }

    @Override
    public void caseTTimes(@SuppressWarnings("unused") TTimes node)
    {
        this.index = 69;
    }

    @Override
    public void caseTTo(@SuppressWarnings("unused") TTo node)
    {
        this.index = 70;
    }

    @Override
    public void caseTTrailing(@SuppressWarnings("unused") TTrailing node)
    {
        this.index = 71;
    }

    @Override
    public void caseTUsage(@SuppressWarnings("unused") TUsage node)
    {
        this.index = 72;
    }

    @Override
    public void caseTValue(@SuppressWarnings("unused") TValue node)
    {
        this.index = 73;
    }

    @Override
    public void caseTValues(@SuppressWarnings("unused") TValues node)
    {
        this.index = 74;
    }

    @Override
    public void caseTWhen(@SuppressWarnings("unused") TWhen node)
    {
        this.index = 75;
    }

    @Override
    public void caseTZeros(@SuppressWarnings("unused") TZeros node)
    {
        this.index = 76;
    }

    @Override
    public void caseTDataName(@SuppressWarnings("unused") TDataName node)
    {
        this.index = 77;
    }

    @Override
    public void caseEOF(@SuppressWarnings("unused") EOF node)
    {
        this.index = 78;
    }
}
