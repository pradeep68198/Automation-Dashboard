

package com.MainFrame.Convert2xml.sablecc.parser;

import java.util.ArrayList;

final class State
{
    int state;
    ArrayList<Object> nodes;

    State(@SuppressWarnings("hiding") int state, @SuppressWarnings("hiding") ArrayList<Object> nodes)
    {
        this.state = state;
        this.nodes = nodes;
    }
}
