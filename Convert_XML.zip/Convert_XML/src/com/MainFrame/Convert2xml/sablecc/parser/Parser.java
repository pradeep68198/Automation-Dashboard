

package com.MainFrame.Convert2xml.sablecc.parser;

import com.MainFrame.Convert2xml.sablecc.lexer.*;
import com.MainFrame.Convert2xml.sablecc.node.*;
import com.MainFrame.Convert2xml.sablecc.analysis.*;
import java.util.*;

import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.io.IOException;

@SuppressWarnings("nls")
public class Parser
{
    public final Analysis ignoredTokens = new AnalysisAdapter();

    protected ArrayList<Object> nodeList;

    private final Lexer lexer;
    private final ListIterator<Object> stack = new LinkedList<Object>().listIterator();
    private int last_pos;
    private int last_line;
    private Token last_token;
    private final TokenIndex converter = new TokenIndex();
    private final int[] action = new int[2];

    private final static int SHIFT = 0;
    private final static int REDUCE = 1;
    private final static int ACCEPT = 2;
    private final static int ERROR = 3;
  
    public Parser(@SuppressWarnings("hiding") Lexer lexer)
    {
        this.lexer = lexer;
        
    }

    protected void filter() throws ParserException, LexerException, IOException
    {
        // Empty body
    }

    private void push(int numstate, ArrayList<Object> listNode, boolean hidden) throws ParserException, LexerException, IOException
    {
        this.nodeList = listNode;

        if(!hidden)
        {
            filter();
        }

        if(!this.stack.hasNext())
        {
            this.stack.add(new State(numstate, this.nodeList));
            return;
        }

        State s = (State) this.stack.next();
        s.state = numstate;
        s.nodes = this.nodeList;
    }

    private int goTo(int index)
    {
        int state = state();
        int low = 1;
        int high = gotoTable[index].length - 1;
        int value = gotoTable[index][0][1];

        while(low <= high)
        {
            // int middle = (low + high) / 2;
            int middle = (low + high) >>> 1;

            if(state < gotoTable[index][middle][0])
            {
                high = middle - 1;
            }
            else if(state > gotoTable[index][middle][0])
            {
                low = middle + 1;
            }
            else
            {
                value = gotoTable[index][middle][1];
                break;
            }
        }

        return value;
    }

    private int state()
    {
        State s = (State) this.stack.previous();
        this.stack.next();
        return s.state;
    }

    private ArrayList<Object> pop()
    {
        return ((State) this.stack.previous()).nodes;
    }

    private int index(Switchable token)
    {
        this.converter.index = -1;
        token.apply(this.converter);
        return this.converter.index;
    }

    @SuppressWarnings("unchecked")
    public Start parse(int initialColumn) throws ParserException, LexerException, IOException
    {
        push(0, null, true);
        List<Node> ign = null;
        while(true)
        {
            while(index(this.lexer.peek()) == -1)
            {
                if(ign == null)
                {
                    ign = new LinkedList<Node>();
                }

                ign.add(this.lexer.next());
            }

            if(ign != null)
            {
                this.ignoredTokens.setIn(this.lexer.peek(), ign);
                ign = null;
            }

            this.last_pos = this.lexer.peek().getPos();
            this.last_line = this.lexer.peek().getLine();
            this.last_token = this.lexer.peek();

            int index = index(this.lexer.peek());
            this.action[0] = Parser.actionTable[state()][0][1];
            this.action[1] = Parser.actionTable[state()][0][2];

            int low = 1;
            int high = Parser.actionTable[state()].length - 1;

            while(low <= high)
            {
                int middle = (low + high) / 2;

                if(index < Parser.actionTable[state()][middle][0])
                {
                    high = middle - 1;
                }
                else if(index > Parser.actionTable[state()][middle][0])
                {
                    low = middle + 1;
                }
                else
                {
                    this.action[0] = Parser.actionTable[state()][middle][1];
                    this.action[1] = Parser.actionTable[state()][middle][2];
                    break;
                }
            }

            switch(this.action[0])
            {
                case SHIFT:
		    {
		        ArrayList<Object> list = new ArrayList<Object>();
		        list.add(this.lexer.next());
                        push(this.action[1], list, false);
                    }
		    break;
                case REDUCE:
                    {
                        int reduction = this.action[1];
                        if(reduction < 500) reduce_0(reduction);
                    }
                    break;
                case ACCEPT:
                    {
                        EOF node2 = (EOF) this.lexer.next();
                        PRecordDescription node1 = (PRecordDescription) pop().get(0);
                        Start node = new Start(node1, node2);
                        return node;
                    }
                case ERROR:
                    throw new ParserException(this.last_token,
                        "[line=" + this.last_line + ", Column=" + (initialColumn+this.last_pos) + "] " +
                        Parser.errorMessages[Parser.errors[this.action[1]]]);
            }
        }
    }

    private void reduce_0(int reduction) throws IOException, LexerException, ParserException
    {
        switch(reduction)
        {
            case 0: /* reduce ARecordDescription */
            {
                ArrayList<Object> list = new0();
                push(goTo(0), list, false);
            }
            break;
            case 1: /* reduce ASingleGroupItem */
            {
                ArrayList<Object> list = new1();
                push(goTo(1), list, false);
            }
            break;
            case 2: /* reduce ASequenceGroupItem */
            {
                ArrayList<Object> list = new2();
                push(goTo(1), list, false);
            }
            break;
            case 3: /* reduce AItemElementaryItem */
            {
                ArrayList<Object> list = new3();
                push(goTo(2), list, false);
            }
            break;
            case 4: /* reduce ARenamesItemElementaryItem */
            {
                ArrayList<Object> list = new4();
                push(goTo(2), list, false);
            }
            break;
            case 5: /* reduce AValueItemElementaryItem */
            {
                ArrayList<Object> list = new5();
                push(goTo(2), list, false);
            }
            break;
            case 6: /* reduce AAitem1Item */
            {
                ArrayList<Object> list = new6();
                push(goTo(3), list, false);
            }
            break;
            case 7: /* reduce AAitem2Item */
            {
                ArrayList<Object> list = new7();
                push(goTo(3), list, false);
            }
            break;
            case 8: /* reduce AAitem3Item */
            {
                ArrayList<Object> list = new8();
                push(goTo(3), list, false);
            }
            break;
            case 9: /* reduce AAitem4Item */
            {
                ArrayList<Object> list = new9();
                push(goTo(3), list, false);
            }
            break;
            case 10: /* reduce AAitem5Item */
            {
                ArrayList<Object> list = new10();
                push(goTo(3), list, false);
            }
            break;
            case 11: /* reduce AAitem6Item */
            {
                ArrayList<Object> list = new11();
                push(goTo(3), list, false);
            }
            break;
            case 12: /* reduce AAitem7Item */
            {
                ArrayList<Object> list = new12();
                push(goTo(3), list, false);
            }
            break;
            case 13: /* reduce AAitem8Item */
            {
                ArrayList<Object> list = new13();
                push(goTo(3), list, false);
            }
            break;
            case 14: /* reduce ADataNameDataNameOrFiller */
            {
                ArrayList<Object> list = new14();
                push(goTo(4), list, false);
            }
            break;
            case 15: /* reduce AFillerDataNameOrFiller */
            {
                ArrayList<Object> list = new15();
                push(goTo(4), list, false);
            }
            break;
            case 16: /* reduce ARedefinesClause */
            {
                ArrayList<Object> list = new16();
                push(goTo(5), list, false);
            }
            break;
            case 17: /* reduce ASingleClauseSequence */
            {
                ArrayList<Object> list = new17();
                push(goTo(6), list, false);
            }
            break;
            case 18: /* reduce ASequenceClauseSequence */
            {
                ArrayList<Object> list = new18();
                push(goTo(6), list, false);
            }
            break;
            case 19: /* reduce ABlankWhenZeroClauseClause */
            {
                ArrayList<Object> list = new19();
                push(goTo(7), list, false);
            }
            break;
            case 20: /* reduce ADateFormatClauseClause */
            {
                ArrayList<Object> list = new20();
                push(goTo(7), list, false);
            }
            break;
            case 21: /* reduce AExternalClauseClause */
            {
                ArrayList<Object> list = new21();
                push(goTo(7), list, false);
            }
            break;
            case 22: /* reduce AGlobalClauseClause */
            {
                ArrayList<Object> list = new22();
                push(goTo(7), list, false);
            }
            break;
            case 23: /* reduce AJustifiedClauseClause */
            {
                ArrayList<Object> list = new23();
                push(goTo(7), list, false);
            }
            break;
            case 24: /* reduce AOccursClauseClause */
            {
                ArrayList<Object> list = new24();
                push(goTo(7), list, false);
            }
            break;
            case 25: /* reduce APictureClauseClause */
            {
                ArrayList<Object> list = new25();
                push(goTo(7), list, false);
            }
            break;
            case 26: /* reduce ASignClauseClause */
            {
                ArrayList<Object> list = new26();
                push(goTo(7), list, false);
            }
            break;
            case 27: /* reduce ASynchronizedClauseClause */
            {
                ArrayList<Object> list = new27();
                push(goTo(7), list, false);
            }
            break;
            case 28: /* reduce AUsageClauseClause */
            {
                ArrayList<Object> list = new28();
                push(goTo(7), list, false);
            }
            break;
            case 29: /* reduce AValueClauseClause */
            {
                ArrayList<Object> list = new29();
                push(goTo(7), list, false);
            }
            break;
            case 30: /* reduce AAblankwhenzeroclause1BlankWhenZeroClause */
            {
                ArrayList<Object> list = new30();
                push(goTo(8), list, false);
            }
            break;
            case 31: /* reduce AAblankwhenzeroclause2BlankWhenZeroClause */
            {
                ArrayList<Object> list = new31();
                push(goTo(8), list, false);
            }
            break;
            case 32: /* reduce AAdateformatclause1DateFormatClause */
            {
                ArrayList<Object> list = new32();
                push(goTo(9), list, false);
            }
            break;
            case 33: /* reduce AAdateformatclause2DateFormatClause */
            {
                ArrayList<Object> list = new33();
                push(goTo(9), list, false);
            }
            break;
            case 34: /* reduce AExternalClause */
            {
                ArrayList<Object> list = new34();
                push(goTo(10), list, false);
            }
            break;
            case 35: /* reduce AGlobalClause */
            {
                ArrayList<Object> list = new35();
                push(goTo(11), list, false);
            }
            break;
            case 36: /* reduce AAjustifiedclause1JustifiedClause */
            {
                ArrayList<Object> list = new36();
                push(goTo(12), list, false);
            }
            break;
            case 37: /* reduce AAjustifiedclause2JustifiedClause */
            {
                ArrayList<Object> list = new37();
                push(goTo(12), list, false);
            }
            break;
            case 38: /* reduce AAoccursclause1OccursClause */
            {
                ArrayList<Object> list = new38();
                push(goTo(13), list, false);
            }
            break;
            case 39: /* reduce AAoccursclause2OccursClause */
            {
                ArrayList<Object> list = new39();
                push(goTo(13), list, false);
            }
            break;
            case 40: /* reduce AAoccursclause3OccursClause */
            {
                ArrayList<Object> list = new40();
                push(goTo(13), list, false);
            }
            break;
            case 41: /* reduce AAoccursclause4OccursClause */
            {
                ArrayList<Object> list = new41();
                push(goTo(13), list, false);
            }
            break;
            case 42: /* reduce AAfixedoccursfixedorvariable1OccursFixedOrVariable */
            {
                ArrayList<Object> list = new42();
                push(goTo(14), list, false);
            }
            break;
            case 43: /* reduce AAfixedoccursfixedorvariable2OccursFixedOrVariable */
            {
                ArrayList<Object> list = new43();
                push(goTo(14), list, false);
            }
            break;
            case 44: /* reduce AAvariableoccursfixedorvariable1OccursFixedOrVariable */
            {
                ArrayList<Object> list = new44();
                push(goTo(14), list, false);
            }
            break;
            case 45: /* reduce AAvariableoccursfixedorvariable2OccursFixedOrVariable */
            {
                ArrayList<Object> list = new45();
                push(goTo(14), list, false);
            }
            break;
            case 46: /* reduce AAvariableoccursfixedorvariable3OccursFixedOrVariable */
            {
                ArrayList<Object> list = new46();
                push(goTo(14), list, false);
            }
            break;
            case 47: /* reduce AAvariableoccursfixedorvariable4OccursFixedOrVariable */
            {
                ArrayList<Object> list = new47();
                push(goTo(14), list, false);
            }
            break;
            case 48: /* reduce AAvariableoccursfixedorvariable5OccursFixedOrVariable */
            {
                ArrayList<Object> list = new48();
                push(goTo(14), list, false);
            }
            break;
            case 49: /* reduce AAvariableoccursfixedorvariable6OccursFixedOrVariable */
            {
                ArrayList<Object> list = new49();
                push(goTo(14), list, false);
            }
            break;
            case 50: /* reduce AAvariableoccursfixedorvariable7OccursFixedOrVariable */
            {
                ArrayList<Object> list = new50();
                push(goTo(14), list, false);
            }
            break;
            case 51: /* reduce AAvariableoccursfixedorvariable8OccursFixedOrVariable */
            {
                ArrayList<Object> list = new51();
                push(goTo(14), list, false);
            }
            break;
            case 52: /* reduce AOccursTo */
            {
                ArrayList<Object> list = new52();
                push(goTo(15), list, false);
            }
            break;
            case 53: /* reduce AAascendingordescendingkeyphrase1AscendingOrDescendingKeyPhrase */
            {
                ArrayList<Object> list = new53();
                push(goTo(16), list, false);
            }
            break;
            case 54: /* reduce AAascendingordescendingkeyphrase2AscendingOrDescendingKeyPhrase */
            {
                ArrayList<Object> list = new54();
                push(goTo(16), list, false);
            }
            break;
            case 55: /* reduce AAascendingordescendingkeyphrase3AscendingOrDescendingKeyPhrase */
            {
                ArrayList<Object> list = new55();
                push(goTo(16), list, false);
            }
            break;
            case 56: /* reduce AAascendingordescendingkeyphrase4AscendingOrDescendingKeyPhrase */
            {
                ArrayList<Object> list = new56();
                push(goTo(16), list, false);
            }
            break;
            case 57: /* reduce AAscendingAscendingOrDescending */
            {
                ArrayList<Object> list = new57();
                push(goTo(17), list, false);
            }
            break;
            case 58: /* reduce ADescendingAscendingOrDescending */
            {
                ArrayList<Object> list = new58();
                push(goTo(17), list, false);
            }
            break;
            case 59: /* reduce AAindexedbyphrase1IndexedByPhrase */
            {
                ArrayList<Object> list = new59();
                push(goTo(18), list, false);
            }
            break;
            case 60: /* reduce AAindexedbyphrase2IndexedByPhrase */
            {
                ArrayList<Object> list = new60();
                push(goTo(18), list, false);
            }
            break;
            case 61: /* reduce AApictureclause1PictureClause */
            {
                ArrayList<Object> list = new61();
                push(goTo(19), list, false);
            }
            break;
            case 62: /* reduce AApictureclause2PictureClause */
            {
                ArrayList<Object> list = new62();
                push(goTo(19), list, false);
            }
            break;
            case 63: /* reduce AAsignclause1SignClause */
            {
                ArrayList<Object> list = new63();
                push(goTo(20), list, false);
            }
            break;
            case 64: /* reduce AAsignclause2SignClause */
            {
                ArrayList<Object> list = new64();
                push(goTo(20), list, false);
            }
            break;
            case 65: /* reduce AAsignclause3SignClause */
            {
                ArrayList<Object> list = new65();
                push(goTo(20), list, false);
            }
            break;
            case 66: /* reduce AAsignclause4SignClause */
            {
                ArrayList<Object> list = new66();
                push(goTo(20), list, false);
            }
            break;
            case 67: /* reduce AAsignis1SignIs */
            {
                ArrayList<Object> list = new67();
                push(goTo(21), list, false);
            }
            break;
            case 68: /* reduce AAsignis2SignIs */
            {
                ArrayList<Object> list = new68();
                push(goTo(21), list, false);
            }
            break;
            case 69: /* reduce ALeadingLeadingOrTrailing */
            {
                ArrayList<Object> list = new69();
                push(goTo(22), list, false);
            }
            break;
            case 70: /* reduce ATrailingLeadingOrTrailing */
            {
                ArrayList<Object> list = new70();
                push(goTo(22), list, false);
            }
            break;
            case 71: /* reduce AAseparatecharacter1SeparateCharacter */
            {
                ArrayList<Object> list = new71();
                push(goTo(23), list, false);
            }
            break;
            case 72: /* reduce AAseparatecharacter2SeparateCharacter */
            {
                ArrayList<Object> list = new72();
                push(goTo(23), list, false);
            }
            break;
            case 73: /* reduce AAsynchronizedclause1SynchronizedClause */
            {
                ArrayList<Object> list = new73();
                push(goTo(24), list, false);
            }
            break;
            case 74: /* reduce AAsynchronizedclause2SynchronizedClause */
            {
                ArrayList<Object> list = new74();
                push(goTo(24), list, false);
            }
            break;
            case 75: /* reduce ALeftLeftOrRight */
            {
                ArrayList<Object> list = new75();
                push(goTo(25), list, false);
            }
            break;
            case 76: /* reduce ARightLeftOrRight */
            {
                ArrayList<Object> list = new76();
                push(goTo(25), list, false);
            }
            break;
            case 77: /* reduce AAusageclause1UsageClause */
            {
                ArrayList<Object> list = new77();
                push(goTo(26), list, false);
            }
            break;
            case 78: /* reduce AAusageclause2UsageClause */
            {
                ArrayList<Object> list = new78();
                push(goTo(26), list, false);
            }
            break;
            case 79: /* reduce AAusageis1UsageIs */
            {
                ArrayList<Object> list = new79();
                push(goTo(27), list, false);
            }
            break;
            case 80: /* reduce AAusageis2UsageIs */
            {
                ArrayList<Object> list = new80();
                push(goTo(27), list, false);
            }
            break;
            case 81: /* reduce AAbinaryusagephrase1UsagePhrase */
            {
                ArrayList<Object> list = new81();
                push(goTo(28), list, false);
            }
            break;
            case 82: /* reduce AAbinaryusagephrase2UsagePhrase */
            {
                ArrayList<Object> list = new82();
                push(goTo(28), list, false);
            }
            break;
            case 83: /* reduce ACompUsagePhrase */
            {
                ArrayList<Object> list = new83();
                push(goTo(28), list, false);
            }
            break;
            case 84: /* reduce AAcomp1usagephrase1UsagePhrase */
            {
                ArrayList<Object> list = new84();
                push(goTo(28), list, false);
            }
            break;
            case 85: /* reduce AAcomp1usagephrase2UsagePhrase */
            {
                ArrayList<Object> list = new85();
                push(goTo(28), list, false);
            }
            break;
            case 86: /* reduce AAcomp2usagephrase1UsagePhrase */
            {
                ArrayList<Object> list = new86();
                push(goTo(28), list, false);
            }
            break;
            case 87: /* reduce AAcomp2usagephrase2UsagePhrase */
            {
                ArrayList<Object> list = new87();
                push(goTo(28), list, false);
            }
            break;
            case 88: /* reduce AComp3UsagePhrase */
            {
                ArrayList<Object> list = new88();
                push(goTo(28), list, false);
            }
            break;
            case 89: /* reduce AAcomp4usagephrase1UsagePhrase */
            {
                ArrayList<Object> list = new89();
                push(goTo(28), list, false);
            }
            break;
            case 90: /* reduce AAcomp4usagephrase2UsagePhrase */
            {
                ArrayList<Object> list = new90();
                push(goTo(28), list, false);
            }
            break;
            case 91: /* reduce AComp5UsagePhrase */
            {
                ArrayList<Object> list = new91();
                push(goTo(28), list, false);
            }
            break;
            case 92: /* reduce AComp6UsagePhrase */
            {
                ArrayList<Object> list = new92();
                push(goTo(28), list, false);
            }
            break;
            case 93: /* reduce AAdisplayusagephrase1UsagePhrase */
            {
                ArrayList<Object> list = new93();
                push(goTo(28), list, false);
            }
            break;
            case 94: /* reduce AAdisplayusagephrase2UsagePhrase */
            {
                ArrayList<Object> list = new94();
                push(goTo(28), list, false);
            }
            break;
            case 95: /* reduce AAdisplay1usagephrase1UsagePhrase */
            {
                ArrayList<Object> list = new95();
                push(goTo(28), list, false);
            }
            break;
            case 96: /* reduce AAdisplay1usagephrase2UsagePhrase */
            {
                ArrayList<Object> list = new96();
                push(goTo(28), list, false);
            }
            break;
            case 97: /* reduce AIndexUsagePhrase */
            {
                ArrayList<Object> list = new97();
                push(goTo(28), list, false);
            }
            break;
            case 98: /* reduce ANationalUsagePhrase */
            {
                ArrayList<Object> list = new98();
                push(goTo(28), list, false);
            }
            break;
            case 99: /* reduce AObjectReferencePhraseUsagePhrase */
            {
                ArrayList<Object> list = new99();
                push(goTo(28), list, false);
            }
            break;
            case 100: /* reduce APackedDecimalUsagePhrase */
            {
                ArrayList<Object> list = new100();
                push(goTo(28), list, false);
            }
            break;
            case 101: /* reduce APointerUsagePhrase */
            {
                ArrayList<Object> list = new101();
                push(goTo(28), list, false);
            }
            break;
            case 102: /* reduce AProcedurePointerUsagePhrase */
            {
                ArrayList<Object> list = new102();
                push(goTo(28), list, false);
            }
            break;
            case 103: /* reduce AFunctionPointerUsagePhrase */
            {
                ArrayList<Object> list = new103();
                push(goTo(28), list, false);
            }
            break;
            case 104: /* reduce AAobjectreferencephrase1ObjectReferencePhrase */
            {
                ArrayList<Object> list = new104();
                push(goTo(29), list, false);
            }
            break;
            case 105: /* reduce AAobjectreferencephrase2ObjectReferencePhrase */
            {
                ArrayList<Object> list = new105();
                push(goTo(29), list, false);
            }
            break;
            case 106: /* reduce AArenamesitem1RenamesItem */
            {
                ArrayList<Object> list = new106();
                push(goTo(30), list, false);
            }
            break;
            case 107: /* reduce AArenamesitem2RenamesItem */
            {
                ArrayList<Object> list = new107();
                push(goTo(30), list, false);
            }
            break;
            case 108: /* reduce AThroughPhrase */
            {
                ArrayList<Object> list = new108();
                push(goTo(31), list, false);
            }
            break;
            case 109: /* reduce AAvalueclause1ValueClause */
            {
                ArrayList<Object> list = new109();
                push(goTo(32), list, false);
            }
            break;
            case 110: /* reduce AAvalueclause2ValueClause */
            {
                ArrayList<Object> list = new110();
                push(goTo(32), list, false);
            }
            break;
            case 111: /* reduce AAvalueclause3ValueClause */
            {
                ArrayList<Object> list = new111();
                push(goTo(32), list, false);
            }
            break;
            case 112: /* reduce AAvalueclause4ValueClause */
            {
                ArrayList<Object> list = new112();
                push(goTo(32), list, false);
            }
            break;
            case 113: /* reduce AValueItem */
            {
                ArrayList<Object> list = new113();
                push(goTo(33), list, false);
            }
            break;
            case 114: /* reduce AAvaluevalueorvalues1ValueOrValues */
            {
                ArrayList<Object> list = new114();
                push(goTo(34), list, false);
            }
            break;
            case 115: /* reduce AAvaluevalueorvalues2ValueOrValues */
            {
                ArrayList<Object> list = new115();
                push(goTo(34), list, false);
            }
            break;
            case 116: /* reduce AAvaluesvalueorvalues1ValueOrValues */
            {
                ArrayList<Object> list = new116();
                push(goTo(34), list, false);
            }
            break;
            case 117: /* reduce AAvaluesvalueorvalues2ValueOrValues */
            {
                ArrayList<Object> list = new117();
                push(goTo(34), list, false);
            }
            break;
            case 118: /* reduce AAsingleliteralsequence1LiteralSequence */
            {
                ArrayList<Object> list = new118();
                push(goTo(35), list, false);
            }
            break;
            case 119: /* reduce AAsingleliteralsequence2LiteralSequence */
            {
                ArrayList<Object> list = new119();
                push(goTo(35), list, false);
            }
            break;
            case 120: /* reduce AAsequenceliteralsequence1LiteralSequence */
            {
                ArrayList<Object> list = new120();
                push(goTo(35), list, false);
            }
            break;
            case 121: /* reduce AAsequenceliteralsequence2LiteralSequence */
            {
                ArrayList<Object> list = new121();
                push(goTo(35), list, false);
            }
            break;
            case 122: /* reduce AThroughSingleLiteralSequence */
            {
                ArrayList<Object> list = new122();
                push(goTo(35), list, false);
            }
            break;
            case 123: /* reduce AAthroughsequenceliteralsequence1LiteralSequence */
            {
                ArrayList<Object> list = new123();
                push(goTo(35), list, false);
            }
            break;
            case 124: /* reduce AAthroughsequenceliteralsequence2LiteralSequence */
            {
                ArrayList<Object> list = new124();
                push(goTo(35), list, false);
            }
            break;
            case 125: /* reduce AZerosLiteral */
            {
                ArrayList<Object> list = new125();
                push(goTo(36), list, false);
            }
            break;
            case 126: /* reduce ASpacesLiteral */
            {
                ArrayList<Object> list = new126();
                push(goTo(36), list, false);
            }
            break;
            case 127: /* reduce AHighValuesLiteral */
            {
                ArrayList<Object> list = new127();
                push(goTo(36), list, false);
            }
            break;
            case 128: /* reduce ALowValuesLiteral */
            {
                ArrayList<Object> list = new128();
                push(goTo(36), list, false);
            }
            break;
            case 129: /* reduce AQuotesLiteral */
            {
                ArrayList<Object> list = new129();
                push(goTo(36), list, false);
            }
            break;
            case 130: /* reduce ANullsLiteral */
            {
                ArrayList<Object> list = new130();
                push(goTo(36), list, false);
            }
            break;
            case 131: /* reduce ANumberLiteral */
            {
                ArrayList<Object> list = new131();
                push(goTo(36), list, false);
            }
            break;
            case 132: /* reduce ANumericLiteralLiteral */
            {
                ArrayList<Object> list = new132();
                push(goTo(36), list, false);
            }
            break;
            case 133: /* reduce AAlphanumericLiteralLiteral */
            {
                ArrayList<Object> list = new133();
                push(goTo(36), list, false);
            }
            break;
            case 134: /* reduce ASingleCharacterString */
            {
                ArrayList<Object> list = new134();
                push(goTo(37), list, false);
            }
            break;
            case 135: /* reduce ASequenceCharacterString */
            {
                ArrayList<Object> list = new135();
                push(goTo(37), list, false);
            }
            break;
            case 136: /* reduce ADataNameCharacterSubstring */
            {
                ArrayList<Object> list = new136();
                push(goTo(38), list, false);
            }
            break;
            case 137: /* reduce APlusCharacterSubstring */
            {
                ArrayList<Object> list = new137();
                push(goTo(38), list, false);
            }
            break;
            case 138: /* reduce AMinusCharacterSubstring */
            {
                ArrayList<Object> list = new138();
                push(goTo(38), list, false);
            }
            break;
            case 139: /* reduce AStarCharacterSubstring */
            {
                ArrayList<Object> list = new139();
                push(goTo(38), list, false);
            }
            break;
            case 140: /* reduce ASlashCharacterSubstring */
            {
                ArrayList<Object> list = new140();
                push(goTo(38), list, false);
            }
            break;
            case 141: /* reduce ADollarCharacterSubstring */
            {
                ArrayList<Object> list = new141();
                push(goTo(38), list, false);
            }
            break;
            case 142: /* reduce ACommaCharacterSubstring */
            {
                ArrayList<Object> list = new142();
                push(goTo(38), list, false);
            }
            break;
            case 143: /* reduce ANumberCharacterSubstring */
            {
                ArrayList<Object> list = new143();
                push(goTo(38), list, false);
            }
            break;
            case 144: /* reduce ANumericLiteralCharacterSubstring */
            {
                ArrayList<Object> list = new144();
                push(goTo(38), list, false);
            }
            break;
            case 145: /* reduce ABracketedNumberCharacterSubstring */
            {
                ArrayList<Object> list = new145();
                push(goTo(38), list, false);
            }
            break;
            case 146: /* reduce ADotMinusCharacterSubstring */
            {
                ArrayList<Object> list = new146();
                push(goTo(38), list, false);
            }
            break;
            case 147: /* reduce ADotPlusCharacterSubstring */
            {
                ArrayList<Object> list = new147();
                push(goTo(38), list, false);
            }
            break;
            case 148: /* reduce ADotZeeCharacterSubstring */
            {
                ArrayList<Object> list = new148();
                push(goTo(38), list, false);
            }
            break;
            case 149: /* reduce ABracketedNumber */
            {
                ArrayList<Object> list = new149();
                push(goTo(39), list, false);
            }
            break;
            case 150: /* reduce ANumberNot88Number */
            {
                ArrayList<Object> list = new150();
                push(goTo(40), list, false);
            }
            break;
            case 151: /* reduce ANumber88Number */
            {
                ArrayList<Object> list = new151();
                push(goTo(40), list, false);
            }
            break;
            case 152: /* reduce ATerminal$AscendingOrDescendingKeyPhrase */
            {
                ArrayList<Object> list = new152();
                push(goTo(41), list, true);
            }
            break;
            case 153: /* reduce ANonTerminal$AscendingOrDescendingKeyPhrase */
            {
                ArrayList<Object> list = new153();
                push(goTo(41), list, true);
            }
            break;
            case 154: /* reduce ATerminal$IndexedByPhrase */
            {
                ArrayList<Object> list = new154();
                push(goTo(42), list, true);
            }
            break;
            case 155: /* reduce ANonTerminal$IndexedByPhrase */
            {
                ArrayList<Object> list = new155();
                push(goTo(42), list, true);
            }
            break;
            case 156: /* reduce ATerminal$DataName */
            {
                ArrayList<Object> list = new156();
                push(goTo(43), list, true);
            }
            break;
            case 157: /* reduce ANonTerminal$DataName */
            {
                ArrayList<Object> list = new157();
                push(goTo(43), list, true);
            }
            break;
        }
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new0() /* reduce ARecordDescription */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PRecordDescription precorddescriptionNode1;
        {
            // Block
        PGroupItem pgroupitemNode2;
        TDot tdotNode3;
        pgroupitemNode2 = (PGroupItem)nodeArrayList1.get(0);
        tdotNode3 = (TDot)nodeArrayList2.get(0);

        precorddescriptionNode1 = new ARecordDescription(pgroupitemNode2, tdotNode3);
        }
	nodeList.add(precorddescriptionNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new1() /* reduce ASingleGroupItem */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PGroupItem pgroupitemNode1;
        {
            // Block
        PElementaryItem pelementaryitemNode2;
        pelementaryitemNode2 = (PElementaryItem)nodeArrayList1.get(0);

        pgroupitemNode1 = new ASingleGroupItem(pelementaryitemNode2);
        }
	nodeList.add(pgroupitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new2() /* reduce ASequenceGroupItem */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PGroupItem pgroupitemNode1;
        {
            // Block
        PGroupItem pgroupitemNode2;
        TDot tdotNode3;
        PElementaryItem pelementaryitemNode4;
        pgroupitemNode2 = (PGroupItem)nodeArrayList1.get(0);
        tdotNode3 = (TDot)nodeArrayList2.get(0);
        pelementaryitemNode4 = (PElementaryItem)nodeArrayList3.get(0);

        pgroupitemNode1 = new ASequenceGroupItem(pgroupitemNode2, tdotNode3, pelementaryitemNode4);
        }
	nodeList.add(pgroupitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new3() /* reduce AItemElementaryItem */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PElementaryItem pelementaryitemNode1;
        {
            // Block
        PItem pitemNode2;
        pitemNode2 = (PItem)nodeArrayList1.get(0);

        pelementaryitemNode1 = new AItemElementaryItem(pitemNode2);
        }
	nodeList.add(pelementaryitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new4() /* reduce ARenamesItemElementaryItem */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PElementaryItem pelementaryitemNode1;
        {
            // Block
        PRenamesItem prenamesitemNode2;
        prenamesitemNode2 = (PRenamesItem)nodeArrayList1.get(0);

        pelementaryitemNode1 = new ARenamesItemElementaryItem(prenamesitemNode2);
        }
	nodeList.add(pelementaryitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new5() /* reduce AValueItemElementaryItem */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PElementaryItem pelementaryitemNode1;
        {
            // Block
        PValueItem pvalueitemNode2;
        pvalueitemNode2 = (PValueItem)nodeArrayList1.get(0);

        pelementaryitemNode1 = new AValueItemElementaryItem(pvalueitemNode2);
        }
	nodeList.add(pelementaryitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new6() /* reduce AAitem1Item */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PItem pitemNode1;
        {
            // Block
        TNumberNot88 tnumbernot88Node2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        @SuppressWarnings("unused") Object nullNode4 = null;
        @SuppressWarnings("unused") Object nullNode5 = null;
        tnumbernot88Node2 = (TNumberNot88)nodeArrayList1.get(0);

        pitemNode1 = new AItem(tnumbernot88Node2, null, null, null);
        }
	nodeList.add(pitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new7() /* reduce AAitem2Item */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PItem pitemNode1;
        {
            // Block
        TNumberNot88 tnumbernot88Node2;
        PDataNameOrFiller pdatanameorfillerNode3;
        @SuppressWarnings("unused") Object nullNode4 = null;
        @SuppressWarnings("unused") Object nullNode5 = null;
        tnumbernot88Node2 = (TNumberNot88)nodeArrayList1.get(0);
        pdatanameorfillerNode3 = (PDataNameOrFiller)nodeArrayList2.get(0);

        pitemNode1 = new AItem(tnumbernot88Node2, pdatanameorfillerNode3, null, null);
        }
	nodeList.add(pitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new8() /* reduce AAitem3Item */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PItem pitemNode1;
        {
            // Block
        TNumberNot88 tnumbernot88Node2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        PRedefinesClause predefinesclauseNode4;
        @SuppressWarnings("unused") Object nullNode5 = null;
        tnumbernot88Node2 = (TNumberNot88)nodeArrayList1.get(0);
        predefinesclauseNode4 = (PRedefinesClause)nodeArrayList2.get(0);

        pitemNode1 = new AItem(tnumbernot88Node2, null, predefinesclauseNode4, null);
        }
	nodeList.add(pitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new9() /* reduce AAitem4Item */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PItem pitemNode1;
        {
            // Block
        TNumberNot88 tnumbernot88Node2;
        PDataNameOrFiller pdatanameorfillerNode3;
        PRedefinesClause predefinesclauseNode4;
        @SuppressWarnings("unused") Object nullNode5 = null;
        tnumbernot88Node2 = (TNumberNot88)nodeArrayList1.get(0);
        pdatanameorfillerNode3 = (PDataNameOrFiller)nodeArrayList2.get(0);
        predefinesclauseNode4 = (PRedefinesClause)nodeArrayList3.get(0);

        pitemNode1 = new AItem(tnumbernot88Node2, pdatanameorfillerNode3, predefinesclauseNode4, null);
        }
	nodeList.add(pitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new10() /* reduce AAitem5Item */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PItem pitemNode1;
        {
            // Block
        TNumberNot88 tnumbernot88Node2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        @SuppressWarnings("unused") Object nullNode4 = null;
        PClauseSequence pclausesequenceNode5;
        tnumbernot88Node2 = (TNumberNot88)nodeArrayList1.get(0);
        pclausesequenceNode5 = (PClauseSequence)nodeArrayList2.get(0);

        pitemNode1 = new AItem(tnumbernot88Node2, null, null, pclausesequenceNode5);
        }
	nodeList.add(pitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new11() /* reduce AAitem6Item */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PItem pitemNode1;
        {
            // Block
        TNumberNot88 tnumbernot88Node2;
        PDataNameOrFiller pdatanameorfillerNode3;
        @SuppressWarnings("unused") Object nullNode4 = null;
        PClauseSequence pclausesequenceNode5;
        tnumbernot88Node2 = (TNumberNot88)nodeArrayList1.get(0);
        pdatanameorfillerNode3 = (PDataNameOrFiller)nodeArrayList2.get(0);
        pclausesequenceNode5 = (PClauseSequence)nodeArrayList3.get(0);

        pitemNode1 = new AItem(tnumbernot88Node2, pdatanameorfillerNode3, null, pclausesequenceNode5);
        }
	nodeList.add(pitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new12() /* reduce AAitem7Item */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PItem pitemNode1;
        {
            // Block
        TNumberNot88 tnumbernot88Node2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        PRedefinesClause predefinesclauseNode4;
        PClauseSequence pclausesequenceNode5;
        tnumbernot88Node2 = (TNumberNot88)nodeArrayList1.get(0);
        predefinesclauseNode4 = (PRedefinesClause)nodeArrayList2.get(0);
        pclausesequenceNode5 = (PClauseSequence)nodeArrayList3.get(0);

        pitemNode1 = new AItem(tnumbernot88Node2, null, predefinesclauseNode4, pclausesequenceNode5);
        }
	nodeList.add(pitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new13() /* reduce AAitem8Item */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PItem pitemNode1;
        {
            // Block
        TNumberNot88 tnumbernot88Node2;
        PDataNameOrFiller pdatanameorfillerNode3;
        PRedefinesClause predefinesclauseNode4;
        PClauseSequence pclausesequenceNode5;
        tnumbernot88Node2 = (TNumberNot88)nodeArrayList1.get(0);
        pdatanameorfillerNode3 = (PDataNameOrFiller)nodeArrayList2.get(0);
        predefinesclauseNode4 = (PRedefinesClause)nodeArrayList3.get(0);
        pclausesequenceNode5 = (PClauseSequence)nodeArrayList4.get(0);

        pitemNode1 = new AItem(tnumbernot88Node2, pdatanameorfillerNode3, predefinesclauseNode4, pclausesequenceNode5);
        }
	nodeList.add(pitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new14() /* reduce ADataNameDataNameOrFiller */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PDataNameOrFiller pdatanameorfillerNode1;
        {
            // Block
        TDataName tdatanameNode2;
        tdatanameNode2 = (TDataName)nodeArrayList1.get(0);

        pdatanameorfillerNode1 = new ADataNameDataNameOrFiller(tdatanameNode2);
        }
	nodeList.add(pdatanameorfillerNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new15() /* reduce AFillerDataNameOrFiller */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PDataNameOrFiller pdatanameorfillerNode1;
        {
            // Block
        TFiller tfillerNode2;
        tfillerNode2 = (TFiller)nodeArrayList1.get(0);

        pdatanameorfillerNode1 = new AFillerDataNameOrFiller(tfillerNode2);
        }
	nodeList.add(pdatanameorfillerNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new16() /* reduce ARedefinesClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PRedefinesClause predefinesclauseNode1;
        {
            // Block
        TRedefines tredefinesNode2;
        TDataName tdatanameNode3;
        tredefinesNode2 = (TRedefines)nodeArrayList1.get(0);
        tdatanameNode3 = (TDataName)nodeArrayList2.get(0);

        predefinesclauseNode1 = new ARedefinesClause(tredefinesNode2, tdatanameNode3);
        }
	nodeList.add(predefinesclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new17() /* reduce ASingleClauseSequence */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClauseSequence pclausesequenceNode1;
        {
            // Block
        PClause pclauseNode2;
        pclauseNode2 = (PClause)nodeArrayList1.get(0);

        pclausesequenceNode1 = new ASingleClauseSequence(pclauseNode2);
        }
	nodeList.add(pclausesequenceNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new18() /* reduce ASequenceClauseSequence */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClauseSequence pclausesequenceNode1;
        {
            // Block
        PClauseSequence pclausesequenceNode2;
        PClause pclauseNode3;
        pclausesequenceNode2 = (PClauseSequence)nodeArrayList1.get(0);
        pclauseNode3 = (PClause)nodeArrayList2.get(0);

        pclausesequenceNode1 = new ASequenceClauseSequence(pclausesequenceNode2, pclauseNode3);
        }
	nodeList.add(pclausesequenceNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new19() /* reduce ABlankWhenZeroClauseClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClause pclauseNode1;
        {
            // Block
        PBlankWhenZeroClause pblankwhenzeroclauseNode2;
        pblankwhenzeroclauseNode2 = (PBlankWhenZeroClause)nodeArrayList1.get(0);

        pclauseNode1 = new ABlankWhenZeroClauseClause(pblankwhenzeroclauseNode2);
        }
	nodeList.add(pclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new20() /* reduce ADateFormatClauseClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClause pclauseNode1;
        {
            // Block
        PDateFormatClause pdateformatclauseNode2;
        pdateformatclauseNode2 = (PDateFormatClause)nodeArrayList1.get(0);

        pclauseNode1 = new ADateFormatClauseClause(pdateformatclauseNode2);
        }
	nodeList.add(pclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new21() /* reduce AExternalClauseClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClause pclauseNode1;
        {
            // Block
        PExternalClause pexternalclauseNode2;
        pexternalclauseNode2 = (PExternalClause)nodeArrayList1.get(0);

        pclauseNode1 = new AExternalClauseClause(pexternalclauseNode2);
        }
	nodeList.add(pclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new22() /* reduce AGlobalClauseClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClause pclauseNode1;
        {
            // Block
        PGlobalClause pglobalclauseNode2;
        pglobalclauseNode2 = (PGlobalClause)nodeArrayList1.get(0);

        pclauseNode1 = new AGlobalClauseClause(pglobalclauseNode2);
        }
	nodeList.add(pclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new23() /* reduce AJustifiedClauseClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClause pclauseNode1;
        {
            // Block
        PJustifiedClause pjustifiedclauseNode2;
        pjustifiedclauseNode2 = (PJustifiedClause)nodeArrayList1.get(0);

        pclauseNode1 = new AJustifiedClauseClause(pjustifiedclauseNode2);
        }
	nodeList.add(pclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new24() /* reduce AOccursClauseClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClause pclauseNode1;
        {
            // Block
        POccursClause poccursclauseNode2;
        poccursclauseNode2 = (POccursClause)nodeArrayList1.get(0);

        pclauseNode1 = new AOccursClauseClause(poccursclauseNode2);
        }
	nodeList.add(pclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new25() /* reduce APictureClauseClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClause pclauseNode1;
        {
            // Block
        PPictureClause ppictureclauseNode2;
        ppictureclauseNode2 = (PPictureClause)nodeArrayList1.get(0);

        pclauseNode1 = new APictureClauseClause(ppictureclauseNode2);
        }
	nodeList.add(pclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new26() /* reduce ASignClauseClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClause pclauseNode1;
        {
            // Block
        PSignClause psignclauseNode2;
        psignclauseNode2 = (PSignClause)nodeArrayList1.get(0);

        pclauseNode1 = new ASignClauseClause(psignclauseNode2);
        }
	nodeList.add(pclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new27() /* reduce ASynchronizedClauseClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClause pclauseNode1;
        {
            // Block
        PSynchronizedClause psynchronizedclauseNode2;
        psynchronizedclauseNode2 = (PSynchronizedClause)nodeArrayList1.get(0);

        pclauseNode1 = new ASynchronizedClauseClause(psynchronizedclauseNode2);
        }
	nodeList.add(pclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new28() /* reduce AUsageClauseClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClause pclauseNode1;
        {
            // Block
        PUsageClause pusageclauseNode2;
        pusageclauseNode2 = (PUsageClause)nodeArrayList1.get(0);

        pclauseNode1 = new AUsageClauseClause(pusageclauseNode2);
        }
	nodeList.add(pclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new29() /* reduce AValueClauseClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PClause pclauseNode1;
        {
            // Block
        PValueClause pvalueclauseNode2;
        pvalueclauseNode2 = (PValueClause)nodeArrayList1.get(0);

        pclauseNode1 = new AValueClauseClause(pvalueclauseNode2);
        }
	nodeList.add(pclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new30() /* reduce AAblankwhenzeroclause1BlankWhenZeroClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PBlankWhenZeroClause pblankwhenzeroclauseNode1;
        {
            // Block
        TBlank tblankNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        TZeros tzerosNode4;
        tblankNode2 = (TBlank)nodeArrayList1.get(0);
        tzerosNode4 = (TZeros)nodeArrayList2.get(0);

        pblankwhenzeroclauseNode1 = new ABlankWhenZeroClause(tblankNode2, null, tzerosNode4);
        }
	nodeList.add(pblankwhenzeroclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new31() /* reduce AAblankwhenzeroclause2BlankWhenZeroClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PBlankWhenZeroClause pblankwhenzeroclauseNode1;
        {
            // Block
        TBlank tblankNode2;
        TWhen twhenNode3;
        TZeros tzerosNode4;
        tblankNode2 = (TBlank)nodeArrayList1.get(0);
        twhenNode3 = (TWhen)nodeArrayList2.get(0);
        tzerosNode4 = (TZeros)nodeArrayList3.get(0);

        pblankwhenzeroclauseNode1 = new ABlankWhenZeroClause(tblankNode2, twhenNode3, tzerosNode4);
        }
	nodeList.add(pblankwhenzeroclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new32() /* reduce AAdateformatclause1DateFormatClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PDateFormatClause pdateformatclauseNode1;
        {
            // Block
        TDate tdateNode2;
        TFormat tformatNode3;
        @SuppressWarnings("unused") Object nullNode4 = null;
        TDataName tdatanameNode5;
        tdateNode2 = (TDate)nodeArrayList1.get(0);
        tformatNode3 = (TFormat)nodeArrayList2.get(0);
        tdatanameNode5 = (TDataName)nodeArrayList3.get(0);

        pdateformatclauseNode1 = new ADateFormatClause(tdateNode2, tformatNode3, null, tdatanameNode5);
        }
	nodeList.add(pdateformatclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new33() /* reduce AAdateformatclause2DateFormatClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PDateFormatClause pdateformatclauseNode1;
        {
            // Block
        TDate tdateNode2;
        TFormat tformatNode3;
        TIs tisNode4;
        TDataName tdatanameNode5;
        tdateNode2 = (TDate)nodeArrayList1.get(0);
        tformatNode3 = (TFormat)nodeArrayList2.get(0);
        tisNode4 = (TIs)nodeArrayList3.get(0);
        tdatanameNode5 = (TDataName)nodeArrayList4.get(0);

        pdateformatclauseNode1 = new ADateFormatClause(tdateNode2, tformatNode3, tisNode4, tdatanameNode5);
        }
	nodeList.add(pdateformatclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new34() /* reduce AExternalClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PExternalClause pexternalclauseNode1;
        {
            // Block
        TExternal texternalNode2;
        texternalNode2 = (TExternal)nodeArrayList1.get(0);

        pexternalclauseNode1 = new AExternalClause(texternalNode2);
        }
	nodeList.add(pexternalclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new35() /* reduce AGlobalClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PGlobalClause pglobalclauseNode1;
        {
            // Block
        TGlobal tglobalNode2;
        tglobalNode2 = (TGlobal)nodeArrayList1.get(0);

        pglobalclauseNode1 = new AGlobalClause(tglobalNode2);
        }
	nodeList.add(pglobalclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new36() /* reduce AAjustifiedclause1JustifiedClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PJustifiedClause pjustifiedclauseNode1;
        {
            // Block
        TJustified tjustifiedNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tjustifiedNode2 = (TJustified)nodeArrayList1.get(0);

        pjustifiedclauseNode1 = new AJustifiedClause(tjustifiedNode2, null);
        }
	nodeList.add(pjustifiedclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new37() /* reduce AAjustifiedclause2JustifiedClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PJustifiedClause pjustifiedclauseNode1;
        {
            // Block
        TJustified tjustifiedNode2;
        TRight trightNode3;
        tjustifiedNode2 = (TJustified)nodeArrayList1.get(0);
        trightNode3 = (TRight)nodeArrayList2.get(0);

        pjustifiedclauseNode1 = new AJustifiedClause(tjustifiedNode2, trightNode3);
        }
	nodeList.add(pjustifiedclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new38() /* reduce AAoccursclause1OccursClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursClause poccursclauseNode1;
        {
            // Block
        POccursFixedOrVariable poccursfixedorvariableNode2;
        LinkedList<Object> listNode3 = new LinkedList<Object>();
        LinkedList<Object> listNode4 = new LinkedList<Object>();
        poccursfixedorvariableNode2 = (POccursFixedOrVariable)nodeArrayList1.get(0);
        {
            // Block
        }
        {
            // Block
        }

        poccursclauseNode1 = new AOccursClause(poccursfixedorvariableNode2, listNode3, listNode4);
        }
	nodeList.add(poccursclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new39() /* reduce AAoccursclause2OccursClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursClause poccursclauseNode1;
        {
            // Block
        POccursFixedOrVariable poccursfixedorvariableNode2;
        LinkedList<Object> listNode4 = new LinkedList<Object>();
        LinkedList<Object> listNode5 = new LinkedList<Object>();
        poccursfixedorvariableNode2 = (POccursFixedOrVariable)nodeArrayList1.get(0);
        {
            // Block
        LinkedList<Object> listNode3 = new LinkedList<Object>();
        listNode3 = (LinkedList)nodeArrayList2.get(0);
	if(listNode3 != null)
	{
	  listNode4.addAll(listNode3);
	}
        }
        {
            // Block
        }

        poccursclauseNode1 = new AOccursClause(poccursfixedorvariableNode2, listNode4, listNode5);
        }
	nodeList.add(poccursclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new40() /* reduce AAoccursclause3OccursClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursClause poccursclauseNode1;
        {
            // Block
        POccursFixedOrVariable poccursfixedorvariableNode2;
        LinkedList<Object> listNode3 = new LinkedList<Object>();
        LinkedList<Object> listNode5 = new LinkedList<Object>();
        poccursfixedorvariableNode2 = (POccursFixedOrVariable)nodeArrayList1.get(0);
        {
            // Block
        }
        {
            // Block
        LinkedList<Object> listNode4 = new LinkedList<Object>();
        listNode4 = (LinkedList)nodeArrayList2.get(0);
	if(listNode4 != null)
	{
	  listNode5.addAll(listNode4);
	}
        }

        poccursclauseNode1 = new AOccursClause(poccursfixedorvariableNode2, listNode3, listNode5);
        }
	nodeList.add(poccursclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new41() /* reduce AAoccursclause4OccursClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursClause poccursclauseNode1;
        {
            // Block
        POccursFixedOrVariable poccursfixedorvariableNode2;
        LinkedList<Object> listNode4 = new LinkedList<Object>();
        LinkedList<Object> listNode6 = new LinkedList<Object>();
        poccursfixedorvariableNode2 = (POccursFixedOrVariable)nodeArrayList1.get(0);
        {
            // Block
        LinkedList<Object> listNode3 = new LinkedList<Object>();
        listNode3 = (LinkedList)nodeArrayList2.get(0);
	if(listNode3 != null)
	{
	  listNode4.addAll(listNode3);
	}
        }
        {
            // Block
        LinkedList<Object> listNode5 = new LinkedList<Object>();
        listNode5 = (LinkedList)nodeArrayList3.get(0);
	if(listNode5 != null)
	{
	  listNode6.addAll(listNode5);
	}
        }

        poccursclauseNode1 = new AOccursClause(poccursfixedorvariableNode2, listNode4, listNode6);
        }
	nodeList.add(poccursclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new42() /* reduce AAfixedoccursfixedorvariable1OccursFixedOrVariable */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursFixedOrVariable poccursfixedorvariableNode1;
        {
            // Block
        TOccurs toccursNode2;
        PNumber pnumberNode3;
        @SuppressWarnings("unused") Object nullNode4 = null;
        toccursNode2 = (TOccurs)nodeArrayList1.get(0);
        pnumberNode3 = (PNumber)nodeArrayList2.get(0);

        poccursfixedorvariableNode1 = new AFixedOccursFixedOrVariable(toccursNode2, pnumberNode3, null);
        }
	nodeList.add(poccursfixedorvariableNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new43() /* reduce AAfixedoccursfixedorvariable2OccursFixedOrVariable */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursFixedOrVariable poccursfixedorvariableNode1;
        {
            // Block
        TOccurs toccursNode2;
        PNumber pnumberNode3;
        TTimes ttimesNode4;
        toccursNode2 = (TOccurs)nodeArrayList1.get(0);
        pnumberNode3 = (PNumber)nodeArrayList2.get(0);
        ttimesNode4 = (TTimes)nodeArrayList3.get(0);

        poccursfixedorvariableNode1 = new AFixedOccursFixedOrVariable(toccursNode2, pnumberNode3, ttimesNode4);
        }
	nodeList.add(poccursfixedorvariableNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new44() /* reduce AAvariableoccursfixedorvariable1OccursFixedOrVariable */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursFixedOrVariable poccursfixedorvariableNode1;
        {
            // Block
        TOccurs toccursNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        PNumber pnumberNode4;
        @SuppressWarnings("unused") Object nullNode5 = null;
        TDepending tdependingNode6;
        @SuppressWarnings("unused") Object nullNode7 = null;
        TDataName tdatanameNode8;
        toccursNode2 = (TOccurs)nodeArrayList1.get(0);
        pnumberNode4 = (PNumber)nodeArrayList2.get(0);
        tdependingNode6 = (TDepending)nodeArrayList3.get(0);
        tdatanameNode8 = (TDataName)nodeArrayList4.get(0);

        poccursfixedorvariableNode1 = new AVariableOccursFixedOrVariable(toccursNode2, null, pnumberNode4, null, tdependingNode6, null, tdatanameNode8);
        }
	nodeList.add(poccursfixedorvariableNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new45() /* reduce AAvariableoccursfixedorvariable2OccursFixedOrVariable */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList5 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursFixedOrVariable poccursfixedorvariableNode1;
        {
            // Block
        TOccurs toccursNode2;
        POccursTo poccurstoNode3;
        PNumber pnumberNode4;
        @SuppressWarnings("unused") Object nullNode5 = null;
        TDepending tdependingNode6;
        @SuppressWarnings("unused") Object nullNode7 = null;
        TDataName tdatanameNode8;
        toccursNode2 = (TOccurs)nodeArrayList1.get(0);
        poccurstoNode3 = (POccursTo)nodeArrayList2.get(0);
        pnumberNode4 = (PNumber)nodeArrayList3.get(0);
        tdependingNode6 = (TDepending)nodeArrayList4.get(0);
        tdatanameNode8 = (TDataName)nodeArrayList5.get(0);

        poccursfixedorvariableNode1 = new AVariableOccursFixedOrVariable(toccursNode2, poccurstoNode3, pnumberNode4, null, tdependingNode6, null, tdatanameNode8);
        }
	nodeList.add(poccursfixedorvariableNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new46() /* reduce AAvariableoccursfixedorvariable3OccursFixedOrVariable */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList5 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursFixedOrVariable poccursfixedorvariableNode1;
        {
            // Block
        TOccurs toccursNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        PNumber pnumberNode4;
        TTimes ttimesNode5;
        TDepending tdependingNode6;
        @SuppressWarnings("unused") Object nullNode7 = null;
        TDataName tdatanameNode8;
        toccursNode2 = (TOccurs)nodeArrayList1.get(0);
        pnumberNode4 = (PNumber)nodeArrayList2.get(0);
        ttimesNode5 = (TTimes)nodeArrayList3.get(0);
        tdependingNode6 = (TDepending)nodeArrayList4.get(0);
        tdatanameNode8 = (TDataName)nodeArrayList5.get(0);

        poccursfixedorvariableNode1 = new AVariableOccursFixedOrVariable(toccursNode2, null, pnumberNode4, ttimesNode5, tdependingNode6, null, tdatanameNode8);
        }
	nodeList.add(poccursfixedorvariableNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new47() /* reduce AAvariableoccursfixedorvariable4OccursFixedOrVariable */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList6 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList5 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursFixedOrVariable poccursfixedorvariableNode1;
        {
            // Block
        TOccurs toccursNode2;
        POccursTo poccurstoNode3;
        PNumber pnumberNode4;
        TTimes ttimesNode5;
        TDepending tdependingNode6;
        @SuppressWarnings("unused") Object nullNode7 = null;
        TDataName tdatanameNode8;
        toccursNode2 = (TOccurs)nodeArrayList1.get(0);
        poccurstoNode3 = (POccursTo)nodeArrayList2.get(0);
        pnumberNode4 = (PNumber)nodeArrayList3.get(0);
        ttimesNode5 = (TTimes)nodeArrayList4.get(0);
        tdependingNode6 = (TDepending)nodeArrayList5.get(0);
        tdatanameNode8 = (TDataName)nodeArrayList6.get(0);

        poccursfixedorvariableNode1 = new AVariableOccursFixedOrVariable(toccursNode2, poccurstoNode3, pnumberNode4, ttimesNode5, tdependingNode6, null, tdatanameNode8);
        }
	nodeList.add(poccursfixedorvariableNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new48() /* reduce AAvariableoccursfixedorvariable5OccursFixedOrVariable */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList5 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursFixedOrVariable poccursfixedorvariableNode1;
        {
            // Block
        TOccurs toccursNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        PNumber pnumberNode4;
        @SuppressWarnings("unused") Object nullNode5 = null;
        TDepending tdependingNode6;
        TOn tonNode7;
        TDataName tdatanameNode8;
        toccursNode2 = (TOccurs)nodeArrayList1.get(0);
        pnumberNode4 = (PNumber)nodeArrayList2.get(0);
        tdependingNode6 = (TDepending)nodeArrayList3.get(0);
        tonNode7 = (TOn)nodeArrayList4.get(0);
        tdatanameNode8 = (TDataName)nodeArrayList5.get(0);

        poccursfixedorvariableNode1 = new AVariableOccursFixedOrVariable(toccursNode2, null, pnumberNode4, null, tdependingNode6, tonNode7, tdatanameNode8);
        }
	nodeList.add(poccursfixedorvariableNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new49() /* reduce AAvariableoccursfixedorvariable6OccursFixedOrVariable */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList6 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList5 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursFixedOrVariable poccursfixedorvariableNode1;
        {
            // Block
        TOccurs toccursNode2;
        POccursTo poccurstoNode3;
        PNumber pnumberNode4;
        @SuppressWarnings("unused") Object nullNode5 = null;
        TDepending tdependingNode6;
        TOn tonNode7;
        TDataName tdatanameNode8;
        toccursNode2 = (TOccurs)nodeArrayList1.get(0);
        poccurstoNode3 = (POccursTo)nodeArrayList2.get(0);
        pnumberNode4 = (PNumber)nodeArrayList3.get(0);
        tdependingNode6 = (TDepending)nodeArrayList4.get(0);
        tonNode7 = (TOn)nodeArrayList5.get(0);
        tdatanameNode8 = (TDataName)nodeArrayList6.get(0);

        poccursfixedorvariableNode1 = new AVariableOccursFixedOrVariable(toccursNode2, poccurstoNode3, pnumberNode4, null, tdependingNode6, tonNode7, tdatanameNode8);
        }
	nodeList.add(poccursfixedorvariableNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new50() /* reduce AAvariableoccursfixedorvariable7OccursFixedOrVariable */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList6 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList5 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursFixedOrVariable poccursfixedorvariableNode1;
        {
            // Block
        TOccurs toccursNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        PNumber pnumberNode4;
        TTimes ttimesNode5;
        TDepending tdependingNode6;
        TOn tonNode7;
        TDataName tdatanameNode8;
        toccursNode2 = (TOccurs)nodeArrayList1.get(0);
        pnumberNode4 = (PNumber)nodeArrayList2.get(0);
        ttimesNode5 = (TTimes)nodeArrayList3.get(0);
        tdependingNode6 = (TDepending)nodeArrayList4.get(0);
        tonNode7 = (TOn)nodeArrayList5.get(0);
        tdatanameNode8 = (TDataName)nodeArrayList6.get(0);

        poccursfixedorvariableNode1 = new AVariableOccursFixedOrVariable(toccursNode2, null, pnumberNode4, ttimesNode5, tdependingNode6, tonNode7, tdatanameNode8);
        }
	nodeList.add(poccursfixedorvariableNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new51() /* reduce AAvariableoccursfixedorvariable8OccursFixedOrVariable */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList7 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList6 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList5 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursFixedOrVariable poccursfixedorvariableNode1;
        {
            // Block
        TOccurs toccursNode2;
        POccursTo poccurstoNode3;
        PNumber pnumberNode4;
        TTimes ttimesNode5;
        TDepending tdependingNode6;
        TOn tonNode7;
        TDataName tdatanameNode8;
        toccursNode2 = (TOccurs)nodeArrayList1.get(0);
        poccurstoNode3 = (POccursTo)nodeArrayList2.get(0);
        pnumberNode4 = (PNumber)nodeArrayList3.get(0);
        ttimesNode5 = (TTimes)nodeArrayList4.get(0);
        tdependingNode6 = (TDepending)nodeArrayList5.get(0);
        tonNode7 = (TOn)nodeArrayList6.get(0);
        tdatanameNode8 = (TDataName)nodeArrayList7.get(0);

        poccursfixedorvariableNode1 = new AVariableOccursFixedOrVariable(toccursNode2, poccurstoNode3, pnumberNode4, ttimesNode5, tdependingNode6, tonNode7, tdatanameNode8);
        }
	nodeList.add(poccursfixedorvariableNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new52() /* reduce AOccursTo */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        POccursTo poccurstoNode1;
        {
            // Block
        PNumber pnumberNode2;
        TTo ttoNode3;
        pnumberNode2 = (PNumber)nodeArrayList1.get(0);
        ttoNode3 = (TTo)nodeArrayList2.get(0);

        poccurstoNode1 = new AOccursTo(pnumberNode2, ttoNode3);
        }
	nodeList.add(poccurstoNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new53() /* reduce AAascendingordescendingkeyphrase1AscendingOrDescendingKeyPhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PAscendingOrDescendingKeyPhrase pascendingordescendingkeyphraseNode1;
        {
            // Block
        PAscendingOrDescending pascendingordescendingNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        @SuppressWarnings("unused") Object nullNode4 = null;
        LinkedList<Object> listNode6 = new LinkedList<Object>();
        pascendingordescendingNode2 = (PAscendingOrDescending)nodeArrayList1.get(0);
        {
            // Block
        LinkedList<Object> listNode5 = new LinkedList<Object>();
        listNode5 = (LinkedList)nodeArrayList2.get(0);
	if(listNode5 != null)
	{
	  listNode6.addAll(listNode5);
	}
        }

        pascendingordescendingkeyphraseNode1 = new AAscendingOrDescendingKeyPhrase(pascendingordescendingNode2, null, null, listNode6);
        }
	nodeList.add(pascendingordescendingkeyphraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new54() /* reduce AAascendingordescendingkeyphrase2AscendingOrDescendingKeyPhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PAscendingOrDescendingKeyPhrase pascendingordescendingkeyphraseNode1;
        {
            // Block
        PAscendingOrDescending pascendingordescendingNode2;
        TKey tkeyNode3;
        @SuppressWarnings("unused") Object nullNode4 = null;
        LinkedList<Object> listNode6 = new LinkedList<Object>();
        pascendingordescendingNode2 = (PAscendingOrDescending)nodeArrayList1.get(0);
        tkeyNode3 = (TKey)nodeArrayList2.get(0);
        {
            // Block
        LinkedList<Object> listNode5 = new LinkedList<Object>();
        listNode5 = (LinkedList)nodeArrayList3.get(0);
	if(listNode5 != null)
	{
	  listNode6.addAll(listNode5);
	}
        }

        pascendingordescendingkeyphraseNode1 = new AAscendingOrDescendingKeyPhrase(pascendingordescendingNode2, tkeyNode3, null, listNode6);
        }
	nodeList.add(pascendingordescendingkeyphraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new55() /* reduce AAascendingordescendingkeyphrase3AscendingOrDescendingKeyPhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PAscendingOrDescendingKeyPhrase pascendingordescendingkeyphraseNode1;
        {
            // Block
        PAscendingOrDescending pascendingordescendingNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        TIs tisNode4;
        LinkedList<Object> listNode6 = new LinkedList<Object>();
        pascendingordescendingNode2 = (PAscendingOrDescending)nodeArrayList1.get(0);
        tisNode4 = (TIs)nodeArrayList2.get(0);
        {
            // Block
        LinkedList<Object> listNode5 = new LinkedList<Object>();
        listNode5 = (LinkedList)nodeArrayList3.get(0);
	if(listNode5 != null)
	{
	  listNode6.addAll(listNode5);
	}
        }

        pascendingordescendingkeyphraseNode1 = new AAscendingOrDescendingKeyPhrase(pascendingordescendingNode2, null, tisNode4, listNode6);
        }
	nodeList.add(pascendingordescendingkeyphraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new56() /* reduce AAascendingordescendingkeyphrase4AscendingOrDescendingKeyPhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PAscendingOrDescendingKeyPhrase pascendingordescendingkeyphraseNode1;
        {
            // Block
        PAscendingOrDescending pascendingordescendingNode2;
        TKey tkeyNode3;
        TIs tisNode4;
        LinkedList<Object> listNode6 = new LinkedList<Object>();
        pascendingordescendingNode2 = (PAscendingOrDescending)nodeArrayList1.get(0);
        tkeyNode3 = (TKey)nodeArrayList2.get(0);
        tisNode4 = (TIs)nodeArrayList3.get(0);
        {
            // Block
        LinkedList<Object> listNode5 = new LinkedList<Object>();
        listNode5 = (LinkedList)nodeArrayList4.get(0);
	if(listNode5 != null)
	{
	  listNode6.addAll(listNode5);
	}
        }

        pascendingordescendingkeyphraseNode1 = new AAscendingOrDescendingKeyPhrase(pascendingordescendingNode2, tkeyNode3, tisNode4, listNode6);
        }
	nodeList.add(pascendingordescendingkeyphraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new57() /* reduce AAscendingAscendingOrDescending */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PAscendingOrDescending pascendingordescendingNode1;
        {
            // Block
        TAscending tascendingNode2;
        tascendingNode2 = (TAscending)nodeArrayList1.get(0);

        pascendingordescendingNode1 = new AAscendingAscendingOrDescending(tascendingNode2);
        }
	nodeList.add(pascendingordescendingNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new58() /* reduce ADescendingAscendingOrDescending */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PAscendingOrDescending pascendingordescendingNode1;
        {
            // Block
        TDescending tdescendingNode2;
        tdescendingNode2 = (TDescending)nodeArrayList1.get(0);

        pascendingordescendingNode1 = new ADescendingAscendingOrDescending(tdescendingNode2);
        }
	nodeList.add(pascendingordescendingNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new59() /* reduce AAindexedbyphrase1IndexedByPhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PIndexedByPhrase pindexedbyphraseNode1;
        {
            // Block
        TIndexed tindexedNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        LinkedList<Object> listNode5 = new LinkedList<Object>();
        tindexedNode2 = (TIndexed)nodeArrayList1.get(0);
        {
            // Block
        LinkedList<Object> listNode4 = new LinkedList<Object>();
        listNode4 = (LinkedList)nodeArrayList2.get(0);
	if(listNode4 != null)
	{
	  listNode5.addAll(listNode4);
	}
        }

        pindexedbyphraseNode1 = new AIndexedByPhrase(tindexedNode2, null, listNode5);
        }
	nodeList.add(pindexedbyphraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new60() /* reduce AAindexedbyphrase2IndexedByPhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PIndexedByPhrase pindexedbyphraseNode1;
        {
            // Block
        TIndexed tindexedNode2;
        TBy tbyNode3;
        LinkedList<Object> listNode5 = new LinkedList<Object>();
        tindexedNode2 = (TIndexed)nodeArrayList1.get(0);
        tbyNode3 = (TBy)nodeArrayList2.get(0);
        {
            // Block
        LinkedList<Object> listNode4 = new LinkedList<Object>();
        listNode4 = (LinkedList)nodeArrayList3.get(0);
	if(listNode4 != null)
	{
	  listNode5.addAll(listNode4);
	}
        }

        pindexedbyphraseNode1 = new AIndexedByPhrase(tindexedNode2, tbyNode3, listNode5);
        }
	nodeList.add(pindexedbyphraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new61() /* reduce AApictureclause1PictureClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PPictureClause ppictureclauseNode1;
        {
            // Block
        TPicture tpictureNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        PCharacterString pcharacterstringNode4;
        tpictureNode2 = (TPicture)nodeArrayList1.get(0);
        pcharacterstringNode4 = (PCharacterString)nodeArrayList2.get(0);

        ppictureclauseNode1 = new APictureClause(tpictureNode2, null, pcharacterstringNode4);
        }
	nodeList.add(ppictureclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new62() /* reduce AApictureclause2PictureClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PPictureClause ppictureclauseNode1;
        {
            // Block
        TPicture tpictureNode2;
        TIs tisNode3;
        PCharacterString pcharacterstringNode4;
        tpictureNode2 = (TPicture)nodeArrayList1.get(0);
        tisNode3 = (TIs)nodeArrayList2.get(0);
        pcharacterstringNode4 = (PCharacterString)nodeArrayList3.get(0);

        ppictureclauseNode1 = new APictureClause(tpictureNode2, tisNode3, pcharacterstringNode4);
        }
	nodeList.add(ppictureclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new63() /* reduce AAsignclause1SignClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PSignClause psignclauseNode1;
        {
            // Block
        @SuppressWarnings("unused") Object nullNode2 = null;
        PLeadingOrTrailing pleadingortrailingNode3;
        @SuppressWarnings("unused") Object nullNode4 = null;
        pleadingortrailingNode3 = (PLeadingOrTrailing)nodeArrayList1.get(0);

        psignclauseNode1 = new ASignClause(null, pleadingortrailingNode3, null);
        }
	nodeList.add(psignclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new64() /* reduce AAsignclause2SignClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PSignClause psignclauseNode1;
        {
            // Block
        PSignIs psignisNode2;
        PLeadingOrTrailing pleadingortrailingNode3;
        @SuppressWarnings("unused") Object nullNode4 = null;
        psignisNode2 = (PSignIs)nodeArrayList1.get(0);
        pleadingortrailingNode3 = (PLeadingOrTrailing)nodeArrayList2.get(0);

        psignclauseNode1 = new ASignClause(psignisNode2, pleadingortrailingNode3, null);
        }
	nodeList.add(psignclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new65() /* reduce AAsignclause3SignClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PSignClause psignclauseNode1;
        {
            // Block
        @SuppressWarnings("unused") Object nullNode2 = null;
        PLeadingOrTrailing pleadingortrailingNode3;
        PSeparateCharacter pseparatecharacterNode4;
        pleadingortrailingNode3 = (PLeadingOrTrailing)nodeArrayList1.get(0);
        pseparatecharacterNode4 = (PSeparateCharacter)nodeArrayList2.get(0);

        psignclauseNode1 = new ASignClause(null, pleadingortrailingNode3, pseparatecharacterNode4);
        }
	nodeList.add(psignclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new66() /* reduce AAsignclause4SignClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PSignClause psignclauseNode1;
        {
            // Block
        PSignIs psignisNode2;
        PLeadingOrTrailing pleadingortrailingNode3;
        PSeparateCharacter pseparatecharacterNode4;
        psignisNode2 = (PSignIs)nodeArrayList1.get(0);
        pleadingortrailingNode3 = (PLeadingOrTrailing)nodeArrayList2.get(0);
        pseparatecharacterNode4 = (PSeparateCharacter)nodeArrayList3.get(0);

        psignclauseNode1 = new ASignClause(psignisNode2, pleadingortrailingNode3, pseparatecharacterNode4);
        }
	nodeList.add(psignclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new67() /* reduce AAsignis1SignIs */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PSignIs psignisNode1;
        {
            // Block
        TSign tsignNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tsignNode2 = (TSign)nodeArrayList1.get(0);

        psignisNode1 = new ASignIs(tsignNode2, null);
        }
	nodeList.add(psignisNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new68() /* reduce AAsignis2SignIs */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PSignIs psignisNode1;
        {
            // Block
        TSign tsignNode2;
        TIs tisNode3;
        tsignNode2 = (TSign)nodeArrayList1.get(0);
        tisNode3 = (TIs)nodeArrayList2.get(0);

        psignisNode1 = new ASignIs(tsignNode2, tisNode3);
        }
	nodeList.add(psignisNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new69() /* reduce ALeadingLeadingOrTrailing */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLeadingOrTrailing pleadingortrailingNode1;
        {
            // Block
        TLeading tleadingNode2;
        tleadingNode2 = (TLeading)nodeArrayList1.get(0);

        pleadingortrailingNode1 = new ALeadingLeadingOrTrailing(tleadingNode2);
        }
	nodeList.add(pleadingortrailingNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new70() /* reduce ATrailingLeadingOrTrailing */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLeadingOrTrailing pleadingortrailingNode1;
        {
            // Block
        TTrailing ttrailingNode2;
        ttrailingNode2 = (TTrailing)nodeArrayList1.get(0);

        pleadingortrailingNode1 = new ATrailingLeadingOrTrailing(ttrailingNode2);
        }
	nodeList.add(pleadingortrailingNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new71() /* reduce AAseparatecharacter1SeparateCharacter */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PSeparateCharacter pseparatecharacterNode1;
        {
            // Block
        TSeparate tseparateNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tseparateNode2 = (TSeparate)nodeArrayList1.get(0);

        pseparatecharacterNode1 = new ASeparateCharacter(tseparateNode2, null);
        }
	nodeList.add(pseparatecharacterNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new72() /* reduce AAseparatecharacter2SeparateCharacter */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PSeparateCharacter pseparatecharacterNode1;
        {
            // Block
        TSeparate tseparateNode2;
        TCharacter tcharacterNode3;
        tseparateNode2 = (TSeparate)nodeArrayList1.get(0);
        tcharacterNode3 = (TCharacter)nodeArrayList2.get(0);

        pseparatecharacterNode1 = new ASeparateCharacter(tseparateNode2, tcharacterNode3);
        }
	nodeList.add(pseparatecharacterNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new73() /* reduce AAsynchronizedclause1SynchronizedClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PSynchronizedClause psynchronizedclauseNode1;
        {
            // Block
        TSynchronized tsynchronizedNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tsynchronizedNode2 = (TSynchronized)nodeArrayList1.get(0);

        psynchronizedclauseNode1 = new ASynchronizedClause(tsynchronizedNode2, null);
        }
	nodeList.add(psynchronizedclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new74() /* reduce AAsynchronizedclause2SynchronizedClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PSynchronizedClause psynchronizedclauseNode1;
        {
            // Block
        TSynchronized tsynchronizedNode2;
        PLeftOrRight pleftorrightNode3;
        tsynchronizedNode2 = (TSynchronized)nodeArrayList1.get(0);
        pleftorrightNode3 = (PLeftOrRight)nodeArrayList2.get(0);

        psynchronizedclauseNode1 = new ASynchronizedClause(tsynchronizedNode2, pleftorrightNode3);
        }
	nodeList.add(psynchronizedclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new75() /* reduce ALeftLeftOrRight */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLeftOrRight pleftorrightNode1;
        {
            // Block
        TLeft tleftNode2;
        tleftNode2 = (TLeft)nodeArrayList1.get(0);

        pleftorrightNode1 = new ALeftLeftOrRight(tleftNode2);
        }
	nodeList.add(pleftorrightNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new76() /* reduce ARightLeftOrRight */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLeftOrRight pleftorrightNode1;
        {
            // Block
        TRight trightNode2;
        trightNode2 = (TRight)nodeArrayList1.get(0);

        pleftorrightNode1 = new ARightLeftOrRight(trightNode2);
        }
	nodeList.add(pleftorrightNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new77() /* reduce AAusageclause1UsageClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsageClause pusageclauseNode1;
        {
            // Block
        @SuppressWarnings("unused") Object nullNode2 = null;
        PUsagePhrase pusagephraseNode3;
        pusagephraseNode3 = (PUsagePhrase)nodeArrayList1.get(0);

        pusageclauseNode1 = new AUsageClause(null, pusagephraseNode3);
        }
	nodeList.add(pusageclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new78() /* reduce AAusageclause2UsageClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsageClause pusageclauseNode1;
        {
            // Block
        PUsageIs pusageisNode2;
        PUsagePhrase pusagephraseNode3;
        pusageisNode2 = (PUsageIs)nodeArrayList1.get(0);
        pusagephraseNode3 = (PUsagePhrase)nodeArrayList2.get(0);

        pusageclauseNode1 = new AUsageClause(pusageisNode2, pusagephraseNode3);
        }
	nodeList.add(pusageclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new79() /* reduce AAusageis1UsageIs */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsageIs pusageisNode1;
        {
            // Block
        TUsage tusageNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tusageNode2 = (TUsage)nodeArrayList1.get(0);

        pusageisNode1 = new AUsageIs(tusageNode2, null);
        }
	nodeList.add(pusageisNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new80() /* reduce AAusageis2UsageIs */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsageIs pusageisNode1;
        {
            // Block
        TUsage tusageNode2;
        TIs tisNode3;
        tusageNode2 = (TUsage)nodeArrayList1.get(0);
        tisNode3 = (TIs)nodeArrayList2.get(0);

        pusageisNode1 = new AUsageIs(tusageNode2, tisNode3);
        }
	nodeList.add(pusageisNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new81() /* reduce AAbinaryusagephrase1UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TBinary tbinaryNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tbinaryNode2 = (TBinary)nodeArrayList1.get(0);

        pusagephraseNode1 = new ABinaryUsagePhrase(tbinaryNode2, null);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new82() /* reduce AAbinaryusagephrase2UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TBinary tbinaryNode2;
        TNative tnativeNode3;
        tbinaryNode2 = (TBinary)nodeArrayList1.get(0);
        tnativeNode3 = (TNative)nodeArrayList2.get(0);

        pusagephraseNode1 = new ABinaryUsagePhrase(tbinaryNode2, tnativeNode3);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new83() /* reduce ACompUsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TComp tcompNode2;
        tcompNode2 = (TComp)nodeArrayList1.get(0);

        pusagephraseNode1 = new ACompUsagePhrase(tcompNode2);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new84() /* reduce AAcomp1usagephrase1UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TComp1 tcomp1Node2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tcomp1Node2 = (TComp1)nodeArrayList1.get(0);

        pusagephraseNode1 = new AComp1UsagePhrase(tcomp1Node2, null);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new85() /* reduce AAcomp1usagephrase2UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TComp1 tcomp1Node2;
        TNative tnativeNode3;
        tcomp1Node2 = (TComp1)nodeArrayList1.get(0);
        tnativeNode3 = (TNative)nodeArrayList2.get(0);

        pusagephraseNode1 = new AComp1UsagePhrase(tcomp1Node2, tnativeNode3);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new86() /* reduce AAcomp2usagephrase1UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TComp2 tcomp2Node2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tcomp2Node2 = (TComp2)nodeArrayList1.get(0);

        pusagephraseNode1 = new AComp2UsagePhrase(tcomp2Node2, null);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new87() /* reduce AAcomp2usagephrase2UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TComp2 tcomp2Node2;
        TNative tnativeNode3;
        tcomp2Node2 = (TComp2)nodeArrayList1.get(0);
        tnativeNode3 = (TNative)nodeArrayList2.get(0);

        pusagephraseNode1 = new AComp2UsagePhrase(tcomp2Node2, tnativeNode3);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new88() /* reduce AComp3UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TComp3 tcomp3Node2;
        tcomp3Node2 = (TComp3)nodeArrayList1.get(0);

        pusagephraseNode1 = new AComp3UsagePhrase(tcomp3Node2);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new89() /* reduce AAcomp4usagephrase1UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TComp4 tcomp4Node2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tcomp4Node2 = (TComp4)nodeArrayList1.get(0);

        pusagephraseNode1 = new AComp4UsagePhrase(tcomp4Node2, null);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new90() /* reduce AAcomp4usagephrase2UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TComp4 tcomp4Node2;
        TNative tnativeNode3;
        tcomp4Node2 = (TComp4)nodeArrayList1.get(0);
        tnativeNode3 = (TNative)nodeArrayList2.get(0);

        pusagephraseNode1 = new AComp4UsagePhrase(tcomp4Node2, tnativeNode3);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new91() /* reduce AComp5UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TComp5 tcomp5Node2;
        tcomp5Node2 = (TComp5)nodeArrayList1.get(0);

        pusagephraseNode1 = new AComp5UsagePhrase(tcomp5Node2);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new92() /* reduce AComp6UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TComp6 tcomp6Node2;
        tcomp6Node2 = (TComp6)nodeArrayList1.get(0);

        pusagephraseNode1 = new AComp6UsagePhrase(tcomp6Node2);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new93() /* reduce AAdisplayusagephrase1UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TDisplay tdisplayNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tdisplayNode2 = (TDisplay)nodeArrayList1.get(0);

        pusagephraseNode1 = new ADisplayUsagePhrase(tdisplayNode2, null);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new94() /* reduce AAdisplayusagephrase2UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TDisplay tdisplayNode2;
        TNative tnativeNode3;
        tdisplayNode2 = (TDisplay)nodeArrayList1.get(0);
        tnativeNode3 = (TNative)nodeArrayList2.get(0);

        pusagephraseNode1 = new ADisplayUsagePhrase(tdisplayNode2, tnativeNode3);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new95() /* reduce AAdisplay1usagephrase1UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TDisplay1 tdisplay1Node2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tdisplay1Node2 = (TDisplay1)nodeArrayList1.get(0);

        pusagephraseNode1 = new ADisplay1UsagePhrase(tdisplay1Node2, null);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new96() /* reduce AAdisplay1usagephrase2UsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TDisplay1 tdisplay1Node2;
        TNative tnativeNode3;
        tdisplay1Node2 = (TDisplay1)nodeArrayList1.get(0);
        tnativeNode3 = (TNative)nodeArrayList2.get(0);

        pusagephraseNode1 = new ADisplay1UsagePhrase(tdisplay1Node2, tnativeNode3);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new97() /* reduce AIndexUsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TIndex tindexNode2;
        tindexNode2 = (TIndex)nodeArrayList1.get(0);

        pusagephraseNode1 = new AIndexUsagePhrase(tindexNode2);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new98() /* reduce ANationalUsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TNational tnationalNode2;
        tnationalNode2 = (TNational)nodeArrayList1.get(0);

        pusagephraseNode1 = new ANationalUsagePhrase(tnationalNode2);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new99() /* reduce AObjectReferencePhraseUsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        PObjectReferencePhrase pobjectreferencephraseNode2;
        pobjectreferencephraseNode2 = (PObjectReferencePhrase)nodeArrayList1.get(0);

        pusagephraseNode1 = new AObjectReferencePhraseUsagePhrase(pobjectreferencephraseNode2);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new100() /* reduce APackedDecimalUsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TPackedDecimal tpackeddecimalNode2;
        tpackeddecimalNode2 = (TPackedDecimal)nodeArrayList1.get(0);

        pusagephraseNode1 = new APackedDecimalUsagePhrase(tpackeddecimalNode2);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new101() /* reduce APointerUsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TPointer tpointerNode2;
        tpointerNode2 = (TPointer)nodeArrayList1.get(0);

        pusagephraseNode1 = new APointerUsagePhrase(tpointerNode2);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new102() /* reduce AProcedurePointerUsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TProcedurePointer tprocedurepointerNode2;
        tprocedurepointerNode2 = (TProcedurePointer)nodeArrayList1.get(0);

        pusagephraseNode1 = new AProcedurePointerUsagePhrase(tprocedurepointerNode2);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new103() /* reduce AFunctionPointerUsagePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PUsagePhrase pusagephraseNode1;
        {
            // Block
        TFunctionPointer tfunctionpointerNode2;
        tfunctionpointerNode2 = (TFunctionPointer)nodeArrayList1.get(0);

        pusagephraseNode1 = new AFunctionPointerUsagePhrase(tfunctionpointerNode2);
        }
	nodeList.add(pusagephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new104() /* reduce AAobjectreferencephrase1ObjectReferencePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PObjectReferencePhrase pobjectreferencephraseNode1;
        {
            // Block
        TObject tobjectNode2;
        TReference treferenceNode3;
        @SuppressWarnings("unused") Object nullNode4 = null;
        tobjectNode2 = (TObject)nodeArrayList1.get(0);
        treferenceNode3 = (TReference)nodeArrayList2.get(0);

        pobjectreferencephraseNode1 = new AObjectReferencePhrase(tobjectNode2, treferenceNode3, null);
        }
	nodeList.add(pobjectreferencephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new105() /* reduce AAobjectreferencephrase2ObjectReferencePhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PObjectReferencePhrase pobjectreferencephraseNode1;
        {
            // Block
        TObject tobjectNode2;
        TReference treferenceNode3;
        TDataName tdatanameNode4;
        tobjectNode2 = (TObject)nodeArrayList1.get(0);
        treferenceNode3 = (TReference)nodeArrayList2.get(0);
        tdatanameNode4 = (TDataName)nodeArrayList3.get(0);

        pobjectreferencephraseNode1 = new AObjectReferencePhrase(tobjectNode2, treferenceNode3, tdatanameNode4);
        }
	nodeList.add(pobjectreferencephraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new106() /* reduce AArenamesitem1RenamesItem */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PRenamesItem prenamesitemNode1;
        {
            // Block
        TNumberNot88 tnumbernot88Node2;
        TDataName tdatanameNode3;
        TRenames trenamesNode4;
        TDataName tdatanameNode5;
        @SuppressWarnings("unused") Object nullNode6 = null;
        tnumbernot88Node2 = (TNumberNot88)nodeArrayList1.get(0);
        tdatanameNode3 = (TDataName)nodeArrayList2.get(0);
        trenamesNode4 = (TRenames)nodeArrayList3.get(0);
        tdatanameNode5 = (TDataName)nodeArrayList4.get(0);

        prenamesitemNode1 = new ARenamesItem(tnumbernot88Node2, tdatanameNode3, trenamesNode4, tdatanameNode5, null);
        }
	nodeList.add(prenamesitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new107() /* reduce AArenamesitem2RenamesItem */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList5 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PRenamesItem prenamesitemNode1;
        {
            // Block
        TNumberNot88 tnumbernot88Node2;
        TDataName tdatanameNode3;
        TRenames trenamesNode4;
        TDataName tdatanameNode5;
        PThroughPhrase pthroughphraseNode6;
        tnumbernot88Node2 = (TNumberNot88)nodeArrayList1.get(0);
        tdatanameNode3 = (TDataName)nodeArrayList2.get(0);
        trenamesNode4 = (TRenames)nodeArrayList3.get(0);
        tdatanameNode5 = (TDataName)nodeArrayList4.get(0);
        pthroughphraseNode6 = (PThroughPhrase)nodeArrayList5.get(0);

        prenamesitemNode1 = new ARenamesItem(tnumbernot88Node2, tdatanameNode3, trenamesNode4, tdatanameNode5, pthroughphraseNode6);
        }
	nodeList.add(prenamesitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new108() /* reduce AThroughPhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PThroughPhrase pthroughphraseNode1;
        {
            // Block
        TThrough tthroughNode2;
        TDataName tdatanameNode3;
        tthroughNode2 = (TThrough)nodeArrayList1.get(0);
        tdatanameNode3 = (TDataName)nodeArrayList2.get(0);

        pthroughphraseNode1 = new AThroughPhrase(tthroughNode2, tdatanameNode3);
        }
	nodeList.add(pthroughphraseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new109() /* reduce AAvalueclause1ValueClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PValueClause pvalueclauseNode1;
        {
            // Block
        TValue tvalueNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        @SuppressWarnings("unused") Object nullNode4 = null;
        PLiteral pliteralNode5;
        tvalueNode2 = (TValue)nodeArrayList1.get(0);
        pliteralNode5 = (PLiteral)nodeArrayList2.get(0);

        pvalueclauseNode1 = new AValueClause(tvalueNode2, null, null, pliteralNode5);
        }
	nodeList.add(pvalueclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new110() /* reduce AAvalueclause2ValueClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PValueClause pvalueclauseNode1;
        {
            // Block
        TValue tvalueNode2;
        TIs tisNode3;
        @SuppressWarnings("unused") Object nullNode4 = null;
        PLiteral pliteralNode5;
        tvalueNode2 = (TValue)nodeArrayList1.get(0);
        tisNode3 = (TIs)nodeArrayList2.get(0);
        pliteralNode5 = (PLiteral)nodeArrayList3.get(0);

        pvalueclauseNode1 = new AValueClause(tvalueNode2, tisNode3, null, pliteralNode5);
        }
	nodeList.add(pvalueclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new111() /* reduce AAvalueclause3ValueClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PValueClause pvalueclauseNode1;
        {
            // Block
        TValue tvalueNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        TAll tallNode4;
        PLiteral pliteralNode5;
        tvalueNode2 = (TValue)nodeArrayList1.get(0);
        tallNode4 = (TAll)nodeArrayList2.get(0);
        pliteralNode5 = (PLiteral)nodeArrayList3.get(0);

        pvalueclauseNode1 = new AValueClause(tvalueNode2, null, tallNode4, pliteralNode5);
        }
	nodeList.add(pvalueclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new112() /* reduce AAvalueclause4ValueClause */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PValueClause pvalueclauseNode1;
        {
            // Block
        TValue tvalueNode2;
        TIs tisNode3;
        TAll tallNode4;
        PLiteral pliteralNode5;
        tvalueNode2 = (TValue)nodeArrayList1.get(0);
        tisNode3 = (TIs)nodeArrayList2.get(0);
        tallNode4 = (TAll)nodeArrayList3.get(0);
        pliteralNode5 = (PLiteral)nodeArrayList4.get(0);

        pvalueclauseNode1 = new AValueClause(tvalueNode2, tisNode3, tallNode4, pliteralNode5);
        }
	nodeList.add(pvalueclauseNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new113() /* reduce AValueItem */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PValueItem pvalueitemNode1;
        {
            // Block
        TNumber88 tnumber88Node2;
        TDataName tdatanameNode3;
        PValueOrValues pvalueorvaluesNode4;
        PLiteralSequence pliteralsequenceNode5;
        tnumber88Node2 = (TNumber88)nodeArrayList1.get(0);
        tdatanameNode3 = (TDataName)nodeArrayList2.get(0);
        pvalueorvaluesNode4 = (PValueOrValues)nodeArrayList3.get(0);
        pliteralsequenceNode5 = (PLiteralSequence)nodeArrayList4.get(0);

        pvalueitemNode1 = new AValueItem(tnumber88Node2, tdatanameNode3, pvalueorvaluesNode4, pliteralsequenceNode5);
        }
	nodeList.add(pvalueitemNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new114() /* reduce AAvaluevalueorvalues1ValueOrValues */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PValueOrValues pvalueorvaluesNode1;
        {
            // Block
        TValue tvalueNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tvalueNode2 = (TValue)nodeArrayList1.get(0);

        pvalueorvaluesNode1 = new AValueValueOrValues(tvalueNode2, null);
        }
	nodeList.add(pvalueorvaluesNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new115() /* reduce AAvaluevalueorvalues2ValueOrValues */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PValueOrValues pvalueorvaluesNode1;
        {
            // Block
        TValue tvalueNode2;
        TIs tisNode3;
        tvalueNode2 = (TValue)nodeArrayList1.get(0);
        tisNode3 = (TIs)nodeArrayList2.get(0);

        pvalueorvaluesNode1 = new AValueValueOrValues(tvalueNode2, tisNode3);
        }
	nodeList.add(pvalueorvaluesNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new116() /* reduce AAvaluesvalueorvalues1ValueOrValues */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PValueOrValues pvalueorvaluesNode1;
        {
            // Block
        TValues tvaluesNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        tvaluesNode2 = (TValues)nodeArrayList1.get(0);

        pvalueorvaluesNode1 = new AValuesValueOrValues(tvaluesNode2, null);
        }
	nodeList.add(pvalueorvaluesNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new117() /* reduce AAvaluesvalueorvalues2ValueOrValues */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PValueOrValues pvalueorvaluesNode1;
        {
            // Block
        TValues tvaluesNode2;
        TAre tareNode3;
        tvaluesNode2 = (TValues)nodeArrayList1.get(0);
        tareNode3 = (TAre)nodeArrayList2.get(0);

        pvalueorvaluesNode1 = new AValuesValueOrValues(tvaluesNode2, tareNode3);
        }
	nodeList.add(pvalueorvaluesNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new118() /* reduce AAsingleliteralsequence1LiteralSequence */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteralSequence pliteralsequenceNode1;
        {
            // Block
        @SuppressWarnings("unused") Object nullNode2 = null;
        PLiteral pliteralNode3;
        pliteralNode3 = (PLiteral)nodeArrayList1.get(0);

        pliteralsequenceNode1 = new ASingleLiteralSequence(null, pliteralNode3);
        }
	nodeList.add(pliteralsequenceNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new119() /* reduce AAsingleliteralsequence2LiteralSequence */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteralSequence pliteralsequenceNode1;
        {
            // Block
        TAll tallNode2;
        PLiteral pliteralNode3;
        tallNode2 = (TAll)nodeArrayList1.get(0);
        pliteralNode3 = (PLiteral)nodeArrayList2.get(0);

        pliteralsequenceNode1 = new ASingleLiteralSequence(tallNode2, pliteralNode3);
        }
	nodeList.add(pliteralsequenceNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new120() /* reduce AAsequenceliteralsequence1LiteralSequence */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteralSequence pliteralsequenceNode1;
        {
            // Block
        PLiteralSequence pliteralsequenceNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        PLiteral pliteralNode4;
        pliteralsequenceNode2 = (PLiteralSequence)nodeArrayList1.get(0);
        pliteralNode4 = (PLiteral)nodeArrayList2.get(0);

        pliteralsequenceNode1 = new ASequenceLiteralSequence(pliteralsequenceNode2, null, pliteralNode4);
        }
	nodeList.add(pliteralsequenceNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new121() /* reduce AAsequenceliteralsequence2LiteralSequence */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteralSequence pliteralsequenceNode1;
        {
            // Block
        PLiteralSequence pliteralsequenceNode2;
        TComma tcommaNode3;
        PLiteral pliteralNode4;
        pliteralsequenceNode2 = (PLiteralSequence)nodeArrayList1.get(0);
        tcommaNode3 = (TComma)nodeArrayList2.get(0);
        pliteralNode4 = (PLiteral)nodeArrayList3.get(0);

        pliteralsequenceNode1 = new ASequenceLiteralSequence(pliteralsequenceNode2, tcommaNode3, pliteralNode4);
        }
	nodeList.add(pliteralsequenceNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new122() /* reduce AThroughSingleLiteralSequence */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteralSequence pliteralsequenceNode1;
        {
            // Block
        PLiteral pliteralNode2;
        TThrough tthroughNode3;
        PLiteral pliteralNode4;
        pliteralNode2 = (PLiteral)nodeArrayList1.get(0);
        tthroughNode3 = (TThrough)nodeArrayList2.get(0);
        pliteralNode4 = (PLiteral)nodeArrayList3.get(0);

        pliteralsequenceNode1 = new AThroughSingleLiteralSequence(pliteralNode2, tthroughNode3, pliteralNode4);
        }
	nodeList.add(pliteralsequenceNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new123() /* reduce AAthroughsequenceliteralsequence1LiteralSequence */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteralSequence pliteralsequenceNode1;
        {
            // Block
        PLiteralSequence pliteralsequenceNode2;
        @SuppressWarnings("unused") Object nullNode3 = null;
        PLiteral pliteralNode4;
        TThrough tthroughNode5;
        PLiteral pliteralNode6;
        pliteralsequenceNode2 = (PLiteralSequence)nodeArrayList1.get(0);
        pliteralNode4 = (PLiteral)nodeArrayList2.get(0);
        tthroughNode5 = (TThrough)nodeArrayList3.get(0);
        pliteralNode6 = (PLiteral)nodeArrayList4.get(0);

        pliteralsequenceNode1 = new AThroughSequenceLiteralSequence(pliteralsequenceNode2, null, pliteralNode4, tthroughNode5, pliteralNode6);
        }
	nodeList.add(pliteralsequenceNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new124() /* reduce AAthroughsequenceliteralsequence2LiteralSequence */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList5 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList4 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteralSequence pliteralsequenceNode1;
        {
            // Block
        PLiteralSequence pliteralsequenceNode2;
        TComma tcommaNode3;
        PLiteral pliteralNode4;
        TThrough tthroughNode5;
        PLiteral pliteralNode6;
        pliteralsequenceNode2 = (PLiteralSequence)nodeArrayList1.get(0);
        tcommaNode3 = (TComma)nodeArrayList2.get(0);
        pliteralNode4 = (PLiteral)nodeArrayList3.get(0);
        tthroughNode5 = (TThrough)nodeArrayList4.get(0);
        pliteralNode6 = (PLiteral)nodeArrayList5.get(0);

        pliteralsequenceNode1 = new AThroughSequenceLiteralSequence(pliteralsequenceNode2, tcommaNode3, pliteralNode4, tthroughNode5, pliteralNode6);
        }
	nodeList.add(pliteralsequenceNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new125() /* reduce AZerosLiteral */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteral pliteralNode1;
        {
            // Block
        TZeros tzerosNode2;
        tzerosNode2 = (TZeros)nodeArrayList1.get(0);

        pliteralNode1 = new AZerosLiteral(tzerosNode2);
        }
	nodeList.add(pliteralNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new126() /* reduce ASpacesLiteral */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteral pliteralNode1;
        {
            // Block
        TSpaces tspacesNode2;
        tspacesNode2 = (TSpaces)nodeArrayList1.get(0);

        pliteralNode1 = new ASpacesLiteral(tspacesNode2);
        }
	nodeList.add(pliteralNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new127() /* reduce AHighValuesLiteral */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteral pliteralNode1;
        {
            // Block
        THighValues thighvaluesNode2;
        thighvaluesNode2 = (THighValues)nodeArrayList1.get(0);

        pliteralNode1 = new AHighValuesLiteral(thighvaluesNode2);
        }
	nodeList.add(pliteralNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new128() /* reduce ALowValuesLiteral */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteral pliteralNode1;
        {
            // Block
        TLowValues tlowvaluesNode2;
        tlowvaluesNode2 = (TLowValues)nodeArrayList1.get(0);

        pliteralNode1 = new ALowValuesLiteral(tlowvaluesNode2);
        }
	nodeList.add(pliteralNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new129() /* reduce AQuotesLiteral */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteral pliteralNode1;
        {
            // Block
        TQuotes tquotesNode2;
        tquotesNode2 = (TQuotes)nodeArrayList1.get(0);

        pliteralNode1 = new AQuotesLiteral(tquotesNode2);
        }
	nodeList.add(pliteralNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new130() /* reduce ANullsLiteral */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteral pliteralNode1;
        {
            // Block
        TNulls tnullsNode2;
        tnullsNode2 = (TNulls)nodeArrayList1.get(0);

        pliteralNode1 = new ANullsLiteral(tnullsNode2);
        }
	nodeList.add(pliteralNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new131() /* reduce ANumberLiteral */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteral pliteralNode1;
        {
            // Block
        PNumber pnumberNode2;
        pnumberNode2 = (PNumber)nodeArrayList1.get(0);

        pliteralNode1 = new ANumberLiteral(pnumberNode2);
        }
	nodeList.add(pliteralNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new132() /* reduce ANumericLiteralLiteral */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteral pliteralNode1;
        {
            // Block
        TNumericLiteral tnumericliteralNode2;
        tnumericliteralNode2 = (TNumericLiteral)nodeArrayList1.get(0);

        pliteralNode1 = new ANumericLiteralLiteral(tnumericliteralNode2);
        }
	nodeList.add(pliteralNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new133() /* reduce AAlphanumericLiteralLiteral */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PLiteral pliteralNode1;
        {
            // Block
        TAlphanumericLiteral talphanumericliteralNode2;
        talphanumericliteralNode2 = (TAlphanumericLiteral)nodeArrayList1.get(0);

        pliteralNode1 = new AAlphanumericLiteralLiteral(talphanumericliteralNode2);
        }
	nodeList.add(pliteralNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new134() /* reduce ASingleCharacterString */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterString pcharacterstringNode1;
        {
            // Block
        PCharacterSubstring pcharactersubstringNode2;
        pcharactersubstringNode2 = (PCharacterSubstring)nodeArrayList1.get(0);

        pcharacterstringNode1 = new ASingleCharacterString(pcharactersubstringNode2);
        }
	nodeList.add(pcharacterstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new135() /* reduce ASequenceCharacterString */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterString pcharacterstringNode1;
        {
            // Block
        PCharacterString pcharacterstringNode2;
        PCharacterSubstring pcharactersubstringNode3;
        pcharacterstringNode2 = (PCharacterString)nodeArrayList1.get(0);
        pcharactersubstringNode3 = (PCharacterSubstring)nodeArrayList2.get(0);

        pcharacterstringNode1 = new ASequenceCharacterString(pcharacterstringNode2, pcharactersubstringNode3);
        }
	nodeList.add(pcharacterstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new136() /* reduce ADataNameCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        TDataName tdatanameNode2;
        tdatanameNode2 = (TDataName)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new ADataNameCharacterSubstring(tdatanameNode2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new137() /* reduce APlusCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        TPlus tplusNode2;
        tplusNode2 = (TPlus)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new APlusCharacterSubstring(tplusNode2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new138() /* reduce AMinusCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        TMinus tminusNode2;
        tminusNode2 = (TMinus)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new AMinusCharacterSubstring(tminusNode2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new139() /* reduce AStarCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        TStar tstarNode2;
        tstarNode2 = (TStar)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new AStarCharacterSubstring(tstarNode2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new140() /* reduce ASlashCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        TSlash tslashNode2;
        tslashNode2 = (TSlash)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new ASlashCharacterSubstring(tslashNode2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new141() /* reduce ADollarCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        TDollar tdollarNode2;
        tdollarNode2 = (TDollar)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new ADollarCharacterSubstring(tdollarNode2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new142() /* reduce ACommaCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        TComma tcommaNode2;
        tcommaNode2 = (TComma)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new ACommaCharacterSubstring(tcommaNode2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new143() /* reduce ANumberCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        TNumberNot88 tnumbernot88Node2;
        tnumbernot88Node2 = (TNumberNot88)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new ANumberCharacterSubstring(tnumbernot88Node2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new144() /* reduce ANumericLiteralCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        TNumericLiteral tnumericliteralNode2;
        tnumericliteralNode2 = (TNumericLiteral)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new ANumericLiteralCharacterSubstring(tnumericliteralNode2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new145() /* reduce ABracketedNumberCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        PBracketedNumber pbracketednumberNode2;
        pbracketednumberNode2 = (PBracketedNumber)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new ABracketedNumberCharacterSubstring(pbracketednumberNode2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new146() /* reduce ADotMinusCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        TDotMinus tdotminusNode2;
        tdotminusNode2 = (TDotMinus)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new ADotMinusCharacterSubstring(tdotminusNode2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new147() /* reduce ADotPlusCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        TDotPlus tdotplusNode2;
        tdotplusNode2 = (TDotPlus)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new ADotPlusCharacterSubstring(tdotplusNode2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new148() /* reduce ADotZeeCharacterSubstring */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PCharacterSubstring pcharactersubstringNode1;
        {
            // Block
        TDotZee tdotzeeNode2;
        tdotzeeNode2 = (TDotZee)nodeArrayList1.get(0);

        pcharactersubstringNode1 = new ADotZeeCharacterSubstring(tdotzeeNode2);
        }
	nodeList.add(pcharactersubstringNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new149() /* reduce ABracketedNumber */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList3 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PBracketedNumber pbracketednumberNode1;
        {
            // Block
        TLparen tlparenNode2;
        PNumber pnumberNode3;
        TRparen trparenNode4;
        tlparenNode2 = (TLparen)nodeArrayList1.get(0);
        pnumberNode3 = (PNumber)nodeArrayList2.get(0);
        trparenNode4 = (TRparen)nodeArrayList3.get(0);

        pbracketednumberNode1 = new ABracketedNumber(tlparenNode2, pnumberNode3, trparenNode4);
        }
	nodeList.add(pbracketednumberNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new150() /* reduce ANumberNot88Number */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PNumber pnumberNode1;
        {
            // Block
        TNumberNot88 tnumbernot88Node2;
        tnumbernot88Node2 = (TNumberNot88)nodeArrayList1.get(0);

        pnumberNode1 = new ANumberNot88Number(tnumbernot88Node2);
        }
	nodeList.add(pnumberNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new151() /* reduce ANumber88Number */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        PNumber pnumberNode1;
        {
            // Block
        TNumber88 tnumber88Node2;
        tnumber88Node2 = (TNumber88)nodeArrayList1.get(0);

        pnumberNode1 = new ANumber88Number(tnumber88Node2);
        }
	nodeList.add(pnumberNode1);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new152() /* reduce ATerminal$AscendingOrDescendingKeyPhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        LinkedList<Object> listNode2 = new LinkedList<Object>();
        {
            // Block
        PAscendingOrDescendingKeyPhrase pascendingordescendingkeyphraseNode1;
        pascendingordescendingkeyphraseNode1 = (PAscendingOrDescendingKeyPhrase)nodeArrayList1.get(0);
	if(pascendingordescendingkeyphraseNode1 != null)
	{
	  listNode2.add(pascendingordescendingkeyphraseNode1);
	}
        }
	nodeList.add(listNode2);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new153() /* reduce ANonTerminal$AscendingOrDescendingKeyPhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        LinkedList<Object> listNode3 = new LinkedList<Object>();
        {
            // Block
        LinkedList<Object> listNode1 = new LinkedList<Object>();
        PAscendingOrDescendingKeyPhrase pascendingordescendingkeyphraseNode2;
        listNode1 = (LinkedList)nodeArrayList1.get(0);
        pascendingordescendingkeyphraseNode2 = (PAscendingOrDescendingKeyPhrase)nodeArrayList2.get(0);
	if(listNode1 != null)
	{
	  listNode3.addAll(listNode1);
	}
	if(pascendingordescendingkeyphraseNode2 != null)
	{
	  listNode3.add(pascendingordescendingkeyphraseNode2);
	}
        }
	nodeList.add(listNode3);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new154() /* reduce ATerminal$IndexedByPhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        LinkedList<Object> listNode2 = new LinkedList<Object>();
        {
            // Block
        PIndexedByPhrase pindexedbyphraseNode1;
        pindexedbyphraseNode1 = (PIndexedByPhrase)nodeArrayList1.get(0);
	if(pindexedbyphraseNode1 != null)
	{
	  listNode2.add(pindexedbyphraseNode1);
	}
        }
	nodeList.add(listNode2);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new155() /* reduce ANonTerminal$IndexedByPhrase */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        LinkedList<Object> listNode3 = new LinkedList<Object>();
        {
            // Block
        LinkedList<Object> listNode1 = new LinkedList<Object>();
        PIndexedByPhrase pindexedbyphraseNode2;
        listNode1 = (LinkedList)nodeArrayList1.get(0);
        pindexedbyphraseNode2 = (PIndexedByPhrase)nodeArrayList2.get(0);
	if(listNode1 != null)
	{
	  listNode3.addAll(listNode1);
	}
	if(pindexedbyphraseNode2 != null)
	{
	  listNode3.add(pindexedbyphraseNode2);
	}
        }
	nodeList.add(listNode3);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new156() /* reduce ATerminal$DataName */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        LinkedList<Object> listNode2 = new LinkedList<Object>();
        {
            // Block
        TDataName tdatanameNode1;
        tdatanameNode1 = (TDataName)nodeArrayList1.get(0);
	if(tdatanameNode1 != null)
	{
	  listNode2.add(tdatanameNode1);
	}
        }
	nodeList.add(listNode2);
        return nodeList;
    }



    @SuppressWarnings({ "unchecked", "rawtypes" })
    ArrayList<Object> new157() /* reduce ANonTerminal$DataName */
    {
        @SuppressWarnings("hiding") ArrayList<Object> nodeList = new ArrayList<Object>();

        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList2 = pop();
        @SuppressWarnings("unused") ArrayList<Object> nodeArrayList1 = pop();
        LinkedList<Object> listNode3 = new LinkedList<Object>();
        {
            // Block
        LinkedList<Object> listNode1 = new LinkedList<Object>();
        TDataName tdatanameNode2;
        listNode1 = (LinkedList)nodeArrayList1.get(0);
        tdatanameNode2 = (TDataName)nodeArrayList2.get(0);
	if(listNode1 != null)
	{
	  listNode3.addAll(listNode1);
	}
	if(tdatanameNode2 != null)
	{
	  listNode3.add(tdatanameNode2);
	}
        }
	nodeList.add(listNode3);
        return nodeList;
    }



    private static int[][][] actionTable;
/*      {
			{{-1, ERROR, 0}, {9, SHIFT, 1}, {10, SHIFT, 2}, },
			{{-1, ERROR, 1}, {77, SHIFT, 9}, },
			{{-1, REDUCE, 6}, {19, SHIFT, 10}, {20, SHIFT, 11}, {23, SHIFT, 12}, {24, SHIFT, 13}, {25, SHIFT, 14}, {26, SHIFT, 15}, {27, SHIFT, 16}, {28, SHIFT, 17}, {29, SHIFT, 18}, {30, SHIFT, 19}, {33, SHIFT, 20}, {34, SHIFT, 21}, {35, SHIFT, 22}, {36, SHIFT, 23}, {38, SHIFT, 24}, {39, SHIFT, 25}, {41, SHIFT, 26}, {44, SHIFT, 27}, {46, SHIFT, 28}, {49, SHIFT, 29}, {52, SHIFT, 30}, {53, SHIFT, 31}, {55, SHIFT, 32}, {56, SHIFT, 33}, {57, SHIFT, 34}, {58, SHIFT, 35}, {60, SHIFT, 36}, {65, SHIFT, 37}, {67, SHIFT, 38}, {71, SHIFT, 39}, {72, SHIFT, 40}, {73, SHIFT, 41}, {77, SHIFT, 42}, },
			{{-1, ERROR, 3}, {78, ACCEPT, -1}, },
			{{-1, ERROR, 4}, {0, SHIFT, 64}, },
			{{-1, REDUCE, 1}, },
			{{-1, REDUCE, 3}, },
			{{-1, REDUCE, 4}, },
			{{-1, REDUCE, 5}, },
			{{-1, ERROR, 9}, {73, SHIFT, 65}, {74, SHIFT, 66}, },
			{{-1, REDUCE, 81}, {50, SHIFT, 68}, },
			{{-1, ERROR, 11}, {75, SHIFT, 69}, {76, SHIFT, 70}, },
			{{-1, REDUCE, 83}, },
			{{-1, REDUCE, 84}, {50, SHIFT, 71}, },
			{{-1, REDUCE, 86}, {50, SHIFT, 72}, },
			{{-1, REDUCE, 88}, },
			{{-1, REDUCE, 89}, {50, SHIFT, 73}, },
			{{-1, REDUCE, 91}, },
			{{-1, REDUCE, 92}, },
			{{-1, ERROR, 19}, {37, SHIFT, 74}, },
			{{-1, REDUCE, 93}, {50, SHIFT, 75}, },
			{{-1, REDUCE, 95}, {50, SHIFT, 76}, },
			{{-1, REDUCE, 34}, },
			{{-1, REDUCE, 15}, },
			{{-1, REDUCE, 103}, },
			{{-1, REDUCE, 35}, },
			{{-1, REDUCE, 97}, },
			{{-1, REDUCE, 36}, {63, SHIFT, 77}, },
			{{-1, REDUCE, 69}, },
			{{-1, REDUCE, 98}, },
			{{-1, ERROR, 30}, {61, SHIFT, 78}, },
			{{-1, ERROR, 31}, {9, SHIFT, 79}, {10, SHIFT, 80}, },
			{{-1, REDUCE, 100}, },
			{{-1, ERROR, 33}, {1, SHIFT, 83}, {2, SHIFT, 84}, {3, SHIFT, 85}, {4, SHIFT, 86}, {5, SHIFT, 87}, {6, SHIFT, 88}, {7, SHIFT, 89}, {10, SHIFT, 90}, {12, SHIFT, 91}, {13, SHIFT, 92}, {14, SHIFT, 93}, {15, SHIFT, 94}, {43, SHIFT, 95}, {77, SHIFT, 96}, },
			{{-1, REDUCE, 101}, },
			{{-1, REDUCE, 102}, },
			{{-1, ERROR, 36}, {77, SHIFT, 100}, },
			{{-1, REDUCE, 67}, {43, SHIFT, 101}, },
			{{-1, REDUCE, 73}, {47, SHIFT, 102}, {63, SHIFT, 103}, },
			{{-1, REDUCE, 70}, },
			{{-1, REDUCE, 79}, {43, SHIFT, 105}, },
			{{-1, ERROR, 41}, {9, SHIFT, 79}, {10, SHIFT, 80}, {11, SHIFT, 106}, {12, SHIFT, 107}, {16, SHIFT, 108}, {40, SHIFT, 109}, {43, SHIFT, 110}, {48, SHIFT, 111}, {51, SHIFT, 112}, {59, SHIFT, 113}, {66, SHIFT, 114}, {76, SHIFT, 115}, },
			{{-1, REDUCE, 14}, {62, SHIFT, 118}, },
			{{-1, REDUCE, 7}, {19, SHIFT, 10}, {20, SHIFT, 11}, {23, SHIFT, 12}, {24, SHIFT, 13}, {25, SHIFT, 14}, {26, SHIFT, 15}, {27, SHIFT, 16}, {28, SHIFT, 17}, {29, SHIFT, 18}, {30, SHIFT, 19}, {33, SHIFT, 20}, {34, SHIFT, 21}, {35, SHIFT, 22}, {38, SHIFT, 24}, {39, SHIFT, 25}, {41, SHIFT, 26}, {44, SHIFT, 27}, {46, SHIFT, 28}, {49, SHIFT, 29}, {52, SHIFT, 30}, {53, SHIFT, 31}, {55, SHIFT, 32}, {56, SHIFT, 33}, {57, SHIFT, 34}, {58, SHIFT, 35}, {60, SHIFT, 36}, {65, SHIFT, 37}, {67, SHIFT, 38}, {71, SHIFT, 39}, {72, SHIFT, 40}, {73, SHIFT, 41}, },
			{{-1, REDUCE, 8}, {19, SHIFT, 10}, {20, SHIFT, 11}, {23, SHIFT, 12}, {24, SHIFT, 13}, {25, SHIFT, 14}, {26, SHIFT, 15}, {27, SHIFT, 16}, {28, SHIFT, 17}, {29, SHIFT, 18}, {30, SHIFT, 19}, {33, SHIFT, 20}, {34, SHIFT, 21}, {35, SHIFT, 22}, {38, SHIFT, 24}, {39, SHIFT, 25}, {41, SHIFT, 26}, {44, SHIFT, 27}, {46, SHIFT, 28}, {49, SHIFT, 29}, {52, SHIFT, 30}, {53, SHIFT, 31}, {55, SHIFT, 32}, {56, SHIFT, 33}, {57, SHIFT, 34}, {58, SHIFT, 35}, {65, SHIFT, 37}, {67, SHIFT, 38}, {71, SHIFT, 39}, {72, SHIFT, 40}, {73, SHIFT, 41}, },
			{{-1, REDUCE, 10}, {19, SHIFT, 10}, {20, SHIFT, 11}, {23, SHIFT, 12}, {24, SHIFT, 13}, {25, SHIFT, 14}, {26, SHIFT, 15}, {27, SHIFT, 16}, {28, SHIFT, 17}, {29, SHIFT, 18}, {30, SHIFT, 19}, {33, SHIFT, 20}, {34, SHIFT, 21}, {35, SHIFT, 22}, {38, SHIFT, 24}, {39, SHIFT, 25}, {41, SHIFT, 26}, {44, SHIFT, 27}, {46, SHIFT, 28}, {49, SHIFT, 29}, {52, SHIFT, 30}, {53, SHIFT, 31}, {55, SHIFT, 32}, {56, SHIFT, 33}, {57, SHIFT, 34}, {58, SHIFT, 35}, {65, SHIFT, 37}, {67, SHIFT, 38}, {71, SHIFT, 39}, {72, SHIFT, 40}, {73, SHIFT, 41}, },
			{{-1, REDUCE, 17}, },
			{{-1, REDUCE, 19}, },
			{{-1, REDUCE, 20}, },
			{{-1, REDUCE, 21}, },
			{{-1, REDUCE, 22}, },
			{{-1, REDUCE, 23}, },
			{{-1, REDUCE, 24}, },
			{{-1, REDUCE, 38}, {18, SHIFT, 123}, {32, SHIFT, 124}, {42, SHIFT, 125}, },
			{{-1, REDUCE, 25}, },
			{{-1, REDUCE, 26}, },
			{{-1, ERROR, 56}, {46, SHIFT, 28}, {71, SHIFT, 39}, },
			{{-1, REDUCE, 63}, {64, SHIFT, 132}, },
			{{-1, REDUCE, 27}, },
			{{-1, REDUCE, 28}, },
			{{-1, ERROR, 60}, {19, SHIFT, 10}, {23, SHIFT, 12}, {24, SHIFT, 13}, {25, SHIFT, 14}, {26, SHIFT, 15}, {27, SHIFT, 16}, {28, SHIFT, 17}, {29, SHIFT, 18}, {33, SHIFT, 20}, {34, SHIFT, 21}, {38, SHIFT, 24}, {41, SHIFT, 26}, {49, SHIFT, 29}, {52, SHIFT, 30}, {55, SHIFT, 32}, {57, SHIFT, 34}, {58, SHIFT, 35}, },
			{{-1, REDUCE, 77}, },
			{{-1, REDUCE, 99}, },
			{{-1, REDUCE, 29}, },
			{{-1, REDUCE, 0}, {9, SHIFT, 1}, {10, SHIFT, 2}, },
			{{-1, REDUCE, 114}, {43, SHIFT, 136}, },
			{{-1, REDUCE, 116}, {17, SHIFT, 137}, },
			{{-1, ERROR, 67}, {9, SHIFT, 79}, {10, SHIFT, 80}, {11, SHIFT, 106}, {12, SHIFT, 107}, {16, SHIFT, 138}, {40, SHIFT, 109}, {48, SHIFT, 111}, {51, SHIFT, 112}, {59, SHIFT, 113}, {66, SHIFT, 114}, {76, SHIFT, 115}, },
			{{-1, REDUCE, 82}, },
			{{-1, ERROR, 69}, {76, SHIFT, 141}, },
			{{-1, REDUCE, 30}, },
			{{-1, REDUCE, 85}, },
			{{-1, REDUCE, 87}, },
			{{-1, REDUCE, 90}, },
			{{-1, ERROR, 74}, {43, SHIFT, 142}, {77, SHIFT, 143}, },
			{{-1, REDUCE, 94}, },
			{{-1, REDUCE, 96}, },
			{{-1, REDUCE, 37}, },
			{{-1, REDUCE, 104}, {77, SHIFT, 144}, },
			{{-1, REDUCE, 151}, },
			{{-1, REDUCE, 150}, },
			{{-1, ERROR, 81}, {9, SHIFT, 79}, {10, SHIFT, 80}, },
			{{-1, REDUCE, 42}, {31, SHIFT, 146}, {69, SHIFT, 147}, {70, SHIFT, 148}, },
			{{-1, REDUCE, 142}, },
			{{-1, REDUCE, 140}, },
			{{-1, REDUCE, 137}, },
			{{-1, REDUCE, 138}, },
			{{-1, REDUCE, 139}, },
			{{-1, REDUCE, 141}, },
			{{-1, ERROR, 89}, {9, SHIFT, 79}, {10, SHIFT, 80}, },
			{{-1, REDUCE, 143}, },
			{{-1, REDUCE, 144}, },
			{{-1, REDUCE, 148}, },
			{{-1, REDUCE, 146}, },
			{{-1, REDUCE, 147}, },
			{{-1, ERROR, 95}, {1, SHIFT, 83}, {2, SHIFT, 84}, {3, SHIFT, 85}, {4, SHIFT, 86}, {5, SHIFT, 87}, {6, SHIFT, 88}, {7, SHIFT, 89}, {10, SHIFT, 90}, {12, SHIFT, 91}, {13, SHIFT, 92}, {14, SHIFT, 93}, {15, SHIFT, 94}, {77, SHIFT, 96}, },
			{{-1, REDUCE, 136}, },
			{{-1, REDUCE, 61}, {1, SHIFT, 83}, {2, SHIFT, 84}, {3, SHIFT, 85}, {4, SHIFT, 86}, {5, SHIFT, 87}, {6, SHIFT, 88}, {7, SHIFT, 89}, {10, SHIFT, 90}, {12, SHIFT, 91}, {13, SHIFT, 92}, {14, SHIFT, 93}, {15, SHIFT, 94}, {77, SHIFT, 96}, },
			{{-1, REDUCE, 134}, },
			{{-1, REDUCE, 145}, },
			{{-1, REDUCE, 16}, },
			{{-1, REDUCE, 68}, },
			{{-1, REDUCE, 75}, },
			{{-1, REDUCE, 76}, },
			{{-1, REDUCE, 74}, },
			{{-1, REDUCE, 80}, },
			{{-1, REDUCE, 133}, },
			{{-1, REDUCE, 132}, },
			{{-1, ERROR, 108}, {9, SHIFT, 79}, {10, SHIFT, 80}, {11, SHIFT, 106}, {12, SHIFT, 107}, {40, SHIFT, 109}, {48, SHIFT, 111}, {51, SHIFT, 112}, {59, SHIFT, 113}, {66, SHIFT, 114}, {76, SHIFT, 115}, },
			{{-1, REDUCE, 127}, },
			{{-1, ERROR, 110}, {9, SHIFT, 79}, {10, SHIFT, 80}, {11, SHIFT, 106}, {12, SHIFT, 107}, {16, SHIFT, 153}, {40, SHIFT, 109}, {48, SHIFT, 111}, {51, SHIFT, 112}, {59, SHIFT, 113}, {66, SHIFT, 114}, {76, SHIFT, 115}, },
			{{-1, REDUCE, 128}, },
			{{-1, REDUCE, 130}, },
			{{-1, REDUCE, 129}, },
			{{-1, REDUCE, 126}, },
			{{-1, REDUCE, 125}, },
			{{-1, REDUCE, 109}, },
			{{-1, REDUCE, 131}, },
			{{-1, ERROR, 118}, {77, SHIFT, 155}, },
			{{-1, REDUCE, 9}, {19, SHIFT, 10}, {20, SHIFT, 11}, {23, SHIFT, 12}, {24, SHIFT, 13}, {25, SHIFT, 14}, {26, SHIFT, 15}, {27, SHIFT, 16}, {28, SHIFT, 17}, {29, SHIFT, 18}, {30, SHIFT, 19}, {33, SHIFT, 20}, {34, SHIFT, 21}, {35, SHIFT, 22}, {38, SHIFT, 24}, {39, SHIFT, 25}, {41, SHIFT, 26}, {44, SHIFT, 27}, {46, SHIFT, 28}, {49, SHIFT, 29}, {52, SHIFT, 30}, {53, SHIFT, 31}, {55, SHIFT, 32}, {56, SHIFT, 33}, {57, SHIFT, 34}, {58, SHIFT, 35}, {65, SHIFT, 37}, {67, SHIFT, 38}, {71, SHIFT, 39}, {72, SHIFT, 40}, {73, SHIFT, 41}, },
			{{-1, REDUCE, 11}, {19, SHIFT, 10}, {20, SHIFT, 11}, {23, SHIFT, 12}, {24, SHIFT, 13}, {25, SHIFT, 14}, {26, SHIFT, 15}, {27, SHIFT, 16}, {28, SHIFT, 17}, {29, SHIFT, 18}, {30, SHIFT, 19}, {33, SHIFT, 20}, {34, SHIFT, 21}, {35, SHIFT, 22}, {38, SHIFT, 24}, {39, SHIFT, 25}, {41, SHIFT, 26}, {44, SHIFT, 27}, {46, SHIFT, 28}, {49, SHIFT, 29}, {52, SHIFT, 30}, {53, SHIFT, 31}, {55, SHIFT, 32}, {56, SHIFT, 33}, {57, SHIFT, 34}, {58, SHIFT, 35}, {65, SHIFT, 37}, {67, SHIFT, 38}, {71, SHIFT, 39}, {72, SHIFT, 40}, {73, SHIFT, 41}, },
			{{-1, REDUCE, 12}, {19, SHIFT, 10}, {20, SHIFT, 11}, {23, SHIFT, 12}, {24, SHIFT, 13}, {25, SHIFT, 14}, {26, SHIFT, 15}, {27, SHIFT, 16}, {28, SHIFT, 17}, {29, SHIFT, 18}, {30, SHIFT, 19}, {33, SHIFT, 20}, {34, SHIFT, 21}, {35, SHIFT, 22}, {38, SHIFT, 24}, {39, SHIFT, 25}, {41, SHIFT, 26}, {44, SHIFT, 27}, {46, SHIFT, 28}, {49, SHIFT, 29}, {52, SHIFT, 30}, {53, SHIFT, 31}, {55, SHIFT, 32}, {56, SHIFT, 33}, {57, SHIFT, 34}, {58, SHIFT, 35}, {65, SHIFT, 37}, {67, SHIFT, 38}, {71, SHIFT, 39}, {72, SHIFT, 40}, {73, SHIFT, 41}, },
			{{-1, REDUCE, 18}, },
			{{-1, REDUCE, 57}, },
			{{-1, REDUCE, 58}, },
			{{-1, ERROR, 125}, {21, SHIFT, 157}, {77, SHIFT, 158}, },
			{{-1, REDUCE, 152}, },
			{{-1, ERROR, 127}, {43, SHIFT, 160}, {45, SHIFT, 161}, {77, SHIFT, 158}, },
			{{-1, REDUCE, 154}, },
			{{-1, REDUCE, 39}, {18, SHIFT, 123}, {32, SHIFT, 124}, {42, SHIFT, 125}, },
			{{-1, REDUCE, 40}, {42, SHIFT, 125}, },
			{{-1, REDUCE, 64}, {64, SHIFT, 132}, },
			{{-1, REDUCE, 71}, {22, SHIFT, 167}, },
			{{-1, REDUCE, 65}, },
			{{-1, REDUCE, 78}, },
			{{-1, REDUCE, 2}, },
			{{-1, REDUCE, 115}, },
			{{-1, REDUCE, 117}, },
			{{-1, ERROR, 138}, {9, SHIFT, 79}, {10, SHIFT, 80}, {11, SHIFT, 106}, {12, SHIFT, 107}, {40, SHIFT, 109}, {48, SHIFT, 111}, {51, SHIFT, 112}, {59, SHIFT, 113}, {66, SHIFT, 114}, {76, SHIFT, 115}, },
			{{-1, REDUCE, 113}, {1, SHIFT, 169}, {9, SHIFT, 79}, {10, SHIFT, 80}, {11, SHIFT, 106}, {12, SHIFT, 107}, {40, SHIFT, 109}, {48, SHIFT, 111}, {51, SHIFT, 112}, {59, SHIFT, 113}, {66, SHIFT, 114}, {76, SHIFT, 115}, },
			{{-1, REDUCE, 118}, {68, SHIFT, 171}, },
			{{-1, REDUCE, 31}, },
			{{-1, ERROR, 142}, {77, SHIFT, 172}, },
			{{-1, REDUCE, 32}, },
			{{-1, REDUCE, 105}, },
			{{-1, ERROR, 145}, {31, SHIFT, 173}, {69, SHIFT, 174}, },
			{{-1, ERROR, 146}, {54, SHIFT, 175}, {77, SHIFT, 176}, },
			{{-1, REDUCE, 43}, {31, SHIFT, 177}, },
			{{-1, REDUCE, 52}, },
			{{-1, ERROR, 149}, {8, SHIFT, 178}, },
			{{-1, REDUCE, 62}, {1, SHIFT, 83}, {2, SHIFT, 84}, {3, SHIFT, 85}, {4, SHIFT, 86}, {5, SHIFT, 87}, {6, SHIFT, 88}, {7, SHIFT, 89}, {10, SHIFT, 90}, {12, SHIFT, 91}, {13, SHIFT, 92}, {14, SHIFT, 93}, {15, SHIFT, 94}, {77, SHIFT, 96}, },
			{{-1, REDUCE, 135}, },
			{{-1, REDUCE, 111}, },
			{{-1, ERROR, 153}, {9, SHIFT, 79}, {10, SHIFT, 80}, {11, SHIFT, 106}, {12, SHIFT, 107}, {40, SHIFT, 109}, {48, SHIFT, 111}, {51, SHIFT, 112}, {59, SHIFT, 113}, {66, SHIFT, 114}, {76, SHIFT, 115}, },
			{{-1, REDUCE, 110}, },
			{{-1, REDUCE, 106}, {68, SHIFT, 180}, },
			{{-1, REDUCE, 13}, {19, SHIFT, 10}, {20, SHIFT, 11}, {23, SHIFT, 12}, {24, SHIFT, 13}, {25, SHIFT, 14}, {26, SHIFT, 15}, {27, SHIFT, 16}, {28, SHIFT, 17}, {29, SHIFT, 18}, {30, SHIFT, 19}, {33, SHIFT, 20}, {34, SHIFT, 21}, {35, SHIFT, 22}, {38, SHIFT, 24}, {39, SHIFT, 25}, {41, SHIFT, 26}, {44, SHIFT, 27}, {46, SHIFT, 28}, {49, SHIFT, 29}, {52, SHIFT, 30}, {53, SHIFT, 31}, {55, SHIFT, 32}, {56, SHIFT, 33}, {57, SHIFT, 34}, {58, SHIFT, 35}, {65, SHIFT, 37}, {67, SHIFT, 38}, {71, SHIFT, 39}, {72, SHIFT, 40}, {73, SHIFT, 41}, },
			{{-1, ERROR, 157}, {77, SHIFT, 158}, },
			{{-1, REDUCE, 156}, },
			{{-1, REDUCE, 59}, {77, SHIFT, 183}, },
			{{-1, ERROR, 160}, {77, SHIFT, 158}, },
			{{-1, ERROR, 161}, {43, SHIFT, 185}, {77, SHIFT, 158}, },
			{{-1, REDUCE, 53}, {77, SHIFT, 183}, },
			{{-1, REDUCE, 153}, },
			{{-1, REDUCE, 41}, {42, SHIFT, 125}, },
			{{-1, REDUCE, 155}, },
			{{-1, REDUCE, 66}, },
			{{-1, REDUCE, 72}, },
			{{-1, REDUCE, 119}, },
			{{-1, ERROR, 169}, {9, SHIFT, 79}, {10, SHIFT, 80}, {11, SHIFT, 106}, {12, SHIFT, 107}, {40, SHIFT, 109}, {48, SHIFT, 111}, {51, SHIFT, 112}, {59, SHIFT, 113}, {66, SHIFT, 114}, {76, SHIFT, 115}, },
			{{-1, REDUCE, 120}, {68, SHIFT, 188}, },
			{{-1, ERROR, 171}, {9, SHIFT, 79}, {10, SHIFT, 80}, {11, SHIFT, 106}, {12, SHIFT, 107}, {40, SHIFT, 109}, {48, SHIFT, 111}, {51, SHIFT, 112}, {59, SHIFT, 113}, {66, SHIFT, 114}, {76, SHIFT, 115}, },
			{{-1, REDUCE, 33}, },
			{{-1, ERROR, 173}, {54, SHIFT, 190}, {77, SHIFT, 191}, },
			{{-1, ERROR, 174}, {31, SHIFT, 192}, },
			{{-1, ERROR, 175}, {77, SHIFT, 193}, },
			{{-1, REDUCE, 44}, },
			{{-1, ERROR, 177}, {54, SHIFT, 194}, {77, SHIFT, 195}, },
			{{-1, REDUCE, 149}, },
			{{-1, REDUCE, 112}, },
			{{-1, ERROR, 180}, {77, SHIFT, 196}, },
			{{-1, REDUCE, 107}, },
			{{-1, REDUCE, 60}, {77, SHIFT, 183}, },
			{{-1, REDUCE, 157}, },
			{{-1, REDUCE, 55}, {77, SHIFT, 183}, },
			{{-1, ERROR, 185}, {77, SHIFT, 158}, },
			{{-1, REDUCE, 54}, {77, SHIFT, 183}, },
			{{-1, REDUCE, 121}, {68, SHIFT, 198}, },
			{{-1, ERROR, 188}, {9, SHIFT, 79}, {10, SHIFT, 80}, {11, SHIFT, 106}, {12, SHIFT, 107}, {40, SHIFT, 109}, {48, SHIFT, 111}, {51, SHIFT, 112}, {59, SHIFT, 113}, {66, SHIFT, 114}, {76, SHIFT, 115}, },
			{{-1, REDUCE, 122}, },
			{{-1, ERROR, 190}, {77, SHIFT, 200}, },
			{{-1, REDUCE, 45}, },
			{{-1, ERROR, 192}, {54, SHIFT, 201}, {77, SHIFT, 202}, },
			{{-1, REDUCE, 48}, },
			{{-1, ERROR, 194}, {77, SHIFT, 203}, },
			{{-1, REDUCE, 46}, },
			{{-1, REDUCE, 108}, },
			{{-1, REDUCE, 56}, {77, SHIFT, 183}, },
			{{-1, ERROR, 198}, {9, SHIFT, 79}, {10, SHIFT, 80}, {11, SHIFT, 106}, {12, SHIFT, 107}, {40, SHIFT, 109}, {48, SHIFT, 111}, {51, SHIFT, 112}, {59, SHIFT, 113}, {66, SHIFT, 114}, {76, SHIFT, 115}, },
			{{-1, REDUCE, 123}, },
			{{-1, REDUCE, 49}, },
			{{-1, ERROR, 201}, {77, SHIFT, 205}, },
			{{-1, REDUCE, 47}, },
			{{-1, REDUCE, 50}, },
			{{-1, REDUCE, 124}, },
			{{-1, REDUCE, 51}, },
        };*/
    private static int[][][] gotoTable;
/*      {
			{{-1, 3}, },
			{{-1, 4}, },
			{{-1, 5}, {64, 135}, },
			{{-1, 6}, },
			{{-1, 43}, },
			{{-1, 44}, {43, 119}, },
			{{-1, 45}, {43, 120}, {44, 121}, {119, 156}, },
			{{-1, 46}, {45, 122}, {120, 122}, {121, 122}, {156, 122}, },
			{{-1, 47}, },
			{{-1, 48}, },
			{{-1, 49}, },
			{{-1, 50}, },
			{{-1, 51}, },
			{{-1, 52}, },
			{{-1, 53}, },
			{{-1, 81}, },
			{{-1, 126}, {129, 163}, },
			{{-1, 127}, },
			{{-1, 128}, {130, 165}, {164, 165}, },
			{{-1, 54}, },
			{{-1, 55}, },
			{{-1, 56}, },
			{{-1, 57}, {56, 131}, },
			{{-1, 133}, {131, 166}, },
			{{-1, 58}, },
			{{-1, 104}, },
			{{-1, 59}, },
			{{-1, 60}, },
			{{-1, 61}, {60, 134}, },
			{{-1, 62}, },
			{{-1, 7}, },
			{{-1, 181}, },
			{{-1, 63}, },
			{{-1, 8}, },
			{{-1, 67}, },
			{{-1, 139}, },
			{{-1, 116}, {67, 140}, {108, 152}, {110, 154}, {138, 168}, {139, 170}, {153, 179}, {169, 187}, {171, 189}, {188, 199}, {198, 204}, },
			{{-1, 97}, {95, 150}, },
			{{-1, 98}, {97, 151}, {150, 151}, },
			{{-1, 99}, },
			{{-1, 117}, {31, 82}, {81, 145}, {89, 149}, },
			{{-1, 129}, },
			{{-1, 130}, {129, 164}, },
			{{-1, 159}, {127, 162}, {157, 182}, {160, 184}, {161, 186}, {185, 197}, },
        };*/
    private static String[] errorMessages;
/*      {
			"expecting: number88, number not88",
			"expecting: data name",
			"expecting: '.', binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, filler, function pointer, global, index, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, redefines, sign, synchronized, trailing, usage, value, data name",
			"expecting: EOF",
			"expecting: '.'",
			"expecting: value, values",
			"expecting: '.', binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, index, justified, leading, national, native, object, occurs, packed decimal, picture, pointer, procedure pointer, sign, synchronized, trailing, usage, value",
			"expecting: when, zeros",
			"expecting: '.', binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, index, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, sign, synchronized, trailing, usage, value",
			"expecting: format",
			"expecting: '.', binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, index, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, redefines, sign, synchronized, trailing, usage, value",
			"expecting: '.', binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, index, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, right, sign, synchronized, trailing, usage, value",
			"expecting: '.', binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, index, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, separate, sign, synchronized, trailing, usage, value",
			"expecting: reference",
			"expecting: ',', '/', '+', '-', '*', '$', '(', number not88, numeric literal, dot zee, dot minus, dot plus, is, data name",
			"expecting: is, leading, trailing",
			"expecting: '.', binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, index, justified, leading, left, national, object, occurs, packed decimal, picture, pointer, procedure pointer, right, sign, synchronized, trailing, usage, value",
			"expecting: binary, comp, comp1, comp2, comp3, comp4, comp5, comp6, display, display1, function pointer, index, is, national, object, packed decimal, pointer, procedure pointer",
			"expecting: number88, number not88, alphanumeric literal, numeric literal, all, high values, is, low values, nulls, quotes, spaces, zeros",
			"expecting: '.', binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, index, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, redefines, renames, sign, synchronized, trailing, usage, value",
			"expecting: '.', ascending, binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, descending, display, display1, external, function pointer, global, index, indexed, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, sign, synchronized, trailing, usage, value",
			"expecting: leading, trailing",
			"expecting: binary, comp, comp1, comp2, comp3, comp4, comp5, comp6, display, display1, function pointer, index, national, object, packed decimal, pointer, procedure pointer",
			"expecting: number88, number not88, EOF",
			"expecting: number88, number not88, alphanumeric literal, numeric literal, all, are, high values, low values, nulls, quotes, spaces, zeros",
			"expecting: number88, number not88, alphanumeric literal, numeric literal, all, high values, low values, nulls, quotes, spaces, zeros",
			"expecting: zeros",
			"expecting: is, data name",
			"expecting: '.', binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, index, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, sign, synchronized, trailing, usage, value, data name",
			"expecting: '.', ',', ')', number88, number not88, alphanumeric literal, numeric literal, ascending, binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, depending, descending, display, display1, external, function pointer, global, high values, index, indexed, justified, leading, low values, national, nulls, object, occurs, packed decimal, picture, pointer, procedure pointer, quotes, sign, spaces, synchronized, through, times, to, trailing, usage, value, zeros",
			"expecting: '.', ascending, binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, depending, descending, display, display1, external, function pointer, global, index, indexed, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, sign, synchronized, times, to, trailing, usage, value",
			"expecting: '.', ',', '/', '+', '-', '*', '$', '(', number not88, numeric literal, dot zee, dot minus, dot plus, binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, index, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, sign, synchronized, trailing, usage, value, data name",
			"expecting: ',', '/', '+', '-', '*', '$', '(', number not88, numeric literal, dot zee, dot minus, dot plus, data name",
			"expecting: '.', ',', number88, number not88, alphanumeric literal, numeric literal, binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, high values, index, justified, leading, low values, national, nulls, object, occurs, packed decimal, picture, pointer, procedure pointer, quotes, sign, spaces, synchronized, through, trailing, usage, value, zeros",
			"expecting: number88, number not88, alphanumeric literal, numeric literal, high values, low values, nulls, quotes, spaces, zeros",
			"expecting: is, key, data name",
			"expecting: by, data name",
			"expecting: '.', binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, index, indexed, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, sign, synchronized, trailing, usage, value",
			"expecting: '.', binary, blank, character, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, index, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, sign, synchronized, trailing, usage, value",
			"expecting: '.', ',', number88, number not88, alphanumeric literal, numeric literal, high values, low values, nulls, quotes, spaces, zeros",
			"expecting: '.', ',', number88, number not88, alphanumeric literal, numeric literal, high values, low values, nulls, quotes, spaces, through, zeros",
			"expecting: depending, times",
			"expecting: on, data name",
			"expecting: '.', ascending, binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, depending, descending, display, display1, external, function pointer, global, index, indexed, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, sign, synchronized, trailing, usage, value",
			"expecting: ')'",
			"expecting: '.', through",
			"expecting: '.', ascending, binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, descending, display, display1, external, function pointer, global, index, indexed, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, sign, synchronized, trailing, usage, value, data name",
			"expecting: '.', binary, blank, comp, comp1, comp2, comp3, comp4, comp5, comp6, date, display, display1, external, function pointer, global, index, indexed, justified, leading, national, object, occurs, packed decimal, picture, pointer, procedure pointer, sign, synchronized, trailing, usage, value, data name",
			"expecting: depending",
        };*/
    private static int[] errors;
/*      {
			0, 1, 2, 3, 4, 4, 4, 4, 4, 5, 6, 7, 8, 6, 6, 8, 6, 8, 8, 9, 6, 6, 8, 10, 8, 8, 8, 11, 12, 8, 13, 0, 8, 14, 8, 8, 1, 15, 16, 12, 17, 18, 19, 10, 8, 8, 8, 8, 8, 8, 8, 8, 8, 20, 8, 8, 21, 12, 8, 8, 22, 8, 8, 8, 23, 18, 24, 25, 8, 26, 8, 8, 8, 8, 27, 8, 8, 8, 28, 29, 29, 0, 30, 31, 31, 31, 31, 31, 31, 0, 31, 31, 31, 31, 31, 32, 31, 31, 31, 31, 8, 21, 8, 8, 8, 22, 33, 33, 34, 33, 25, 33, 33, 33, 33, 33, 8, 33, 1, 8, 8, 8, 8, 35, 35, 36, 20, 35, 37, 20, 37, 12, 38, 8, 8, 4, 25, 25, 34, 39, 40, 8, 1, 8, 8, 41, 42, 43, 0, 44, 31, 31, 8, 34, 8, 45, 8, 1, 46, 47, 1, 27, 46, 20, 37, 37, 8, 8, 39, 34, 40, 34, 8, 42, 48, 1, 20, 42, 31, 8, 1, 4, 47, 46, 46, 1, 46, 40, 34, 39, 1, 20, 42, 20, 1, 20, 4, 46, 34, 39, 20, 1, 20, 20, 39, 20, 
        };*/

    static 
    {
        try
        {
            DataInputStream s = new DataInputStream(
                new BufferedInputStream(
                Parser.class.getResourceAsStream("parser.dat")));

            // read actionTable
            int length = s.readInt();
            Parser.actionTable = new int[length][][];
            for(int i = 0; i < Parser.actionTable.length; i++)
            {
                length = s.readInt();
                Parser.actionTable[i] = new int[length][3];
                for(int j = 0; j < Parser.actionTable[i].length; j++)
                {
                for(int k = 0; k < 3; k++)
                {
                    Parser.actionTable[i][j][k] = s.readInt();
                }
                }
            }

            // read gotoTable
            length = s.readInt();
            gotoTable = new int[length][][];
            for(int i = 0; i < gotoTable.length; i++)
            {
                length = s.readInt();
                gotoTable[i] = new int[length][2];
                for(int j = 0; j < gotoTable[i].length; j++)
                {
                for(int k = 0; k < 2; k++)
                {
                    gotoTable[i][j][k] = s.readInt();
                }
                }
            }

            // read errorMessages
            length = s.readInt();
            errorMessages = new String[length];
            for(int i = 0; i < errorMessages.length; i++)
            {
                length = s.readInt();
                StringBuffer buffer = new StringBuffer();

                for(int j = 0; j < length; j++)
                {
                buffer.append(s.readChar());
                }
                errorMessages[i] = buffer.toString();
            }

            // read errors
            length = s.readInt();
            errors = new int[length];
            for(int i = 0; i < errors.length; i++)
            {
                errors[i] = s.readInt();
            }

            s.close();
        }
        catch(Exception e)
        {
            throw new RuntimeException("The file \"parser.dat\" is either missing or corrupted.");
        }
    }
}
