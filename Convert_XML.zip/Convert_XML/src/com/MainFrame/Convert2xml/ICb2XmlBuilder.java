package com.MainFrame.Convert2xml;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;

import javax.xml.stream.XMLStreamException;
import javax.xml.transform.Result;

import com.MainFrame.Convert2xml.def.Cb2xmlConstants;
import com.MainFrame.Convert2xml.def.ICopybook;
import com.MainFrame.Convert2xml.def.IBasicDialect;
import com.MainFrame.Convert2xml.sablecc.lexer.LexerException;
import com.MainFrame.Convert2xml.sablecc.parser.ParserException;



public interface ICb2XmlBuilder {

	
	public ICb2XmlBuilder setDebug(boolean debug); 
	
	
	public ICb2XmlBuilder setCobolLineFormat(int format);
	
	
	public ICb2XmlBuilder setCobolColumns(int startingColumn, int lastColumn);
	
	
	public ICb2XmlBuilder setIndent(boolean indent);

	
	public ICb2XmlBuilder setXmlEncoding(String encoding);

	
	public ICb2XmlBuilder setStackSize(long stackSize);

	
	public ICb2XmlBuilder setXmlFormat(Cb2xmlConstants.Cb2xmlXmlFormat xmlFormat);

	
	public ICb2XmlBuilder setDialect(IBasicDialect dialect);

	
	public ICb2XmlBuilder setLoadComments(boolean loadComments);
	
	
	public ICopybook asCobolItemTree();
	
	public String asXmlString() throws XMLStreamException, LexerException, IOException, ParserException;
	
	public void writeXml(String filename) throws XMLStreamException, LexerException, IOException, ParserException;

	
	public void writeXml(OutputStream out) throws XMLStreamException, LexerException, IOException, ParserException;
	
	
	public void writeXml(Writer writer) throws XMLStreamException, LexerException, IOException, ParserException;

	public void writeXml(Result result) throws XMLStreamException, LexerException, IOException, ParserException;

}
