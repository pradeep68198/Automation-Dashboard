package com.MainFrame.Convert2xml.def;


public interface IBasicDialect {

	public abstract NumericDefinition getNumericDefinition();
	
}
