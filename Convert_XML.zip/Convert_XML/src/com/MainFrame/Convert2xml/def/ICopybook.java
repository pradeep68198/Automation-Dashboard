
package com.MainFrame.Convert2xml.def;

import java.util.List;

public interface ICopybook extends IItemBase {

	
	public abstract List<? extends IItem> getChildItems();

	
	public abstract String getFilename();

	
	public abstract String getDialect();

}