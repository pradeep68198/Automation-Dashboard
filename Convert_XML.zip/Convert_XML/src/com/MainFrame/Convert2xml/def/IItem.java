
package com.MainFrame.Convert2xml.def;

import java.util.List;

import com.MainFrame.Convert2xml.def.Cb2xmlConstants.SignClause;



public interface IItem extends IItemBase {

	public static final int NULL_INT_VALUE = Integer.MIN_VALUE;


	
	public abstract List<? extends ICondition> getConditions();
	
	
	public abstract String getLevelString();
	public abstract int getLevelNumber();
	
	
	public abstract String getFieldName();

	
	
	public abstract String getPicture();


	public abstract Cb2xmlConstants.NumericClass getNumericClass();

	
	public abstract String getDependingOn();

	/**
	 * Gets the value of the displayLength property.
	 * 
	 */
	public abstract int getDisplayLength();

	public abstract int getDisplayPosition();

//	public boolean isEditedNumeric();

//	/**
//	 * Wether a physical decimal point appears in the field
//	 * (i.e. a physical '.' is used instead of the assumed decimal
//	 *  ~~ -,--9.99 instead of s9(4)V99)
//	 *  
//	 * @return
//	 */
//	public boolean isInsertDecimal();
	
	/**
	 * Gets the value of the usage property. 
	 */
	public abstract Cb2xmlConstants.Usage getUsage();

	/**
	 * Gets the value of the occurs property.
	 * 
	 */
	public abstract int getOccurs();

	/**
	 * Gets the value of the occursMin property.
	 * 
	 * @return
	 *     possible object is
	 *     {@link Integer }
	 *     
	 */
	public abstract int getOccursMin();

	/**
	 * Justified clause (returns null if no justified clause)
	 */
	public Cb2xmlConstants.Justified getJustified();
	
	/**
	 * Gets the value of the position property.
	 * 
	 */
	public abstract int getPosition();

	/**
	 * Gets the name of the item being redefined.
	 */
	public abstract String getRedefinesFieldName();

	/**
	 * Gets the scale of the number (< 0 for non-numeric). 
	 */
	public abstract int getScale();

//	/**
//	 * Does the the item have a sign ???
//	 */
//	public abstract boolean isSigned();

	/**
	 * Get details of Cobol Sign clause
	 */
	public abstract SignClause getSignClause();

	/**
	 * Gets the number of bytes the field occupies
	 */
	public abstract int getStorageLength();

	/**
	 * Is there a Sync clause ??.
	 */
	public abstract boolean isSync();

	/**
	 * Gets the value of the value property.
	 */
	public abstract String getValue();


	/**
	 * is the field redefined ???
	 */
	public abstract boolean isFieldRedefined();

	/**
	 * does the fields redefine another field
	 */
	public abstract boolean isFieldRedefines();

	/**
	 * is the usage inherited from an upper level
	 */
	public abstract boolean isInheritedUsage();

	/**
	 * is the usage inherited from an upper level
	 */
	public boolean isBlankWhenZero();

//	public int getDoubleByteChars();
}