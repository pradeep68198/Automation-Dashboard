
package com.MainFrame.Convert2xml.def;

import java.util.List;

public interface IItemJr extends IItem {
	

	public abstract int getType();

	
	@Override
	public abstract List<? extends IItemJr> getChildItems();
}
