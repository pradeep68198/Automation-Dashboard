
package com.MainFrame.Convert2xml.def;


public interface NumericDefinition {


    
    public abstract String getName();

     public abstract int getBinarySize(String usage, int numDigits, boolean positive, boolean sync);
    
	public abstract int chkStorageLength(int storageLength, String usage);

    public abstract int getSyncAt(String usage, int actualLength);
}
