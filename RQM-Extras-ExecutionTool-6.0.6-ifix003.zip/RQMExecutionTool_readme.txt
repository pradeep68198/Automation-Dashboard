Rational Quality Manager Command Line Execution Tool, Version 6.0.6 iFix003
===========================================================================

Compatibility
=============

The Rational Quality Manager Command Line Execution Tool is compatible with Rational Quality Manager 4.0 and later. 
To use the execution tool with a project area that is enabled for configuration management, use version 6.0.1 or later of the execution tool.

Latest documentation
====================

For the latest Rational Quality Manager Command Line Execution Tool documentation, see https://jazz.net/wiki/bin/view/Main/RQMExecutionTool.

Introduction
============

The Rational Quality Manager Command Line Execution Tool is a stand-alone Java application for running test case execution records (TCERs) and 
test suite execution records (TSERs). You can use the tool to enable test execution from the command line for automation frameworks outside 
Rational Quality Manager. You can trigger test execution and then exit either immediately or after the tests are run. 

The following exit codes are valid:
0: Execution was triggered in Rational Quality Manager, but might not have completed.
1: An internal error occurred. For details, see the log.
2: Execution was canceled from within Rational Quality Manager.
3: The login failed. Either the user name or password is incorrect.
4: An invalid argument was provided. For the argument list and usage, see the help.
5: Execution was triggered in Rational Quality Manager, but the tool exited before execution was complete.
6: A network connection error occurred.
7: The project was not found.
20: Execution completed with a status of Passed.
21: Execution completed with a status of Failed.
22: Execution completed with a status of Blocked.
23: Execution completed with a status of Error.
24: Execution completed with a status of Inconclusive.
25: Execution completed with a status of Incomplete.
26: Execution completed with a status of Partially Blocked.
27: Execution completed with a status of Permanently Failed.
28: Execution completed with a status of Deferred.
29: Execution was triggered, but the tool exited because of an internal error.
30: An unknown error occurred. For details, see the log.
31: Execution completed, but the test was not executed.
32: Execution was canceled successfully. 


Setup considerations
====================

To use the execution tool, complete these steps:

    * Download the RQMExecutionTool.zip file to a temporary location.
    * Extract the contents of the file to a known location, for example, <RQMExecutionTool>.
    * Locate a Java JRE that is at least version 1.6, for example, <JavaHome16>.
    * Change directories to <RQMExecutionTool> and execute this command: <JavaHome16>/bin/java -jar RQMExecutionTool.jar -help
    * Review the available arguments to determine which ones to use. 
	  Note: Ant tasks are also available for the same functions. For reference, see the sample rqmexectool.xml file.
    * If an out-of-memory error occurs, increase the available JVM memory by adding the -Xmxnm argument where n is the maximum amount of available memory (MB) in multiples of 1024 (recommended values: 2048 MB or 2 GB).
    * If you run the tool from a Windows command prompt, some special characters (for example, ( ) = ; , ` ' % " * ? & \ < > ^ |) in the command are interpreted by the command prompt and you must preface them with a caret (for example, ^( ^) ^= ^; ^, ^` ^' ^% ^" ^* ^? ^& ^\ ^< ^> ^^ ^|).
    * If you run the tool from a UNIX shell, some special characters (for example, ~ ` # $ & * ( ) \ | [ ] { } ; ' " < > / ? *) in the command are interpreted by the shell and you must preface them with a backslash (for example, \~ \` \# \$ \& \* \( \) \\ \| \[ \] \{ \} \; \' \" \< \> \/ \? \*).
	* Attempting to start the command line adapter when TLS 1.2 is used and the -Dcom.ibm.team.repository.transport.client.protocol="TLSv1.2" argument is not set will result in a connection handshake failure. If using TLS 1.2, ensure the -Dcom.ibm.team.repository.transport.client.protocol="TLSv1.2" argument is included in order to ensure a successful connection.	

Argument reference
==================

To execute test case execution records (TCERs):

ExecutionUtility -tcerId -user -publicURI -projectName [-password] [-passwordFile] [-createPasswordFile] [-scriptId] [-adapterId] [-resultState] [-exitOnComplete] [-variables] [-testCellName]

To execute TCERs when the tcerId value is not provided:

ExecutionUtility -testCaseId -user -publicURI -projectName [-testPlanId] [-testEnvironment] [-currentIteration] [-runLastCreatedER] [-password] [-passwordFile] [-createPasswordFile] [-scriptId] [-adapterId] [-resultState] [-exitOnComplete] [-variables] [-testCellName]

To cancel TCER execution:

ExecutionUtility -requestId -cancel -user -publicURI -projectName [-password] [-passwordFile] [-createPasswordFile]
        
To execute test suite execution records (TSERs):

ExecutionUtility -tserId -user -publicURI -projectName [-password] [-passwordFile] [-createPasswordFile] [-haltOnFailure] [-parallelExecution] [-suiteStepScriptIds] [-suiteStepAdapterIds] [-adapterIdForAllSuiteStep][-resultState] [-exitOnComplete] [-variables] [-passVariables] [-testCellName]

To execute TSERs when the tserId value is not provided:

ExecutionUtility -testSuiteId -user -publicURI -projectName [-testPlanId] [-testEnvironment] [-currentIteration] [-runLastCreatedER] [-password] [-passwordFile] [-createPasswordFile] [-haltOnFailure] [-parallelExecution] [-suiteStepScriptIds] [-suiteStepAdapterIds] [-adapterIdForAllSuiteStep][-resultState] [-exitOnComplete] [-variables] [-passVariables] [-testCellName]

To cancel TSER execution:

ExecutionUtility -tserId -cancel -user -publicURI -projectName [-password] [-passwordFile] [-createPasswordFile] [-testsuiteResultId]

 -help : Prints this help message
 -version : Prints the version of the execution tool
 
 #Mandatory arguments
 -user=<userid> : User ID for a valid user with execution permission in the specified project.
 -publicURI=https://<server>:<port>/<context root> : Base public URI of the Rational Quality Manager server.
 -projectName=<Project area name> : Name of the project area. 
 -projectAlias=<Project area alias> : Optional. Alias of the project area. If specified, the alias overrides the project name. Note: The alias must be URL-encoded (see https://jazz.net/wiki/bin/view/Main/RqmApi#projectAlias).
 *[Either of the following four arguments is mandatory for the command line. Do not provide these in the Ant tasks.]
 -tcerId=<integer ID or external ID> : Integer ID of the TCER to execute.
 -testCaseId=<integer ID> : Integer ID of the test case for which to find the TCER ID.
 -tserId=<integer ID> : Integer ID of the TSER to execute.
 -testSuiteId=<integer ID> : Integer ID of the test suite for which to find the TSER ID.
 -cancel=<boolean - true or false> : Cancel the execution of the TCER or TSER. 
 -testsuiteResultId=<integer ID> : Integer ID of the test suite result to cancel. When you run the TSER by using the tool, the log file will have an entry with - <testsuiteResultId>value</testsuiteResultId>. Use that value to provide the ID for the test suite result.
 -requestId=<integer ID> : Integer ID of the execution request that is created during the execution of the TCER. When you run the TCER by using the tool, the log file will have an entry with - <requestId>value</requestId>. Use that value to provide the request ID.
  
 #Optional arguments
 -password=<password> : The password for the specified user ID. (Only one of -password or -passwordFile must be specified. If -passwordFile is specified, the -password parameter will be ignored. The user will be prompted for a password if it is not provided by one of the parameters.)
 -passwordFile=<password file> : The path to a password file that contains the password for the specified user ID. Valid password files can be created by this tool with the -createPasswordFile parameter or from the Jazz Build Engine tool.
 -createPasswordFile : Creates a password file in the path specified in the -passwordFile parameter. The password is provided by the -password parameter or the user is prompted if the password parameter is not provided.
 -streamId=<Item ID of stream> : (Specify either the streamId or StreamName value.) The stream that contains the artifacts to execute. If not specified, the stream will be the default project area stream. 
 -streamName=<Name of stream> : (Specify either the streamId or StreamName value.) The stream that contains the artifacts to execute. If not specified, the stream will be the default project area stream. 
 -scriptId=<Web ID of the script to execute> : If no script is specified, the default script set on the test execution record will be executed.
 -adapterId=<Web ID of the adapter (numeric) OR user-specified adapter name (non-numeric)> : Adapter on which to execute for remote execution. If not specified, an available adapter is assigned for the execution.
 -resultState=<State of the result> : If specified, execution will be considered "execute without execution" and the result will be created directly with the result state provided.
        Supported values:
        com.ibm.rqm.execution.common.state.passed
		com.ibm.rqm.execution.common.state.failed
		com.ibm.rqm.execution.common.state.blocked
		com.ibm.rqm.execution.common.state.part_blocked
		com.ibm.rqm.execution.common.state.incomplete
		com.ibm.rqm.execution.common.state.perm_failed
		com.ibm.rqm.execution.common.state.deferred
		com.ibm.rqm.execution.common.state.inconclusive
		com.ibm.rqm.execution.common.state.error
   
 -exitOnComplete=<true or false> : If true, the command will not exit until execution is completed or canceled.
    	If false (default), the command will exit immediately after triggering execution.
 -printResultUrl=<true or false> : If true, the URL for the associated execution result will be logged.
 		Note: For automated test case execution, this option also requires -exitOnComplete=true to be specified.
 -variables=<var1Name:var1Value,var2Name:,var3Name:var3Value> : Specify the execution variables and optional values to pass to execution.
        Note: Variable names and values are separated by colons (:), if values are provided.
 -haltOnFailure=<true or false> : If true, execution stops if any test cases fail in the overall test suite execution.
        This value is optional and applies only to serial execution. The default value is as specified in the test suite.
 -parallelExecution=<true or false> : If true, all suite steps execute in parallel. If false, the execution is sequential.
        Note: The default value is as specified in the test suite level.
 -suiteStepScriptIds=1,,4,10 : Optional. Comma-separated script IDs for each step in the order of steps. Leave the value blank for steps that do not apply or to use the default script.
        For example, to specify script ID 4 for step 1, and script 78 for step 3 in a suite with 5 steps, the argument value would be as follows:
        -suiteStepScriptIds=4,,78,,
 -suiteStepAdapterIds=<comma-separated adapter IDs (numeric) OR user-specified adapter names (non-numeric) for each suite step> : Optional. Comma-separated adapter IDs for each step in the order of steps. Leave the value blank for a step where an adapter is not required or if you want Rational Quality Manager to assign an adapter.
        For example, to specify adapter ID 20 for step 2, and adapter 15 for step 3 in a suite with 3 steps, the argument value would be as follows:
        -suiteStepAdapterIds=,20,15
 -adapterIdForAllSuiteStep=<adapter ID (numeric) OR user-specified adapter name (non-numeric)> : Optional adapter ID for all steps. This value overrides the parameter "suiteStepAdapterIds".
 -passVariables=<true or false> : If true, variables will be passed from one step to the next in the sequential execution of the test suite.
 -progressCycle=<number in seconds> : Applicable only when the -exitOnComplete parameter is true. This cycle determines the gap between two consecutive checks for the progress of TER/TCSER.
        The default value is 10 seconds. If execution is expected to take 10 minutes, a 5-minute (300 sec) cycle would be idle to avoid too much traffic on the server.
 -channelName=<channelName> : Name of the channel on which the test case execution is performed.
 -suiteChannelName=<channelName> : Name of the channel on which test suite execution is performed.
 -testCellItemId=<testCellItemId> : Item ID of the test cell from which adapters will be selected during execution of a test case execution record or test suite execution record.
 -testCellName=<testCellName> : Name of the test cell from which adapters will be selected during execution of a test case execution record or test suite execution record. This argument is ignored if the testCellItemId argument is provided.
 -verbose=<true or false> : If true, additional log messages are printed in the console.
 -buildRecord=<Web ID of the build record> : ID of the build record to link to the test case result that is created by TCER execution.
 -suiteBuildRecord=<Web ID of the build record> : ID of the build record to link to the test suite result and test case result that is created by TSER execution.
 -configURI=<URI of a global configuration or stream> : The URI that uniquely identifies a global configuration or stream against which to execute the tool.
 *[The following arguments are provided when the testCaseId or testSuiteId value is provided instead of the tcerId or tserId value]
 -testPlanId=<Integer ID> : Finds the execution record in a specified test plan.
 -testEnvironment=<EnvironmentName> : Limits the search of an execution record to a specific environment.
 -currentIteration=<true or false> : If true, chooses the execution record in the current iteration only. 
 -runLastCreatedER=<true or false> : If true, uses the last created execution record when multiple execution records are available for a single test case or suite.
 
Examples
==============
Note: These examples use /qm as the default context root for Rational Quality Manager. The default context root is configurable during installation. 

        To execute a TCER synchronously:
        <JavaHome16>/bin/java -jar RQMExecutionTool.jar -tcerId=1512 -projectName="Quality Manager" -publicURI=https://myhost:9443/qm -user=<userid> -passwordFile=<path to a file that contains the password> -scriptId=10 -adapterId=20 -exitOnComplete=true
        
        To find and execute a TCER synchronously when the tcerId value is not provided:
        <JavaHome16>/bin/java -jar RQMExecutionTool.jar -testCaseId=512 -testPlanId=315 -testEnvironment=<Environment Name> -currentIteration=true -runLastCreatedER=true -projectName="Quality Manager" -publicURI=https://myhost:9443/qm -user=<userid> -passwordFile=<path to a file that contains the password> -scriptId=10 -adapterId=20 -exitOnComplete=true
        
        To cancel execution of a TCER:
        <JavaHome16>/bin/java -jar RQMExecutionTool.jar -requestId=154 -projectName="Quality Manager" -publicURI=https://myhost:9443/qm -user=<userid> -password=<password> -cancel=true

        To execute a TSER asynchronously:
        <JavaHome16>/bin/java -jar RQMExecutionTool.jar -tserId=134 -projectName="Quality Manager" -publicURI=https://myhost:9443/qm -user=<userid> -password=<password> -suiteStepScriptIds=10,23,45 -suiteStepAdapterIds=20,20,11 -exitOnComplete=false
        
        To find and execute a TSER synchronously when the tserId value is not provided:
        <JavaHome16>/bin/java -jar RQMExecutionTool.jar -testSuiteId=512 -testPlanId=315 -testEnvironment=<Environment Name> -currentIteration=true -runLastCreatedER=true -projectName="Quality Manager" -publicURI=https://myhost:9443/qm -user=<userid> -passwordFile=<path to a file that contains the password> -scriptId=10 -adapterId=20 -exitOnComplete=true

		To cancel execution of a TSER:
        <JavaHome16>/bin/java -jar RQMExecutionTool.jar -tserId=134 -projectName="Quality Manager" -publicURI=https://myhost:9443/qm -user=<userid> -password=<password> -cancel=true

