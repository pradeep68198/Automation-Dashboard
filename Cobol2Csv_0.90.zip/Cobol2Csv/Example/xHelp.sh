#! /bin/sh


java -jar ../lib/MultiRecordCobol2Csv.jar -h
