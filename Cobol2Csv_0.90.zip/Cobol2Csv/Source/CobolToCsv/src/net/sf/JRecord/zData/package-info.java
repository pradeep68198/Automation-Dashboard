/**
 * 
 */
/**
 * @author bruce
 *
 */
package net.sf.JRecord.zData;