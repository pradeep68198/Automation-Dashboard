/**
 * 
 */
/**
 * @author bruce
 *
 */
package net.sf.JRecord.cbl2csv.imp;