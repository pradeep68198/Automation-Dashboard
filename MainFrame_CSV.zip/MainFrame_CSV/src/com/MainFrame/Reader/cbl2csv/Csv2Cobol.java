
package com.MainFrame.Reader.cbl2csv;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import com.MainFrame.Reader.JRecordInterface1;
import com.MainFrame.Reader.Common.CommonBits;
import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.cbl2csv.args.CommonCsv2CblCode;
import com.MainFrame.Reader.cbl2csv.args.ParseArgsCobol2Csv;
import com.MainFrame.Reader.def.IO.builders.ICobolIOBuilder;
import com.MainFrame.Reader.def.IO.builders.ICsvIOBuilder;
import com.MainFrame.Reader.utilityClasses.Copy;




public class Csv2Cobol {


//	/**
//	 * Basic CSV schema; it will be modified as required.
//	 */
//	private static String csvXml 
//					= "<RECORD RECORDNAME=\"Generic CSV\" COPYBOOK=\"\" "
//					+     "DELIMITER=\"|\" DESCRIPTION=\"Generic CSV\" "
//					+     "FILESTRUCTURE=\"" + Constants.IO_NAME_1ST_LINE + "\" STYLE=\"0\" RECORDTYPE=\"Delimited\" LIST=\"Y\" "
//					+     "QUOTE=\"\" RecSep=\"default\">"
//					+        "<FIELDS><FIELD NAME=\"Field 1\" POSITION=\"1\" TYPE=\"Char\"/></FIELDS>"
//					+ "</RECORD>";
//	
   
    public static void main(String[] arguments) { 

		try {
		    ParseArgsCobol2Csv csvArgs = new ParseArgsCobol2Csv(false, arguments);
		    
		    CommonBits.setUseCsvLine(true); // Use the new CsvLine !!!

		    if (csvArgs.infilePresent) {
		    	ICobolIOBuilder iobOut = JRecordInterface1.COBOL
		        		.newIOBuilder(csvArgs.copybookName);
		        doCopy(csvArgs, iobOut, 
		        		new FileInputStream(csvArgs.infile), new FileOutputStream(csvArgs.outfile));
		    }
		} catch (Exception e) {
			e.printStackTrace();
		}
    }

	
	public static void doCopy(ParseArgsCobol2Csv csvArgs, ICobolIOBuilder iobOut, InputStream inStream, OutputStream outStream) 
			throws IOException, FileNotFoundException {
		ICsvIOBuilder iobIn = JRecordInterface1.CSV
				.newIOBuilder(csvArgs.sep, csvArgs.quote)
					.setFont(csvArgs.inFont)
					.setParser(csvArgs.csvParser)
					.setFileOrganization(csvArgs.inputFileStructure);
		LayoutDetail outSchema = iobOut.getLayout();

        iobOut	 	.setFont(csvArgs.outFont)
        			.setDialect(csvArgs.binFormat)
        			.setFileOrganization(csvArgs.outputFileStructure);

        if (! CommonBits.areFieldNamesOnTheFirstLine(csvArgs.inputFileStructure)) {
        	CommonCsv2CblCode.updateCsvNames(iobOut.getLayout(), csvArgs, iobIn.defineFields());
        }
		Copy.copyFileUsingMap(
				iobIn.newReader(inStream), 
				iobOut.newWriter(outStream), outSchema, getNameList(csvArgs, outSchema), iobOut);
	}
    
    private static List<String> getNameList(ParseArgsCobol2Csv csvArgs, LayoutDetail schema) {
    	ArrayList<String> list = new ArrayList<String>(schema.getRecord(0).getFieldCount());
    	FieldDetail  f;
    	
    	for (int i = 0; i < schema.getRecordCount(); i++) {
    		for (int j = 0; j < schema.getRecord(0).getFieldCount(); j++) {
    			f = schema.getField(i, j);
    			list.add(csvArgs.updateName(f.getLookupName()));
    		}
    	}
    	
    	return list;
    }
    
 
    
//    /**
//     * This method updates field names, converting cobol '-' to _ and (,) to _
//     *  
//     * @param rec Schema to be updated
//     */
//    private static void updateFieldNames(ExternalRecord rec, ParseArgsCobol2Csv csvArgs) {
//    	ArrayList<DependingOn> dependingOn = rec.getDependingOn();
//    	if (dependingOn != null && dependingOn.size() > 0) {
//    		for (int i = 0; i < dependingOn.size(); i++) {
//    			DependingOn dep = dependingOn.get(i);
//    			dependingOn.set(
//    					i, 
//    					new DependingOn(
//    							csvArgs.updateName(dep.getVariableName()), 
//    							dep.getPosition(), dep.getOccursLength(), dep.getOccursMaxLength()));
//    		}
//    	}
//    	if (rec.getNumberOfRecords() == 0) {
//    		ExternalField recordField;
//    		for (int i = 0; i < rec.getNumberOfRecordFields(); i++) {
//    			recordField = rec.getRecordField(i);
//    			recordField.setName(csvArgs.updateName(recordField.getName()));
//    		}
//    	} else {
//    		for (int i = 0; i < rec.getNumberOfRecords(); i++) {
//    			updateFieldNames(rec.getRecord(i), csvArgs);
//    		}
//    	}
//    }
//
//    
//
//    
//    
//    /**
//     * Create a Csv Layout
//     * 
//     * @param csvArgs the arguments supplied to the program
//     * 
//     * @return requested layout
//     * @throws Exception any exception thrown
//     */
//    private static LayoutDetail getCsvLayout(ParseArgsCobol2Csv csvArgs) throws Exception {
//    	ExternalRecord csvRec 
//    			= ExternalRecord.newCsvRecord("Csv", Constants.IO_NAME_1ST_LINE, csvArgs.inFont, csvArgs.sep, csvArgs.quote)
//    							.asExternalRecord();
//    	
//    	csvRec.setRecordStyle(csvArgs.csvParser);
//    	
//    	return csvRec.asLayoutDetail();
//    }
}
