
package com.MainFrame.Reader.cbl2csv;

import com.MainFrame.Reader.JRecordInterface1;
import com.MainFrame.Reader.Common.CommonBits;
import com.MainFrame.Reader.ExternalRecordSelection.ExternalFieldSelection;
import com.MainFrame.Reader.cbl2csv.args.ParseArgsCobol2Csv;
import com.MainFrame.Reader.cbl2csv.args.RecordSelect;
import com.MainFrame.Reader.cbl2csv.imp.CobolToCsvBldr;
import com.MainFrame.Reader.cbl2csv.imp.ICobolToCsvBldr;
import com.MainFrame.Reader.def.IO.builders.ICobolIOBuilder;




public class Cobol2CsvMultiRecord {


    public static void main(String[] arguments) { 

		try {
		    ParseArgsCobol2Csv csvArgs = ParseArgsCobol2Csv.multiRecArgs(arguments);

		    CommonBits.setUseCsvLine(true); // Use the new CsvLine !!!
		    if (csvArgs.infilePresent) {
		        ICobolIOBuilder iobCbl = JRecordInterface1.COBOL
		        					.newIOBuilder(csvArgs.copybookName)
		        					.setDialect(csvArgs.binFormat)
		        					.setFileOrganization(csvArgs.inputFileStructure)
		        					.setFont(csvArgs.inFont)
		        					.setSplitCopybook(csvArgs.split)
		        					.setOptimizeTypes(csvArgs.reportInvalid);
				
				for (RecordSelect rs : csvArgs.recordSelect) {
					iobCbl.setRecordSelection(rs.recordName, newFieldSelection(rs.fieldName, rs.value));
				}

				ICobolToCsvBldr csvBldr = CobolToCsvBldr.newMultiRecordCsvBuilder()
								.setSeparator(csvArgs.sep)
								.setQuote(csvArgs.quote)
								.setOutputCharacterSet(csvArgs.outFont)
								.setLineReader(iobCbl.newReader(csvArgs.infile))
								.setUpdateFieldName(csvArgs.updateFieldName)
								.setWriteRecordName(csvArgs.addRecordNameToCsv)
								.setReportInvalidFields(csvArgs.reportInvalid)
							;
				String outFileName = csvArgs.outfile;
				
				if (csvArgs.lowValuesTxt != null) {
					csvBldr.setLowValueTxt(csvArgs.lowValuesTxt);
				}
				if (csvArgs.highValuesTxt != null) {
					csvBldr.setHighValueTxt(csvArgs.highValuesTxt);
				}
				if (csvArgs.numericSpaceTxt != null) {
					csvBldr.setNumericSpacesTxt(csvArgs.numericSpaceTxt);
				}
				
				if (outFileName.indexOf("${record}") >= 0) {
					csvBldr.setOutputFile(outFileName, "${record}");
				} else if (outFileName.indexOf("&record;") >= 0) {
					csvBldr.setOutputFile(outFileName, "&record;");
				} else if (outFileName.indexOf("{record}") >= 0) {
					csvBldr.setOutputFile(outFileName, "{record}");
				} else{
					csvBldr.setOutputFile(outFileName);
				}
				
				csvBldr.run();
		    }
		} catch (Exception e) {
			System.out.println();
			System.out.println();
			e.printStackTrace();
		}
    }

	
    public static ExternalFieldSelection newFieldSelection(String fieldName, String value) {
    	ExternalFieldSelection r = new ExternalFieldSelection(fieldName, value);
    	r.setCaseSensitive(false);
    	return r;
    }

}
