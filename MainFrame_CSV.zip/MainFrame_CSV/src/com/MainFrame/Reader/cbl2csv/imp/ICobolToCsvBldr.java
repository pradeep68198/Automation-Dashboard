package com.MainFrame.Reader.cbl2csv.imp;

import java.io.BufferedWriter;
import java.io.IOException;

import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.IO.AbstractLineReader;
import com.MainFrame.Reader.cbl2csv.args.IUpdateFieldName;

public interface ICobolToCsvBldr {

	
	ICobolToCsvBldr setSchema(LayoutDetail schema);

	
	ICobolToCsvBldr setSeparator(String seperator);

	
	ICobolToCsvBldr setQuote(String quote);

	
	ICobolToCsvBldr setWriteRecordName(boolean writeRecordName);

	
	ICobolToCsvBldr addRecordDetails(String recordName, BufferedWriter writer);

	
	ICobolToCsvBldr setOutputFile(String filename, String recordVariable);

	
	ICobolToCsvBldr setOutputFile(String filename);

	
	ICobolToCsvBldr setCsvWriter(BufferedWriter csvWriter);

	
	
	ICobolToCsvBldr setCsvHeader(boolean csvHeader);

	
	ICobolToCsvBldr setLineReader(AbstractLineReader reader);

	
	ICobolToCsvBldr setOutputCharacterSet(String outputCharacterset);

	
	ICobolToCsvBldr setUpdateFieldName(IUpdateFieldName updateFieldName);

	
	void run() throws IOException;

	
	ICobolToCsvBldr setNumericSpacesTxt(String numericSpaces);

	
	ICobolToCsvBldr setHighValueTxt(String highValueTxt);

	
	ICobolToCsvBldr setLowValueTxt(String lowValueTxt);

	
	ICobolToCsvBldr setReportInvalidFields(boolean reportInvalidFields);

}