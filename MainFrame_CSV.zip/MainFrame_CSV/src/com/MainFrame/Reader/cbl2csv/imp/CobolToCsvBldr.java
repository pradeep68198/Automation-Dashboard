package com.MainFrame.Reader.cbl2csv.imp;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import com.MainFrame.Reader.JRecordInterface1;
import com.MainFrame.Reader.Common.Conversion;
import com.MainFrame.Reader.Common.RecordException;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.IO.AbstractLineReader;
import com.MainFrame.Reader.cbl2csv.args.IUpdateFieldName;
import com.MainFrame.Reader.def.IO.builders.ICobolIOBuilder;


public class CobolToCsvBldr implements ICobolToCsvDefinition, ICobolToCsvBldr {
    private LayoutDetail schema=null;
    private String separator="\t", quote="\"",  outFileName, recordVariable, outputCharacterSet, 
    		lowValueTxt="Low-Values", highValueTxt="High-Values", numericSpacesTxt="";
    private AbstractLineReader lineReader;
    private BufferedWriter csvWriter;
    
    private boolean writeRecordName = false, csvHeader=true, reportInvalidFields=false;
    private IUpdateFieldName updateFieldName=new IUpdateFieldName() {		
		@Override public String updateName(String name) {
			return name;
		}
	};
    
	
    public static ICobolIOBuilder newCobolIOBuilder(String copybookFileame) {
    	return JRecordInterface1.COBOL.newIOBuilder(copybookFileame);
    }
    
    

    public static ICobolIOBuilder newCobolIOBuilder(Reader copybookReader, String copybookName) {
    	return JRecordInterface1.COBOL.newIOBuilder(copybookReader, copybookName);
    }
    
    
    public static ICobolToCsvBldr newMultiRecordCsvBuilder() {
    	return new CobolToCsvBldr();
    }
    
    private List<RecordWriterDetails> recordList = new ArrayList<RecordWriterDetails>();

	
	@Override
	public final LayoutDetail getSchema() {
		if (schema == null && lineReader != null) {
			schema = lineReader.getLayout();
		}
		return schema;
	}


	@Override
	public final CobolToCsvBldr setSchema(LayoutDetail schema) {
		this.schema = schema;
		return this;
	}

	
	@Override
	public final String getSeparator() {
		return separator;
	}

	@Override
	public final CobolToCsvBldr setSeparator(String separator) {
		this.separator = separator;
		return this;
	}

	@Override
	public final String getQuote() {
		return quote;
	}

	
	@Override
	public final CobolToCsvBldr setQuote(String quote) {
		this.quote = quote;
		return this;
	}

	
	@Override
	public final boolean isWriteRecordName() {
		return writeRecordName;
	}

	
	@Override
	public final boolean isCsvHeader() {
		return csvHeader;
	}


	
	@Override
	public final CobolToCsvBldr setCsvHeader(boolean csvHeader) {
		this.csvHeader = csvHeader;
		return this;
	}


	
	@Override
	public final CobolToCsvBldr setWriteRecordName(boolean writeRecordName) {
		this.writeRecordName = writeRecordName;
		return this;
	}

	
	@Override
	public final String getLowValueTxt() {
		return lowValueTxt;
	}


	
	@Override
	public final CobolToCsvBldr setLowValueTxt(String lowValueTxt) {
		this.lowValueTxt = lowValueTxt;
		this.reportInvalidFields = true;
		return this;
	}


	
	@Override
	public final String getHighValueTxt() {
		return highValueTxt;
	}


	@Override
	public final CobolToCsvBldr setHighValueTxt(String highValueTxt) {
		this.highValueTxt = highValueTxt;
		this.reportInvalidFields = true;
		return this;
	}


	
	@Override
	public final String getNumericSpacesTxt() {
		return numericSpacesTxt;
	}


	
	@Override
	public final CobolToCsvBldr setNumericSpacesTxt(String numericSpacesText) {
		this.numericSpacesTxt = numericSpacesText;
		this.reportInvalidFields = true;
		return this;
	}


	
	@Override
	public final boolean isReportInvalidFields() {
		return reportInvalidFields;
	}


	@Override
	public final CobolToCsvBldr setReportInvalidFields(boolean reportInvalidFields) {
		this.reportInvalidFields = reportInvalidFields;
		return this;
	}


	
	@Override
	public final List<RecordWriterDetails> getRecordList() throws IOException {
		LayoutDetail fileSchema = getSchema();
		if (recordList.size() == 0 && fileSchema != null&& recordVariable != null && recordVariable.length() > 0 
		&& outFileName != null) {
			for (int i = 0; i < fileSchema.getRecordCount(); i++) {
				String recordName = fileSchema.getRecord(i).getRecordName();
				recordList.add(new RecordWriterDetails(
						recordName, 
						newBufferedWriter(Conversion.replace(outFileName, recordVariable, recordName).toString())));
			}
		}
		return recordList;
	}

	
	@Override
	public final CobolToCsvBldr setOutputCharacterSet(String outputCharacterSet) {
		this.outputCharacterSet = outputCharacterSet;
		return this;
	}


	@Override
	public final CobolToCsvBldr addRecordDetails(String recordName, BufferedWriter writter) {
		recordList.add(new RecordWriterDetails(recordName, writter));
		return this;
	}

	
	@Override
	public final BufferedWriter getCsvWriter() {
		if (csvWriter == null && outFileName != null && recordVariable == null) {
			try {
				csvWriter = newBufferedWriter(outFileName);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return csvWriter;
	}


	private BufferedWriter newBufferedWriter(String fileName) throws IOException {
		if (outputCharacterSet != null && outputCharacterSet.length() > 0) {
			try {
				return new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), outputCharacterSet));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}
		return new BufferedWriter(new FileWriter(fileName));
	}


	
	@Override
	public final CobolToCsvBldr setCsvWriter(BufferedWriter csvWriter) {
		this.csvWriter = csvWriter;
		return this;
	}


	
	@Override
	public final AbstractLineReader getLineReader() {
		return lineReader;
	}

	
	@Override
	public final CobolToCsvBldr setLineReader(AbstractLineReader reader) {
		this.lineReader = reader;
		return this;
	}
	
	
	@Override
	public CobolToCsvBldr setOutputFile(String filename) {
		this.outFileName = filename;
		return this;
	}

	@Override
	public CobolToCsvBldr setOutputFile(String filename, String recordVariable) {
		this.outFileName = filename;
		this.recordVariable = recordVariable;
		if (recordVariable != null && recordVariable.length() > 0 && ! filename.contains(recordVariable)) {
			throw new RecordException("The filename must contain the record-variable: " + recordVariable);
		}
		return this;
	}

	
	public final String getOutFileName() {
		return outFileName;
	}

	
	public final String getRecordVariable() {
		return recordVariable;
	}
    
	
	@Override
	public final IUpdateFieldName getUpdateFieldName() {
		return updateFieldName;
	}


	
	@Override
	public final CobolToCsvBldr setUpdateFieldName(IUpdateFieldName updateFieldName) {
		this.updateFieldName = updateFieldName;
		return this;
	}


	@Override
    public final void run() throws IOException {
    	new Cobol2CsvMr(this);
    }
}
