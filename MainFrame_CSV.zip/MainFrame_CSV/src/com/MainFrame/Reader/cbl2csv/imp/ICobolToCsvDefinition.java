package com.MainFrame.Reader.cbl2csv.imp;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.List;

import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.IO.AbstractLineReader;
import com.MainFrame.Reader.cbl2csv.args.IUpdateFieldName;

public interface ICobolToCsvDefinition {

	LayoutDetail getSchema();

	String getSeparator();

	
	String getQuote();

	boolean isWriteRecordName();

	
	
	List<RecordWriterDetails> getRecordList() throws IOException;

	BufferedWriter getCsvWriter();

	
	boolean isCsvHeader();

	
	AbstractLineReader getLineReader();

	
	IUpdateFieldName getUpdateFieldName();

	boolean isReportInvalidFields();

	String getNumericSpacesTxt();

	String getHighValueTxt();

	String getLowValueTxt();

}