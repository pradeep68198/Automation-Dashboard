package com.MainFrame.Reader.cbl2csv.args;

import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Types.Type;
import com.MainFrame.Reader.Types.TypeManager;
import com.MainFrame.Reader.def.IO.builders.IDefineCsvFields;

public class CommonCsv2CblCode {

	
    public static void updateCsvNames(LayoutDetail schema, ParseArgsCobol2Csv csvArgs, IDefineCsvFields defineFields) {
 	
		FieldDetail field;
		int fieldCount = schema.getRecord(0).getFieldCount();
		for (int i = 0; i < fieldCount; i++) {
			field = schema.getField(0, i);
			if (TypeManager.isNumeric(field.getType())) {
				defineFields.addCsvField(csvArgs.updateName(field.getName()), Type.ftNumAnyDecimal, 0);
			} else {
				defineFields.addCsvField(csvArgs.updateName(field.getName()), Type.ftChar, 0);
			}
 		}  
    }

}
