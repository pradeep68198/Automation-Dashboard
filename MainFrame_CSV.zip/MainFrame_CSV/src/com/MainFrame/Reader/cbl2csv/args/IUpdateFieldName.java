
package com.MainFrame.Reader.cbl2csv.args;

public interface IUpdateFieldName {

	
	public abstract String updateName(String name);

}