
package com.MainFrame.Reader.External;

import java.io.IOException;
import java.io.InputStream;

import com.MainFrame.Reader.Common.CommonBits;
import com.MainFrame.Reader.Common.RecordException;
import com.MainFrame.Reader.External.base.BaseCobolItemLoader;
import com.MainFrame.Reader.Log.AbsSSLogger;



public class CobolCopybookLoader extends BaseCobolItemLoader<ExternalRecord> 
implements ICopybookLoaderStream, ICopybookLoaderCobol  {

	private static boolean available = true;
    private static boolean toCheck = true;

	
	public CobolCopybookLoader() {
		super(true, new ExternalRecordBuilder());
	}
	
	
    public final ExternalRecord loadCopyBook(
    								InputStream inputStream, //Document copyBookXml,
    		                             String copyBookName,
            						  		int splitCopybook,
            						  		int dbIdx,
                  						  final String font,
                						  final int binaryFormat,
                						  final int systemId,
                						  final AbsSSLogger log)
    				{
    	try {
			return loadCopyBook(inputStream, copyBookName, splitCopybook, dbIdx, font, CommonBits.getDefaultCobolTextFormat(), binaryFormat, systemId, log);
		} catch (IOException e) {
			throw new RecordException("IO Exception: " + e, e);

		}
    }

   
    public static final boolean isAvailable() {

        if (toCheck) {
            try {
                
                available = ((new CobolCopybookLoader()).getClass().getClassLoader().getResource("com/MainFrame/Convert2xml/Cb2Xml.class") != null);
            } catch (Exception e) {
                available = false;
            }
            toCheck = false;
        }
        return available;
    }

}
