
package com.MainFrame.Reader.External;

public interface ISetDropCopybookName {

	
	public abstract void setDropCopybookFromFieldNames(
			boolean dropCopybookFromFieldNames);

	
	public abstract void setSaveCb2xmlDocument(boolean saveCb2xml);

	
	public abstract void setKeepFillers(boolean keepFiller);
	
	
	public abstract void setStackSize(int stackSize);

}