
package com.MainFrame.Reader.External;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import com.MainFrame.Reader.Common.CommonBits;
import com.MainFrame.Reader.Common.Conversion;
import com.MainFrame.Reader.IO.XmlLineReader;
import com.MainFrame.Reader.Log.AbsSSLogger;

import org.xml.sax.SAXException;

public class XmlFileLoader implements CopybookLoader {

	
	@Override
	public final ExternalRecord loadCopyBook(String copyBookFile,
			int splitCopybookOption, int dbIdx, String font, int binFormat,
			int systemId, AbsSSLogger log) throws IOException, SAXException, ParserConfigurationException {
		// TODO Auto-generated method stub
		return loadCopyBook(copyBookFile, splitCopybookOption, dbIdx, font, CommonBits.getDefaultCobolTextFormat(), binFormat, systemId, log);
		
	}

	
	public ExternalRecord loadCopyBook(String copyBookFile, int splitCopybookOption, int dbIdx, String font, int copybookFormat, int binFormat, int systemId, AbsSSLogger log) 
	throws IOException, SAXException, ParserConfigurationException {
		int i;
		XmlLineReader r = new XmlLineReader(true);
		r.open(copyBookFile);
		
		for (i = 0; i < 20000 && (r.read() != null); i++) {
		}
		
		r.close();
		
		return ToExternalRecord.getInstance()
				.getExternalRecord(r.getLayout(), Conversion.getCopyBookId(copyBookFile), systemId);
	}

}
