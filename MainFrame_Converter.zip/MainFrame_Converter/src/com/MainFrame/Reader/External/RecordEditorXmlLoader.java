
package com.MainFrame.Reader.External;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;

import com.MainFrame.Reader.Common.Conversion;
import com.MainFrame.Reader.Common.ILineFieldNames;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.External.base.BaseRecordEditorXmlLoader;
import com.MainFrame.Reader.IO.AbstractLineReader;
import com.MainFrame.Reader.IO.XmlLineReader;
import com.MainFrame.Reader.Log.AbsSSLogger;


public class RecordEditorXmlLoader extends BaseCopybookLoader implements ICopybookLoaderStream {

	public static ExternalRecord getExternalRecord(String xml, String copyBookName) throws IOException {
		return new RecordEditorXmlLoader().loadCopyBook(new StringReader(xml), copyBookName, 0, 0, "", 0, 0, 0, null);
	}
	
//	public static ExternalRecord getExternalRecord(String xml, String name) throws Exception {
//		ByteArrayInputStream bs = new ByteArrayInputStream(xml.getBytes());
//
//		return (new RecordEditorXmlLoader()).loadCopyBook(bs, name, "", null);
//	}


	
	@Override
	public ExternalRecord loadCopyBook(InputStream inputStream,
			String copyBookName, int splitCopybook, int dbIdx, String font,
			int copybookFormat, int binaryFormat, int systemId, AbsSSLogger log)
			throws IOException {
		
        XmlLineReader r = new XmlLineReader(true);
		r.open(inputStream, (LayoutDetail) null);

	    return loadCopybook(r, copyBookName, font, log);
	}
	
	public ExternalRecord loadCopyBook(InputStream is, String copyBookName) throws IOException {
		XmlLineReader r = new XmlLineReader(true);
		r.open(is, (LayoutDetail) null);

		return loadCopybook(r, copyBookName, "", null);
	}

	
	@Override
	public ExternalRecord loadCopyBook(String copyBookFile,
			int splitCopybookOption, int dbIdx, String font,
			int copybookFormat, int binFormat, int systemId, AbsSSLogger log)
			throws Exception {
			
		XmlLineReader reader = new XmlLineReader(true);
		reader.open(copyBookFile);

		return loadCopybook(reader, Conversion.getCopyBookId(copyBookFile), font, log);
	}
	
	@Override
	public ExternalRecord loadCopyBook(Reader reader, String copyBookName, int splitCopybook, int dbIdx, String font,
			int copybookFormat, int binaryFormat, int systemId, AbsSSLogger log) throws IOException {

        XmlLineReader r = new XmlLineReader(true);
		r.open(reader, (LayoutDetail) null);
	    return loadCopybook(r, copyBookName, font, log);
	}

	
	private ExternalRecord loadCopybook(XmlLineReader reader, String copyBookName, String font, AbsSSLogger log)
			throws IOException {
		return (new BaseRecordEditorXmlLoader<ExternalRecord>(
								new XmlReader(reader),
								new ExternalRecordBuilder()
					)).loadCopyBook(copyBookName, font, log);
	}

	

	private static class XmlReader implements BaseRecordEditorXmlLoader.ILineReader {

		private final AbstractLineReader reader;
		
		public XmlReader(AbstractLineReader reader) {
			super();
			this.reader = reader;
		}

		@Override
		public ILineFieldNames read() throws IOException {
			return reader.read();
		}

		@Override
		public void close()  throws IOException {
			reader.close();
		}
		
	}
}
