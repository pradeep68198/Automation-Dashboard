
package com.MainFrame.Reader.External;

import com.MainFrame.Reader.Details.LayoutDetail;

public interface ICsvSchemaBuilder {

	
	public ICsvSchemaBuilder addCsvField(String name, int type, int decimal);
	
	
	public LayoutDetail asLayoutDetail();

	
	public ExternalRecord asExternalRecord();


}
