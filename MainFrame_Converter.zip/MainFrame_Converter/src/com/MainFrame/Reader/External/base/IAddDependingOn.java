package com.MainFrame.Reader.External.base;

import com.MainFrame.Reader.External.Def.DependingOn;

public interface IAddDependingOn {
  void addDependingOn(DependingOn paramDependingOn);
}


