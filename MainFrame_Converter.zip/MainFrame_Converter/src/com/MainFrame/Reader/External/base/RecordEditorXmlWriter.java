/*     */ package com.MainFrame.Reader.External.base;
/*     */ 
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.util.List;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import com.MainFrame.Reader.External.Def.ExternalField;
/*     */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalFieldSelection;
/*     */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalGroupSelection;
/*     */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
/*     */ import com.MainFrame.Reader.ExternalRecordSelection.StreamLine;
/*     */ import com.MainFrame.Reader.Log.AbsSSLogger;
/*     */ import com.MainFrame.Convert2xml.def.IItem;
/*     */ import com.MainFrame.Convert2xml.util.WriteXml;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordEditorXmlWriter
/*     */   implements CopybookWriter
/*     */ {
/*     */   private static final String STANDARD_FONT = "UTF-8";
/*     */   
/*     */   public String writeCopyBook(String directory, BaseExternalRecord<?> copybook, AbsSSLogger log) throws Exception {
/*  68 */     directory = ExternalConversion.fixDirectory(directory);
/*     */     
/*  70 */     String fileName = directory + ExternalConversion.fixFileName(copybook.getRecordName()) + ".Xml";
/*  71 */     writeCopyBook(new FileOutputStream(fileName), copybook, log);
/*     */     
/*  73 */     return fileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeCopyBook(OutputStream outStream, BaseExternalRecord<?> copybook, AbsSSLogger log) throws XMLStreamException, IOException {
/*  81 */     XMLOutputFactory f = XMLOutputFactory.newInstance();
/*     */     
/*  83 */     XMLStreamWriter writer = f.createXMLStreamWriter(new OutputStreamWriter(outStream, "UTF-8"));
/*     */     
/*  85 */     writeCopyBook(writer, copybook);
/*  86 */     outStream.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeCopyBook(XMLStreamWriter writer, BaseExternalRecord<?> copybook) throws XMLStreamException {
/*  96 */     writer.writeStartDocument("UTF-8", "1.0");
/*     */     
/*  98 */     writeRecord(writer, null, copybook, hasGroupDetails(copybook));
/*     */     
/* 100 */     writer.writeEndDocument();
/* 101 */     writer.close();
/*     */   }
/*     */   private boolean hasGroupDetails(BaseExternalRecord<?> copybook) {
/*     */     int i;
/* 105 */     for (i = copybook.getNumberOfRecords() - 1; i >= 0; i--) {
/* 106 */       if (hasGroupDetails((BaseExternalRecord<?>)copybook.getRecord(i))) {
/* 107 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 111 */     for (i = copybook.getNumberOfRecordFields() - 1; i >= 0; i--) {
/* 112 */       String group = copybook.getRecordField(i).getGroup();
/* 113 */       if (group != null && group.length() > 0) {
/* 114 */         return true;
/*     */       }
/*     */     } 
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeRecord(XMLStreamWriter writer, BaseExternalRecord<?> master, BaseExternalRecord<?> copybook, boolean hasGroup) throws XMLStreamException {
/* 130 */     boolean toPrint = true;
/*     */     
/* 132 */     String name = copybook.getCopyBook();
/*     */     
/* 134 */     writer.writeStartElement("RECORD");
/*     */     
/* 136 */     writer.writeAttribute("RECORDNAME", copybook.getRecordName());
/* 137 */     writer.writeAttribute("COPYBOOK", name);
/* 138 */     writeAttr(writer, "DELIMITER", encodeDelim(copybook.getDelimiter()));
/* 139 */     writeAttr(writer, "DESCRIPTION", copybook.getDescription());
/* 140 */     writeAttr(writer, "FONTNAME", copybook.getFontName());
/* 141 */     writer.writeAttribute("FILESTRUCTURE", 
/* 142 */         ExternalConversion.getFileStructureAsString(0, copybook.getFileStructure()));
/* 143 */     writer.writeAttribute("STYLE", 
/* 144 */         ExternalConversion.getRecordStyleAsString(0, copybook.getRecordStyle()));
/* 145 */     writer.writeAttribute("RECORDTYPE", 
/* 146 */         ExternalConversion.getRecordTypeAsString(0, copybook.getRecordType()));
/* 147 */     writer.writeAttribute("LIST", copybook.getListChar());
/* 148 */     if (copybook.isEmbeddedCr()) {
/* 149 */       writer.writeAttribute("EMBEDDEDCR", "Y");
/*     */     }
/* 151 */     if (copybook.isInitToSpaces()) {
/* 152 */       writer.writeAttribute("INITSPACES", "Y");
/*     */     }
/*     */     
/* 155 */     if (master != null && copybook.getParentRecord() >= 0) {
/*     */       try {
/* 157 */         writer.writeAttribute("PARENT", master.getRecord(copybook.getParentRecord()).getRecordName());
/* 158 */       } catch (Exception exception) {}
/*     */     }
/*     */     
/* 161 */     writer.writeAttribute("QUOTE", copybook.getQuote());
/* 162 */     writer.writeAttribute("RecSep", copybook.getRecSepList());
/* 163 */     String s = copybook.getSystemName();
/* 164 */     if (s != null && !"".equals(s)) {
/* 165 */       writer.writeAttribute("SYSTEMNAME", s);
/*     */     }
/* 167 */     ExternalSelection xSel = StreamLine.getExternalStreamLine().streamLine(copybook.getRecordSelection());
/* 168 */     if (copybook.isDefaultRecord()) {
/* 169 */       if (xSel == null) {
/* 170 */         writeAttr(writer, "TESTFIELD", "");
/* 171 */         writeAttr(writer, "TESTVALUE", "*");
/* 172 */         toPrint = false;
/*     */       } 
/* 174 */     } else if (xSel == null) {
/* 175 */       toPrint = false;
/* 176 */     } else if (xSel instanceof ExternalFieldSelection) {
/* 177 */       ExternalFieldSelection eFld = (ExternalFieldSelection)xSel;
/* 178 */       if ("=".equals(eFld.getOperator()) || "eq".equalsIgnoreCase(eFld.getOperator())) {
/* 179 */         writeAttr(writer, "TESTFIELD", eFld.getFieldName());
/* 180 */         writeAttr(writer, "TESTVALUE", eFld.getRawFieldValue());
/* 181 */         toPrint = false;
/*     */       } 
/* 183 */     } else if (xSel instanceof ExternalGroupSelection) {
/* 184 */       toPrint = (((ExternalGroupSelection)xSel).getSize() > 0);
/*     */     } 
/* 186 */     writeAttr(writer, "LINE_NO_FIELD_NAMES", copybook.getLineNumberOfFieldNames(), 1);
/* 187 */     int recordLength = copybook.getRecordLength();
/* 188 */     int maxLength = getRecLength(copybook);
/*     */ 
/*     */     
/* 191 */     if (recordLength > 0 && recordLength != maxLength) {
/* 192 */       writeAttr(writer, "RECORDLENGTH", recordLength, 0);
/*     */     }
/*     */     
/* 195 */     if (copybook.getNumberOfRecords() > 0) {
/* 196 */       writer.writeStartElement("RECORDS");
/*     */       
/* 198 */       for (int i = 0; i < copybook.getNumberOfRecords(); i++) {
/* 199 */         writeRecord(writer, copybook, (BaseExternalRecord<?>)copybook.getRecord(i), hasGroup);
/*     */       }
/* 201 */       writer.writeEndElement();
/*     */     } 
/*     */     
/* 204 */     if (toPrint) {
/* 205 */       writer.writeStartElement("TSTFIELDS");
/* 206 */       if (copybook.isDefaultRecord()) {
/* 207 */         writer.writeAttribute("DEFAULTRECORD", "Y");
/*     */       }
/*     */       
/* 210 */       writeSelection(writer, xSel);
/* 211 */       writer.writeEndElement();
/*     */     } 
/*     */     
/* 214 */     List<? extends IItem> items = (List)copybook.getItems();
/* 215 */     if (items != null && items.size() > 0) {
/* 216 */       WriteXml wXml = new WriteXml(true, true, "");
/*     */       
/* 218 */       writer.writeStartElement("ITEMS");
/* 219 */       writer.writeAttribute("CopybookPref", copybook.getCopybookPref());
/*     */       
/* 221 */       if (copybook.getDialectCode() != 1) {
/* 222 */         writer.writeAttribute("DIALECT", 
/*     */             
/* 224 */             Integer.toString(copybook.getDialectCode()));
/*     */       }
/*     */       
/* 227 */       if (copybook.isKeepFillers()) {
/* 228 */         writer.writeAttribute("KeepFiller", "TRUE");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 233 */       if (copybook.isDropCopybookFromFieldNames()) {
/* 234 */         writer.writeAttribute("DropCopybook", "TRUE");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 239 */       if (copybook.isUseJRecordNaming()) {
/* 240 */         writer.writeAttribute("JRecNaming", "TRUE");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 246 */       String[] parentGroupNames = copybook.getParentGroupNames();
/* 247 */       if (parentGroupNames != null && parentGroupNames.length > 0) {
/* 248 */         StringBuilder b = new StringBuilder(parentGroupNames[0]);
/* 249 */         for (int j = 1; j < parentGroupNames.length; j++) {
/* 250 */           if (parentGroupNames[j] != null && parentGroupNames[j].length() > 0) {
/* 251 */             b.append('.').append(parentGroupNames[j]);
/*     */           }
/*     */         } 
/*     */         
/* 255 */         writer.writeAttribute("GROUPNAMES", b.toString());
/*     */       } 
/*     */ 
/*     */       
/* 259 */       wXml.writeIItems(writer, items);
/*     */       
/* 261 */       writer.writeEndElement();
/* 262 */     } else if (copybook.getNumberOfRecordFields() > 0) {
/* 263 */       String lastGroupName = null;
/* 264 */       writer.writeStartElement("FIELDS");
/*     */       
/* 266 */       for (int i = 0; i < copybook.getNumberOfRecordFields(); i++) {
/* 267 */         lastGroupName = writeField(writer, copybook.getRecordField(i), hasGroup, lastGroupName);
/*     */       }
/* 269 */       writer.writeEndElement();
/*     */     } 
/*     */     
/* 272 */     writer.writeEndElement();
/*     */   }
/*     */   
/*     */   private int getRecLength(BaseExternalRecord<?> r) {
/* 276 */     int ret = 0;
/* 277 */     if (r.getNumberOfRecordFields() > 0) {
/* 278 */       ExternalField recordField = r.getRecordField(r.getNumberOfRecordFields() - 1);
/* 279 */       ret = recordField.getPos() + recordField.getLen() - 1;
/*     */     } 
/*     */     
/* 282 */     for (int i = 0; i < r.getNumberOfRecords(); i++) {
/* 283 */       ret = Math.max(ret, getRecLength((BaseExternalRecord<?>)r.getRecord(i)));
/*     */     }
/* 285 */     return ret;
/*     */   }
/*     */   
/*     */   private String encodeDelim(String delim) {
/* 289 */     if ("\t".equals(delim)) {
/* 290 */       delim = "<TAB>";
/*     */     }
/*     */     
/* 293 */     return delim;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeSelection(XMLStreamWriter writer, ExternalSelection sel) throws XMLStreamException {
/* 299 */     if (sel == null)
/*     */       return; 
/* 301 */     switch (sel.getType()) {
/*     */       case 1:
/* 303 */         writeTstField(writer, (ExternalFieldSelection)sel);
/*     */         break;
/*     */       case 2:
/* 306 */         writeSelectionGroup(writer, (ExternalGroupSelection)sel, "AND");
/*     */         break;
/*     */       case 3:
/* 309 */         writeSelectionGroup(writer, (ExternalGroupSelection)sel, "OR");
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeSelectionGroup(XMLStreamWriter writer, ExternalGroupSelection<?> g, String s) throws XMLStreamException {
/* 317 */     writer.writeStartElement(s);
/*     */     
/* 319 */     for (int i = 0; i < g.size(); i++) {
/* 320 */       writeSelection(writer, g.get(i));
/*     */     }
/*     */     
/* 323 */     writer.writeEndElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String writeField(XMLStreamWriter writer, ExternalField fld, boolean hasGroups, String lastGroup) throws XMLStreamException {
/* 334 */     writer.writeEmptyElement("FIELD");
/* 335 */     writer.writeAttribute("NAME", fld.getName());
/* 336 */     writeAttr(writer, "DESCRIPTION", fld.getDescription());
/* 337 */     writer.writeAttribute("POSITION", Integer.toString(fld.getPos()));
/* 338 */     if (fld.getLen() > 0) {
/* 339 */       writer.writeAttribute("LENGTH", Integer.toString(fld.getLen()));
/*     */     }
/*     */     
/* 342 */     if (fld.getDecimal() > 0) {
/* 343 */       writer.writeAttribute("DECIMAL", Integer.toString(fld.getDecimal()));
/*     */     }
/*     */     
/* 346 */     writer.writeAttribute("TYPE", ExternalConversion.getTypeAsString(-1, fld.getType()));
/* 347 */     writeAttr(writer, "CELLFORMAT", ExternalConversion.getFormatAsString(0, fld.getCellFormat()));
/* 348 */     writeAttr(writer, "PARAMETER", fld.getParameter());
/* 349 */     writeAttr(writer, "DEFAULT", fld.getDefault());
/* 350 */     writeAttr(writer, "COBOLNAME", fld.getCobolName());
/*     */     
/* 352 */     if (hasGroups) {
/* 353 */       String g = fld.getGroup();
/* 354 */       if (lastGroup == null || !lastGroup.equalsIgnoreCase(g)) {
/* 355 */         writeAttr(writer, "GROUPNAMES", fld.getGroup());
/*     */       }
/* 357 */       lastGroup = g;
/*     */     } 
/* 359 */     return lastGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeTstField(XMLStreamWriter writer, ExternalFieldSelection fld) throws XMLStreamException {
/* 365 */     writer.writeEmptyElement("TSTFIELD");
/* 366 */     writeAttr(writer, "NAME", fld.getFieldName());
/* 367 */     writeAttr(writer, "VALUE", fld.getRawFieldValue());
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeAttr(XMLStreamWriter writer, String attr, String value) throws XMLStreamException {
/* 372 */     if (value != null && !"".equals(value)) {
/* 373 */       writer.writeAttribute(attr, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeAttr(XMLStreamWriter writer, String attr, int value, int min) throws XMLStreamException {
/* 380 */     if (value > min)
/* 381 */       writer.writeAttribute(attr, Integer.toString(value)); 
/*     */   }
/*     */ }

