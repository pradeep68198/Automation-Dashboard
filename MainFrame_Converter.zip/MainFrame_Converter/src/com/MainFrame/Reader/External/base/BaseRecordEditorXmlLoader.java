/*     */ package com.MainFrame.Reader.External.base;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import com.MainFrame.Reader.Common.AbstractFieldValue;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.ILineFieldNames;
/*     */ import com.MainFrame.Reader.External.Def.ExternalField;
/*     */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalFieldSelection;
/*     */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalGroupSelection;
/*     */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
/*     */ import com.MainFrame.Reader.Log.AbsSSLogger;
/*     */ import com.MainFrame.Reader.Log.TextLog;
/*     */ import com.MainFrame.Convert2xml.analysis.BaseItem;
/*     */ import com.MainFrame.Convert2xml.analysis.Item;
/*     */ import com.MainFrame.Convert2xml.analysis.ItemBuilder;
/*     */ import com.MainFrame.Convert2xml.def.Cb2xmlConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseRecordEditorXmlLoader<XRecord extends BaseExternalRecord<XRecord>>
/*     */ {
/*     */   private static final String END_ITEMS = "/ITEMS";
/*  73 */   private String lastGroupDetails = null;
/*     */   
/*     */   private final ILineReader xmlReader;
/*     */   
/*     */   private final IExernalRecordBuilder<XRecord> recBuilder;
/*     */   
/*     */   public BaseRecordEditorXmlLoader(ILineReader xmlReader, IExernalRecordBuilder<XRecord> recBuilder) {
/*  80 */     this.xmlReader = xmlReader;
/*  81 */     this.recBuilder = recBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XRecord loadCopyBook(String copyBookFile, int splitCopybookOption, int dbIdx, String font, int copybookFormat, int binFormat, int systemId, AbsSSLogger log) throws Exception {
/*  93 */     XRecord rec = createXRecord(Conversion.getCopyBookId(copyBookFile), font);
/*     */     
/*  95 */     insertRecord(TextLog.getLog(log), null, rec, this.xmlReader, dbIdx);
/*  96 */     this.xmlReader.close();
/*     */     
/*  98 */     return rec;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public XRecord loadCopyBook(String layoutName, String font, AbsSSLogger log) throws IOException {
/* 104 */     XRecord rec = createXRecord(layoutName, font);
/*     */     
/* 106 */     insertRecord(TextLog.getLog(log), null, rec, this.xmlReader, -121);
/* 107 */     this.xmlReader.close();
/*     */     
/* 109 */     return rec;
/*     */   }
/*     */ 
/*     */   
/*     */   private XRecord createXRecord(String layoutName, String font) {
/* 114 */     int rt = 1;
/*     */     
/* 116 */     XRecord rec = this.recBuilder.getNullRecord(layoutName, rt, font);
/*     */ 
/*     */ 
/*     */     
/* 120 */     rec.setNew(true);
/*     */     
/* 122 */     return rec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean insertRecord(AbsSSLogger log, XRecord parentRec, XRecord childRec, ILineReader reader, int dbIdx) throws IOException {
/* 145 */     ILineFieldNames line = reader.read();
/*     */     
/* 147 */     log = TextLog.getLog(log);
/*     */     String name;
/* 149 */     if (line == null || (name = line.getFieldValue("Xml~Name").asString()).startsWith("/"))
/*     */     {
/* 151 */       return false;
/*     */     }
/*     */     
/* 154 */     if ("XML Start_Document".equalsIgnoreCase(name)) {
/* 155 */       line = reader.read();
/* 156 */       name = line.getFieldValue("Xml~Name").asString();
/*     */     } 
/*     */     
/* 159 */     if ("RECORD".equalsIgnoreCase(name)) {
/* 160 */       childRec.setRecordName(line.getFieldValue("RECORDNAME").asString());
/* 161 */       childRec.setCopyBook(line.getFieldValueIfExists("COPYBOOK").asString());
/* 162 */       childRec.setDelimiter(line.getFieldValueIfExists("DELIMITER").asString());
/* 163 */       childRec.setDescription(line.getFieldValueIfExists("DESCRIPTION").asString());
/* 164 */       childRec.setFileStructure(
/* 165 */           ExternalConversion.getFileStructure(dbIdx, line
/* 166 */             .getFieldValue("FILESTRUCTURE").asString()));
/*     */       
/* 168 */       Object o = line.getField("FONTNAME");
/* 169 */       if (o != null) {
/* 170 */         childRec.setFontName(o.toString());
/*     */       }
/* 172 */       childRec.setListChar(line.getFieldValueIfExists("LIST").asString());
/* 173 */       childRec.setParentName(line.getFieldValueIfExists("PARENT").asString());
/* 174 */       childRec.setQuote(line.getFieldValueIfExists("QUOTE").asString());
/* 175 */       childRec.setRecordStyle(
/* 176 */           ExternalConversion.getRecordStyle(dbIdx, line
/* 177 */             .getFieldValueIfExists("STYLE").asString()));
/* 178 */       childRec.setRecordType(
/* 179 */           ExternalConversion.getRecordType(dbIdx, line
/* 180 */             .getFieldValueIfExists("RECORDTYPE").asString()));
/* 181 */       childRec.setEmbeddedCr("Y"
/* 182 */           .equalsIgnoreCase(line
/* 183 */             .getFieldValueIfExists("EMBEDDEDCR").asString()));
/* 184 */       childRec.setInitToSpaces("Y"
/* 185 */           .equalsIgnoreCase(line
/* 186 */             .getFieldValueIfExists("INITSPACES").asString()));
/*     */       
/* 188 */       String s = line.getFieldValueIfExists("RecSep").asString();
/* 189 */       if (s != null && !"".equals(s)) {
/* 190 */         childRec.setRecSepList(s);
/*     */       }
/* 192 */       s = line.getFieldValueIfExists("SYSTEMNAME").asString();
/* 193 */       if (s != null && !"".equals(s)) {
/* 194 */         childRec.setSystemName(s);
/*     */       }
/*     */       
/* 197 */       s = line.getFieldValueIfExists("RECORDLENGTH").asString();
/* 198 */       if (s != null && !"".equals(s)) {
/*     */         try {
/* 200 */           childRec.setRecordLength(Integer.parseInt(s));
/* 201 */         } catch (NumberFormatException e) {
/* 202 */           e.printStackTrace();
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 208 */       ExternalFieldSelection fs = new ExternalFieldSelection();
/* 209 */       fs.setFieldName(line.getFieldValueIfExists("TESTFIELD").asString());
/* 210 */       fs.setFieldValue(line.getFieldValueIfExists("TESTVALUE").asString());
/*     */       
/* 212 */       if ("".equals(fs.getFieldName())) {
/* 213 */         if ("*".equals(fs.getFieldValue())) {
/* 214 */           childRec.setDefaultRecord(true);
/*     */         }
/*     */       } else {
/* 217 */         childRec.setRecordSelection((ExternalSelection)fs);
/*     */       } 
/*     */       
/*     */       try {
/* 221 */         AbstractFieldValue val = line.getFieldValueIfExists("LINE_NO_FIELD_NAMES");
/* 222 */         if (parentRec == null && val != null && !"".equals(val.asString())) {
/* 223 */           childRec.setLineNumberOfFieldNames(val.asInt());
/*     */         }
/* 225 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 228 */       if (parentRec != null) {
/* 229 */         parentRec.addRecord(childRec);
/*     */       }
/*     */     } else {
/* 232 */       String s = "Error loading copybook; Expected RECORD Tag, but got " + name;
/* 233 */       log.logMsg(30, s);
/* 234 */       throw new RuntimeException(s);
/*     */     } 
/*     */     
/* 237 */     line = reader.read();
/*     */     
/* 239 */     if (line != null) {
/* 240 */       if ("RECORDS".equalsIgnoreCase(line.getFieldValue("Xml~Name").asString())) {
/*     */         
/* 242 */         if (childRec.getRecordType() != 10 && childRec
/* 243 */           .getRecordType() != 0) {
/* 244 */           childRec.setRecordType(9);
/*     */         }
/*     */         
/*     */         while (true) {
/* 248 */           XRecord newRec = this.recBuilder.getNullRecord("", 1, childRec
/*     */ 
/*     */               
/* 251 */               .getFontName());
/* 252 */           newRec.setNew(true);
/*     */           
/* 254 */           if (!insertRecord(log, childRec, newRec, reader, dbIdx)) {
/* 255 */             childRec.setParentsFromName();
/*     */             
/* 257 */             line = reader.read(); break;
/*     */           } 
/*     */         } 
/* 260 */       }  line = addItems(childRec, reader, line, dbIdx);
/*     */       
/* 262 */       if (line != null) {
/* 263 */         if ("/ITEMS".equals(line.getFieldValue("Xml~Name").asString())) {
/* 264 */           line = reader.read();
/*     */         } else {
/* 266 */           line = addFieldTsts(childRec, reader, line, dbIdx);
/* 267 */           line = addFields(childRec, reader, line, dbIdx);
/* 268 */           line = addFieldTsts(childRec, reader, line, dbIdx);
/*     */         } 
/*     */       }
/*     */     } 
/* 272 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ILineFieldNames addItems(XRecord childRec, ILineReader reader, ILineFieldNames line, int dbIdx) throws IOException {
/* 283 */     if (line != null && "ITEMS"
/* 284 */       .equalsIgnoreCase(line.getFieldValue("Xml~Name").asString())) {
/* 285 */       String endItem = "/item";
/* 286 */       String endCondition = "/condition";
/* 287 */       ItemBuilder bldr = new ItemBuilder();
/* 288 */       ItemHelper itmReader = new ItemHelper(reader, new Item(null, 0, "00", ""));
/* 289 */       itmReader.line = line;
/*     */       
/* 291 */       String copybookPref = itmReader.getAttr("CopybookPref");
/* 292 */       int dialect = 1; 
/* 293 */       try { dialect = Integer.parseInt(itmReader.getAttr("DIALECT")); } catch (Exception exception) {}
/* 294 */       String[] groupNames = null;
/* 295 */       String groupNameStr = itmReader.getAttr("GROUPNAMES");
/* 296 */       if (groupNameStr != null && groupNameStr.length() > 0) {
/* 297 */         groupNames = groupNameStr.split("\\.");
/*     */       }
/* 299 */       boolean keepFillers = "TRUE".equals(itmReader.getAttr("KeepFiller"));
/* 300 */       boolean dropCopybookName = "TRUE".equals(itmReader.getAttr("DropCopybook"));
/* 301 */       boolean useJRecordNaming = "TRUE".equals(itmReader.getAttr("JRecNaming"));
/*     */       
/* 303 */       while ((line = itmReader.read()) != null) {
/* 304 */         String recType = line.getFieldValue("Xml~Name").asString();
/* 305 */         if ("item".equalsIgnoreCase(recType)) {
/* 306 */           processItem(bldr, itmReader); continue;
/* 307 */         }  if ("condition".equalsIgnoreCase(recType))
/*     */           continue; 
/* 309 */         if (endItem.equalsIgnoreCase(recType)) {
/* 310 */           itmReader.pop(); continue;
/* 311 */         }  if (endCondition.equalsIgnoreCase(recType))
/*     */           continue; 
/* 313 */         if ("/ITEMS".equalsIgnoreCase(recType)) {
/*     */           break;
/*     */         }
/*     */       } 
/* 317 */       List<? extends Item> childItems = itmReader.topItem.getChildItems();
/* 318 */       childRec.setCobolConversionOptions(keepFillers, dropCopybookName, useJRecordNaming);
/* 319 */       childRec.setItems(copybookPref, groupNames, dialect, (List)childItems);
/* 320 */       childRec.updateTypeOnCobolItems();
/*     */     } 
/*     */     
/* 323 */     return line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processItem(ItemBuilder itmBldr, ItemHelper rBldr) {
/* 330 */     itmBldr.setLevelString(rBldr.getAttr("level"));
/* 331 */     itmBldr.setFieldName(rBldr.getAttr("name"));
/* 332 */     itmBldr.setBlankWhenZero(rBldr.getBooleanAttr("blank-when-zero"));
/* 333 */     itmBldr.setDependingOn(rBldr.getAttr("depending-on"));
/* 334 */     itmBldr.setDisplayLength(rBldr.getIntAttr("display-length"));
/* 335 */     itmBldr.setFieldRedefined(rBldr.getBooleanAttr("redefined"));
/* 336 */     itmBldr.setInheritedUsage(rBldr.getBooleanAttr("inherited-usage"));
/* 337 */     itmBldr.setJustified(rBldr.getJustified());
/* 338 */     itmBldr.setNumericClass(rBldr.getNumericClass());
/* 339 */     itmBldr.setOccursMin(rBldr.getIntAttr("occurs-min"));
/* 340 */     itmBldr.setOccurs(rBldr.getIntAttr("occurs"));
/* 341 */     itmBldr.setPicture(rBldr.getAttr("picture"));
/* 342 */     itmBldr.setPosition(rBldr.getIntAttr("position"));
/* 343 */     itmBldr.setRedefines(rBldr.getAttr("redefines"));
/* 344 */     itmBldr.setScale(rBldr.getIntAttr("scale"));
/* 345 */     itmBldr.setSignClause(rBldr.getSignClause());
/* 346 */     itmBldr.setSigned(rBldr.getBooleanAttr("signed"));
/* 347 */     itmBldr.setStorageLength(rBldr.getIntAttr("storage-length"));
/* 348 */     itmBldr.setSync(rBldr.getBooleanAttr("sync"));
/* 349 */     itmBldr.setUsage(rBldr.getUsage());
/* 350 */     itmBldr.setValue(rBldr.getAttr("value"));
/*     */     
/* 352 */     int size = rBldr.list.size();
/* 353 */     Item parent = (size == 0) ? null : rBldr.list.get(size - 1);
/* 354 */     Item newItem = itmBldr.build((BaseItem)parent);
/*     */     
/* 356 */     if (!"True".equalsIgnoreCase(rBldr.getAttr("Xml~End"))) {
/* 357 */       rBldr.add(newItem);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ILineFieldNames addFields(XRecord childRec, ILineReader reader, ILineFieldNames line, int dbIdx) throws IOException {
/* 369 */     if ("FIELDS".equalsIgnoreCase(line.getFieldValue("Xml~Name").asString())) {
/*     */ 
/*     */ 
/*     */       
/* 373 */       line = reader.read();
/*     */       
/* 375 */       while (line != null && !line.getFieldValue("Xml~Name").asString().startsWith("/")) {
/* 376 */         String s = null;
/* 377 */         String cobolName = "";
/*     */         try {
/* 379 */           int decimal = getIntFld(line, "DECIMAL", 0);
/* 380 */           int len = getIntFld(line, "LENGTH", -121);
/* 381 */           String fldName = line.getFieldValue("NAME").asString();
/*     */           try {
/* 383 */             s = line.getFieldValueIfExists("DEFAULT").asString();
/* 384 */             cobolName = line.getFieldValueIfExists("COBOLNAME").asString();
/* 385 */           } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 397 */           ExternalField fld = new ExternalField(getIntFld(line, "POSITION", -121), len, fldName, line.getFieldValueIfExists("DESCRIPTION").asString(), ExternalConversion.getType(dbIdx, line.getFieldValueIfExists("TYPE").asString()), decimal, ExternalConversion.getFormat(dbIdx, line.getFieldValueIfExists("CELLFORMAT").asString()), line.getFieldValueIfExists("PARAMETER").asString(), line.getFieldValueIfExists("DEFAULT").asString(), cobolName, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 402 */           if (!"".equals(s)) {
/* 403 */             fld.setDefault(s);
/*     */           }
/*     */           
/* 406 */           String groupDetails = line.getFieldValueIfExists("GROUPNAMES").asString();
/* 407 */           if (!"".equals(groupDetails)) {
/* 408 */             fld.setGroup(groupDetails);
/* 409 */             this.lastGroupDetails = groupDetails;
/* 410 */           } else if (this.lastGroupDetails != null) {
/* 411 */             fld.setGroup(this.lastGroupDetails);
/*     */           } 
/* 413 */           childRec.addRecordField(fld);
/* 414 */         } catch (Exception e) {
/* 415 */           e.printStackTrace();
/*     */         } 
/*     */         
/* 418 */         line = reader.read();
/*     */       } 
/* 420 */       line = reader.read();
/*     */     } 
/* 422 */     return line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ILineFieldNames addFieldTsts(XRecord childRec, ILineReader reader, ILineFieldNames line, int dbIdx) throws IOException {
/* 432 */     String name = line.getFieldValue("Xml~Name").asString();
/* 433 */     if ("TSTFIELDS".equalsIgnoreCase(name) || "AND"
/* 434 */       .equalsIgnoreCase(name)) {
/* 435 */       setDefault(childRec, line.getFieldValueIfExists("DEFAULTRECORD").asString());
/* 436 */       childRec.setRecordSelection((ExternalSelection)getGroup(reader, 2));
/*     */       
/* 438 */       line = reader.read();
/* 439 */     } else if ("OR".equalsIgnoreCase(name)) {
/* 440 */       setDefault(childRec, line.getFieldValueIfExists("DEFAULTRECORD").asString());
/* 441 */       childRec.setRecordSelection((ExternalSelection)getGroup(reader, 3));
/*     */       
/* 443 */       line = reader.read();
/*     */     } 
/* 445 */     return line;
/*     */   }
/*     */   
/*     */   private void setDefault(XRecord childRec, String s) {
/* 449 */     if (s != null && "Y".equalsIgnoreCase(s)) {
/* 450 */       childRec.setDefaultRecord(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ExternalGroupSelection<ExternalSelection> getGroup(ILineReader reader, int type) throws IOException {
/* 457 */     ExternalGroupSelection<ExternalSelection> g = new ExternalGroupSelection();
/*     */ 
/*     */     
/* 460 */     g.setType(type);
/*     */     
/* 462 */     ILineFieldNames line = reader.read();
/* 463 */     while (line != null && !line.getFieldValueIfExists("Xml~Name").asString().startsWith("/")) {
/* 464 */       String name = line.getFieldValueIfExists("Xml~Name").asString();
/*     */       try {
/* 466 */         if ("TSTFIELD".equalsIgnoreCase(name)) {
/* 467 */           g.add((ExternalSelection)new ExternalFieldSelection(line
/* 468 */                 .getFieldValueIfExists("NAME").asString(), line
/* 469 */                 .getFieldValueIfExists("VALUE").asString(), line
/* 470 */                 .getFieldValueIfExists("OPERATOR").asString()));
/* 471 */         } else if ("AND".equalsIgnoreCase(name)) {
/* 472 */           g.add((ExternalSelection)getGroup(reader, 2));
/* 473 */         } else if ("OR".equalsIgnoreCase(name)) {
/* 474 */           g.add((ExternalSelection)getGroup(reader, 3));
/*     */         } 
/* 476 */       } catch (Exception exception) {}
/*     */       
/* 478 */       line = reader.read();
/*     */     } 
/*     */     
/* 481 */     return g;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getIntFld(ILineFieldNames line, String fldName, int defaultValue) {
/* 510 */     int ret = defaultValue;
/* 511 */     AbstractFieldValue value = line.getFieldValueIfExists(fldName);
/* 512 */     if (value != null && !"".equals(value.asString())) {
/*     */       try {
/* 514 */         ret = value.asInt();
/* 515 */       } catch (Exception exception) {}
/*     */     }
/*     */     
/* 518 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ItemHelper
/*     */   {
/*     */     final BaseRecordEditorXmlLoader.ILineReader reader;
/*     */ 
/*     */ 
/*     */     
/*     */     ILineFieldNames line;
/*     */ 
/*     */ 
/*     */     
/*     */     public final BaseItem topItem;
/*     */ 
/*     */ 
/*     */     
/* 538 */     public final ArrayList<Item> list = new ArrayList<Item>();
/*     */ 
/*     */     
/*     */     public ItemHelper(BaseRecordEditorXmlLoader.ILineReader reader, Item topItem) {
/* 542 */       this.reader = reader;
/* 543 */       this.topItem = (BaseItem)topItem;
/* 544 */       add(topItem);
/*     */     }
/*     */ 
/*     */     
/*     */     public ILineFieldNames read() throws IOException {
/* 549 */       return this.line = this.reader.read();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getAttr(String localName) {
/* 554 */       Object o = this.line.getField(localName);
/*     */       
/* 556 */       return (o == null) ? "" : o.toString();
/*     */     }
/*     */     
/*     */     public int getIntAttr(String localName) {
/* 560 */       String s = getAttr(localName);
/* 561 */       if (s != null && s.length() > 0) {
/* 562 */         return Integer.parseInt(s);
/*     */       }
/* 564 */       return Integer.MIN_VALUE;
/*     */     }
/*     */     
/*     */     public boolean getBooleanAttr(String localName) {
/* 568 */       String s = getAttr(localName);
/* 569 */       return "true".equals(s);
/*     */     }
/*     */     
/*     */     public Cb2xmlConstants.Justified getJustified() {
/* 573 */       String s = getAttr("justified");
/* 574 */       return Cb2xmlConstants.toJustified(s);
/*     */     }
/*     */     
/*     */     public Cb2xmlConstants.Usage getUsage() {
/* 578 */       String s = getAttr("usage");
/* 579 */       return Cb2xmlConstants.toUsage(s);
/*     */     }
/*     */     
/*     */     public Cb2xmlConstants.SignClause getSignClause() {
/* 583 */       String s = getAttr("sign-clause");
/* 584 */       return Cb2xmlConstants.toSignClause(s);
/*     */     }
/*     */     
/*     */     public Cb2xmlConstants.NumericClass getNumericClass() {
/* 588 */       String s = getAttr("numeric");
/* 589 */       return Cb2xmlConstants.toNumeric(s);
/*     */     }
/*     */     
/*     */     public void add(Item itm) {
/* 593 */       this.list.add(itm);
/*     */     }
/*     */ 
/*     */     
/*     */     public void pop() {
/* 598 */       this.list.remove(this.list.size() - 1);
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface ILineReader {
/*     */     ILineFieldNames read() throws IOException;
/*     */     
/*     */     void close() throws IOException;
/*     */   }
/*     */ }

