/*     */ package com.MainFrame.Reader.External.base;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import com.MainFrame.Reader.Common.CommonBits;
/*     */ import com.MainFrame.Reader.External.Def.DependingOn;
/*     */ import com.MainFrame.Reader.External.Def.DependingOnDtls;
/*     */ import com.MainFrame.Reader.External.Def.ExternalField;
/*     */ import com.MainFrame.Reader.Numeric.ConversionManager;
/*     */ import com.MainFrame.Reader.Numeric.Convert;
/*     */ import com.MainFrame.Reader.Types.Type;
/*     */ import com.MainFrame.Reader.Types.TypeManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldCreatorHelper
/*     */ {
/*  25 */   private boolean dropCopybookFromFieldNames = CommonBits.isDropCopybookFromFieldNames();
/*     */   
/*     */   private List<DependingOn> commonDependingOn;
/*     */   
/*     */   private final int splitCopybook;
/*  30 */   private final HashMap<String, String> fieldToNameWithArrayIndexs = new HashMap<String, String>();
/*     */   
/*     */   private boolean foundRedefine = false;
/*     */   
/*     */   private int position;
/*     */   private int length;
/*     */   private int childOccurs;
/*     */   private final String copyBookPref;
/*     */   private final String font;
/*     */   private final Convert numTranslator;
/*     */   private ArrayList<String> groupName;
/*  41 */   int lastEndPos = -1;
/*     */   ExternalField lastFiller;
/*  43 */   private int initialLevel = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldCreatorHelper(int splitCopybook, int dialect, boolean useJRecordNaming, String copyBookPref, String font) {
/*  48 */     this.splitCopybook = splitCopybook;
/*     */     
/*  50 */     this.copyBookPref = (useJRecordNaming ? copyBookPref.toUpperCase() : copyBookPref) + "-";
/*     */ 
/*     */     
/*  53 */     this.font = font;
/*  54 */     this.numTranslator = ConversionManager.getInstance().getConverter4code(dialect);
/*  55 */     this.groupName = new ArrayList<String>();
/*  56 */     this.groupName.add(".");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setParentGroup(String[] parentGroupNames) {
/*  61 */     int level = 1;
/*  62 */     if (parentGroupNames != null) {
/*  63 */       for (String s : parentGroupNames) {
/*  64 */         updateGroup(level++, s);
/*     */       }
/*     */     }
/*  67 */     this.initialLevel = level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInitialLevel() {
/*  74 */     return this.initialLevel;
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldCreatorHelper dependingOnBuilder() {
/*  79 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldCreatorHelper setPosition(int position) {
/*  86 */     this.position = position;
/*     */     
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldCreatorHelper setLength(int length) {
/*  95 */     this.length = length;
/*     */     
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldCreatorHelper setChildOccurs(int childOccurs) {
/* 104 */     this.childOccurs = childOccurs;
/*     */     
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFoundRedefine(boolean foundRedefine) {
/* 114 */     this.foundRedefine = foundRedefine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DependingOn newDependingOn(IAddDependingOn currentLayout, DependingOnDtls dependOnParentDtls, String dependingVar) {
/* 124 */     DependingOn dependOn = null;
/* 125 */     if (dependingVar.length() > 0) {
/*     */       
/* 127 */       String dependingVarNoIdx = dependingVar;
/* 128 */       String key = dependingVar.toLowerCase();
/* 129 */       String lookup = this.fieldToNameWithArrayIndexs.get(key);
/* 130 */       if (lookup != null) {
/* 131 */         dependingVar = lookup;
/* 132 */         key = lookup.toLowerCase();
/*     */       } 
/*     */       
/* 135 */       dependOn = new DependingOn(dependingVar, dependingVarNoIdx, this.position, this.length, this.childOccurs);
/* 136 */       if (dependOnParentDtls == null) {
/* 137 */         if (this.splitCopybook != 1 || this.foundRedefine) {
/* 138 */           currentLayout.addDependingOn(dependOn);
/*     */         } else {
/* 140 */           if (this.commonDependingOn == null) {
/* 141 */             this.commonDependingOn = new ArrayList<DependingOn>();
/*     */           }
/* 143 */           this.commonDependingOn.add(dependOn);
/*     */         } 
/*     */       }
/*     */     } 
/* 147 */     return dependOn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DependingOn> getCommonDependingOn() {
/* 154 */     return this.commonDependingOn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createFieldName(String cobolFieldName, String arrayIndexDetails) {
/* 164 */     String nameKey = cobolFieldName.toLowerCase();
/* 165 */     if (!"".equals(arrayIndexDetails)) {
/* 166 */       cobolFieldName = cobolFieldName + " (" + arrayIndexDetails + ")";
/* 167 */       this.fieldToNameWithArrayIndexs.put(nameKey, cobolFieldName);
/*     */     } else {
/* 169 */       this.fieldToNameWithArrayIndexs.remove(nameKey);
/*     */     } 
/*     */     
/* 172 */     if (this.dropCopybookFromFieldNames && cobolFieldName.toUpperCase().startsWith(this.copyBookPref)) {
/* 173 */       cobolFieldName = cobolFieldName.substring(this.copyBookPref.length());
/*     */     }
/* 175 */     return cobolFieldName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createOriginalName(String lName) {
/* 185 */     if (this.dropCopybookFromFieldNames && lName.toUpperCase().startsWith(this.copyBookPref)) {
/* 186 */       lName = lName.substring(this.copyBookPref.length());
/*     */     }
/* 188 */     return lName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String updateFieldNameIndex(String nameSuffix, int arrayIdx) {
/* 193 */     if (nameSuffix.equals("")) {
/* 194 */       nameSuffix = Integer.toString(arrayIdx);
/*     */     } else {
/* 196 */       nameSuffix = nameSuffix + ", " + arrayIdx;
/*     */     } 
/* 198 */     return nameSuffix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDropCopybookFromFieldNames() {
/* 205 */     return this.dropCopybookFromFieldNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDropCopybookFromFieldNames(boolean dropCopybookFromFieldNames) {
/* 212 */     this.dropCopybookFromFieldNames = dropCopybookFromFieldNames;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int deriveType(boolean isNumeric, String usage, String picture, boolean signSeperate, String signPosition, boolean justified) {
/* 218 */     int iType = 0;
/* 219 */     picture = (picture == null) ? "" : picture;
/*     */     
/* 221 */     if (isNumeric) {
/* 222 */       boolean signed = (picture.length() > 0 && (picture.charAt(0) == 's' || picture.charAt(0) == 'S'));
/* 223 */       iType = this.numTranslator.getTypeIdentifier((usage == null) ? "" : usage, picture, signed, signSeperate, signPosition);
/*     */ 
/*     */     
/*     */     }
/* 227 */     else if (justified) {
/* 228 */       iType = 1;
/* 229 */     } else if ("null-padded".equals(usage)) {
/* 230 */       iType = 3;
/* 231 */     } else if ("null-terminated".equals(usage)) {
/* 232 */       iType = 2;
/*     */     } 
/*     */     
/* 235 */     return iType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int calculateDecimalSize(int type, String pFormat, int scale) {
/* 244 */     if (scale < 0 && scale != Integer.MIN_VALUE) return scale; 
/* 245 */     int lRet = 0;
/*     */ 
/*     */ 
/*     */     
/* 249 */     String format = "";
/* 250 */     char decimalPnt = '.';
/* 251 */     Type t = TypeManager.getInstance().getType(type);
/* 252 */     if (pFormat != null) {
/* 253 */       format = pFormat.toUpperCase();
/*     */     }
/* 255 */     if (t != null) {
/* 256 */       decimalPnt = t.getDecimalChar();
/*     */     }
/*     */     
/* 259 */     int decimalPos = format.indexOf(decimalPnt);
/* 260 */     if (decimalPos != format.lastIndexOf(decimalPnt)) {
/* 261 */       decimalPos = -1;
/*     */     }
/* 263 */     int lPos = Math.max(format.indexOf("V"), decimalPos);
/* 264 */     if (lPos >= 0) {
/* 265 */       String lDecimalStr = format.substring(lPos + 1);
/* 266 */       int lBracketOpenPos = lDecimalStr.indexOf("(");
/* 267 */       int lBracketClosePos = lDecimalStr.indexOf(")");
/*     */       
/* 269 */       if (lBracketOpenPos >= 0 && lBracketClosePos >= lBracketOpenPos) {
/*     */         try {
/* 271 */           String lNumStr = lDecimalStr.substring(lBracketOpenPos + 1, lBracketClosePos);
/*     */ 
/*     */           
/* 274 */           int lNum = Integer.parseInt(lNumStr);
/* 275 */           lRet = lNum + lDecimalStr.length() - lBracketClosePos - lBracketOpenPos - 2;
/*     */         }
/* 277 */         catch (Exception exception) {}
/*     */       }
/*     */       else {
/*     */         
/* 281 */         lRet = lDecimalStr.length();
/*     */       } 
/*     */       
/* 284 */       if (lRet > 0 && (pFormat.endsWith("+") || pFormat.endsWith("-"))) {
/* 285 */         lRet--;
/*     */       }
/*     */     } 
/*     */     
/* 289 */     return lRet;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateGroup(int level, String lOrigName) {
/* 295 */     if (level > 0 && level <= this.groupName.size()) {
/* 296 */       String s = this.groupName.get(level - 1);
/* 297 */       if (lOrigName != null && lOrigName.length() > 0 && !"filler".equalsIgnoreCase(lOrigName)) {
/* 298 */         s = s + lOrigName + '.';
/*     */       } else {
/* 300 */         s = s + '.';
/*     */       } 
/*     */       
/* 303 */       if (this.groupName.size() > level) {
/* 304 */         this.groupName.set(level, s);
/*     */       } else {
/* 306 */         this.groupName.add(s);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getGroupNameSize() {
/* 312 */     return this.groupName.size();
/*     */   }
/*     */   
/*     */   public String getGroupName(int level) {
/* 316 */     return this.groupName.get(level);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCopyBookPref() {
/* 323 */     return this.copyBookPref;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFont() {
/* 331 */     return this.font;
/*     */   }
/*     */ }

