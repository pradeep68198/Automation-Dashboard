/*    */ package com.MainFrame.Reader.External.base;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cb2xmlDocument
/*    */ {
/*    */   public final int splitOption;
/*    */   public final String splitAtLevel;
/*    */   public final Object cb2xmlDocument;
/*    */   
/*    */   public Cb2xmlDocument(int splitOption, String splitAtLevel, Object cb2xmlDocument) {
/* 40 */     this.splitOption = splitOption;
/* 41 */     this.splitAtLevel = splitAtLevel;
/* 42 */     this.cb2xmlDocument = cb2xmlDocument;
/*    */   }
/*    */ }

