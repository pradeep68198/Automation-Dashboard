/*     */ package com.MainFrame.Reader.External.base;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.External.Def.ExternalField;
/*     */ import com.MainFrame.Reader.Log.AbsSSLogger;
/*     */ import com.MainFrame.Reader.Log.TextLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordEditorCSVWriter
/*     */   implements CopybookWriter
/*     */ {
/*  64 */   private String fldSeperator = "\t";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RecordEditorCSVWriter(String fieldSeperator) {
/*  71 */     this.fldSeperator = fieldSeperator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String writeCopyBook(String directory, BaseExternalRecord<?> copybook, AbsSSLogger log) throws Exception {
/*  84 */     log = TextLog.getLog(log);
/*  85 */     directory = ExternalConversion.fixDirectory(directory);
/*     */     
/*  87 */     for (int i = 0; i < copybook.getNumberOfRecords(); i++) {
/*  88 */       writeCopyBook(directory, (BaseExternalRecord<?>)copybook.getRecord(i), log);
/*     */     }
/*     */     
/*  91 */     String fileName = directory + copybook.getRecordName() + ".Txt";
/*  92 */     copybook.setRecordName(ExternalConversion.copybookNameToFileName(copybook.getRecordName()));
/*  93 */     writeCopyBook(new FileOutputStream(fileName), copybook, log);
/*     */     
/*  95 */     return fileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeCopyBook(OutputStream outStream, BaseExternalRecord<?> copybook, AbsSSLogger log) throws Exception {
/* 112 */     BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outStream));
/*     */     
/* 114 */     writer.write("Record" + this.fldSeperator + copybook
/* 115 */         .getFileStructure() + this.fldSeperator + copybook
/* 116 */         .getRecordType() + this.fldSeperator + copybook
/* 117 */         .getDelimiter() + this.fldSeperator + copybook
/* 118 */         .getRecordStyle() + this.fldSeperator + copybook
/* 119 */         .getQuote() + this.fldSeperator + copybook
/* 120 */         .getListChar() + this.fldSeperator + 
/* 121 */         fixDescription(copybook.getDescription()));
/*     */     
/* 123 */     writer.newLine();
/*     */     int i;
/* 125 */     for (i = 0; i < copybook.getNumberOfRecords(); i++) {
/* 126 */       BaseExternalRecord<?> sr = (BaseExternalRecord<?>)copybook.getRecord(i);
/* 127 */       writer.write("SR" + this.fldSeperator + sr
/* 128 */           .getRecordName() + this.fldSeperator + sr
/* 129 */           .getTstField() + this.fldSeperator + sr
/* 130 */           .getTstFieldValue() + this.fldSeperator + sr
/* 131 */           .getParentRecord() + this.fldSeperator + sr
/* 132 */           .getListChar());
/*     */       
/* 134 */       writer.newLine();
/*     */     } 
/*     */     
/* 137 */     for (i = 0; i < copybook.getNumberOfRecordFields(); i++) {
/* 138 */       ExternalField field = copybook.getRecordField(i);
/* 139 */       String description = field.getDescription();
/* 140 */       if (description == null) {
/* 141 */         description = "";
/* 142 */       } else if (description.indexOf(this.fldSeperator) >= 0 || description
/* 143 */         .indexOf('\n') >= 0) {
/* 144 */         description = fixDescription(description);
/*     */       } 
/* 146 */       writer.write(field.getPos() + this.fldSeperator + field
/* 147 */           .getLen() + this.fldSeperator + field
/* 148 */           .getName() + this.fldSeperator + description + this.fldSeperator + field
/*     */           
/* 150 */           .getType() + this.fldSeperator + field
/* 151 */           .getDecimal() + this.fldSeperator + field
/* 152 */           .getCellFormat() + this.fldSeperator + field
/* 153 */           .getParameter());
/* 154 */       writer.newLine();
/*     */     } 
/* 156 */     writer.close();
/* 157 */     outStream.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private String fixDescription(String description) {
/* 162 */     StringBuilder b = new StringBuilder(description);
/*     */     
/* 164 */     Conversion.replace(b, this.fldSeperator, " ");
/* 165 */     Conversion.replace(b, "\n", "\\n");
/* 166 */     return b.toString();
/*     */   }
/*     */ }

