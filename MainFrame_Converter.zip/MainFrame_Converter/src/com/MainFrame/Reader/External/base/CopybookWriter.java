package com.MainFrame.Reader.External.base;

import java.io.OutputStream;
import com.MainFrame.Reader.Log.AbsSSLogger;

public interface CopybookWriter {
  String writeCopyBook(String paramString, BaseExternalRecord<?> paramBaseExternalRecord, AbsSSLogger paramAbsSSLogger) throws Exception;
  
  void writeCopyBook(OutputStream paramOutputStream, BaseExternalRecord<?> paramBaseExternalRecord, AbsSSLogger paramAbsSSLogger) throws Exception;
}

