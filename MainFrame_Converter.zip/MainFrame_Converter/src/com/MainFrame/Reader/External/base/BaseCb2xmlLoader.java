/*      */ package com.MainFrame.Reader.External.base;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import com.MainFrame.Reader.Common.CommonBits;
/*      */ import com.MainFrame.Reader.Common.Conversion;
/*      */ import com.MainFrame.Reader.External.Def.DependingOn;
/*      */ import com.MainFrame.Reader.External.Def.DependingOnDtls;
/*      */ import com.MainFrame.Reader.External.Def.ExternalField;
/*      */ import com.MainFrame.Reader.Log.AbsSSLogger;
/*      */ import com.MainFrame.Reader.Numeric.ConversionManager;
/*      */ import com.MainFrame.Reader.Numeric.Convert;
/*      */ import com.MainFrame.Reader.Types.TypeManager;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BaseCb2xmlLoader<XRecord extends BaseExternalRecord<XRecord>>
/*      */ {
/*      */   private static final int OPT_WRITE_ELEMENT = 1;
/*      */   private static final int OPT_REDEFINES = 2;
/*      */   private static final int OPT_SAVE = 3;
/*      */   private static final int OPT_REDEFINED = 4;
/*      */   private static final String STR_YES = "Y";
/*      */   private static final String STR_NO = "N";
/*      */   private String copybookName;
/*      */   private ArrayList<ExternalField> commonDetails;
/*      */   private String redefinedField;
/*      */   private boolean foundRedefine;
/*  107 */   private boolean dropCopybookFromFieldNames = CommonBits.isDropCopybookFromFieldNames();
/*      */   
/*      */   private boolean saveCb2xml = false;
/*      */   
/*      */   private int splitCopybook;
/*      */   private int fieldNum;
/*      */   private int recordNum;
/*      */   private XRecord currentLayout;
/*  115 */   private XRecord parentLayout = null;
/*      */ 
/*      */ 
/*      */   
/*      */   private XRecord groupRecord;
/*      */ 
/*      */ 
/*      */   
/*  123 */   private int binaryFormat = 0;
/*      */   private Convert numTranslator;
/*  125 */   private String fontName = "";
/*  126 */   private int system = 0;
/*      */   
/*  128 */   private int redefLevel = Integer.MAX_VALUE;
/*      */   
/*      */   private int level;
/*      */   private String splitAtLevel;
/*  132 */   private int positionAdjustment = 0;
/*      */ 
/*      */   
/*      */   boolean keepFiller = false;
/*      */ 
/*      */   
/*      */   private final boolean useJRecordNaming;
/*      */ 
/*      */   
/*      */   private final IExernalRecordBuilder<XRecord> recBuilder;
/*      */   
/*      */   private FieldCreatorHelper fieldHelper;
/*      */ 
/*      */   
/*      */   public void setStackSize(int size) {}
/*      */ 
/*      */   
/*      */   protected BaseCb2xmlLoader(IExernalRecordBuilder<XRecord> recBuilder, boolean useJRecordNaming) {
/*  150 */     this.recBuilder = recBuilder;
/*  151 */     this.useJRecordNaming = useJRecordNaming;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Document fileToDom(String fileName) throws IOException, SAXException, ParserConfigurationException {
/*  166 */     synchronized (this) {
/*      */       
/*  168 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*  169 */       return factory.newDocumentBuilder().parse(new File(fileName));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSaveCb2xmlDocument(boolean saveCb2xml) {
/*  179 */     this.saveCb2xml = saveCb2xml;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final XRecord loadCopyBook(String copyBookFile, int splitCopybookOption, int dbIdx, String font, int binFormat, int systemId, AbsSSLogger log) throws IOException, SAXException, ParserConfigurationException {
/*  191 */     return loadCopyBook(copyBookFile, splitCopybookOption, dbIdx, font, CommonBits.getDefaultCobolTextFormat(), binFormat, systemId, log);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XRecord loadCopyBook(InputStream inputStream, String copyBookName, int splitCopybook, int dbIdx, String font, int copybookFormat, int binaryFormat, int systemId, AbsSSLogger log) throws IOException {
/*      */     try {
/*  204 */       synchronized (this) {
/*      */         
/*  206 */         DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*  207 */         Document doc = factory.newDocumentBuilder().parse(inputStream);
/*  208 */         return loadDOMCopyBook(doc, copyBookName, splitCopybook, dbIdx, font, binaryFormat, systemId);
/*      */       } 
/*  210 */     } catch (SAXException e) {
/*  211 */       throw new IOException(e);
/*  212 */     } catch (ParserConfigurationException e) {
/*  213 */       throw new IOException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XRecord loadCopyBook(Reader reader, String copyBookName, int splitCopybook, int dbIdx, String font, int copybookFormat, int binaryFormat, int systemId, AbsSSLogger log) throws IOException {
/*      */     try {
/*  224 */       synchronized (this) {
/*      */         
/*  226 */         DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*  227 */         Document doc = factory.newDocumentBuilder().parse(new InputSource(reader));
/*  228 */         return loadDOMCopyBook(doc, copyBookName, splitCopybook, dbIdx, font, binaryFormat, systemId);
/*      */       } 
/*  230 */     } catch (SAXException e) {
/*  231 */       throw new IOException(e);
/*  232 */     } catch (ParserConfigurationException e) {
/*  233 */       throw new IOException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XRecord loadCopyBook(String copyBookFile, int splitCopybookOption, int dbIdx, String font, int copybookFormat, int binFormat, int systemId, AbsSSLogger log) throws IOException, SAXException, ParserConfigurationException {
/*  263 */     return loadDOMCopyBook(fileToDom(copyBookFile), Conversion.getCopyBookId(copyBookFile), splitCopybookOption, dbIdx, font, binFormat, systemId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XRecord loadDOMCopyBook(Document pCopyBookXml, String pCopyBook, int pSplitCopybook, int pDbIdx, String font, int binFormat, int systemId) {
/*  290 */     synchronized (this) {
/*      */       String topLevel;
/*      */       
/*  293 */       this.numTranslator = ConversionManager.getInstance().getConverter4code(binFormat);
/*      */       
/*  295 */       this.copybookName = pCopyBook;
/*  296 */       this.binaryFormat = this.numTranslator.getBinaryIdentifier();
/*  297 */       this.fontName = font;
/*  298 */       this.system = systemId;
/*  299 */       this.parentLayout = null;
/*      */ 
/*      */       
/*  302 */       this.fieldHelper = new FieldCreatorHelper(pSplitCopybook, binFormat, this.useJRecordNaming, pCopyBook, font);
/*  303 */       this.fieldHelper.setDropCopybookFromFieldNames(this.dropCopybookFromFieldNames);
/*  304 */       this.splitCopybook = pSplitCopybook;
/*      */       
/*  306 */       this.redefinedField = "";
/*  307 */       this.commonDetails = new ArrayList<ExternalField>();
/*  308 */       this.foundRedefine = false;
/*  309 */       this.fieldNum = 0;
/*  310 */       this.recordNum = 1;
/*  311 */       this.positionAdjustment = 0;
/*      */       
/*  313 */       Element element = pCopyBookXml.getDocumentElement();
/*      */       
/*  315 */       allocDBs(pDbIdx);
/*      */       
/*  317 */       String lCopyBookPref = this.fieldHelper.getCopyBookPref();
/*  318 */       this.splitAtLevel = "1";
/*      */       
/*  320 */       switch (pSplitCopybook) {
/*      */         case 0:
/*  322 */           createRecord(pCopyBook, pCopyBook, "Y");
/*      */           
/*  324 */           insertXMLcopybook(lCopyBookPref, element);
/*      */           break;
/*      */         case 1:
/*  327 */           scanCopybook4RedefLevel(element);
/*  328 */           processCopybook(pCopyBook, lCopyBookPref, element);
/*      */           break;
/*      */         case 4:
/*  331 */           scanCopybook4Level(element);
/*  332 */           processCopybook(pCopyBook, lCopyBookPref, element);
/*      */           break;
/*      */         default:
/*  335 */           topLevel = getTopLevel(element);
/*  336 */           if ("1".equals(topLevel)) {
/*  337 */             processCopybook(pCopyBook, lCopyBookPref, element); break;
/*      */           } 
/*  339 */           createRecord(pCopyBook, pCopyBook, "Y");
/*      */           
/*  341 */           insertXMLcopybook(lCopyBookPref, element);
/*      */           break;
/*      */       } 
/*      */       
/*  345 */       this.commonDetails = null;
/*      */       
/*  347 */       if (this.parentLayout == null) {
/*  348 */         this.parentLayout = this.currentLayout;
/*      */       }
/*      */       
/*  351 */       if (!this.keepFiller) {
/*  352 */         this.parentLayout.dropFiller();
/*      */       }
/*      */       
/*  355 */       boolean multipleRecordLengths = false;
/*  356 */       boolean binary = false;
/*      */       
/*  358 */       if (this.parentLayout.getNumberOfRecords() == 0) {
/*  359 */         binary = isBinaryRec(this.parentLayout);
/*      */       } else {
/*  361 */         int len = getRecLength(this.parentLayout.getRecord(0));
/*  362 */         binary = (binary || isBinaryRec(this.parentLayout.getRecord(0)));
/*      */         
/*  364 */         for (int i = 1; i < this.parentLayout.getNumberOfRecords(); i++) {
/*  365 */           binary = (binary || isBinaryRec(this.parentLayout.getRecord(i)));
/*      */           
/*  367 */           multipleRecordLengths = (multipleRecordLengths || len != getRecLength(this.parentLayout.getRecord(i)));
/*      */         } 
/*      */       } 
/*  370 */       this.parentLayout.setFileStructure(this.numTranslator.getFileStructure(multipleRecordLengths, binary));
/*  371 */       freeDBs(pDbIdx);
/*      */       
/*  373 */       if (this.saveCb2xml) {
/*  374 */         this.parentLayout.addCb2xmlDocument(new Cb2xmlDocument(pSplitCopybook, this.splitAtLevel, pCopyBookXml));
/*      */       }
/*      */       
/*  377 */       return this.parentLayout;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void processCopybook(String pCopyBook, String lCopyBookPref, Element element) {
/*  382 */     insertXMLcopybook(lCopyBookPref, element);
/*      */ 
/*      */     
/*  385 */     if (!this.foundRedefine && this.commonDetails.size() > 0) {
/*  386 */       createRecord(pCopyBook, pCopyBook, "Y");
/*      */       
/*  388 */       for (int i = 1; i < this.commonDetails.size(); i++) {
/*  389 */         insertRecordField(this.commonDetails.get(i));
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isBinaryRec(XRecord rec) {
/*  396 */     boolean ret = false;
/*  397 */     TypeManager m = TypeManager.getInstance();
/*      */     
/*      */     try {
/*  400 */       for (int i = 0; i < rec.getNumberOfRecordFields() && !ret; i++) {
/*  401 */         ret = m.getType(rec.getRecordField(i).getType()).isBinary();
/*      */       }
/*  403 */     } catch (Exception e) {
/*  404 */       System.out.println("Error checking for binary field Types");
/*      */     } 
/*      */     
/*  407 */     return ret;
/*      */   }
/*      */   
/*      */   private int getRecLength(XRecord rec) {
/*  411 */     int ret = 0;
/*      */     
/*      */     try {
/*  414 */       for (int i = 0; i < rec.getNumberOfRecordFields(); i++) {
/*  415 */         ExternalField recordField = rec.getRecordField(i);
/*  416 */         ret = Math.max(ret, recordField.getPos() + recordField.getLen() - 1);
/*      */       } 
/*  418 */     } catch (Exception e) {
/*  419 */       System.out.println("Error Finding Record Length Types");
/*      */     } 
/*      */     
/*  422 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void allocDBs(int pDbIdx) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void freeDBs(int pDbIdx) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void scanCopybook4RedefLevel(Element element) {
/*  441 */     NodeList lNodeList = element.getChildNodes();
/*      */     
/*  443 */     for (int i = 0; i < lNodeList.getLength(); i++) {
/*  444 */       Node node = lNodeList.item(i);
/*  445 */       if (node.getNodeType() == 1) {
/*  446 */         Element childElement = (Element)node;
/*  447 */         if (!childElement.getAttribute("level").equals("88")) {
/*  448 */           checkRedef(childElement);
/*  449 */           scanCopybook4RedefLevel(childElement);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void scanCopybook4Level(Element element) {
/*  457 */     String lvl = getTopLevel(element);
/*  458 */     if (lvl != null) {
/*  459 */       this.splitAtLevel = lvl;
/*      */     }
/*      */   }
/*      */   
/*      */   private String getTopLevel(Element element) {
/*  464 */     NodeList lNodeList = element.getChildNodes();
/*  465 */     while (lNodeList != null && lNodeList.getLength() == 1) {
/*  466 */       lNodeList = lNodeList.item(0).getChildNodes();
/*      */     }
/*  468 */     if (lNodeList != null && lNodeList.getLength() > 0) {
/*  469 */       Node node = null;
/*  470 */       int i = 0;
/*      */       
/*  472 */       while (i < lNodeList.getLength() && (
/*  473 */         node = lNodeList.item(i++)).getNodeType() != 1);
/*      */       
/*  475 */       if (node.getNodeType() == 1) {
/*  476 */         Element childElement = (Element)node;
/*  477 */         String attrLevel = childElement.getAttribute("level");
/*  478 */         if (!attrLevel.equals("88")) {
/*  479 */           return Conversion.numTrim(attrLevel);
/*      */         }
/*      */       } 
/*      */     } 
/*  483 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkRedef(Element element) {
/*  496 */     if (element.hasAttribute("name")) {
/*      */       try {
/*  498 */         int levelNum = getIntAttribute(element, "level");
/*  499 */         if (levelNum > 0 && levelNum < this.redefLevel && 
/*      */           
/*  501 */           getStringAttribute(element, "redefined").equalsIgnoreCase("true")) {
/*  502 */           this.redefLevel = levelNum;
/*      */         }
/*  504 */       } catch (Exception exception) {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void insertXMLcopybook(String copyBookPref, Element element) {
/*  520 */     this.level = 0;
/*      */ 
/*      */ 
/*      */     
/*  524 */     insertXMLcopybook(copyBookPref, element, 0, "", null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void insertXMLcopybook(String copyBookPref, Element element, int basePosition, String nameSuffix, DependingOnDtls dependOnParentDtls) {
/*  543 */     NodeList lNodeList = element.getChildNodes();
/*  544 */     this.level++;
/*      */     
/*  546 */     for (int i = 0; i < lNodeList.getLength(); i++) {
/*  547 */       Node node = lNodeList.item(i);
/*  548 */       if (node.getNodeType() == 1) {
/*  549 */         Element childElement = (Element)node;
/*  550 */         if (!childElement.getAttribute("level").equals("88"))
/*      */         {
/*  552 */           if (childElement.hasAttribute("occurs")) {
/*  553 */             int childOccurs = getIntAttribute(childElement, "occurs");
/*  554 */             int length = getIntAttribute(childElement, "storage-length");
/*  555 */             String dependingVar = getStringAttribute(childElement, "depending-on");
/*  556 */             DependingOn dependOn = null;
/*      */             
/*  558 */             if (dependingVar.length() > 0) {
/*  559 */               ExternalField tmpField = convertElement2Field("xx", false, basePosition, childElement, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  565 */               dependOn = this.fieldHelper.dependingOnBuilder().setPosition(tmpField.getPos()).setLength(length).setChildOccurs(childOccurs).newDependingOn((IAddDependingOn)this.currentLayout, dependOnParentDtls, dependingVar);
/*      */             } 
/*      */ 
/*      */             
/*  569 */             int size = 0;
/*  570 */             if (this.currentLayout != null && ((BaseExternalRecord)this.currentLayout).fields != null) {
/*  571 */               size = ((BaseExternalRecord)this.currentLayout).fields.size();
/*      */               
/*  573 */               ((BaseExternalRecord)this.currentLayout).fields.ensureCapacity(size + childOccurs);
/*      */             } 
/*  575 */             for (int j = 0; j < childOccurs; j++) {
/*  576 */               String newSuffix = this.fieldHelper.updateFieldNameIndex(nameSuffix, j);
/*      */               
/*  578 */               DependingOnDtls dependOnDtls = dependOnParentDtls;
/*  579 */               if (dependOn != null) {
/*  580 */                 dependOnDtls = new DependingOnDtls(dependOn, j, dependOnParentDtls);
/*      */               }
/*  582 */               insertElement(childElement, copyBookPref, newSuffix, basePosition + j * length, dependOnDtls);
/*      */               
/*  584 */               insertXMLcopybook(copyBookPref, childElement, basePosition + j * length, newSuffix, dependOnDtls);
/*      */             } 
/*      */           } else {
/*  587 */             insertElement(childElement, copyBookPref, nameSuffix, basePosition, dependOnParentDtls);
/*  588 */             insertXMLcopybook(copyBookPref, childElement, basePosition, nameSuffix, dependOnParentDtls);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  594 */     this.level--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void insertElement(Element element, String copyBookPref, String nameSuffix, int posBase, DependingOnDtls dependDtls) {
/*  614 */     if (element.hasAttribute("name")) {
/*  615 */       String lOrigName = getStringAttribute(element, "name");
/*  616 */       String lName = this.fieldHelper.createFieldName(lOrigName, nameSuffix);
/*  617 */       String usage = "";
/*      */       
/*  619 */       lOrigName = this.fieldHelper.createOriginalName(lOrigName);
/*      */       
/*  621 */       boolean lIsNumeric = getStringAttribute(element, "numeric").equalsIgnoreCase("true");
/*      */       
/*  623 */       if (element.hasAttribute("usage")) {
/*  624 */         usage = element.getAttribute("usage");
/*      */       }
/*      */       
/*  627 */       boolean print = (element.hasAttribute("picture") || "computational-1".equals(usage) || "computational-2".equals(usage));
/*  628 */       int opt = 1;
/*  629 */       switch (this.splitCopybook) {
/*      */         case 1:
/*  631 */           if (this.foundRedefine) {
/*  632 */             if (getStringAttribute(element, "redefines").equals(this.redefinedField))
/*  633 */               opt = 2; 
/*      */             break;
/*      */           } 
/*  636 */           opt = 3;
/*      */           try {
/*  638 */             if (this.redefLevel == getIntAttribute(element, "level") && 
/*  639 */               getStringAttribute(element, "redefined").equalsIgnoreCase("true")) {
/*  640 */               opt = 4;
/*      */             }
/*  642 */           } catch (Exception exception) {}
/*      */           break;
/*      */ 
/*      */         
/*      */         case 4:
/*  647 */           if (Conversion.numTrim(getStringAttribute(element, "level")).equals(this.splitAtLevel)) {
/*  648 */             this.positionAdjustment = getIntAttribute(element, "position") - 1;
/*  649 */             opt = this.foundRedefine ? 2 : 4;
/*      */           } 
/*      */           break;
/*      */         case 2:
/*  653 */           if (Conversion.numTrim(getStringAttribute(element, "level")).equals(this.splitAtLevel)) {
/*  654 */             opt = this.foundRedefine ? 2 : 4;
/*      */           }
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  669 */       this.fieldHelper.updateGroup(opt, lOrigName);
/*      */       
/*  671 */       switch (opt) {
/*      */         case 1:
/*  673 */           if (print) {
/*  674 */             insertRecordField(convertElement2Field(lName, lIsNumeric, posBase, element, dependDtls));
/*      */           }
/*      */           break;
/*      */         case 4:
/*  678 */           this.redefinedField = lOrigName;
/*  679 */           insertCommonFields(copyBookPref, lName, true);
/*      */           
/*  681 */           this.foundRedefine = true;
/*  682 */           this.fieldHelper.setFoundRedefine(this.foundRedefine);
/*  683 */           if (print) {
/*  684 */             insertRecordField(convertElement2Field(lName, lIsNumeric, posBase, element, dependDtls));
/*      */           }
/*      */           break;
/*      */         case 2:
/*  688 */           insertCommonFields(copyBookPref, lName, false);
/*  689 */           if (print) {
/*  690 */             insertRecordField(convertElement2Field(lName, lIsNumeric, posBase, element, dependDtls));
/*      */           }
/*      */           break;
/*      */         case 3:
/*  694 */           if (print) {
/*  695 */             this.commonDetails.add(convertElement2Field(lName, lIsNumeric, posBase, element, dependDtls));
/*      */           }
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void insertCommonFields(String copyBookPref, String recordName, boolean first) {
/*      */     String name;
/*  716 */     int start = 0;
/*      */     
/*  718 */     switch (this.splitCopybook) {
/*      */       case 2:
/*      */       case 4:
/*  721 */         start = 1;
/*      */         break;
/*      */     } 
/*  724 */     if (first) {
/*  725 */       int rt = 9;
/*  726 */       if (this.binaryFormat == 1 || this.binaryFormat == 3)
/*      */       {
/*  728 */         rt = 10;
/*      */       }
/*      */       
/*  731 */       this.groupRecord = this.recBuilder.getNullRecord(this.copybookName, rt, this.fontName);
/*      */ 
/*      */ 
/*      */       
/*  735 */       this.groupRecord.setListChar("Y");
/*  736 */       this.groupRecord = getUpdatedRecord(this.copybookName, this.groupRecord, false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  744 */     if (this.useJRecordNaming) {
/*  745 */       name = recordName.trim();
/*  746 */     } else if (copyBookPref.endsWith("-") || copyBookPref.endsWith("_")) {
/*  747 */       name = copyBookPref.trim() + recordName.trim();
/*      */     } else {
/*  749 */       name = copyBookPref + " " + recordName;
/*      */     } 
/*      */     
/*  752 */     XRecord rec = createRecord(copyBookPref + this.recordNum++, name, "N");
/*      */ 
/*      */     
/*  755 */     this.parentLayout.addRecord(rec);
/*      */     
/*  757 */     for (int i = start; i < this.commonDetails.size(); i++) {
/*  758 */       insertRecordField(this.commonDetails.get(i));
/*      */     }
/*      */     
/*  761 */     this.fieldNum = this.commonDetails.size() + 1;
/*      */     
/*  763 */     List<DependingOn> commonDependingOn = this.fieldHelper.getCommonDependingOn();
/*  764 */     if (commonDependingOn != null) {
/*  765 */       for (DependingOn dependOn : commonDependingOn) {
/*  766 */         this.currentLayout.addDependingOn(dependOn);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private XRecord createRecord(String copyBook, String recordName, String listChar) {
/*  785 */     int rt = 1;
/*  786 */     if (this.binaryFormat == 1) {
/*  787 */       rt = 0;
/*      */     }
/*      */     
/*  790 */     XRecord rec = this.recBuilder.getNullRecord(recordName, rt, this.fontName);
/*      */ 
/*      */     
/*  793 */     rec.setListChar(listChar);
/*  794 */     rec.setSystem(this.system);
/*      */     
/*  796 */     return getUpdatedRecord(copyBook, rec, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private XRecord getUpdatedRecord(String copyBook, XRecord rec, boolean updateRequired) {
/*  815 */     updateRecord(copyBook, rec, updateRequired);
/*      */     
/*  817 */     this.currentLayout = rec;
/*  818 */     if (this.parentLayout == null) {
/*  819 */       this.parentLayout = rec;
/*      */     }
/*  821 */     return rec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateRecord(String copyBook, XRecord rec, boolean updateRequired) {
/*  838 */     rec.setSystem(this.system);
/*  839 */     rec.setCopyBook(copyBook);
/*  840 */     rec.setNew(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void insertRecordField(ExternalField field) {
/*  851 */     this.currentLayout.addRecordField(field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ExternalField convertElement2Field(String name, boolean isNumeric, int base, Element element, DependingOnDtls dependDtls) {
/*  872 */     String usage = getStringAttribute(element, "usage");
/*  873 */     String just = getStringAttribute(element, "justified");
/*  874 */     String picture = getStringAttribute(element, "picture").toUpperCase();
/*  875 */     String signSeparate = getStringAttribute(element, "sign-separate");
/*  876 */     String signPosition = getStringAttribute(element, "sign-position");
/*      */ 
/*      */     
/*  879 */     int iType = this.fieldHelper.deriveType(isNumeric, usage, picture, "true"
/*  880 */         .equals(signSeparate), signPosition, (just != null && just
/*  881 */         .length() > 0));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  916 */     ExternalField externalField = new ExternalField(getIntAttribute(element, "position") + base - this.positionAdjustment, getIntAttribute(element, "storage-length"), name, "", iType, this.fieldHelper.calculateDecimalSize(iType, getStringAttribute(element, "picture"), getIntAttribute(element, "scale")), 0, "", "", getStringAttribute(element, "name"), this.fieldNum++, dependDtls);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  921 */     if (this.level > 1 && this.fieldHelper.getGroupNameSize() > this.level) {
/*  922 */       externalField.setGroup(this.fieldHelper.getGroupName(this.level - 1));
/*      */     }
/*  924 */     return externalField;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getIntAttribute(Element element, String attributeName) {
/*  937 */     int lRet = 0;
/*      */     
/*  939 */     if (element.hasAttribute(attributeName)) {
/*  940 */       lRet = Integer.parseInt(element.getAttribute(attributeName));
/*      */     }
/*      */     
/*  943 */     return lRet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSystem() {
/*  951 */     return this.system;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSystem(int system) {
/*  958 */     this.system = system;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getStringAttribute(Element element, String attributeName) {
/*  970 */     String lRet = "";
/*      */     
/*  972 */     if (element.hasAttribute(attributeName)) {
/*  973 */       lRet = element.getAttribute(attributeName);
/*      */     }
/*      */     
/*  976 */     return lRet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFontName() {
/*  987 */     return this.fontName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFontName(String pFontName) {
/*  997 */     this.fontName = pFontName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFormat(int pMachine) {
/* 1007 */     this.binaryFormat = pMachine;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setDropCopybookFromFieldNames(boolean dropCopybookFromFieldNames) {
/* 1015 */     this.dropCopybookFromFieldNames = dropCopybookFromFieldNames;
/*      */     
/* 1017 */     if (this.fieldHelper != null) {
/* 1018 */       this.fieldHelper.setDropCopybookFromFieldNames(dropCopybookFromFieldNames);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeepFillers(boolean keepFiller) {
/* 1028 */     this.keepFiller = keepFiller;
/*      */   }
/*      */ }

