/*      */ package com.MainFrame.Reader.External.base;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import com.MainFrame.Reader.External.Def.AbstractUpdatableRecord;
/*      */ import com.MainFrame.Reader.External.Def.DependingOn;
/*      */ import com.MainFrame.Reader.External.Def.DependingOnDefinition;
/*      */ import com.MainFrame.Reader.External.Def.DependingOnDtls;
/*      */ import com.MainFrame.Reader.External.Def.ExternalField;
/*      */ import com.MainFrame.Reader.External.Def.IFieldUpdatedListner;
/*      */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalFieldSelection;
/*      */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalGroupSelection;
/*      */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
/*      */ import com.MainFrame.Reader.ExternalRecordSelection.StreamLine;
/*      */ import com.MainFrame.Reader.Option.IRecordPositionOption;
/*      */ import com.MainFrame.Reader.Types.TypeManager;
/*      */ import com.MainFrame.Convert2xml.def.ICopybook;
/*      */ import com.MainFrame.Convert2xml.def.IItemJr;
/*      */ import com.MainFrame.Convert2xml.def.IItemJrUpd;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BaseExternalRecord<xRecord extends BaseExternalRecord<xRecord>>
/*      */   extends AbstractUpdatableRecord
/*      */   implements IFieldUpdatedListner, IAddDependingOn
/*      */ {
/*      */   protected static final int POSITION_IDX = 0;
/*      */   protected static final int LENGTH_IDX = 1;
/*      */   private int recordId;
/*      */   private int initRecordId;
/*      */   private String recordName;
/*      */   private String description;
/*      */   private int recordType;
/*      */   private int system;
/*  109 */   private String systemName = null;
/*      */   private String listChar;
/*      */   private String copyBook;
/*      */   private String delimiter;
/*      */   private String quote;
/*      */   private int posRecInd;
/*      */   private String recSepList;
/*      */   private byte[] recordSep;
/*      */   private String fontName;
/*      */   private int recordStyle;
/*      */   private int fileStructure;
/*  120 */   private int lineNumberOfFieldNames = 1;
/*  121 */   private int recordLength = -1;
/*  122 */   private int dialectCode = 1;
/*      */   
/*      */   private String[] parentGroupNames;
/*      */   private ExternalSelection recSelect;
/*  126 */   private IRecordPositionOption recordPosistionOption = null;
/*      */   
/*      */   private boolean defaultRecord = false;
/*      */   
/*      */   private boolean embeddedCr = false;
/*      */   
/*      */   private boolean initToSpaces = false;
/*      */   
/*      */   protected boolean optimizeTypes = true;
/*      */   
/*      */   private List<? extends IItemJrUpd> items;
/*      */   
/*      */   private ICopybook copybook;
/*  139 */   private int parentRecord = -1;
/*      */   
/*  141 */   private String parentName = null;
/*      */   
/*      */   private String copybookPref;
/*      */   
/*  145 */   protected ArrayList<xRecord> subRecords = new ArrayList<xRecord>();
/*  146 */   protected ArrayList<ExternalField> fields = new ArrayList<ExternalField>(250);
/*  147 */   protected ArrayList<DependingOn> dependingOn = new ArrayList<DependingOn>(3);
/*      */ 
/*      */   
/*      */   private DependingOnDefinition dependingOnDef;
/*      */   
/*  152 */   private ArrayList<Cb2xmlDocument> cb2xmlDocuments = new ArrayList<Cb2xmlDocument>();
/*      */   
/*      */   private boolean keepFillers = false;
/*      */   
/*      */   private boolean dropCopybookFromFieldNames;
/*      */   private boolean saveCb2xml = false;
/*      */   private boolean useJRecordNaming;
/*  159 */   private final xRecord self = (xRecord)this;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BaseExternalRecord() {
/*  168 */     super(true);
/*      */     
/*  170 */     this.recordId = 0;
/*  171 */     this.recordName = "";
/*  172 */     this.description = "";
/*  173 */     this.recordType = 0;
/*  174 */     this.system = 0;
/*  175 */     this.listChar = "";
/*  176 */     this.copyBook = "";
/*  177 */     this.delimiter = "";
/*  178 */     this.quote = "";
/*  179 */     this.posRecInd = 0;
/*  180 */     this.recSepList = "";
/*  181 */     this.recordSep = NULL_BYTES;
/*  182 */     this.fontName = "";
/*  183 */     this.recordStyle = 0;
/*  184 */     this.fileStructure = 0;
/*      */     
/*  186 */     setKeys();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BaseExternalRecord(int pRecordId, String pRecordName, String pDescription, int pRecordType, int pSystem, String pListChar, String pCopyBook, String pDelimiter, String pQuote, int pPosRecInd, String pRecSepList, byte[] pRecordSep, String pFontName, int precordStyle, int pfileStructure, boolean pEmbeddedCr) {
/*  208 */     super(false);
/*      */     
/*  210 */     this.recordId = pRecordId;
/*  211 */     this.recordName = pRecordName;
/*  212 */     this.description = pDescription;
/*  213 */     this.recordType = pRecordType;
/*  214 */     this.system = pSystem;
/*  215 */     this.listChar = pListChar;
/*  216 */     this.copyBook = pCopyBook;
/*  217 */     this.delimiter = pDelimiter;
/*  218 */     this.quote = pQuote;
/*  219 */     this.posRecInd = pPosRecInd;
/*  220 */     this.recSepList = pRecSepList;
/*  221 */     this.recordSep = pRecordSep;
/*  222 */     this.fontName = pFontName;
/*  223 */     this.recordStyle = precordStyle;
/*  224 */     this.fileStructure = pfileStructure;
/*  225 */     this.embeddedCr = pEmbeddedCr;
/*      */     
/*  227 */     setKeys();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeys() {
/*  236 */     this.initRecordId = this.recordId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRecordId() {
/*  290 */     return this.recordId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRecordId(int val) {
/*  300 */     if (val != this.recordId || this.updateStatus == -1) {
/*  301 */       this.recordId = val;
/*  302 */       this.updateStatus = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRecordName() {
/*  311 */     return this.recordName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRecordName(String val) {
/*  321 */     if ((val == null || "".equals(val)) && (this.recordName == null || ""
/*  322 */       .equals(this.recordName))) {
/*      */       return;
/*      */     }
/*      */     
/*  326 */     if (val == null || !val.equals(this.recordName) || this.updateStatus == -1) {
/*  327 */       this.recordName = val;
/*  328 */       this.updateStatus = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDescription() {
/*  351 */     return this.description;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDescription(String val) {
/*  361 */     if ((val == null || "".equals(val)) && (this.description == null || ""
/*  362 */       .equals(this.description))) {
/*      */       return;
/*      */     }
/*      */     
/*  366 */     if (val == null || !val.equals(this.description) || this.updateStatus == -1) {
/*  367 */       this.description = val;
/*  368 */       this.updateStatus = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRecordType() {
/*  377 */     return this.recordType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public xRecord setRecordType(int val) {
/*  387 */     if (val != this.recordType || this.updateStatus == -1) {
/*  388 */       this.recordType = val;
/*  389 */       this.updateStatus = 3;
/*      */     } 
/*  391 */     return this.self;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSystem() {
/*  401 */     return this.system;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSystem(int val) {
/*  413 */     if (val != this.system || this.updateStatus == -1) {
/*  414 */       this.system = val;
/*  415 */       this.updateStatus = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getListChar() {
/*  424 */     return this.listChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListChar(String val) {
/*  434 */     if ((val == null || "".equals(val)) && (this.listChar == null || ""
/*  435 */       .equals(this.listChar))) {
/*      */       return;
/*      */     }
/*      */     
/*  439 */     if (val == null || !val.equals(this.listChar) || this.updateStatus == -1) {
/*  440 */       this.listChar = val;
/*  441 */       this.updateStatus = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCopyBook() {
/*  450 */     return this.copyBook;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCopyBook(String val) {
/*  462 */     if ((val == null || "".equals(val)) && (this.copyBook == null || ""
/*  463 */       .equals(this.copyBook))) {
/*      */       return;
/*      */     }
/*      */     
/*  467 */     if (val == null || !val.equals(this.copyBook) || this.updateStatus == -1) {
/*  468 */       this.copyBook = val;
/*  469 */       this.updateStatus = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDelimiter() {
/*  478 */     return this.delimiter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDelimiter(String val) {
/*  488 */     if ((val == null || "".equals(val)) && (this.delimiter == null || ""
/*  489 */       .equals(this.delimiter))) {
/*      */       return;
/*      */     }
/*      */     
/*  493 */     if (val == null || !val.equals(this.delimiter) || this.updateStatus == -1) {
/*  494 */       this.delimiter = val;
/*  495 */       this.updateStatus = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public xRecord setCobolConversionOptions(boolean keepFillers, boolean dropCopybookFromFieldNames, boolean saveCb2xml, boolean useJRecordNaming) {
/*  506 */     this.keepFillers = keepFillers;
/*  507 */     this.dropCopybookFromFieldNames = dropCopybookFromFieldNames;
/*  508 */     this.saveCb2xml = saveCb2xml;
/*  509 */     this.useJRecordNaming = useJRecordNaming;
/*      */     
/*  511 */     return this.self;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public xRecord setCobolConversionOptions(boolean keepFillers, boolean dropCopybookFromFieldNames, boolean useJRecordNaming) {
/*  519 */     this.keepFillers = keepFillers;
/*  520 */     this.dropCopybookFromFieldNames = dropCopybookFromFieldNames;
/*  521 */     this.useJRecordNaming = useJRecordNaming;
/*      */     
/*  523 */     return this.self;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getQuote() {
/*  532 */     if (this.quote == null) {
/*  533 */       return "";
/*      */     }
/*  535 */     return this.quote;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setQuote(String val) {
/*  545 */     if ((val == null || "".equals(val)) && (this.quote == null || ""
/*  546 */       .equals(this.quote))) {
/*      */       return;
/*      */     }
/*      */     
/*  550 */     if (val == null || !val.equals(this.quote) || this.updateStatus == -1) {
/*  551 */       this.quote = val;
/*  552 */       this.updateStatus = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPosRecInd() {
/*  561 */     return this.posRecInd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPosRecInd(int val) {
/*  571 */     if (val != this.posRecInd || this.updateStatus == -1) {
/*  572 */       this.posRecInd = val;
/*  573 */       this.updateStatus = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRecSepList() {
/*  582 */     return this.recSepList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRecSepList(String val) {
/*  592 */     if ((val == null || "".equals(val)) && (this.recSepList == null || ""
/*  593 */       .equals(this.recSepList))) {
/*      */       return;
/*      */     }
/*      */     
/*  597 */     if (val == null || !val.equals(this.recSepList) || this.updateStatus == -1) {
/*  598 */       this.recSepList = val;
/*  599 */       this.updateStatus = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getRecordSep() {
/*  608 */     return this.recordSep;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRecordSep(byte[] val) {
/*  618 */     if (val == null && this.recordSep == null) {
/*      */       return;
/*      */     }
/*  621 */     if (!isEqual(val, this.recordSep) || this.updateStatus == -1) {
/*  622 */       this.recordSep = val;
/*  623 */       this.updateStatus = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFontName() {
/*  632 */     return this.fontName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public xRecord setFontName(String val) {
/*  642 */     if ((val == null || "".equals(val)) && (this.fontName == null || ""
/*  643 */       .equals(this.fontName))) {
/*  644 */       return this.self;
/*      */     }
/*      */     
/*  647 */     if (val == null || !val.equals(this.fontName) || this.updateStatus == -1) {
/*  648 */       this.fontName = val;
/*  649 */       this.updateStatus = 3;
/*      */     } 
/*  651 */     return this.self;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRecordStyle() {
/*  659 */     return this.recordStyle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public xRecord setRecordStyle(int val) {
/*  669 */     if (val != this.recordStyle || this.updateStatus == -1) {
/*  670 */       this.recordStyle = val;
/*  671 */       this.updateStatus = 3;
/*      */     } 
/*  673 */     if (this.subRecords != null && this.subRecords.size() > 0) {
/*  674 */       for (BaseExternalRecord baseExternalRecord : this.subRecords) {
/*  675 */         baseExternalRecord.setRecordStyle(val);
/*      */       }
/*      */     }
/*  678 */     return this.self;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFileStructure() {
/*  687 */     return this.fileStructure;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public xRecord setFileStructure(int val) {
/*  697 */     if (val != this.fileStructure || this.updateStatus == -1) {
/*  698 */       this.fileStructure = val;
/*      */       
/*  700 */       this.updateStatus = 3;
/*      */     } 
/*      */     
/*  703 */     return this.self;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean addRecord(xRecord o) {
/*  718 */     return this.subRecords.add(o);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<? extends IItemJr> getItems() {
/*  727 */     return (List)this.items;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setItems(String copybookPref, String[] groupArray, int dialectCode, List<? extends IItemJrUpd> items) {
/*  735 */     this.copybookPref = copybookPref;
/*  736 */     this.parentGroupNames = groupArray;
/*  737 */     this.dialectCode = dialectCode;
/*  738 */     this.items = items;
/*  739 */     this.fields.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ICopybook getCopybook() {
/*  746 */     return this.copybook;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCopybook(ICopybook copybook) {
/*  754 */     this.copybook = copybook;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setItems(String copybookPref, String[] parentGroupNames, int dialectCode, IItemJrUpd item) {
/*  759 */     ArrayList<IItemJrUpd> itms = new ArrayList<IItemJrUpd>(1);
/*      */     
/*  761 */     this.copybookPref = copybookPref;
/*  762 */     this.dialectCode = dialectCode;
/*  763 */     this.parentGroupNames = parentGroupNames;
/*  764 */     itms.add(item);
/*  765 */     this.items = itms;
/*  766 */     this.fields.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isKeepFillers() {
/*  774 */     return this.keepFillers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUseJRecordNaming() {
/*  782 */     return this.useJRecordNaming;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDropCopybookFromFieldNames() {
/*  789 */     return this.dropCopybookFromFieldNames;
/*      */   }
/*      */   
/*      */   public void updateTypeOnCobolItems() {
/*  793 */     FieldCreatorHelper fldhelper = createFieldHelper();
/*      */     
/*  795 */     updateType(fldhelper, this.items);
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateType(FieldCreatorHelper fldhelper, List<? extends IItemJrUpd> items) {
/*  800 */     if (items != null) {
/*  801 */       for (IItemJrUpd itm : items) {
/*  802 */         updateItemForType(fldhelper, itm);
/*  803 */         updateType(fldhelper, itm.getChildItems());
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateItemForType(FieldCreatorHelper fldhelper, IItemJrUpd item) {
/*  809 */     int typeId = 0;
/*  810 */     List<? extends IItemJrUpd> childItems = item.getChildItems();
/*  811 */     if (childItems == null || childItems.size() == 0) {
/*  812 */       typeId = fldhelper.deriveType(
/*  813 */           (item.getNumericClass()).numeric, item.getUsage().getName(), item.getPicture(), 
/*  814 */           (item.getSignClause()).signSeparate, (item.getSignClause()).signPosition.getName(), 
/*  815 */           (item.getJustified()).isJustified);
/*      */     }
/*  817 */     item.setType(typeId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDialectCode() {
/*  824 */     return this.dialectCode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getParentGroupNames() {
/*  832 */     return this.parentGroupNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCopybookPref() {
/*  840 */     return this.copybookPref;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInitRecordId() {
/*  879 */     return this.initRecordId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public xRecord getRecord(int index) {
/*  889 */     return this.subRecords.get(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public xRecord getRecord(String recordName) {
/*  932 */     if (recordName == null || "".equals(recordName)) {
/*  933 */       throw new RuntimeException("Invalid Record Name: " + recordName);
/*      */     }
/*      */     
/*  936 */     for (int i = this.subRecords.size() - 1; i >= 0; i--) {
/*  937 */       BaseExternalRecord baseExternalRecord = (BaseExternalRecord)this.subRecords.get(i);
/*  938 */       if (recordName.equalsIgnoreCase(baseExternalRecord.getRecordName())) {
/*  939 */         return (xRecord)baseExternalRecord;
/*      */       }
/*      */     } 
/*      */     
/*  943 */     StringBuilder b = new StringBuilder("Record Names: ");
/*  944 */     for (int j = this.subRecords.size() - 1; j >= 0; j--) {
/*  945 */       b.append(((BaseExternalRecord)this.subRecords.get(j)).getRecordName()).append("; ");
/*      */     }
/*      */     
/*  948 */     throw new RuntimeException("No Record named \"" + recordName + "\" exists: " + b.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfRecords() {
/*  957 */     return this.subRecords.size();
/*      */   }
/*      */   
/*      */   public void fieldUpdated(ExternalField field) {
/*  961 */     this.items = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean addRecordField(ExternalField o) {
/*  971 */     loadFields();
/*  972 */     fieldUpdated(o);
/*  973 */     o.setListner(this);
/*  974 */     return this.fields.add(o);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDependingOn(DependingOn child) {
/*  982 */     this.dependingOn.add(child);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addRecordFields(List<? extends ExternalField> flds) {
/*  991 */     if (flds != null && flds.size() > 0) {
/*  992 */       loadFields();
/*  993 */       fieldUpdated((ExternalField)null);
/*  994 */       this.fields.addAll(flds);
/*      */       
/*  996 */       for (ExternalField f : flds) {
/*  997 */         f.setListner(this);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeRecordField(int index) {
/* 1007 */     loadFields();
/* 1008 */     fieldUpdated((ExternalField)null);
/* 1009 */     this.fields.remove(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExternalField getRecordField(int index) {
/* 1018 */     loadFields();
/* 1019 */     return this.fields.get(index);
/*      */   }
/*      */   
/*      */   public ExternalField getRecordField(String name) {
/* 1023 */     if (name != null) {
/* 1024 */       loadFields();
/* 1025 */       for (ExternalField f : this.fields) {
/* 1026 */         if (name.equalsIgnoreCase(f.getName())) {
/* 1027 */           return f;
/*      */         }
/*      */       } 
/*      */       
/* 1031 */       for (BaseExternalRecord baseExternalRecord : this.subRecords) {
/* 1032 */         ExternalField f = baseExternalRecord.getRecordField(name);
/* 1033 */         if (f != null) return f; 
/*      */       } 
/*      */     } 
/* 1036 */     return null;
/*      */   }
/*      */   
/*      */   public int getfieldPosition(String name) {
/* 1040 */     if (this.items != null && this.fields.size() == 0 && name != null && name.indexOf('(') < 0) {
/* 1041 */       int pos = searchFieldPos(this.items, name);
/* 1042 */       if (pos > 0) {
/* 1043 */         return pos;
/*      */       }
/*      */     } 
/*      */     
/* 1047 */     ExternalField f = getRecordField(name);
/* 1048 */     if (f == null) {
/* 1049 */       return -1;
/*      */     }
/* 1051 */     return f.getPos();
/*      */   }
/*      */ 
/*      */   
/*      */   private int searchFieldPos(List<? extends IItemJrUpd> items, String name) {
/* 1056 */     for (IItemJrUpd itm : items) {
/* 1057 */       if (itm.getChildItems().size() > 0) {
/* 1058 */         int pos; if ((pos = searchFieldPos(itm.getChildItems(), name)) > 0)
/* 1059 */           return pos;  continue;
/*      */       } 
/* 1061 */       if (name.equalsIgnoreCase(itm.getFieldName())) {
/* 1062 */         return itm.getPosition();
/*      */       }
/*      */     } 
/* 1065 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfRecordFields() {
/* 1175 */     loadFields();
/* 1176 */     return this.fields.size();
/*      */   }
/*      */   
/*      */   public void clearRecordFields() {
/* 1180 */     this.fields.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExternalField[] getRecordFields() {
/* 1188 */     loadFields();
/* 1189 */     return this.fields.<ExternalField>toArray(new ExternalField[this.fields.size()]);
/*      */   }
/*      */   
/*      */   protected final void loadFields() {
/* 1193 */     if (this.items != null && this.fields.size() == 0) {
/* 1194 */       FieldCreatorHelper fldHelper = createFieldHelper();
/*      */       
/* 1196 */       loadItems(fldHelper, (List)this.items, "", (DependingOnDtls)null, fldHelper
/*      */ 
/*      */ 
/*      */           
/* 1200 */           .getInitialLevel(), 0);
/*      */       
/* 1202 */       if (fldHelper.lastFiller != null && fldHelper.lastFiller
/* 1203 */         .getPos() + fldHelper.lastFiller.getLen() > fldHelper.lastEndPos) {
/* 1204 */         this.fields.add(fldHelper.lastFiller);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected FieldCreatorHelper createFieldHelper() {
/* 1214 */     FieldCreatorHelper fldHelper = new FieldCreatorHelper(0, this.dialectCode, this.useJRecordNaming, this.copybookPref, this.fontName);
/*      */     
/* 1216 */     fldHelper.setDropCopybookFromFieldNames(this.dropCopybookFromFieldNames);
/* 1217 */     fldHelper.setParentGroup(this.parentGroupNames);
/* 1218 */     return fldHelper;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadItems(FieldCreatorHelper fldHelper, List<? extends IItemJr> itms, String nameSuffix, DependingOnDtls dependOnParentDtls, int level, int basePos) {
/* 1228 */     for (IItemJr itm : itms) {
/* 1229 */       if (itm.getLevelNumber() == 88) {
/*      */         continue;
/*      */       }
/* 1232 */       List<? extends IItemJr> childItems = itm.getChildItems();
/* 1233 */       int size = childItems.size();
/* 1234 */       String dependingVar = itm.getDependingOn();
/* 1235 */       fldHelper.updateGroup(level, itm.getFieldName());
/*      */       
/* 1237 */       if (itm.getOccurs() > 0) {
/* 1238 */         DependingOn dependOn = null;
/*      */         
/* 1240 */         if (dependingVar != null && dependingVar.length() > 0)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1246 */           dependOn = fldHelper.dependingOnBuilder().setPosition(itm.getPosition() + basePos).setLength(itm.getStorageLength()).setChildOccurs(itm.getOccurs()).newDependingOn(this, dependOnParentDtls, dependingVar);
/*      */         }
/* 1248 */         if (size == 0) {
/* 1249 */           for (int j = 0; j < itm.getOccurs(); j++)
/* 1250 */             createField(fldHelper, level, itm, fldHelper
/*      */                 
/* 1252 */                 .updateFieldNameIndex(nameSuffix, j), 
/* 1253 */                 createDependingOnDtls(dependOn, dependOnParentDtls, j), basePos + j * itm
/* 1254 */                 .getStorageLength()); 
/*      */           continue;
/*      */         } 
/* 1257 */         for (int i = 0; i < itm.getOccurs(); i++)
/* 1258 */           loadItems(fldHelper, childItems, fldHelper
/*      */               
/* 1260 */               .updateFieldNameIndex(nameSuffix, i), 
/* 1261 */               createDependingOnDtls(dependOn, dependOnParentDtls, i), level + 1, basePos + i * itm
/*      */               
/* 1263 */               .getStorageLength()); 
/*      */         continue;
/*      */       } 
/* 1266 */       if (itm.getOccurs() == 0)
/* 1267 */         continue;  if (size == 0) {
/* 1268 */         createField(fldHelper, level, itm, nameSuffix, dependOnParentDtls, basePos); continue;
/*      */       } 
/* 1270 */       loadItems(fldHelper, childItems, nameSuffix, dependOnParentDtls, level + 1, basePos);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private DependingOnDtls createDependingOnDtls(DependingOn dependOn, DependingOnDtls dependOnParentDtls, int idx) {
/* 1277 */     DependingOnDtls dependOnDtls = dependOnParentDtls;
/* 1278 */     if (dependOn != null) {
/* 1279 */       dependOnDtls = new DependingOnDtls(dependOn, idx, dependOnParentDtls);
/*      */     }
/* 1281 */     return dependOnDtls;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void createField(FieldCreatorHelper fieldHelper, int level, IItemJr itm, String nameSuffix, DependingOnDtls dependOnParentDtls, int basePos) {
/* 1289 */     String fieldName = itm.getFieldName();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1296 */     ExternalField fld = new ExternalField(itm.getPosition() + basePos, itm.getStorageLength(), fieldHelper.createFieldName(fieldName, nameSuffix), "", itm.getType(), fieldHelper.calculateDecimalSize(itm.getType(), itm.getPicture(), itm.getScale()), 0, "", "", itm.getFieldName(), 0, dependOnParentDtls);
/*      */ 
/*      */     
/* 1299 */     if (level > 1 && fieldHelper.getGroupNameSize() > level) {
/* 1300 */       fld.setGroup(fieldHelper.getGroupName(level - 1));
/*      */     }
/*      */     
/* 1303 */     int fldEnd = fld.getPos() + fld.getLen();
/* 1304 */     if (this.keepFillers || (fieldName != null && fieldName.length() > 0 && !"filler".equalsIgnoreCase(fieldName))) {
/* 1305 */       this.fields.add(fld);
/* 1306 */       fieldHelper.lastEndPos = Math.max(fldEnd, fieldHelper.lastEndPos);
/* 1307 */     } else if (fieldHelper.lastFiller == null || fieldHelper.lastFiller.getPos() + fieldHelper.lastFiller.getLen() < fldEnd) {
/* 1308 */       fieldHelper.lastFiller = fld;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSystemName() {
/* 1319 */     return this.systemName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSystemName(String newSystemName) {
/* 1329 */     this.systemName = newSystemName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String getTstField() {
/* 1342 */     ExternalFieldSelection f = getFirstSelection(this.recSelect);
/* 1343 */     if (f == null) {
/* 1344 */       return null;
/*      */     }
/* 1346 */     return f.getFieldName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setTstField(String tstField, String value) {
/* 1361 */     this.recSelect = (ExternalSelection)new ExternalFieldSelection(tstField, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addTstField(String tstField, String value) {
/* 1372 */     addTstField(tstField, "=", value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addTstField(String tstField, String op, String value) {
/* 1378 */     if (this.recSelect == null) {
/* 1379 */       this.recSelect = (ExternalSelection)new ExternalGroupSelection(1);
/*      */     }
/* 1381 */     if (this.recSelect instanceof ExternalGroupSelection) {
/* 1382 */       ExternalGroupSelection g = (ExternalGroupSelection)this.recSelect;
/* 1383 */       g.add((ExternalSelection)new ExternalFieldSelection(tstField, value, op));
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1389 */     throw new RuntimeException("Can not add Test Field");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTstFieldValue() {
/* 1399 */     ExternalFieldSelection f = getFirstSelection(this.recSelect);
/* 1400 */     if (f == null) {
/* 1401 */       return null;
/*      */     }
/* 1403 */     return f.getFieldValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTstFieldCount() {
/* 1409 */     int ret = 0;
/* 1410 */     if (this.recSelect != null) {
/* 1411 */       ret = this.recSelect.getElementCount();
/*      */     }
/*      */     
/* 1414 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private ExternalFieldSelection getFirstSelection(ExternalSelection s) {
/* 1420 */     if (s == null)
/* 1421 */       return null; 
/* 1422 */     if (s instanceof ExternalFieldSelection) {
/* 1423 */       return (ExternalFieldSelection)s;
/*      */     }
/* 1425 */     ExternalGroupSelection g = (ExternalGroupSelection)s;
/* 1426 */     ExternalFieldSelection fs = null;
/*      */     
/* 1428 */     for (int i = 0; i < g.size() && fs == null; i++) {
/* 1429 */       fs = getFirstSelection(g.get(i));
/*      */     }
/*      */     
/* 1432 */     return fs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getParentRecord() {
/* 1454 */     return this.parentRecord;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParentRecord(int parentRecord) {
/* 1463 */     this.parentRecord = parentRecord;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNew(boolean isNew) {
/* 1472 */     super.setNew(isNew);
/*      */     
/* 1474 */     if (isNew) {
/* 1475 */       setChildrenNew(true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setChildrenNew(boolean isNew) {
/* 1484 */     for (int i = 0; i < this.subRecords.size(); i++) {
/* 1485 */       ((BaseExternalRecord)this.subRecords.get(i)).setNew(isNew);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void dropFiller() {
/* 1496 */     int maxPos = 0;
/* 1497 */     int count = 1;
/*      */ 
/*      */ 
/*      */     
/* 1501 */     loadFields();
/*      */     
/* 1503 */     if (this.fields != null) {
/* 1504 */       loadFields(); int i;
/* 1505 */       for (i = 0; i < this.fields.size(); i++) {
/* 1506 */         if (!isFiller(((ExternalField)this.fields.get(i)).getName())) {
/* 1507 */           count++;
/*      */         }
/*      */         
/* 1510 */         maxPos = Math.max(maxPos, ((ExternalField)this.fields.get(i)).getPos() + ((ExternalField)this.fields.get(i)).getLen());
/*      */       } 
/*      */       
/* 1513 */       ArrayList<ExternalField> tmpFields = new ArrayList<ExternalField>(count + 1);
/*      */       
/* 1515 */       for (i = 0; i < this.fields.size(); i++) {
/* 1516 */         ExternalField fld = this.fields.get(i);
/* 1517 */         int endPos = fld.getPos() + fld.getLen();
/*      */         
/* 1519 */         if (endPos == maxPos || !isFiller(fld.getName())) {
/* 1520 */           tmpFields.add(fld);
/*      */         }
/*      */       } 
/* 1523 */       this.fields = tmpFields;
/*      */     } 
/*      */     
/* 1526 */     if (this.subRecords != null) {
/* 1527 */       for (int i = 0; i < this.subRecords.size(); i++) {
/* 1528 */         ((BaseExternalRecord)this.subRecords.get(i)).dropFiller();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isFiller(String s) {
/* 1534 */     return (s == null || "".equals(s.trim()) || "filler"
/* 1535 */       .equalsIgnoreCase(s) || s
/* 1536 */       .toLowerCase().startsWith("filler ("));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParentsFromName() {
/* 1546 */     if (this.subRecords != null) {
/* 1547 */       for (int i = 0; i < this.subRecords.size(); i++) {
/* 1548 */         String parent = ((BaseExternalRecord)this.subRecords.get(i)).parentName;
/* 1549 */         if (parent != null && !"".equalsIgnoreCase(parent)) {
/* 1550 */           for (int j = 0; j < this.subRecords.size(); j++) {
/*      */ 
/*      */ 
/*      */             
/* 1554 */             if (parent.equalsIgnoreCase(((BaseExternalRecord)this.subRecords.get(j)).getRecordName())) {
/* 1555 */               ((BaseExternalRecord)this.subRecords.get(i)).setParentRecord(j);
/* 1556 */               ((BaseExternalRecord)this.subRecords.get(i)).setParentName((String)null);
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final xRecord asExternalRecord() {
/* 1571 */     return this.self;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setParentName(String tmpParentName) {
/* 1587 */     this.parentName = tmpParentName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DependingOnDefinition getDependingOnDefinition() {
/* 1595 */     if (this.dependingOnDef == null) {
/* 1596 */       this.dependingOnDef = new DependingOnDefinition(this.dependingOn);
/*      */     }
/* 1598 */     return this.dependingOnDef;
/*      */   }
/*      */   
/*      */   public final void newDependingOn() {
/* 1602 */     this.dependingOn = new ArrayList<DependingOn>();
/* 1603 */     this.dependingOnDef = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLineNumberOfFieldNames() {
/* 1611 */     return this.lineNumberOfFieldNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLineNumberOfFieldNames(int lineNumberOfFieldNames) {
/* 1618 */     this.lineNumberOfFieldNames = lineNumberOfFieldNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getRecordLength() {
/* 1625 */     return this.recordLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setRecordLength(int recordLength) {
/* 1632 */     this.recordLength = recordLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOptimizeTypes(boolean optimizeTypes) {
/* 1639 */     this.optimizeTypes = optimizeTypes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDefaultRecord() {
/* 1647 */     return this.defaultRecord;
/*      */   }
/*      */   
/*      */   public boolean isBinary() {
/* 1651 */     return checkBinary(this);
/*      */   }
/*      */   
/*      */   private boolean checkBinary(BaseExternalRecord<xRecord> rec) {
/* 1655 */     if (rec.fields.size() == 0 && rec.items != null && rec.items.size() > 0 && 
/* 1656 */       checkBinary(rec.items)) {
/* 1657 */       return true;
/*      */     }
/*      */ 
/*      */     
/* 1661 */     for (ExternalField f : rec.fields) {
/* 1662 */       if (TypeManager.isBinary(f.getType())) {
/* 1663 */         return true;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1668 */     for (BaseExternalRecord<xRecord> baseExternalRecord : rec.subRecords) {
/* 1669 */       if (checkBinary(baseExternalRecord)) {
/* 1670 */         return true;
/*      */       }
/*      */     } 
/* 1673 */     return false;
/*      */   }
/*      */   
/*      */   private boolean checkBinary(List<? extends IItemJrUpd> itms) {
/* 1677 */     for (IItemJrUpd item : itms) {
/* 1678 */       if (item.getChildItems().size() == 0) {
/* 1679 */         if (TypeManager.isBinary(item.getType()))
/* 1680 */           return true;  continue;
/*      */       } 
/* 1682 */       if (checkBinary(item.getChildItems())) {
/* 1683 */         return true;
/*      */       }
/*      */     } 
/*      */     
/* 1687 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultRecord(boolean defaultRecord) {
/* 1694 */     this.defaultRecord = defaultRecord;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExternalSelection getRecordSelection() {
/* 1701 */     return this.recSelect;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRecordSelection(ExternalSelection recSelect) {
/* 1708 */     this.recSelect = StreamLine.getExternalStreamLine().streamLine(recSelect);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmbeddedCr() {
/* 1715 */     return this.embeddedCr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEmbeddedCr(boolean embeddedCr) {
/* 1722 */     this.embeddedCr = embeddedCr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final IRecordPositionOption getRecordPositionOption() {
/* 1730 */     return this.recordPosistionOption;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setRecordPositionOption(IRecordPositionOption recordOption) {
/* 1737 */     this.recordPosistionOption = recordOption;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isInitToSpaces() {
/* 1744 */     return this.initToSpaces;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setInitToSpaces(boolean initToSpaces) {
/* 1751 */     this.initToSpaces = initToSpaces;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<Cb2xmlDocument> getCb2xmlDocuments() {
/* 1758 */     return this.cb2xmlDocuments;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addCb2xmlDocument(Cb2xmlDocument e) {
/* 1766 */     this.cb2xmlDocuments.add(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean addAllCb2xmlDocuments(Collection<Cb2xmlDocument> c) {
/* 1775 */     return this.cb2xmlDocuments.addAll(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int[][] getPosLength() {
/* 1783 */     loadFields();
/* 1784 */     int[][] ret = new int[2][];
/* 1785 */     ret[0] = new int[this.fields.size()];
/* 1786 */     ret[1] = new int[this.fields.size()];
/*      */     
/* 1788 */     if (this.recordType == 2 || this.recordType == 3) {
/* 1789 */       int lastPos = 0;
/*      */       
/* 1791 */       for (int i = 0; i < this.fields.size(); i++) {
/* 1792 */         int pos = ((ExternalField)this.fields.get(i)).getPos();
/* 1793 */         if (pos <= 0) {
/* 1794 */           lastPos++;
/*      */         } else {
/* 1796 */           lastPos = pos;
/*      */         } 
/*      */         
/* 1799 */         ret[1][i] = -121;
/* 1800 */         ret[0][i] = lastPos;
/*      */       } 
/*      */     } else {
/* 1803 */       int lastPos = 0;
/* 1804 */       int lastLen = 1;
/*      */       
/* 1806 */       for (int i = 0; i < this.fields.size(); i++) {
/* 1807 */         ExternalField fld = this.fields.get(i);
/* 1808 */         int pos = fld.getPos();
/* 1809 */         if (pos <= 0) {
/* 1810 */           if (lastLen <= 0) {
/* 1811 */             throw new RuntimeException("Error Field: " + i + " " + fld.getName() + ": Can not calculate position");
/*      */           }
/*      */           
/* 1814 */           lastPos += lastLen;
/*      */         } else {
/* 1816 */           if (lastLen <= 0 && i > 0) {
/* 1817 */             ret[1][i - 1] = pos - lastPos;
/*      */           }
/* 1819 */           lastPos = pos;
/*      */         } 
/*      */         
/* 1822 */         lastLen = fld.getLen();
/* 1823 */         ret[1][i] = lastLen;
/* 1824 */         ret[0][i] = lastPos;
/*      */       } 
/* 1826 */       if (lastLen < 0) {
/* 1827 */         ret[1][(ret[1]).length - 1] = 1;
/*      */       }
/*      */     } 
/*      */     
/* 1831 */     return ret;
/*      */   }
/*      */
public int compare(ExternalField o1, ExternalField o2) {
	// TODO Auto-generated method stub
	return 0;
} }

