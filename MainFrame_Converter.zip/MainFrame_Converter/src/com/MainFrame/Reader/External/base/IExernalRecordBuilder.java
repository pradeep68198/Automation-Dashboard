package com.MainFrame.Reader.External.base;

public interface IExernalRecordBuilder<XRecord extends BaseExternalRecord<XRecord>> {
  XRecord getNullRecord(String paramString1, int paramInt, String paramString2);
}

