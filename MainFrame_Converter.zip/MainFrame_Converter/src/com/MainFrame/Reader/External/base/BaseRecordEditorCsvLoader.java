/*     */ package com.MainFrame.Reader.External.base;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import com.MainFrame.Reader.Common.CommonBits;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.CsvParser.BasicCsvLineParser;
/*     */ import com.MainFrame.Reader.CsvParser.CsvDefinition;
/*     */ import com.MainFrame.Reader.CsvParser.ICsvDefinition;
/*     */ import com.MainFrame.Reader.External.Def.ExternalField;
/*     */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalFieldSelection;
/*     */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
/*     */ import com.MainFrame.Reader.Log.AbsSSLogger;
/*     */ import com.MainFrame.Reader.Log.TextLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseRecordEditorCsvLoader<XRecord extends BaseExternalRecord<XRecord>>
/*     */ {
/*     */   private final String delimiter;
/*     */   private final IExernalRecordBuilder<XRecord> recBuilder;
/*     */   
/*     */   public BaseRecordEditorCsvLoader(IExernalRecordBuilder<XRecord> recBuilder, String fieldSeperator) {
/*  90 */     this.delimiter = fieldSeperator;
/*  91 */     this.recBuilder = recBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final XRecord loadCopyBook(String copyBookFile, int splitCopybookOption, int dbIdx, String font, int binFormat, int systemId, AbsSSLogger log) throws Exception {
/*  98 */     return loadCopyBook(copyBookFile, splitCopybookOption, dbIdx, font, CommonBits.getDefaultCobolTextFormat(), binFormat, systemId, log);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XRecord loadCopyBook(String copyBookFile, int splitCopybookOption, int dbIdx, String font, int copybookFormat, int binFormat, int systemId, AbsSSLogger log) throws IOException {
/* 108 */     return loadCopyBook(new FileReader(copyBookFile), copyBookFile, splitCopybookOption, dbIdx, font, copybookFormat, binFormat, systemId, log);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XRecord loadCopyBook(InputStream in, String copyBookFile, int splitCopybookOption, int dbIdx, String font, int copybookFormat, int binFormat, int systemId, AbsSSLogger log) throws IOException {
/* 119 */     return loadCopyBook(new InputStreamReader(in), copyBookFile, splitCopybookOption, dbIdx, font, copybookFormat, binFormat, systemId, log);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XRecord loadCopyBook(Reader r, String copyBookFile, int splitCopybookOption, int dbIdx, String font, int copybookFormat, int binFormat, int systemId, AbsSSLogger log) throws IOException {
/* 127 */     int rt = 1;
/* 128 */     log = TextLog.getLog(log);
/*     */     
/* 130 */     if (binFormat == 1) {
/* 131 */       rt = 0;
/*     */     }
/*     */     
/* 134 */     XRecord rec = this.recBuilder.getNullRecord(
/* 135 */         Conversion.getCopyBookId(copyBookFile), rt, font);
/*     */ 
/*     */     
/* 138 */     rec.setNew(true);
/*     */     
/* 140 */     insertFields(log, rec, r, copyBookFile, dbIdx);
/*     */     
/* 142 */     return rec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void insertFields(AbsSSLogger log, XRecord rec, String copyBookFile, int dbIdx) {
/*     */     try {
/* 153 */       insertFields(log, rec, new FileReader(copyBookFile), copyBookFile, dbIdx);
/* 154 */     } catch (Exception e) {
/* 155 */       System.out.println("Error Opening file " + copyBookFile + ": " + e
/*     */           
/* 157 */           .getMessage());
/* 158 */       e.printStackTrace();
/* 159 */       log.logMsg(30, "Error Loading Copybook: " + e.getMessage());
/* 160 */       log.logException(30, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void insertFields(AbsSSLogger log, XRecord rec, Reader in, String layoutName, int dbIdx) {
/* 168 */     String directory = null;
/* 169 */     BasicCsvLineParser t = BasicCsvLineParser.getInstance();
/* 170 */     String[] fields = new String[8];
/*     */ 
/*     */ 
/*     */     
/* 174 */     int idx = 0;
/* 175 */     int i = 1;
/* 176 */     int inputLine = 1;
/* 177 */     log = TextLog.getLog(log);
/*     */     
/*     */     try {
/* 180 */       BufferedReader r = new BufferedReader(in);
/* 181 */       CsvDefinition csvDef = new CsvDefinition(this.delimiter, null); String s;
/* 182 */       while ((s = r.readLine()) != null) {
/* 183 */         if (!s.trim().startsWith("#")) {
/*     */ 
/*     */           
/* 186 */           for (int j = 0; j < fields.length; j++) {
/* 187 */             fields[j] = t.getField(j, s, (ICsvDefinition)csvDef);
/*     */             
/* 189 */             if (fields[j] == null) {
/* 190 */               fields[j] = "";
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 195 */           idx = 1;
/*     */           
/*     */           try {
/* 198 */             if ("Record".equalsIgnoreCase(fields[0])) {
/* 199 */               rec.setFileStructure(ExternalConversion.getFileStructure(dbIdx, fields[idx++]));
/* 200 */               rec.setRecordType(ExternalConversion.getRecordType(dbIdx, fields[idx++]));
/* 201 */               rec.setDelimiter(fields[idx++]);
/* 202 */               rec.setRecordStyle(ExternalConversion.getRecordStyle(dbIdx, fields[idx++]));
/* 203 */               rec.setQuote(fields[idx++]);
/* 204 */               rec.setListChar(fields[idx++]);
/* 205 */               rec.setDescription(fixDescription(fields[idx++]));
/* 206 */             } else if ("SR".equalsIgnoreCase(fields[0])) {
/* 207 */               XRecord sr = this.recBuilder.getNullRecord(fields[idx++], 1, "");
/*     */               try {
/* 209 */                 ExternalFieldSelection f = new ExternalFieldSelection();
/* 210 */                 f.setFieldName(fields[idx++]);
/* 211 */                 f.setFieldValue(fields[idx++]);
/* 212 */                 sr.setRecordSelection((ExternalSelection)f);
/*     */                 
/* 214 */                 sr.setParentRecord(Integer.parseInt(fields[idx++]));
/* 215 */               } catch (Exception e) {
/* 216 */                 log.logMsg(30, "Error File: " + layoutName + " line " + inputLine + " Field Number: " + idx + " : " + e
/*     */                     
/* 218 */                     .getMessage());
/*     */               } 
/* 220 */               rec.addRecord(sr);
/*     */               
/* 222 */               if (directory == null) {
/* 223 */                 directory = getDirectory(layoutName);
/* 224 */                 System.out.println("Directory: >" + directory + "<");
/*     */               } 
/*     */               
/* 227 */               System.out.println("File >" + directory + fields[1] + ".Txt");
/* 228 */               insertFields(log, sr, directory + fields[1] + ".Txt", dbIdx);
/*     */             } else {
/* 230 */               idx = 0;
/* 231 */               int pos = toInt(fields[idx++], -121);
/*     */               
/* 233 */               int len = toInt(fields[idx++], -121);
/* 234 */               String name = fields[idx++];
/* 235 */               String description = fixDescription(fields[idx++]);
/* 236 */               String typeStr = fields[idx++];
/*     */               
/* 238 */               int decimal = toInt(fields[idx++], 0);
/* 239 */               String formatStr = fields[idx++];
/* 240 */               String param = fields[idx++];
/*     */               
/* 242 */               int type = 0;
/* 243 */               if (typeStr != null && !"".equals(typeStr)) {
/* 244 */                 typeStr = typeStr.toLowerCase();
/* 245 */                 type = ExternalConversion.getType(dbIdx, typeStr);
/*     */               } 
/* 247 */               int format = 0;
/* 248 */               if (formatStr != null && !"".equals(typeStr)) {
/* 249 */                 formatStr = formatStr.toLowerCase();
/* 250 */                 format = ExternalConversion.getFormat(dbIdx, formatStr);
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 256 */               ExternalField field = new ExternalField(pos, len, name, description, type, decimal, format, param, "", "", i);
/*     */               
/* 258 */               rec.addRecordField(field);
/* 259 */               i++;
/*     */             } 
/* 261 */           } catch (Exception e) {
/* 262 */             log.logMsg(30, "Error File: " + layoutName + " Adding line " + inputLine + " Field Number: " + idx + " : " + e
/*     */                 
/* 264 */                 .getMessage());
/* 265 */             e.printStackTrace();
/*     */           } 
/*     */           
/* 268 */           inputLine++;
/*     */         } 
/*     */       } 
/* 271 */     } catch (Exception e) {
/* 272 */       System.out.println("Error Adding line " + inputLine + " from file " + layoutName + ": " + e
/*     */           
/* 274 */           .getMessage());
/* 275 */       e.printStackTrace();
/* 276 */       log.logMsg(30, "Error Loading Copybook: " + e.getMessage());
/* 277 */       log.logException(30, e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private int toInt(String v, int defaultValue) {
/* 282 */     if (v != null && v.length() > 0) {
/*     */       try {
/* 284 */         defaultValue = Integer.parseInt(v);
/* 285 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */ 
/*     */     
/* 289 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getDirectory(String fileName) {
/* 294 */     int e = Math.max(fileName
/* 295 */         .lastIndexOf('/'), fileName
/* 296 */         .lastIndexOf('\\'));
/*     */     
/* 298 */     if (e > 0) {
/* 299 */       e++;
/*     */     }
/* 301 */     return fileName.substring(0, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String fixDescription(String description) {
/* 312 */     if (description == null || description.indexOf('\n') == 0) {
/* 313 */       return description;
/*     */     }
/* 315 */     StringBuilder b = new StringBuilder(description);
/*     */     
/* 317 */     Conversion.replace(b, "\\n", "\n");
/* 318 */     return b.toString();
/*     */   }
/*     */ }

