/*     */ package com.MainFrame.Reader.External.base;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import com.MainFrame.Reader.Common.BasicKeyedField;
/*     */ import com.MainFrame.Reader.Common.Constants;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.External.Def.AbstractConversion;
/*     */ import com.MainFrame.Reader.External.Def.BasicConversion;
/*     */ import com.MainFrame.Reader.Types.TypeManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExternalConversion
/*     */ {
/*     */   public static final int USE_DEFAULT_DB = -1;
/*     */   private static AbstractConversion standardConversion;
/*  51 */   private static String invalidFileChars = null;
/*  52 */   private static String replacementChar = " ";
/*     */ 
/*     */   
/*  55 */   private static String[] names = new String[15];
/*  56 */   private static int[] keys = new int[15];
/*     */   static {
/*  58 */     int i = 0;
/*  59 */     keys[i] = 0; names[i++] = "BinaryRecord";
/*  60 */     keys[i] = 1; names[i++] = "RecordLayout";
/*  61 */     keys[i] = 2; names[i++] = "Delimited";
/*  62 */     keys[i] = 3; names[i++] = "DelimitedAndQuote";
/*  63 */     keys[i] = 6; names[i++] = "XML";
/*  64 */     keys[i] = 9; names[i++] = "GroupOfRecords";
/*  65 */     keys[i] = 10; names[i++] = "GroupOfBinaryRecords";
/*  66 */     keys[i] = 11; names[i++] = "FixedLengthRecords";
/*  67 */     keys[i] = -121; names[i++] = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int getType(int dbIdx, String typeStr) {
/*  87 */     int type = -121;
/*     */     
/*     */     try {
/*  90 */       type = Integer.parseInt(typeStr);
/*  91 */     } catch (Exception exception) {}
/*     */     
/*  93 */     if (type < 0) {
/*  94 */       type = getStandardConversion().getType(dbIdx, typeStr);
/*     */     }
/*     */     
/*  97 */     if (type < 0) {
/*  98 */       type = 0;
/*     */     }
/*     */     
/* 101 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int getRecordType(int dbIdx, String typeStr) {
/* 111 */     int type = -121;
/*     */     
/* 113 */     for (int i = 0; i < keys.length && keys[i] != -121; i++) {
/* 114 */       if (names[i].equalsIgnoreCase(typeStr)) {
/* 115 */         return keys[i];
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 120 */       type = Integer.parseInt(typeStr);
/* 121 */     } catch (Exception exception) {}
/*     */     
/* 123 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int getRecordStyle(int dbIdx, String styleStr) {
/* 135 */     int type = -121;
/*     */     
/*     */     try {
/* 138 */       type = Integer.parseInt(styleStr);
/* 139 */     } catch (Exception exception) {}
/*     */     
/* 141 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int getFileStructure(int dbIdx, String fileStructureStr) {
/* 154 */     int fileStructure = -121;
/*     */     
/* 156 */     fileStructure = BasicConversion.getStructure(fileStructureStr);
/*     */     
/* 158 */     if (fileStructure == -121) {
/*     */       try {
/* 160 */         fileStructure = Integer.parseInt(fileStructureStr);
/* 161 */       } catch (Exception exception) {}
/*     */     }
/*     */     
/* 164 */     return fileStructure;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getTypeAsString(int dbIdx, int type) {
/* 174 */     String typeStr = Integer.toString(type);
/*     */     
/*     */     try {
/* 177 */       typeStr = getStandardConversion().getTypeAsString(dbIdx, type);
/* 178 */     } catch (Exception e) {
/* 179 */       System.out.println(">> " + dbIdx + ": " + type);
/* 180 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 183 */     return typeStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int getFormat(int dbIdx, String formatStr) {
/* 195 */     int format = -121;
/*     */     
/*     */     try {
/* 198 */       format = Integer.parseInt(formatStr);
/* 199 */     } catch (Exception exception) {}
/*     */     
/* 201 */     if (format < 0) {
/* 202 */       format = getStandardConversion().getFormat(dbIdx, formatStr);
/*     */     }
/*     */     
/* 205 */     if (format < 0) {
/* 206 */       format = 0;
/*     */     }
/*     */     
/* 209 */     return format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getFormatAsString(int dbIdx, int format) {
/* 220 */     String formatStr = "";
/*     */ 
/*     */     
/* 223 */     if (format > 0) {
/* 224 */       formatStr = getStandardConversion().getFormatAsString(dbIdx, format);
/*     */     } else {
/* 226 */       formatStr = "";
/*     */     } 
/*     */     
/* 229 */     return formatStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getFileStructureAsString(int dbIdx, int fileStructure) {
/* 241 */     String fileStructureStr = "";
/*     */     
/* 243 */     fileStructureStr = BasicConversion.getStructureName(fileStructure);
/*     */     
/* 245 */     if ("".equals(fileStructureStr) && fileStructure >= 0) {
/*     */       try {
/* 247 */         fileStructureStr = Integer.toString(fileStructure);
/* 248 */       } catch (Exception exception) {}
/*     */     }
/*     */     
/* 251 */     return fileStructureStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getRecordStyleAsString(int dbIdx, int fileStructure) {
/* 262 */     String recordStyleStr = "";
/*     */     
/*     */     try {
/* 265 */       recordStyleStr = Integer.toString(fileStructure);
/* 266 */     } catch (Exception exception) {}
/*     */     
/* 268 */     if (fileStructure < 0) {
/* 269 */       recordStyleStr = "";
/*     */     }
/*     */     
/* 272 */     return recordStyleStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getRecordTypeAsString(int dbIdx, int recordType) {
/* 284 */     String recordTypeStr = "";
/*     */     
/* 286 */     for (int i = 0; i < keys.length && keys[i] != -121; i++) {
/* 287 */       if (keys[i] == recordType) {
/* 288 */         return names[i];
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 293 */       recordTypeStr = Integer.toString(recordType);
/* 294 */     } catch (Exception exception) {}
/*     */     
/* 296 */     if (recordType < 0) {
/* 297 */       recordTypeStr = "";
/*     */     }
/*     */     
/* 300 */     return recordTypeStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void setStandardConversion(AbstractConversion newStandardConversion) {
/* 310 */     standardConversion = newStandardConversion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String copybookNameToFileName(String name) {
/* 321 */     StringBuilder b = new StringBuilder(name);
/* 322 */     if (invalidFileChars != null) {
/* 323 */       for (int i = 0; i < invalidFileChars.length(); i++) {
/* 324 */         Conversion.replace(b, invalidFileChars.substring(i, i + 1), replacementChar);
/*     */       }
/*     */     }
/* 327 */     Conversion.replace(b, "\t", " ");
/* 328 */     Conversion.replace(b, "\n", " ");
/*     */     
/* 330 */     return b.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ArrayList<BasicKeyedField> getTypes(int idx) {
/* 338 */     TypeManager manager = TypeManager.getInstance();
/* 339 */     AbstractConversion conv = getStandardConversion();
/* 340 */     ArrayList<BasicKeyedField> ret = new ArrayList<BasicKeyedField>(manager.getNumberOfTypes());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 345 */     for (int i = 0; i < manager.getNumberOfTypes(); i++) {
/* 346 */       int t = manager.getTypeId(i);
/* 347 */       String s = conv.getTypeAsString(idx, t);
/* 348 */       if (s != null && !"".equals(s)) {
/* 349 */         BasicKeyedField fld = new BasicKeyedField();
/* 350 */         fld.key = t;
/* 351 */         fld.name = s;
/* 352 */         fld.valid = Boolean.valueOf(conv.isValid(idx, t));
/* 353 */         ret.add(fld);
/*     */       } 
/*     */     } 
/*     */     
/* 357 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ArrayList<BasicKeyedField> getRecordTypes() {
/* 365 */     ArrayList<BasicKeyedField> ret = new ArrayList<BasicKeyedField>();
/*     */ 
/*     */     
/* 368 */     for (int i = 0; i < names.length && !"".equals(names[i]); i++) {
/* 369 */       BasicKeyedField fld = new BasicKeyedField();
/* 370 */       fld.key = keys[i];
/* 371 */       fld.name = names[i];
/* 372 */       ret.add(fld);
/*     */     } 
/*     */     
/* 375 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void setInvalidFileChars(String invalidFileCharacters, String replacementCharacter) {
/* 385 */     invalidFileChars = invalidFileCharacters;
/*     */     
/* 387 */     if (replacementChar != null) {
/* 388 */       replacementChar = replacementCharacter;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final String fixDirectory(String directory) {
/* 394 */     String ret = directory;
/*     */     
/* 396 */     if (!"".equals(ret)) {
/* 397 */       if (ret.endsWith("*")) {
/* 398 */         ret = ret.substring(0, ret.length() - 2);
/*     */       }
/* 400 */       if (!ret.endsWith("/") && !ret.endsWith("\\")) {
/* 401 */         ret = ret + Constants.FILE_SEPERATOR;
/*     */       }
/*     */     } 
/* 404 */     return ret;
/*     */   }
/*     */   
/*     */   public static final String fixFileName(String filename) {
/* 408 */     String ret = filename;
/*     */     
/* 410 */     if (ret != null && !"".equals(ret)) {
/* 411 */       StringBuilder b = new StringBuilder(filename);
/* 412 */       Conversion.replace(b, ":", " ");
/* 413 */       Conversion.replace(b, "*", " ");
/* 414 */       ret = b.toString();
/*     */     } 
/* 416 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDialectName(int key) {
/* 425 */     return getStandardConversion().getDialectName(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getDialect(String name) {
/* 434 */     return getStandardConversion().getDialect(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static AbstractConversion getStandardConversion() {
/* 444 */     if (standardConversion == null) {
/* 445 */       standardConversion = (AbstractConversion)new BasicConversion();
/*     */     }
/* 447 */     return standardConversion;
/*     */   }
/*     */ }


