/*     */ package com.MainFrame.Reader.External.base;
/*     */ 
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import com.MainFrame.Reader.Common.CommonBits;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.External.Def.Cb2Xml;
/*     */ import com.MainFrame.Reader.External.Def.ExternalField;
/*     */ import com.MainFrame.Reader.Log.AbsSSLogger;
/*     */ import com.MainFrame.Reader.Numeric.ConversionManager;
/*     */ import com.MainFrame.Reader.Numeric.Convert;
/*     */ import com.MainFrame.Convert2xml.analysis.BaseItem;
/*     */ import com.MainFrame.Convert2xml.analysis.Copybook;
/*     */ import com.MainFrame.Convert2xml.analysis.Item;
/*     */ import com.MainFrame.Convert2xml.def.ICopybook;
/*     */ import com.MainFrame.Convert2xml.def.IItem;
/*     */ import com.MainFrame.Convert2xml.def.IItemBase;
/*     */ import com.MainFrame.Convert2xml.def.IItemJrUpd;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseCobolItemLoader<XRecord extends BaseExternalRecord<XRecord>>
/*     */ {
/*     */   private static final String STR_YES = "Y";
/*     */   private static final String STR_NO = "N";
/*     */   private final boolean useJRecordNaming;
/*     */   private final IExernalRecordBuilder<XRecord> recBuilder;
/*  40 */   private int stackSize = -1;
/*     */   
/*     */   private boolean keepFiller;
/*     */   
/*  44 */   private boolean dropCopybookFromFieldNames = CommonBits.isDropCopybookFromFieldNames();
/*     */ 
/*     */   
/*     */   private boolean saveCb2xml;
/*     */ 
/*     */   
/*     */   String indent;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeepFillers(boolean keepFiller) {
/*  55 */     this.keepFiller = keepFiller;
/*     */   }
/*     */   
/*     */   public void setDropCopybookFromFieldNames(boolean dropCopybookFromFieldNames) {
/*  59 */     this.dropCopybookFromFieldNames = dropCopybookFromFieldNames;
/*     */   }
/*     */   
/*     */   public void setSaveCb2xmlDocument(boolean saveCb2xml) {
/*  63 */     this.saveCb2xml = saveCb2xml;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStackSize(int stackSize) {
/*  71 */     this.stackSize = stackSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final XRecord loadCopyBook(String copyBookFile, int splitCopybookOption, int dbIdx, String font, int binFormat, int systemId, AbsSSLogger log) throws IOException {
/*  81 */     return loadCopyBook(new FileReader(copyBookFile), Conversion.getCopyBookId(copyBookFile), splitCopybookOption, dbIdx, font, 
/*     */         
/*  83 */         CommonBits.getDefaultCobolTextFormat(), binFormat, systemId, log);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XRecord loadCopyBook(InputStream inputStream, String copyBookName, int splitCopybook, int dbIdx, String font, int copybookFormat, int binaryFormat, int systemId, AbsSSLogger log) throws IOException {
/*  95 */     return loadCopyBook(new InputStreamReader(inputStream), copyBookName, splitCopybook, dbIdx, font, copybookFormat, binaryFormat, systemId, log);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XRecord loadCopyBook(String copyBookFile, int splitCopybookOption, int dbIdx, String font, int copybookFormat, int binFormat, int systemId, AbsSSLogger log) throws IOException {
/* 124 */     return loadCopyBook(new FileReader(copyBookFile), Conversion.getCopyBookId(copyBookFile), splitCopybookOption, dbIdx, font, copybookFormat, binFormat, systemId, log);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XRecord loadCopyBook(Reader reader, String copyBookName, int splitCopybook, int dbIdx, String font, int copybookFormat, int binaryFormat, int systemId, AbsSSLogger log) throws IOException {
/* 140 */     Copybook copybook = Cb2Xml.getCopybook(reader, copyBookName, binaryFormat, false, copybookFormat, this.stackSize);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     return loadCopybook(copybook, copyBookName, splitCopybook, dbIdx, font, binaryFormat, systemId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XRecord loadCopybook(Copybook copybook, String copyBookName, int splitCopybook, int dbIdx, String font, int binaryFormat, int systemId) {
/*     */     XRecord ret;
/*     */     ArrayList<String> groups;
/*     */     List<? extends IItemJrUpd> list;
/*     */     String[] groupArray;
/* 165 */     List<? extends IItemJrUpd> copybookItems = copybook.getChildItems();
/*     */     
/* 167 */     allocDBs(dbIdx);
/*     */     
/* 169 */     switch (splitCopybook) {
/*     */       case 0:
/* 171 */         ret = createSingleRecordSchema(copyBookName, null, font, binaryFormat, copybookItems);
/*     */         break;
/*     */       case 1:
/* 174 */         ret = createSplitOnRedefinesSchema(copyBookName, font, binaryFormat, systemId, copybookItems);
/*     */         break;
/*     */       case 3:
/* 177 */         ret = createGroupRecordSchema(copyBookName, null, font, binaryFormat, systemId, copybookItems, true);
/*     */         break;
/*     */       case 4:
/* 180 */         groups = new ArrayList<String>();
/* 181 */         list = copybookItems;
/* 182 */         while (list != null && list.size() == 1) {
/* 183 */           IItemJrUpd itm = list.get(0);
/* 184 */           String fn = itm.getFieldName();
/* 185 */           if (fn != null && fn.length() > 0 && !"filler".equalsIgnoreCase(fn)) {
/* 186 */             groups.add(fn);
/*     */           }
/* 188 */           list = itm.getChildItems();
/*     */         } 
/* 190 */         groupArray = groups.<String>toArray(new String[groups.size()]);
/* 191 */         if (list == null || list.size() < 2) {
/* 192 */           ret = createSingleRecordSchema(copyBookName, groupArray, font, binaryFormat, copybookItems); break;
/*     */         } 
/* 194 */         ret = createGroupRecordSchema(copyBookName, groupArray, font, binaryFormat, systemId, list, true);
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/* 200 */         ret = createGroupRecordSchema(copyBookName, null, font, binaryFormat, systemId, copybookItems, false);
/*     */         break;
/*     */     } 
/*     */     
/* 204 */     ret.setCopybook((ICopybook)copybook);
/* 205 */     updateRecord(copyBookName, systemId, font, ret, "Y");
/*     */     
/* 207 */     Convert numTranslator = ConversionManager.getInstance().getConverter4code(binaryFormat);
/* 208 */     boolean multipleRecordLengths = false;
/* 209 */     boolean binary = false;
/*     */     
/* 211 */     if (ret.getNumberOfRecords() == 0) {
/* 212 */       binary = ret.isBinary();
/*     */     } else {
/* 214 */       int len = getRecLength(ret.getRecord(0));
/* 215 */       binary = (binary || ret.getRecord(0).isBinary());
/*     */       
/* 217 */       for (int i = 1; i < ret.getNumberOfRecords(); i++) {
/* 218 */         binary = (binary || ret.getRecord(i).isBinary());
/*     */         
/* 220 */         multipleRecordLengths = (multipleRecordLengths || len != getRecLength(ret.getRecord(i)));
/*     */       } 
/*     */     } 
/* 223 */     ret.setFileStructure(numTranslator.getFileStructure(multipleRecordLengths, binary));
/*     */     
/* 225 */     freeDBs(dbIdx);
/*     */     
/* 227 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   private int getRecLength(XRecord rec) {
/* 232 */     int ret = 0;
/*     */     
/*     */     try {
/* 235 */       for (int i = 0; i < rec.getNumberOfRecordFields(); i++) {
/* 236 */         ExternalField recordField = rec.getRecordField(i);
/* 237 */         ret = Math.max(ret, recordField.getPos() + recordField.getLen() - 1);
/*     */       } 
/* 239 */     } catch (Exception e) {
/* 240 */       System.out.println("Error Finding Record Length Types");
/*     */     } 
/*     */     
/* 243 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void allocDBs(int pDbIdx) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void freeDBs(int pDbIdx) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private XRecord createSingleRecordSchema(String copyBookName, String[] groupArray, String font, int binaryFormat, List<? extends IItemJrUpd> copybookItems) {
/* 259 */     XRecord ret = createRecord(copyBookName, font, binaryFormat);
/*     */ 
/*     */     
/* 262 */     ret.setItems(copyBookName, groupArray, binaryFormat, copybookItems);
/* 263 */     ret.updateTypeOnCobolItems();
/* 264 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private XRecord createGroupRecordSchema(String copyBookName, String[] parentGroupNames, String font, int binaryFormat, int systemId, List<? extends IItemJrUpd> copybookItems, boolean updatePosition) {
/* 275 */     XRecord ret = createGroupRecord(copyBookName, font, binaryFormat);
/*     */     
/* 277 */     for (int i = 0; i < copybookItems.size(); i++) {
/* 278 */       IItemJrUpd itm = copybookItems.get(i);
/* 279 */       XRecord childRec = createChildRecord(copyBookName, itm.getFieldName(), i, font, binaryFormat, systemId);
/*     */       
/* 281 */       if (updatePosition) {
/* 282 */         itm.updatePosition(-itm.getPosition() + 1);
/*     */       }
/*     */       
/* 285 */       childRec.setItems(copyBookName, parentGroupNames, binaryFormat, itm);
/* 286 */       childRec.updateTypeOnCobolItems();
/* 287 */       ret.addRecord(childRec);
/*     */     } 
/* 289 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private XRecord createSplitOnRedefinesSchema(String copyBookName, String font, int binaryFormat, int systemId, List<? extends IItemJrUpd> copybookItems) {
/* 296 */     XRecord ret = createGroupRecord(copyBookName, font, binaryFormat);
/* 297 */     RedefineSearcher redef = new RedefineSearcher(copybookItems);
/*     */     
/* 299 */     if (redef.item == null) {
/* 300 */       return createSingleRecordSchema(copyBookName, null, font, binaryFormat, copybookItems);
/*     */     }
/*     */     
/* 303 */     int idx = 0;
/* 304 */     for (IItem redefItem : redef.redefineItems) {
/* 305 */       XRecord childRec = createChildRecord(copyBookName, redefItem.getFieldName(), idx++, font, binaryFormat, systemId);
/* 306 */       childRec.setItems(copyBookName, (String[])null, binaryFormat, 
/*     */ 
/*     */ 
/*     */           
/* 310 */           createSplitOnRedefines_processList(redefItem, (BaseItem)new Copybook("", ""), redef, copybookItems));
/*     */ 
/*     */ 
/*     */       
/* 314 */       childRec.updateTypeOnCobolItems();
/* 315 */       ret.addRecord(childRec);
/*     */     } 
/*     */     
/* 318 */     return ret;
/*     */   }
/*     */   
/*     */   public BaseCobolItemLoader(boolean useJRecordNaming, IExernalRecordBuilder<XRecord> recBuilder) {
/* 322 */     this.indent = "\t";
/*     */     this.useJRecordNaming = useJRecordNaming;
/*     */     this.recBuilder = recBuilder;
/*     */   } private List<? extends IItemJrUpd> createSplitOnRedefines_processList(IItem redefItem, BaseItem parent, RedefineSearcher redef, List<? extends IItemJrUpd> list) {
/* 326 */     if (list == null || list.size() == 0) return list; 
/* 327 */     String oindent = this.indent;
/* 328 */     this.indent += "\t";
/* 329 */     List<IItemJrUpd> nList = new ArrayList<IItemJrUpd>(list.size());
/* 330 */     for (IItemJrUpd itm : list) {
/*     */       
/* 332 */       if (itm == redefItem) {
/* 333 */         nList.add(itm); continue;
/* 334 */       }  if (redef.parents.contains(itm)) {
/*     */         
/* 336 */         Item newItem = new Item(parent, itm.getLevelNumber(), itm.getLevelString(), itm.getFieldName());
/* 337 */         newItem.set((IItem)itm);
/* 338 */         List<? extends IItemJrUpd> children = createSplitOnRedefines_processList(redefItem, (BaseItem)newItem, redef, itm.getChildItems());
/* 339 */         for (IItemJrUpd ci : children) {
/* 340 */           newItem.addItem((Item)ci);
/*     */         }
/* 342 */         nList.add(newItem); continue;
/*     */       } 
/* 344 */       if (!redef.redefineItems.contains(itm)) {
/* 345 */         nList.add(itm);
/*     */       }
/*     */     } 
/*     */     
/* 349 */     this.indent = oindent;
/*     */     
/* 351 */     return nList;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private XRecord createChildRecord(String copyBookName, String fieldName, int idx, String font, int binaryFormat, int systemId) {
/* 357 */     String name = fieldName;
/* 358 */     if (name == null || name.length() == 0 || "filler".equalsIgnoreCase(name)) {
/* 359 */       name = copyBookName + "_" + idx;
/* 360 */     } else if (this.useJRecordNaming) {
/* 361 */       name = name.trim();
/*     */     } else {
/* 363 */       name = copyBookName.trim() + "-" + name.trim();
/*     */     } 
/*     */     
/* 366 */     XRecord childRec = createRecord(name, font, binaryFormat);
/* 367 */     updateRecord(name, systemId, font, childRec, "N");
/* 368 */     return childRec;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateRecord(String copyBookName, int systemId, String font, XRecord ret, String list) {
/* 373 */     ret.setListChar(list);
/* 374 */     ret.setSystem(systemId);
/* 375 */     ret.setCopyBook(copyBookName);
/* 376 */     ret.setNew(true);
/*     */   }
/*     */   
/*     */   private XRecord createRecord(String copyBookName, String font, int binaryFormat) {
/* 380 */     int rt = 1;
/* 381 */     if (binaryFormat == 1) {
/* 382 */       rt = 0;
/*     */     }
/*     */     
/* 385 */     return this.recBuilder.getNullRecord(copyBookName, rt, font)
/*     */ 
/*     */ 
/*     */       
/* 389 */       .setCobolConversionOptions(this.keepFiller, this.dropCopybookFromFieldNames, this.saveCb2xml, this.useJRecordNaming);
/*     */   }
/*     */ 
/*     */   
/*     */   private XRecord createGroupRecord(String copyBookName, String font, int binaryFormat) {
/* 394 */     int rt = 9;
/* 395 */     if (binaryFormat == 1 || binaryFormat == 3)
/*     */     {
/* 397 */       rt = 10;
/*     */     }
/*     */     
/* 400 */     return this.recBuilder.getNullRecord(copyBookName, rt, font)
/*     */ 
/*     */ 
/*     */       
/* 404 */       .setCobolConversionOptions(this.keepFiller, this.dropCopybookFromFieldNames, this.saveCb2xml, this.useJRecordNaming);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class RedefineSearcher
/*     */   {
/* 446 */     int level = Integer.MAX_VALUE;
/*     */     IItemJrUpd item;
/*     */     List<IItem> redefineItems;
/*     */     Set<IItem> redefSet;
/*     */     Set<IItemBase> parents;
/*     */     
/*     */     RedefineSearcher(List<? extends IItemJrUpd> items) {
/* 453 */       search(items);
/*     */       
/* 455 */       if (this.item != null) {
/* 456 */         this.redefineItems = new ArrayList<IItem>();
/*     */         
/* 458 */         int pos = this.item.getPosition();
/* 459 */         for (IItem itm : this.item.getParent().getChildItems()) {
/* 460 */           if (itm.getPosition() == pos) {
/* 461 */             this.redefineItems.add(itm);
/*     */           }
/*     */         } 
/*     */         
/* 465 */         this.redefSet = new HashSet<IItem>(this.redefineItems);
/* 466 */         this.parents = new HashSet<IItemBase>();
/*     */         
/* 468 */         IItemJrUpd iItemJrUpd = this.item;
/* 469 */         while (iItemJrUpd.getParent() != null) {
/* 470 */           IItemBase iItemBase = iItemJrUpd.getParent();
/* 471 */           this.parents.add(iItemBase);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void search(List<? extends IItemJrUpd> items) {
/* 477 */       if (items == null || items.size() == 0 || ((IItemJrUpd)items.get(0)).getLevelNumber() >= this.level)
/*     */         return; 
/* 479 */       for (IItemJrUpd itm : items) {
/* 480 */         if (itm.getLevelNumber() < this.level && (itm.isFieldRedefined() || itm.isFieldRedefines())) {
/* 481 */           this.level = itm.getLevelNumber();
/* 482 */           this.item = itm;
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 487 */       for (IItemJrUpd itm : items)
/* 488 */         search(itm.getChildItems()); 
/*     */     }
/*     */   }
/*     */ }

