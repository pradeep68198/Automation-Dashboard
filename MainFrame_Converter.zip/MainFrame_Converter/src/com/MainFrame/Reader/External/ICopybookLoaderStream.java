
package com.MainFrame.Reader.External;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

import com.MainFrame.Reader.Log.AbsSSLogger;

public interface ICopybookLoaderStream extends CopybookLoader {

	
	public abstract ExternalRecord loadCopyBook(
			InputStream inputStream, //Document copyBookXml,
			String copyBookName, int splitCopybook, int dbIdx, String font,
			int copybookFormat, int binaryFormat, int systemId, AbsSSLogger log)
			throws IOException;
	
	
	public abstract ExternalRecord loadCopyBook(
			Reader reader, //Document copyBookXml,
			String copyBookName, int splitCopybook, int dbIdx, String font,
			int copybookFormat, int binaryFormat, int systemId, AbsSSLogger log)
			throws IOException;

	
}