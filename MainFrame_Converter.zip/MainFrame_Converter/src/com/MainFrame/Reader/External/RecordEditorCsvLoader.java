
package com.MainFrame.Reader.External;

import com.MainFrame.Reader.External.base.BaseRecordEditorCsvLoader;


public class RecordEditorCsvLoader {


	
    public static final class Tab 
    extends BaseRecordEditorCsvLoader<ExternalRecord> 
    implements ICopybookLoaderStream {
    	public Tab() {
    		super(new ExternalRecordBuilder(), "\t");
    	}
    }


  
    public static final class Comma 
    extends BaseRecordEditorCsvLoader<ExternalRecord> 
    implements ICopybookLoaderStream {
    	public Comma() {
    		super(new ExternalRecordBuilder(), ",");
    	}
    }
}