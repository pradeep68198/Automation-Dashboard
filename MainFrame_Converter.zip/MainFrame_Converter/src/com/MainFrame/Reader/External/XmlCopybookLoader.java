
package com.MainFrame.Reader.External;

import com.MainFrame.Reader.External.base.BaseCb2xmlLoader;


public class XmlCopybookLoader extends BaseCb2xmlLoader<ExternalRecord> 
implements ICopybookLoaderStream, ICopybookLoaderCobol {

    public XmlCopybookLoader() {
		super(new ExternalRecordBuilder(), true);
	}
}