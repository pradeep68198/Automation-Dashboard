
package com.MainFrame.Reader.External;

import com.MainFrame.Reader.Common.CommonBits;
import com.MainFrame.Reader.Log.AbsSSLogger;


public abstract class BaseCopybookLoader implements CopybookLoader {

	
	@Override
	public final ExternalRecord loadCopyBook(String copyBookFile,
			int splitCopybookOption, int dbIdx, String font, int binFormat,
			int systemId, AbsSSLogger log) throws Exception {
		return loadCopyBook(copyBookFile, splitCopybookOption, dbIdx, font, CommonBits.getDefaultCobolTextFormat(), binFormat, systemId, log);
	}

}
