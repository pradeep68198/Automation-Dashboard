
package com.MainFrame.Reader.External;

import com.MainFrame.Reader.Details.LayoutDetail;



/**
 
 * @deprecated use externalRecord.asLayoutDetail() instead
 */
public class ToLayoutDetail {

    private static ToLayoutDetail instance = new ToLayoutDetail();

	/**
	 
	 * @deprecated use externalRecord.asLayoutDetail() instead
	 */
	public LayoutDetail getLayout(ExternalRecord externalRecord) {

		if (externalRecord == null) {
			return null;
		}
		return externalRecord.asLayoutDetail();
	}


    /**
     * @return Returns the instance.
     */
    public static ToLayoutDetail getInstance() {
        return instance;
    }
}
