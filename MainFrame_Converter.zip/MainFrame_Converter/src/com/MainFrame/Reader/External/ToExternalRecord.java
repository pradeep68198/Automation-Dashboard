
package com.MainFrame.Reader.External;

import com.MainFrame.Reader.Common.Constants;
import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Details.RecordDetail;
import com.MainFrame.Reader.External.Def.ExternalField;


public final class ToExternalRecord {

	private static ToExternalRecord instance = null;

	
	public final ExternalRecord getExternalRecord(LayoutDetail layout, String copybookName, int system) {
		//int rt = Constants.rtGroupOfRecords;
		//int type = recordDefinition.getLayoutType();

//		System.out.println();
//		System.out.println("layout type >> " + layout.getFileStructure());

		String fldSep = layout.getDelimiterDetails().jrDefinition();
		String quote = "";
		if (layout.getRecordCount() > 0) {
			//AbstractRecordDetail r = layout.getRecord(0);
			//fldSep = r.getDelimiter();
			quote = layout.getRecord(0).getQuoteDefinition().jrDefinition();
		}
		ExternalRecord rec = new ExternalRecord(
				-1, copybookName, layout.getDescription(),
				Constants.rtGroupOfRecords, system, "Y", copybookName,
				getSeperator(fldSep), quote, 0, "default",
				layout.getRecordSep(), layout.getFontName(),
				0, fixIOType(layout.getFileStructure())
		);
		rec.setNew(true);

		for (int i = 0; i < layout.getRecordCount(); i++) {
			if (! layout.getRecord(i).getRecordName().startsWith("XML")) {
				rec.addRecord(convert(i, layout, copybookName, system));
			}
		}

		return rec;
	}

	
	private ExternalRecord convert(int id, LayoutDetail layout, String copybookName, int system) {
		FieldDetail dtl;
		ExternalField field;
		ExternalRecord rec;
		RecordDetail record = layout.getRecord(id);
		String name = record.getRecordName();
		boolean embeddedCr = record.isEmbeddedNewLine();

		rec = new ExternalRecord(
				id, name, "", record.getRecordType(),
				system, "N", copybookName + "_" + name, getSeperator(record.getDelimiterDetails().jrDefinition()),
				record.getQuoteDefinition().jrDefinition(), 0, "default", layout.getRecordSep(), record.getFontName(),
				record.getRecordStyle(), fixIOType(layout.getFileStructure()), embeddedCr
		);
		rec.setNew(true);
		System.out.println("Record >> " + id +  " " + record.getRecordName());

		for (int i = 0; i < record.getFieldCount(); i++) {
			dtl = record.getField(i);
			field = new ExternalField(dtl.getPos(), dtl.getLen(),
							dtl.getName(), dtl.getDescription(),
							dtl.getType(), dtl.getDecimal(), dtl.getFormat(), dtl.getParamater(),
							"", "", i
			);

//			if (dtl.getDefaultValue() != null
//			&& ! "".equals(dtl.getDefaultValue().toString())) {
//				field.setDefault(dtl.getDefaultValue().toString());
//			}
			rec.addRecordField(field);
		}
		return rec;
	}

//	
//	private int fixLength(int len) {
//		int ret = len;
//		if (len < 0) {
//			ret = 0;
//		}
//		return ret;
//	}

	private int fixIOType(int ioType) {
		int ret = ioType;
		if (ret == Constants.IO_XML_BUILD_LAYOUT) {
			ret = Constants.IO_XML_USE_LAYOUT;
		}
		return ret;
	}


	private static String getSeperator(String sep) {
		String s = sep;
		if ("\t".equals(s)) {
			s = "<tab>";
		} else if ("\t".equals(s)) {
			s = "<tab>";
		}

		return s;
	}

	
	public final static ToExternalRecord getInstance() {
		if (instance == null) {
			instance = new ToExternalRecord();
		}
		return instance;
	}
}
