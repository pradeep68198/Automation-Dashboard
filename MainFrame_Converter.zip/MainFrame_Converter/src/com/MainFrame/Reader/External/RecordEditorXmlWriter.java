package com.MainFrame.Reader.External;

/**
 
 *
 * @deprecated use {@link com.MainFrame.Reader.External.base.RecordEditorXmlWriter}
 */

public class RecordEditorXmlWriter extends com.MainFrame.Reader.External.base.RecordEditorXmlWriter {

}
