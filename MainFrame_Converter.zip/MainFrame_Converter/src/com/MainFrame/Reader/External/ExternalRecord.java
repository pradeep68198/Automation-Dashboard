
package com.MainFrame.Reader.External;

import com.MainFrame.Reader.External.Def.*;
import com.MainFrame.Reader.Types.*;
import com.MainFrame.Reader.Details.*;
import com.MainFrame.Reader.Option.*;
import com.MainFrame.Reader.Details.Item.*;
import com.MainFrame.Reader.Common.*;
import java.util.*;
import com.MainFrame.Convert2xml.def.*;
import com.MainFrame.Reader.detailsBasic.*;
import com.MainFrame.Reader.External.base.*;
import com.MainFrame.Reader.def.IO.builders.*;
import com.MainFrame.Reader.IO.builders.*;

public class ExternalRecord extends BaseExternalRecord<ExternalRecord> implements ICsvSchemaBuilder, IFixedWidthSchemaBuilder
{
    private RecordDecider recordDecider;
    private int lastPosition;
    
    public ExternalRecord() {
        this.recordDecider = null;
        this.lastPosition = -1;
    }
    
    public ExternalRecord(final int pRecordId, final String pRecordName, final String pDescription, final int pRecordType, final int pSystem, final String pListChar, final String pCopyBook, final String pDelimiter, final String pQuote, final int pPosRecInd, final String pRecSepList, final byte[] pRecordSep, final String pFontName, final int precordStyle, final int pfileStructure) {
        this(pRecordId, pRecordName, pDescription, pRecordType, pSystem, pListChar, pCopyBook, pDelimiter, pQuote, pPosRecInd, pRecSepList, pRecordSep, pFontName, precordStyle, pfileStructure, false);
    }
    
    public ExternalRecord(final int pRecordId, final String pRecordName, final String pDescription, final int pRecordType, final int pSystem, final String pListChar, final String pCopyBook, final String pDelimiter, final String pQuote, final int pPosRecInd, final String pRecSepList, final byte[] pRecordSep, final String pFontName, final int precordStyle, final int pfileStructure, final boolean pEmbeddedCr) {
        super(pRecordId, pRecordName, pDescription, pRecordType, pSystem, pListChar, pCopyBook, pDelimiter, pQuote, pPosRecInd, pRecSepList, pRecordSep, pFontName, precordStyle, pfileStructure, pEmbeddedCr);
        this.recordDecider = null;
        this.lastPosition = -1;
    }
    
    public int addFixedWidthField(final ExternalField fld, final FieldAdjustmentOptions adjustment) {
        final int pos = fld.getPos();
        final int len = fld.getLen();
        int idx = 0;
        if (pos < 1 || len < 1) {
            throw new RecordException("Invalif position/length: " + pos + "/" + len);
        }
        super.loadFields();
        switch (adjustment) {
            case NO_ADJUSTMENT: {
                return this.insertField(fld);
            }
            case ADJUST_BY_LENGTH: {
                idx = this.insertField(fld);
                this.adjustFieldPositions(idx, len);
                break;
            }
            case CALCULATE_ADJUSTMENT: {
            	Collections.sort(fields, new Comparator<ExternalField>() {
    				@Override public int compare(ExternalField o1, ExternalField o2) {
    					return Integer.compare(o1.getPos(), o2.getPos());
    				}
    			});
                for (int i = 0; i < this.fields.size(); ++i) {
                    if (this.fields.get(i).getPos() >= pos) {
                        final int adj = len + pos - this.fields.get(i).getPos();
                        this.fields.add(i, fld);
                        if (adj > 0) {
                            this.adjustFieldPositions(i, adj);
                        }
                        return i;
                    }
                }
                idx = this.fields.size();
                this.fields.add(fld);
                break;
            }
        }
        return idx;
    }
    
    private int insertField(final ExternalField fld) {
        final int pos = fld.getPos();
        for (int i = 0; i < this.fields.size(); ++i) {
            if (this.fields.get(i).getPos() >= pos) {
                this.fields.add(i, fld);
                return i;
            }
        }
        this.fields.add(fld);
        super.fieldUpdated(fld);
        return this.fields.size() - 1;
    }
    
    private void adjustFieldPositions(final int idx, final int adj) {
        for (int j = idx + 1; j < this.fields.size(); ++j) {
            final ExternalField cf = this.fields.get(j);
            if (cf.getPos() > 0) {
                cf.setPos(cf.getPos() + adj);
            }
        }
    }
    
    public Object clone() {
        return this.fullClone();
    }
    
    public ExternalRecord fullClone() {
        ExternalRecord ret;
        try {
            ret = (ExternalRecord)super.clone();
        }
        catch (Exception e) {
            ret = new ExternalRecord(super.getRecordId(), super.getRecordName(), super.getDescription(), super.getRecordType(), super.getSystem(), super.getListChar(), super.getCopyBook(), super.getDelimiter(), super.getQuote(), super.getPosRecInd(), super.getRecSepList(), super.getRecordSep(), super.getFontName(), super.getRecordStyle(), super.getFileStructure(), false);
        }
        return ret;
    }
    
    final RecordDecider getRecordDecider() {
        return this.recordDecider;
    }
    
    public final void setRecordDecider(final RecordDecider recordDecider) {
        this.recordDecider = recordDecider;
    }
    
    public static final ExternalRecord getNullRecord(final String pRecordName, final String fontName) {
        return getNullRecord(pRecordName, 1, fontName);
    }
    
    public static final ExternalRecord getNullRecord(final String pRecordName, final int recordType, final String fontName) {
        return new ExternalRecord(-1, pRecordName, "", recordType, 0, "N", "", "<Tab>", "", 0, "default", Constants.SYSTEM_EOL_BYTES, fontName, 0, -1, false);
    }
    
    public ExternalRecord[] toArray() {
        return this.subRecords.toArray(new ExternalRecord[this.subRecords.size()]);
    }
    
    public ExternalRecord addCsvField(final String name, final int type, final int decimal) {
        this.addRecordField(new ExternalField(this.fields.size() + 1, -121, name, "", type, decimal, 0, "", "", "", 0));
        return this;
    }
    
    public ExternalRecord addField(final String name, final int type, final int pos, final int length, final int decimal) {
        this.addRecordField(new ExternalField(pos, length, name, "", type, decimal, 0, "", "", "", 0));
        return this;
    }
    
    public ExternalRecord addFieldByLength(final String name, final int type, final int length, final int decimal) {
        this.addRecordField(new ExternalField(this.calcNextPos(), length, name, "", type, decimal, 0, "", "", "", 0));
        return this;
    }
    
    public ExternalRecord skipBytes(final int numberOfBytes) {
        this.lastPosition = this.calcNextPos() + numberOfBytes;
        return this;
    }
    
    private int calcNextPos() {
        int pos = 1;
        if (this.fields.size() > 0) {
            final ExternalField lf = this.fields.get(this.fields.size() - 1);
            pos = Math.max(this.lastPosition, lf.getPos() + lf.getLen());
        }
        return pos;
    }
    
    public ExternalRecord addFieldByPosition(final String name, final int type, final int pos, final int decimal) {
        final int length = 1;
        this.setLastFieldsLength(pos);
        this.addRecordField(new ExternalField(pos, length, name, "", type, decimal, 0, "", "", "", 0));
        return this;
    }
    
    public ExternalRecord skipFieldPosition(final int pos) {
        this.setLastFieldsLength(pos);
        this.lastPosition = pos;
        return this;
    }
    
    private void setLastFieldsLength(final int pos) {
        if (this.fields.size() > 0) {
            final ExternalField lf = this.fields.get(this.fields.size() - 1);
            if (lf.getPos() >= this.lastPosition) {
                lf.setLen(pos - lf.getPos());
            }
        }
    }
    
    public ExternalRecord addFieldByPosition(final String name, final int type, final int pos, final int length, final int decimal) {
        if (this.fields.size() > 0) {
            final ExternalField lf = this.fields.get(this.fields.size() - 1);
            lf.setLen(pos - lf.getPos());
        }
        this.addRecordField(new ExternalField(pos, length, name, "", type, decimal, 0, "", "", "", 0));
        return this;
    }
    
    public final LayoutDetail asLayoutDetail() {
        LayoutDetail ret = null;
        final String recordSepString = this.getRecSepList();
        String fontName = this.getFontName();
        if ((fontName == null || fontName.length() == 0) && Conversion.isMultiByte("") && this.isBinary()) {
            fontName = Conversion.DEFAULT_ASCII_CHARSET;
        }
        final byte[] recordSep = CommonBits.getEolBytes(this.getRecordSep(), recordSepString, fontName);
        this.setParentsFromName();
        final TypeManager.CharsetType charsetType = TypeManager.getInstance().getCharsetType(fontName);
        if (this.getNumberOfRecords() == 0) {
            final RecordDetail[] records = { this.toRecordDetail(charsetType, super.optimizeTypes) };
            records[0].updateRecordSelection(this.getRecordSelection(), (IGetFieldByName)records[0]);
            ret = this.genSchema(records, fontName, recordSepString, recordSep);
        }
        else {
            final RecordDetail[] records = new RecordDetail[this.getNumberOfRecords()];
            for (int i = 0; i < records.length; ++i) {
                records[i] = ((ExternalRecord)this.getRecord(i)).toRecordDetail(charsetType, super.optimizeTypes);
            }
            ret = this.genSchema(records, fontName, recordSepString, recordSep);
            for (int i = 0; i < records.length; ++i) {
                records[i].updateRecordSelection(((ExternalRecord)this.getRecord(i)).getRecordSelection(), (IGetFieldByName)new LayoutGetFieldByName(ret, records[i]));
            }
        }
        ret.setDelimiter(this.getDelimiter());
        return ret;
    }
    
    private LayoutDetail genSchema(final RecordDetail[] recordDefs, final String fontname, final String recordSepString, final byte[] recordSep) {
        return new LayoutDetail(this.getRecordName(), recordDefs, this.getDescription(), this.getRecordType(), recordSep, recordSepString, fontname, this.getRecordDecider(), this.getFileStructure(), (IRecordPositionOption)null, this.isInitToSpaces(), this.getRecordLength());
    }
    
    private RecordDetail toRecordDetail(final TypeManager.CharsetType charsetType, boolean optermize) {
        final int[][] posLength = super.getPosLength();
        final List<? extends IItemJr> items = (List<? extends IItemJr>)super.getItems();
        List<? extends IItemDetails> itemDtls = null;
        final TypeManager typeMgr = TypeManager.getInstance();
        optermize |= super.optimizeTypes;
        FieldDetail[] fields;
        if (items != null) {
            final FieldCreatorHelper fieldHelper = super.createFieldHelper();
            final ItemCopyJr itmCpy = new ItemCopyJr(this.isKeepFillers(), charsetType, optermize || this.optimizeTypes);
            itemDtls = (List<? extends IItemDetails>)itmCpy.copy(fieldHelper, items);
            fields = itmCpy.getFields();
            super.dependingOn = itmCpy.getDependingOn();
            Arrays.sort(fields, new Comparator<FieldDetail>() {
                @Override
                public int compare(final FieldDetail o1, final FieldDetail o2) {
                    return Integer.compare(o1.getPos(), o2.getPos());
                }
            });
        }
        else {
            fields = new FieldDetail[this.getNumberOfRecordFields()];
            for (int i = 0; i < fields.length; ++i) {
                final ExternalField fieldRec = this.getRecordField(i);
                int type = fieldRec.getType();
                if (optermize) {
                    type = typeMgr.getShortType(type, posLength[1][i], charsetType);
                }
                fields[i] = new FieldDetail(fieldRec.getName(), fieldRec.getDescription(), type, fieldRec.getDecimal(), this.getFontName(), 0, fieldRec.getParameter());
                if (posLength[1][i] < 0) {
                    fields[i].setPosOnly(posLength[0][i]);
                }
                else {
                    fields[i].setPosLen(posLength[0][i], posLength[1][i]);
                }
                fields[i].setGroupName(fieldRec.getGroup());
                fields[i].setDependingOnDtls(fieldRec.getDependOnDtls());
                final String s = fieldRec.getDefault();
                if (s != null && !"".equals(s)) {
                    fields[i].setDefaultValue((Object)s);
                }
            }
        }
        final RecordDetail ret = new RecordDetail(this.getRecordName(), this.getRecordPositionOption(), this.getRecordType(), this.getDelimiter(), this.getQuote(), this.getFontName(), fields, (List)itemDtls, this.getRecordStyle());
        ret.setParentRecordIndex(this.getParentRecord());
        ret.setDependingOn(this.getDependingOnDefinition());
        if (this.isDefaultRecord()) {
            ret.getRecordSelection().setDefaultRecord(true);
        }
        return ret;
    }
    
    public final ISchemaIOBuilder asIOBuilder() {
        final LayoutDetail layoutDetail = this.asLayoutDetail();
        return (layoutDetail == null) ? null : SchemaIOBuilder.newSchemaIOBuilder(layoutDetail);
    }
    
    public static IFixedWidthSchemaBuilder newFixedWidthRecord(final String name, final int fileStructure, final String fontName) {
        final ExternalRecord r = getNullRecord(name, 1, fontName);
        r.setFileStructure(fileStructure);
        return (IFixedWidthSchemaBuilder)r;
    }
    
    public static ICsvSchemaBuilder newCsvRecord(final String name, final int fileStructure, final String fontName, final String delimeter, final String quote) {
        final ExternalRecord r = new ExternalRecord(-1, name, "", 2, 0, "N", "", delimeter, quote, 0, "default", Constants.SYSTEM_EOL_BYTES, fontName, 0, fileStructure, false);
        return (ICsvSchemaBuilder)r;
    }
    
    public enum FieldAdjustmentOptions
    {
        NO_ADJUSTMENT, 
        ADJUST_BY_LENGTH, 
        CALCULATE_ADJUSTMENT;
    }
   
    
}