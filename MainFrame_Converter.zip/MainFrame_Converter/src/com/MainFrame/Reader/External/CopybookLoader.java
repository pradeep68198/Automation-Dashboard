
package com.MainFrame.Reader.External;

import com.MainFrame.Reader.Log.AbsSSLogger;
import com.MainFrame.Reader.Option.ICobolSplitOptions;




public interface CopybookLoader extends ICobolSplitOptions {


   
    public abstract ExternalRecord loadCopyBook(final String copyBookFile,
            final int splitCopybookOption, final int dbIdx, final String font,
            final int binFormat,
            final int systemId,
            final AbsSSLogger log) throws Exception;
    
   
    public abstract ExternalRecord loadCopyBook(final String copyBookFile,
            final int splitCopybookOption, final int dbIdx, final String font,
            final int copybookFormat,
            final int binFormat,
            final int systemId,
            final AbsSSLogger log) throws Exception;
}