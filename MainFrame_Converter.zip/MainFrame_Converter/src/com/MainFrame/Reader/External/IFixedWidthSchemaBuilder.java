
package com.MainFrame.Reader.External;


public interface IFixedWidthSchemaBuilder extends IBasicSchemaBuilder {

	
	public IFixedWidthSchemaBuilder addFieldByPosition(String name, int type, int pos, int length, int decimal);
	
	
	public IFixedWidthSchemaBuilder addFieldByLength(String name, int type, int length, int decimal);
	
	
	public IFixedWidthSchemaBuilder skipBytes(int numberOfBytes);

	public IFixedWidthSchemaBuilder addField(String name, int type, int pos, int length, int decimal);

	public IFixedWidthSchemaBuilder addFieldByPosition(String name, int type, int pos,
			int decimal);

	public IFixedWidthSchemaBuilder skipFieldPosition(int pos);
	
}
