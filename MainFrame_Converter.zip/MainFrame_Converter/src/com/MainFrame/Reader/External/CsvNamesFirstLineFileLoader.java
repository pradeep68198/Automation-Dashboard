
package com.MainFrame.Reader.External;

import java.io.IOException;

import com.MainFrame.Reader.Common.CommonBits;
import com.MainFrame.Reader.Common.Conversion;
import com.MainFrame.Reader.Details.DefaultLineProvider;
import com.MainFrame.Reader.IO.TextLineReader;
import com.MainFrame.Reader.Log.AbsSSLogger;


public class CsvNamesFirstLineFileLoader implements CopybookLoader {

	private String fieldSeperator = ",";
	
	
	public CsvNamesFirstLineFileLoader() {
		
	}
	
	
	public CsvNamesFirstLineFileLoader(String sep) {
		fieldSeperator = sep;
	}
	
	
	
	
	@Override
	public final ExternalRecord loadCopyBook(String copyBookFile,
			int splitCopybookOption, int dbIdx, String font, int binFormat,
			int systemId, AbsSSLogger log) throws IOException {
		// TODO Auto-generated method stub
		return loadCopyBook(copyBookFile, splitCopybookOption, dbIdx, font, CommonBits.getDefaultCobolTextFormat(), binFormat, systemId, log);
		
	}

	
	public ExternalRecord loadCopyBook(String copyBookFile, int splitCopybookOption, int dbIdx, String font, int copybookFormat, int binFormat, 
			int systemId, AbsSSLogger log) 
	throws IOException {
		TextLineReader r = new TextLineReader(new DefaultLineProvider(),  true);
		r.setDefaultDelim(fieldSeperator);
		r.open(copyBookFile);
		
		r.read();
		
		r.close();
		
		return ToExternalRecord.getInstance()
				.getExternalRecord(r.getLayout(), Conversion.getCopyBookId(copyBookFile), systemId);
	}

	
	public static final class Tab extends CsvNamesFirstLineFileLoader {
		public Tab() {
			super("\t");
		}
	}
}
