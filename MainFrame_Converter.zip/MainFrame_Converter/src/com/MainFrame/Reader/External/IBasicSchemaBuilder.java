
package com.MainFrame.Reader.External;

import com.MainFrame.Reader.Details.LayoutDetail;

public interface IBasicSchemaBuilder {
	

	
	public LayoutDetail asLayoutDetail();

	
	public ExternalRecord asExternalRecord();
}

