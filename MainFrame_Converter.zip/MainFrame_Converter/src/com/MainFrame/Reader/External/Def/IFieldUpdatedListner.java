package com.MainFrame.Reader.External.Def;

public interface IFieldUpdatedListner {
  void fieldUpdated(ExternalField paramExternalField);
}

