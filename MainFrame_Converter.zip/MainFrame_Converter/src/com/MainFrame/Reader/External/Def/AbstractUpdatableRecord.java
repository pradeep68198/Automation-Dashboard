/*     */ package com.MainFrame.Reader.External.Def;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractUpdatableRecord
/*     */ {
/*     */   public static final int UNCHANGED = 1;
/*     */   public static final int NEW_RECORD = 2;
/*     */   public static final int UPDATED = 3;
/*     */   public static final int BLANK_RECORD = 4;
/*     */   public static final int NULL_INT_VALUE = -1;
/*  61 */   protected int updateStatus = 1;
/*     */   
/*  63 */   public static final byte[] NULL_BYTES = new byte[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean newRecord = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractUpdatableRecord(boolean isNull) {
/*  75 */     if (isNull) {
/*  76 */       this.updateStatus = -1;
/*  77 */       this.newRecord = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getUpdateStatus() {
/*  87 */     return this.updateStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUpdateStatus(int status) {
/*  96 */     this.updateStatus = status;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean isEqual(byte[] val1, byte[] val2) {
/* 112 */     if (val1 == null && val2 == null) {
/* 113 */       return true;
/*     */     }
/*     */     
/* 116 */     boolean more = (val1 != null && val2 != null && val1.length == val2.length);
/*     */     
/* 118 */     for (int i = 0; more && i < val1.length; i++) {
/* 119 */       more = (val1[i] == val2[i]);
/*     */     }
/*     */     
/* 122 */     return more;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNew() {
/* 130 */     return this.newRecord;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNew(boolean pInserted) {
/* 139 */     this.newRecord = pInserted;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean equals(String val, String fieldValue) {
/* 144 */     if ((val != null && !"".equals(val)) || (fieldValue != null && 
/* 145 */       !"".equals(fieldValue)))
/*     */     {
/* 147 */       if (val == null || !val.equals(fieldValue) || this.updateStatus == -1) {
/* 148 */         this.updateStatus = 3;
/* 149 */         return false;
/*     */       }  } 
/* 151 */     return true;
/*     */   }
/*     */ }

