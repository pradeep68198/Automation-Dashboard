/*     */ package com.MainFrame.Reader.External.Def;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import com.MainFrame.Reader.Common.AbstractRecordX;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DependingOnDtls
/*     */   implements IDependingOnIndexDtls
/*     */ {
/*     */   public final DependingOn dependingOn;
/*     */   public final int index;
/*     */   public final DependingOnDtls parent;
/*     */   public final boolean firstIdx;
/*  66 */   private List<DependingOn> children = null;
/*     */   
/*     */   private int reliableCalculationsTo;
/*     */   
/*     */   public DependingOnDtls(DependingOn dependingOn, int index, DependingOnDtls parent) {
/*  71 */     this(dependingOn, index, parent, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DependingOnDtls(DependingOn dependingOn, int index, DependingOnDtls parent, boolean permanent) {
/*  77 */     this.dependingOn = dependingOn;
/*  78 */     this.index = index;
/*  79 */     this.parent = parent;
/*  80 */     this.firstIdx = (index == 0 && (parent == null || parent.firstIdx));
/*     */ 
/*     */     
/*  83 */     if (permanent) {
/*  84 */       if (parent != null && index == 0) {
/*  85 */         if (parent.children == null) {
/*  86 */           parent.children = new ArrayList<DependingOn>(3);
/*     */         }
/*  88 */         parent.children.add(dependingOn);
/*     */       } 
/*     */       
/*  91 */       dependingOn.indexDtls.add(this);
/*     */     } 
/*     */     
/*  94 */     this.reliableCalculationsTo = dependingOn.getPosition() + dependingOn.getOccursLength() * (index + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public DependingOnDtls[] getTree() {
/*  99 */     return getTree(1);
/*     */   }
/*     */ 
/*     */   
/*     */   private DependingOnDtls[] getTree(int lvl) {
/*     */     DependingOnDtls[] ret;
/* 105 */     if (this.parent == null) {
/* 106 */       ret = new DependingOnDtls[lvl];
/*     */     } else {
/* 108 */       ret = this.parent.getTree(lvl + 1);
/*     */     } 
/* 110 */     ret[ret.length - lvl] = this;
/* 111 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DependingOn getDependingOn() {
/* 120 */     return this.dependingOn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex() {
/* 129 */     return this.index;
/*     */   }
/*     */   
/*     */   public int getReliableCalculationsTo() {
/* 133 */     return this.reliableCalculationsTo;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DependingOn> getChildren() {
/* 139 */     return this.children;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateFieldInChildren(AbstractRecordX<? extends IFieldDetail> rec) {
/* 148 */     if (this.children != null) {
/* 149 */       for (DependingOn dependingOn : this.children) {
/* 150 */         dependingOn.updateField(rec);
/*     */       }
/*     */       
/* 153 */       DependingOn c = this.children.get(0);
/* 154 */       this.reliableCalculationsTo = c.getPosition() + c.getOccursLength();
/*     */     } 
/*     */   }
/*     */ }

