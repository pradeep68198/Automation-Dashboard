/*     */ package com.MainFrame.Reader.External.Def;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExternalField
/*     */   extends AbstractUpdatableRecord
/*     */ {
/*     */   private int position;
/*     */   private int length;
/*     */   private String name;
/*     */   private String description;
/*     */   private int type;
/*     */   private int decimal;
/*     */   private int cellFormat;
/*     */   private String parameter;
/*     */   private String defaultValue;
/*     */   private String cobolName;
/*     */   private int subKey;
/*     */   private final DependingOnDtls dependOnDtls;
/*  52 */   private String group = "";
/*     */ 
/*     */ 
/*     */   
/*     */   private IFieldUpdatedListner listner;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExternalField() {
/*  62 */     super(true);
/*     */     
/*  64 */     this.position = 0;
/*  65 */     this.length = 0;
/*  66 */     this.name = "";
/*  67 */     this.description = "";
/*  68 */     this.type = 0;
/*  69 */     this.decimal = 0;
/*  70 */     this.cellFormat = 0;
/*  71 */     this.parameter = "";
/*  72 */     this.defaultValue = "";
/*  73 */     this.cobolName = "";
/*  74 */     this.subKey = 0;
/*  75 */     this.dependOnDtls = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExternalField(int pPos, int pLen, String pName, String pDescription, int pType, int pDecimal, int pCellFormat, String pParameter, String pDefault, String pCobolName, int pSubKey) {
/* 108 */     this(pPos, pLen, pName, pDescription, pType, pDecimal, pCellFormat, pParameter, pDefault, pCobolName, pSubKey, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExternalField(int pPos, int pLen, String pName, String pDescription, int pType, int pDecimal, int pCellFormat, String pParameter, String pDefault, String pCobolName, int pSubKey, DependingOnDtls dependDtls) {
/* 127 */     super(false);
/*     */     
/* 129 */     this.position = pPos;
/* 130 */     this.length = pLen;
/* 131 */     this.name = pName;
/* 132 */     this.description = pDescription;
/* 133 */     this.type = pType;
/* 134 */     this.decimal = pDecimal;
/* 135 */     this.cellFormat = pCellFormat;
/* 136 */     this.parameter = pParameter;
/* 137 */     this.defaultValue = pDefault;
/* 138 */     this.cobolName = pCobolName;
/* 139 */     this.subKey = pSubKey;
/* 140 */     this.dependOnDtls = dependDtls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 151 */     return fullClone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExternalField fullClone() {
/* 160 */     ExternalField ret = null;
/*     */     try {
/* 162 */       ret = (ExternalField)super.clone();
/* 163 */     } catch (Exception e) {
/* 164 */       ret = new ExternalField(this.position, this.length, this.name, this.description, this.type, this.decimal, this.cellFormat, this.parameter, this.defaultValue, this.cobolName, this.subKey);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPos() {
/* 189 */     return this.position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPos(int val) {
/* 199 */     if (val != this.position || this.updateStatus == -1) {
/* 200 */       this.position = val;
/* 201 */       notifyOfUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLen() {
/* 210 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLen(int val) {
/* 220 */     if (val != this.length || this.updateStatus == -1) {
/* 221 */       this.length = val;
/* 222 */       notifyOfUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 231 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String val) {
/* 241 */     if ((val == null || "".equals(val)) && (this.name == null || ""
/* 242 */       .equals(this.name))) {
/*     */       return;
/*     */     }
/*     */     
/* 246 */     if (val == null || !val.equals(this.name) || this.updateStatus == -1) {
/* 247 */       this.name = val;
/* 248 */       notifyOfUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 257 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String val) {
/* 267 */     if ((val == null || "".equals(val)) && (this.description == null || ""
/* 268 */       .equals(this.description))) {
/*     */       return;
/*     */     }
/*     */     
/* 272 */     if (val == null || !val.equals(this.description) || this.updateStatus == -1) {
/* 273 */       this.description = val;
/* 274 */       notifyOfUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/* 283 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(int val) {
/* 293 */     if (val != this.type || this.updateStatus == -1) {
/* 294 */       this.type = val;
/* 295 */       notifyOfUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDecimal() {
/* 304 */     return this.decimal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDecimal(int val) {
/* 314 */     if (val != this.decimal || this.updateStatus == -1) {
/* 315 */       this.decimal = val;
/* 316 */       notifyOfUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCellFormat() {
/* 325 */     return this.cellFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCellFormat(int val) {
/* 335 */     if (val != this.cellFormat || this.updateStatus == -1) {
/* 336 */       this.cellFormat = val;
/* 337 */       notifyOfUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParameter() {
/* 346 */     return this.parameter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String val) {
/* 356 */     if ((val == null || "".equals(val)) && (this.parameter == null || ""
/* 357 */       .equals(this.parameter))) {
/*     */       return;
/*     */     }
/*     */     
/* 361 */     if (val == null || !val.equals(this.parameter) || this.updateStatus == -1) {
/* 362 */       this.parameter = val;
/* 363 */       notifyOfUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefault() {
/* 372 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefault(String val) {
/* 382 */     if ((val == null || "".equals(val)) && (this.defaultValue == null || ""
/* 383 */       .equals(this.defaultValue))) {
/*     */       return;
/*     */     }
/*     */     
/* 387 */     if (val == null || !val.equals(this.defaultValue) || this.updateStatus == -1) {
/* 388 */       this.defaultValue = val;
/* 389 */       notifyOfUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCobolName() {
/* 398 */     return this.cobolName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCobolName(String val) {
/* 408 */     if ((val == null || "".equals(val)) && (this.cobolName == null || ""
/* 409 */       .equals(this.cobolName))) {
/*     */       return;
/*     */     }
/*     */     
/* 413 */     if (val == null || !val.equals(this.cobolName) || this.updateStatus == -1) {
/* 414 */       this.cobolName = val;
/* 415 */       notifyOfUpdate();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSubKey() {
/* 424 */     return this.subKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubKey(int val) {
/* 434 */     if (val != this.subKey || this.updateStatus == -1) {
/* 435 */       this.subKey = val;
/* 436 */       this.updateStatus = 3;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getGroup() {
/* 447 */     return this.group;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DependingOnDtls getDependOnDtls() {
/* 457 */     return this.dependOnDtls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setGroup(String group) {
/* 467 */     this.group = group;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListner(IFieldUpdatedListner listner) {
/* 474 */     this.listner = listner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void notifyOfUpdate() {
/* 481 */     this.updateStatus = 3;
/* 482 */     if (this.listner != null)
/* 483 */       this.listner.fieldUpdated(this); 
/*     */   }
/*     */ }

