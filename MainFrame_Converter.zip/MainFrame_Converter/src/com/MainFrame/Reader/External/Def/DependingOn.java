/*     */ package com.MainFrame.Reader.External.Def;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import com.MainFrame.Reader.Common.AbstractRecordX;
/*     */ import com.MainFrame.Reader.Common.FieldDetail;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DependingOn
/*     */ {
/*  69 */   private static final Pattern OF_SPLIT = Pattern.compile("\\sOF\\s", 2);
/*     */ 
/*     */   
/*     */   private final String variableName;
/*     */ 
/*     */   
/*     */   private final String variableNameNoIndex;
/*     */ 
/*     */   
/*     */   private final int position;
/*     */   
/*     */   private final int occursLength;
/*     */   
/*     */   private final int occursMax;
/*     */   
/*     */   private final int occursMaxLength;
/*     */   
/*     */   final List<IDependingOnIndexDtls> indexDtls;
/*     */   
/*     */   private IFieldDetail field;
/*     */   
/*     */   int fieldNumber;
/*     */   
/*     */   private boolean complicatedDependingOn = false;
/*     */ 
/*     */   
/*     */   public DependingOn(String variableName, String variableNameNoIndex, int position, int occursLength, int occursMax) {
/*  96 */     this.variableName = variableName;
/*  97 */     this.variableNameNoIndex = variableNameNoIndex;
/*  98 */     this.position = position;
/*  99 */     this.occursLength = occursLength;
/* 100 */     this.occursMax = occursMax;
/* 101 */     this.occursMaxLength = occursLength * occursMax;
/* 102 */     this.indexDtls = new ArrayList<IDependingOnIndexDtls>(occursMax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<DependingOn> getChildren() {
/* 110 */     if (this.indexDtls == null || this.indexDtls.size() == 0) return null; 
/* 111 */     return ((IDependingOnIndexDtls)this.indexDtls.get(0)).getChildren();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<IDependingOnIndexDtls> getIndexDtls() {
/* 116 */     return this.indexDtls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getVariableName() {
/* 123 */     return this.variableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getVariableNameNoIndex() {
/* 130 */     return this.variableNameNoIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getPosition() {
/* 137 */     return this.position;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getEnd() {
/* 143 */     return this.position + this.occursMaxLength - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getOccursLength() {
/* 150 */     return this.occursLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getOccursMax() {
/* 157 */     return this.occursMax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IFieldDetail getField() {
/* 165 */     return this.field;
/*     */   }
/*     */   
/*     */   public int getFieldNumber() {
/* 169 */     return this.fieldNumber;
/*     */   }
/*     */   
/*     */   public boolean isComplicatedDependingOn() {
/* 173 */     return this.complicatedDependingOn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getOccursMaxLength() {
/* 180 */     return this.occursMaxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateField(AbstractRecordX<? extends IFieldDetail> rec) {
/* 261 */     if (this.field == null) {
/*     */       try {
/* 263 */         String[] groups = OF_SPLIT.split(this.variableName);
/* 264 */         if (groups == null || groups.length < 2) {
/* 265 */           this.field = rec.getField(this.variableName);
/*     */         } else {
/* 267 */           String[] groupsNS = new String[groups.length];
/* 268 */           for (int i = 0; i < groups.length; i++) {
/* 269 */             groupsNS[groups.length - i] = groups[i];
/*     */           }
/* 271 */           this.field = rec.getGroupField(groupsNS);
/*     */         } 
/* 273 */       } catch (Exception e) {
/* 274 */         throw new RuntimeException("Error With Occurs Depending On Field: " + this.variableName, e);
/*     */       } 
/*     */       
/* 277 */       if (this.field == null) {
/* 278 */         throw new RuntimeException("Error With Occurs Depending On Field: " + this.variableName);
/*     */       }
/*     */       
/* 281 */       if (this.field instanceof FieldDetail) {
/* 282 */         ((FieldDetail)this.field).setOccursDependingOnValue(true);
/*     */       }
/*     */ 
/*     */       
/* 286 */       for (IDependingOnIndexDtls idxDtls : this.indexDtls) {
/* 287 */         idxDtls.updateFieldInChildren(rec);
/*     */       }
/*     */       
/* 290 */       List<DependingOn> children2 = ((IDependingOnIndexDtls)this.indexDtls.get(0)).getChildren();
/* 291 */       if (children2 != null && children2.size() > 0)
/* 292 */         for (DependingOn c : children2)
/*     */         {
/* 294 */           this
/*     */             
/* 296 */             .complicatedDependingOn = (this.complicatedDependingOn || c.complicatedDependingOn || !c.variableName.equalsIgnoreCase(c.variableNameNoIndex));
/*     */         } 
/*     */     } 
/*     */   }
/*     */ }

