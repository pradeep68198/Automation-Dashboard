package com.MainFrame.Reader.External.Def;

import java.util.List;
import com.MainFrame.Reader.Common.AbstractRecordX;
import com.MainFrame.Reader.Common.IFieldDetail;

public interface IDependingOnIndexDtls {
  DependingOn getDependingOn();
  
  int getIndex();
  
  void updateFieldInChildren(AbstractRecordX<? extends IFieldDetail> paramAbstractRecordX);
  
  List<DependingOn> getChildren();
}
