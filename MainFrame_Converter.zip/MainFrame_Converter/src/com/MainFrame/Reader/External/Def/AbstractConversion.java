package com.MainFrame.Reader.External.Def;

public interface AbstractConversion {
  public static final int USE_DEFAULT_IDX = -121;
  
  int getType(int paramInt, String paramString);
  
  int getFormat(int paramInt, String paramString);
  
  String getTypeAsString(int paramInt1, int paramInt2);
  
  boolean isValid(int paramInt1, int paramInt2);
  
  String getFormatAsString(int paramInt1, int paramInt2);
  
  String getDialectName(int paramInt);
  
  int getDialect(String paramString);
}

