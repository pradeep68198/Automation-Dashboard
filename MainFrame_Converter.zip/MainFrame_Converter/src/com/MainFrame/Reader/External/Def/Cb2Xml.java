/*     */ package com.MainFrame.Reader.External.Def;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import com.MainFrame.Reader.Log.AbsSSLogger;
/*     */ import com.MainFrame.Reader.Numeric.ConversionManager;
/*     */ import com.MainFrame.Reader.Numeric.Convert;
/*     */ import com.MainFrame.Convert2xml.Cb2Xml2;
/*     */ import com.MainFrame.Convert2xml.Cb2Xml3;
/*     */ import com.MainFrame.Convert2xml.ICb2XmlBuilder;
/*     */ import com.MainFrame.Convert2xml.analysis.Copybook;
/*     */ import com.MainFrame.Convert2xml.def.Cb2xmlConstants;
/*     */ import com.MainFrame.Convert2xml.def.IBasicDialect;
/*     */ import com.MainFrame.Convert2xml.sablecc.lexer.LexerException;
/*     */ import com.MainFrame.Convert2xml.sablecc.parser.ParserException;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cb2Xml
/*     */ {
/*     */   public static final int USE_DEFAULT_THREADSIZE = 0;
/*     */   public static final int CALCULATE_THREAD_SIZE = -1;
/*     */   
/*     */   public static Document convertToXMLDOM(File file, int cobolDialect, boolean debug, int format, AbsSSLogger log) throws ParserException, LexerException, IOException, XMLStreamException {
/*  94 */     return convertToXMLDOM(
/*     */         
/*  96 */         Cb2Xml3.newBuilder(file), cobolDialect, debug, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document convertToXMLDOM(InputStream is, String name, int cobolDialect, boolean debug, int copybookFormat) throws ParserException, LexerException, IOException, XMLStreamException {
/* 176 */     return convertToXMLDOM(
/*     */         
/* 178 */         Cb2Xml3.newBuilder(new InputStreamReader(is), name), cobolDialect, debug, copybookFormat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document convertToXMLDOM(Reader reader, String name, int cobolDialect, boolean debug, int format) throws ParserException, LexerException, IOException, XMLStreamException {
/* 208 */     return convertToXMLDOM(
/*     */         
/* 210 */         Cb2Xml3.newBuilder(reader, name), cobolDialect, debug, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Document convertToXMLDOM(ICb2XmlBuilder bldr, int cobolDialect, boolean debug, int format) throws ParserException, LexerException, IOException, XMLStreamException {
/* 219 */     Convert conv = ConversionManager.getInstance().getConverter4code(cobolDialect);
/* 220 */     bldr
/* 221 */       .setDebug(debug)
/* 222 */       .setCobolLineFormat(format)
/* 223 */       .setLoadComments(false)
/* 224 */       .setXmlFormat(Cb2xmlConstants.Cb2xmlXmlFormat.CLASSIC)
/* 225 */       .setDialect((IBasicDialect)conv);
/*     */     
/* 227 */     return Cb2Xml2.bldrToDocument(bldr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Copybook getCopybook(Reader reader, String name, int cobolDialect, boolean debug, int format, int stackSize) {
/* 254 */     Convert conv = ConversionManager.getInstance().getConverter4code(cobolDialect);
/*     */     
/* 256 */     return 
/* 257 */       Cb2Xml3.newBuilderJRec(reader, name)
/* 258 */       .setDebug(debug)
/* 259 */       .setCobolLineFormat(format)
/* 260 */       .setLoadComments(false)
/* 261 */       .setStackSize(stackSize)
/* 262 */       .setDialect((IBasicDialect)conv)
/* 263 */       .asCobolItemTree();
/*     */   }
/*     */ }

