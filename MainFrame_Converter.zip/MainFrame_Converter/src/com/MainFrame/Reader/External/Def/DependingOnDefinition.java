/*     */ package com.MainFrame.Reader.External.Def;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DependingOnDefinition
/*     */ {
/*     */   public final List<DependingOn> dependOnList;
/*  19 */   int sizeFieldCount = 0;
/*  20 */   int moveableSizeFields = -1;
/*     */   
/*     */   public HashMap<Integer, SizeField> sizeFields;
/*     */   public ArrayList<SizeField> sizeFieldList;
/*     */   
/*     */   public DependingOnDefinition(List<DependingOn> dependOnList) {
/*  26 */     this.dependOnList = dependOnList;
/*     */     
/*  28 */     for (DependingOn c : dependOnList) {
/*  29 */       calcNumberOfSizeFields(new HashMap<String, Integer>(), c);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void calcNumberOfSizeFields(HashMap<String, Integer> fieldMap, DependingOn dependOn) {
/*  35 */     String key = dependOn.getVariableName().toLowerCase();
/*  36 */     Integer num = fieldMap.get(key);
/*     */     
/*  38 */     if (num == null) {
/*  39 */       num = Integer.valueOf(this.sizeFieldCount++);
/*  40 */       fieldMap.put(key, num);
/*     */     } 
/*  42 */     dependOn.fieldNumber = num.intValue();
/*     */     
/*  44 */     List<IDependingOnIndexDtls> indexDtls = dependOn.getIndexDtls();
/*  45 */     if (indexDtls != null) {
/*  46 */       for (IDependingOnIndexDtls id : indexDtls) {
/*  47 */         List<DependingOn> children = id.getChildren();
/*  48 */         if (children != null) {
/*  49 */           for (DependingOn c : children) {
/*  50 */             calcNumberOfSizeFields(fieldMap, c);
/*     */           }
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public int getSizeFieldCount() {
/*  58 */     return this.sizeFieldCount;
/*     */   }
/*     */   
/*     */   public Map<String, SizeField> getNameSizeFieldMap() {
/*  62 */     Map<String, SizeField> ret = new HashMap<String, SizeField>(this.sizeFieldCount * 2);
/*     */     
/*  64 */     for (SizeField sf : this.sizeFieldList) {
/*  65 */       if (sf != null && sf.name != null) {
/*  66 */         String key = sf.name.toLowerCase();
/*  67 */         if (!ret.containsKey(key)) {
/*  68 */           ret.put(key, sf);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  73 */     return ret;
/*     */   }
/*     */   
/*     */   public int getMoveableSizeFields() {
/*  77 */     if (this.moveableSizeFields < 0) {
/*  78 */       this.moveableSizeFields = 0;
/*  79 */       buildSizeFieldMap();
/*     */     } 
/*  81 */     return this.moveableSizeFields;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void buildSizeFieldMap() {
/*  86 */     if (this.sizeFields == null) {
/*  87 */       this.sizeFieldList = new ArrayList<SizeField>(this.sizeFieldCount + 1);
/*  88 */       for (int i = this.sizeFieldCount; i >= 0; i--) {
/*  89 */         this.sizeFieldList.add(null);
/*     */       }
/*  91 */       checkForMovingFields(this.dependOnList, this.sizeFieldList);
/*     */       
/*  93 */       this.sizeFields = new HashMap<Integer, SizeField>(this.sizeFieldCount * 3 / 2);
/*  94 */       for (SizeField sf : this.sizeFieldList) {
/*  95 */         if (sf != null) {
/*  96 */           this.sizeFields.put(Integer.valueOf(sf.position), sf);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SizeField getSizeField(int position) {
/* 111 */     return this.sizeFields.get(Integer.valueOf(position));
/*     */   }
/*     */   
/*     */   private void checkForMovingFields(List<DependingOn> list, List<SizeField> sizeFields) {
/* 115 */     if (list != null && list.size() > 0) {
/* 116 */       for (DependingOn c : list) {
/* 117 */         IFieldDetail field = c.getField();
/* 118 */         if (field.getPos() > ((DependingOn)this.dependOnList.get(0)).getPosition()) {
/* 119 */           this.moveableSizeFields++;
/*     */         }
/*     */         
/* 122 */         if (sizeFields.get(c.fieldNumber) == null) {
/* 123 */           sizeFields.set(c.fieldNumber, new SizeField(field
/*     */ 
/*     */                 
/* 126 */                 .getPos(), c.fieldNumber, c
/* 127 */                 .getVariableNameNoIndex(), 
/* 128 */                 !c.getVariableNameNoIndex().equals(c.getVariableName())));
/*     */         }
/*     */         
/* 131 */         List<IDependingOnIndexDtls> indexDtls = c.getIndexDtls();
/* 132 */         if (indexDtls != null) {
/* 133 */           for (IDependingOnIndexDtls id : indexDtls) {
/* 134 */             checkForMovingFields(id.getChildren(), sizeFields);
/*     */           }
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SizeField
/*     */   {
/*     */     public final int position;
/*     */     public final int fieldNumber;
/*     */     public final String name;
/*     */     public final boolean indexedOD;
/*     */     
/*     */     private SizeField(int position, int fieldNumber, String name, boolean indexedOD) {
/* 149 */       this.position = position;
/* 150 */       this.fieldNumber = fieldNumber;
/* 151 */       this.name = name;
/* 152 */       this.indexedOD = indexedOD;
/*     */     }
/*     */   }
/*     */ }

