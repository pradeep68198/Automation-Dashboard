package com.MainFrame.Reader.External.Def;

public interface Cb2xmlJrConsts {
  public static final int USE_DEFAULT_THREADSIZE = 0;
  
  public static final int CALCULATE_THREAD_SIZE = -1;
}

