/*     */ package com.MainFrame.Reader.External.Def;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Numeric.ConversionManager;
/*     */ import com.MainFrame.Reader.Numeric.Convert;
/*     */ import com.MainFrame.Reader.Types.TypeManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicConversion
/*     */   implements AbstractConversion
/*     */ {
/*     */   private static final int numberOfEntries;
/*  42 */   private static String[] names = new String[40];
/*  43 */   private static String[] externalNames = new String[40];
/*  44 */   private static int[] keys = new int[40];
/*  45 */   private static int[] keysIdx = new int[200];
/*     */   
/*     */   static {
/*  48 */     int i = 0;
/*     */     
/*  50 */     String rdDefault = "Default";
/*  51 */     String rdFixed = "Fixed Length Binary";
/*  52 */     String rdLineBin = "Line based Binary";
/*  53 */     String rdVb = "Mainframe VB (rdw based) Binary";
/*  54 */     String rdVbDump = "Mainframe VB Dump: includes Block length";
/*     */ 
/*     */ 
/*     */     
/*  58 */     keys[i] = 0; externalNames[i] = "Default"; names[i++] = rdDefault;
/*  59 */     keys[i] = 1; externalNames[i] = "Text"; names[i++] = "Text IO";
/*  60 */     keys[i] = 9; externalNames[i] = "Byte_Text"; names[i++] = "Text IO (byte Based)";
/*  61 */     keys[i] = 90; externalNames[i] = "Text_Unicode"; names[i++] = "Text IO (Unicode)";
/*  62 */     keys[i] = 2; externalNames[i] = "Fixed_Length"; names[i++] = rdFixed;
/*  63 */     keys[i] = 10; externalNames[i] = "Fixed_Length_Char"; names[i++] = "Fixed Length Char";
/*     */     
/*  65 */     keys[i] = 3; externalNames[i] = "Binary"; names[i++] = rdLineBin;
/*  66 */     keys[i] = 4; externalNames[i] = "Mainframe_VB"; names[i++] = rdVb;
/*  67 */     keys[i] = 5; externalNames[i] = "Mainframe_VB_As_RECFMU"; names[i++] = rdVbDump;
/*  68 */     keys[i] = 14; externalNames[i] = "VB_DUMP2"; names[i++] = "VB_DUMP2";
/*  69 */     keys[i] = 7; externalNames[i] = "FUJITSU_VB"; names[i++] = "Fujitsu Variable Binary";
/*  70 */     keys[i] = 8; externalNames[i] = "Gnu_Cobol_VB"; names[i++] = "GNU Cobol VB";
/*  71 */     keys[i] = 31; externalNames[i] = "Microfocus_Format"; names[i++] = "Experimental Microfocus Header File";
/*  72 */     keys[i] = 21; externalNames[i] = "UNKOWN_FORMAT"; names[i++] = "Unknown File Format";
/*  73 */     keys[i] = 22; externalNames[i] = "FILE_WIZARD"; names[i++] = "File Wizard";
/*  74 */     keys[i] = 44; externalNames[i] = "CSV_EMBEDDED_CR"; names[i++] = "Csv Embedded Cr";
/*  75 */     keys[i] = 46; externalNames[i] = "UNICODE_CSV_EMBEDDED_CR"; names[i++] = "Unicode Csv Embedded Cr";
/*  76 */     keys[i] = 51; externalNames[i] = "CSV_NAME_1ST_LINE"; names[i++] = "Csv Name on 1st line";
/*  77 */     keys[i] = 47; externalNames[i] = "CSV_NAME_1ST_LINE_EMBEDDED_CR"; names[i++] = "Csv Name on 1st line (Embedded Cr)";
/*  78 */     keys[i] = 54; externalNames[i] = "Byte_Text_NAME_1ST_LINE"; names[i++] = "Text IO (byte Based) name 1st Line";
/*  79 */     keys[i] = 55; externalNames[i] = "UNICODE_CSV_NAME_1ST_LINE"; names[i++] = "Unicode Name on 1st line";
/*  80 */     keys[i] = 49; externalNames[i] = "UNICODE_CSV_NAME_1ST_LINE_EMBEDDED_CR"; names[i++] = "Unicode Name on 1st line (Embedded Cr)";
/*     */     
/*  82 */     keys[i] = 55; externalNames[i] = "UNICODE_CSV_NAME_1ST_LINE_"; names[i++] = "Unicode Name on 1st line";
/*  83 */     keys[i] = 52; externalNames[i] = "CSV_GENERIC"; names[i++] = "Generic CSV (Choose details at run time)";
/*     */     
/*  85 */     keys[i] = 61; externalNames[i] = "XML_Use_Layout"; names[i++] = "XML - Existing Layout";
/*  86 */     keys[i] = 62; externalNames[i] = "XML_Build_Layout"; names[i++] = "XML - Build Layout";
/*  87 */     keys[i] = 11; externalNames[i] = "Continuous"; names[i++] = "Continuous no eol marker";
/*  88 */     keys[i] = 12; externalNames[i] = "Mainframe_VBS"; names[i++] = "Variable Block Spanned (VBS)";
/*     */     
/*  90 */     keys[i] = -121; externalNames[i] = null; names[i] = null;
/*     */     
/*  92 */     keys[i] = 35; externalNames[i] = "FIXED_BYTE_ENTER_FONT"; names[i++] = "Fixed Byte, enter font";
/*  93 */     keys[i] = 36; externalNames[i] = "FIXED_CHAR_ENTER_FONT"; names[i++] = "Fixed Char, enter font";
/*  94 */     keys[i] = 37; externalNames[i] = "TEXT_BYTE_ENTER_FONT"; names[i++] = "Text IO (Byte), Enter Font";
/*  95 */     keys[i] = 38; externalNames[i] = "TEXT_CHAR_ENTER_FONT"; names[i++] = "Text IO (Char), Enter Font";
/*     */     
/*  97 */     if (i < keys.length) {
/*  98 */       keys[i] = -121;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 103 */     numberOfEntries = i;
/*     */     
/* 105 */     Arrays.fill(keysIdx, -1);
/*     */     
/* 107 */     for (int j = 0; j < numberOfEntries; j++) {
/* 108 */       int idx = keys[j];
/* 109 */       if (idx >= 0 && keysIdx[idx] < 0) {
/* 110 */         keysIdx[idx] = j;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String[] typeNames;
/*     */   
/*     */   private HashMap<String, Integer> typeNumbers;
/* 119 */   private HashMap<String, Integer> dialectLookup = new HashMap<String, Integer>(50);
/* 120 */   private HashMap<Integer, String> dialectNameLookup = new HashMap<Integer, String>(50);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicConversion() {
/* 127 */     TypeManager manager = TypeManager.getInstance();
/* 128 */     this.typeNames = new String[manager.getNumberOfTypes()];
/* 129 */     this.typeNumbers = new HashMap<String, Integer>(manager.getNumberOfTypes() * 2);
/*     */     
/* 131 */     for (int i = 0; i < this.typeNames.length; i++) {
/* 132 */       this.typeNames[i] = "";
/*     */     }
/*     */     
/* 135 */     setName(0, "Char");
/* 136 */     setName(19, "Number any decimal", "NumAnyDecimal");
/* 137 */     setName(131, "Number any decimal or Empty", "NumberOrEmpty");
/* 138 */     setName(20, "PositiveNumAnyDecimal", "Number (+ve) any decimal");
/* 139 */     setName(1, "Char (right justified)");
/* 140 */     setName(2, "Char Null terminated");
/* 141 */     setName(3, "Char Null padded");
/* 142 */     setName(82, "Char (no Trim)");
/* 143 */     setName(4, "Hex Field");
/* 144 */     setName(5, "Num (Left Justified)");
/* 145 */     setName(6, "Num (Right Justified space padded)");
/* 146 */     setName(29, "Num (Right Justified space padded) +/- sign");
/* 147 */     setName(42, "Num (Right Just space padded, \",\" Decimal)");
/* 148 */     setName(43, "Num (Right Just space padded, \",\" Decimal) +/- sign", "Num (Right Just space padded, \",\" Decimal) +/- sig");
/* 149 */     setName(7, "Num (Right Justified zero padded)", "Zero Padded Number with sign=+/-");
/* 150 */     setName(24, "Num (Right Justified zero padded +/- sign)", "Zero Padded Number with sign=+/-");
/* 151 */     setName(8, "Num Assumed Decimal (Zero padded)");
/* 152 */     setName(22, "Num Assumed Decimal (+ve)");
/* 153 */     setName(25, "Num (Right Justified zero padded positive)", "Positive Zero Padded Number");
/* 154 */     setName(26, "Zero Padded Number decimal=\",\"");
/* 155 */     setName(27, "Zero Padded Number decimal=\",\" sign=+/-");
/* 156 */     setName(28, "Zero Padded Number decimal=\",\" (only +ve)");
/*     */ 
/*     */     
/* 159 */     setName(9, "Num Sign Separate Leading");
/* 160 */     setName(10, "Num Sign Separate Trailing");
/* 161 */     setName(44, "Num Sign Sep Leading Actual Dec");
/* 162 */     setName(45, "Num Sign Sep Trailing Actual Dec");
/* 163 */     setName(11, "Decimal");
/* 164 */     setName(15, "Binary Integer");
/* 165 */     setName(23, "Binary Integer (only +ve)");
/* 166 */     setName(16, "Postive Binary Integer");
/* 167 */     setName(17, "Float");
/* 168 */     setName(18, "Double");
/* 169 */     setName(21, "Bit");
/* 170 */     setName(31, "Mainframe Packed Decimal (comp-3)");
/* 171 */     setName(33, "Mainframe Packed Decimal (+ve)");
/* 172 */     setName(32, "Mainframe Zoned Numeric");
/* 173 */     this.typeNumbers.put("Binary Integer Big Edian (Mainframe, AIX etc)".toLowerCase(), Integer.valueOf(35));
/*     */     
/* 175 */     setName(35, "Binary Integer Big Endian (Mainframe?)", "Binary Integer Big Endian (Mainframe, AIX etc)");
/* 176 */     setName(39, "Binary Integer Big Endian (only +ve)", "Binary Integer Big Endian (only +ve )");
/* 177 */     setName(36, "Positive Integer Big Endian", "Positive Integer (Big Endian)");
/* 178 */     setName(41, "Fujitsu Zoned Numeric");
/* 179 */     setName(46, "GNU Cobol Zoned Numeric");
/*     */ 
/*     */     
/* 182 */     setName(37, "Rm Cobol Comp");
/* 183 */     setName(38, "Rm Cobol Comp (+ve)", "RM Cobol Positive Comp");
/* 184 */     setName(114, "Check Box (Boolean)");
/*     */ 
/*     */     
/* 187 */     setName(71, "Date - Format in Parameter field");
/* 188 */     setName(72, "Date - YYMMDD");
/* 189 */     setName(73, "Date - YYYYMMDD");
/* 190 */     setName(74, "Date - DDMMYY");
/* 191 */     setName(75, "Date - DDMMYYYY");
/* 192 */     setName(110, "Check Box True / Space");
/* 193 */     setName(109, "Checkbox Y/<null>", "CheckBox Y/null");
/* 194 */     setName(111, "Checkbox Y/N");
/* 195 */     setName(112, "Checkbox T/F");
/* 196 */     setName(115, "CSV array");
/* 197 */     setName(116, "XML Name Tag");
/* 198 */     setName(117, "Edit Multi Line field");
/*     */     
/* 200 */     setName(80, "Char Rest of Fixed Length");
/* 201 */     setName(81, "Char Rest of Record");
/* 202 */     setName(118, "Char (Multi-Line)", "Char Multi Line");
/*     */ 
/*     */     
/* 205 */     setName(51, "Char (Multi-Line)");
/* 206 */     setName(119, "Html Field");
/* 207 */     setName(92, "Array Field");
/* 208 */     setName(130, "RecordEditor_Type");
/*     */     
/* 210 */     ConversionManager dialectMgr = ConversionManager.getInstance();
/*     */     
/* 212 */     for (int j = 0; j < dialectMgr.getNumberOfEntries(); j++) {
/* 213 */       Convert converter = dialectMgr.getConverter(j);
/* 214 */       String name = Conversion.replace(converter.getName(), " ", "_").toString();
/* 215 */       this.dialectLookup.put(name.toLowerCase(), Integer.valueOf(converter.getIdentifier()));
/* 216 */       this.dialectLookup.put(converter.getName().toLowerCase(), Integer.valueOf(converter.getIdentifier()));
/* 217 */       this.dialectLookup.put(Integer.toString(converter.getIdentifier()), Integer.valueOf(converter.getIdentifier()));
/* 218 */       this.dialectNameLookup.put(Integer.valueOf(converter.getIdentifier()), name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Integer setName(int type, String name) {
/* 228 */     this.typeNames[TypeManager.getInstance().getIndex(type)] = name;
/* 229 */     Integer typeId = Integer.valueOf(type);
/* 230 */     this.typeNumbers.put(name.toLowerCase(), typeId);
/* 231 */     if (name.length() > 40) {
/* 232 */       this.typeNumbers.put(name.toLowerCase().substring(0, 40), typeId);
/*     */     }
/* 234 */     return typeId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setName(int type, String name, String altname) {
/* 243 */     Integer typeId = setName(type, name);
/* 244 */     this.typeNumbers.put(altname.toLowerCase(), typeId);
/* 245 */     if (altname.length() > 40) {
/* 246 */       this.typeNumbers.put(altname.toLowerCase().substring(0, 40), typeId);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFormat(int idx, String format) {
/* 253 */     if (format != null && !"".equals(format)) {
/*     */       try {
/* 255 */         return Integer.parseInt(format);
/* 256 */       } catch (Exception exception) {}
/*     */     }
/*     */     
/* 259 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFormatAsString(int idx, int format) {
/* 264 */     return Integer.toString(format);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType(int idx, String type) {
/* 269 */     String key = type.toLowerCase();
/* 270 */     if (this.typeNumbers.containsKey(key)) {
/* 271 */       return ((Integer)this.typeNumbers.get(key)).intValue();
/*     */     }
/* 273 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTypeAsString(int idx, int type) {
/* 279 */     String s = this.typeNames[TypeManager.getInstance().getIndex(type)];
/* 280 */     if (s == null || "".equals(s)) {
/* 281 */       s = Integer.toString(type);
/*     */     }
/* 283 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidTypeName(String name) {
/* 289 */     return (name != null && name.length() > 0 && this.typeNumbers.containsKey(name.toLowerCase()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid(int idx, int type) {
/* 297 */     String s = this.typeNames[TypeManager.getInstance().getIndex(type)];
/* 298 */     return (s != null && !"".equals(s));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDialect(String name) {
/* 304 */     int ret = -1;
/*     */     
/* 306 */     if (name != null) {
/* 307 */       Integer lookup = this.dialectLookup.get(name.trim().toLowerCase());
/* 308 */       if (lookup != null) {
/* 309 */         ret = lookup.intValue();
/*     */       } else {
/*     */         try {
/* 312 */           ret = Integer.parseInt(name);
/* 313 */         } catch (NumberFormatException e) {
/* 314 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 319 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDialectName(int key) {
/* 325 */     String ret = "";
/*     */     
/* 327 */     String lookup = this.dialectNameLookup.get(Integer.valueOf(key));
/* 328 */     if (lookup != null) {
/* 329 */       ret = lookup;
/*     */     }
/*     */     
/* 332 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getStructureName(int fileStructure) {
/* 344 */     if (fileStructure >= 0 && fileStructure < keysIdx.length) {
/* 345 */       int idx = keysIdx[fileStructure];
/* 346 */       if (idx >= 0)
/*     */       {
/* 348 */         return externalNames[idx];
/*     */       }
/*     */     } 
/* 351 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getStructureNameForIndex(int index) {
/* 356 */     return externalNames[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getStructure(String name) {
/* 366 */     for (int i = 0; i < numberOfEntries && keys[i] != -121; i++) {
/* 367 */       if (externalNames[i].equalsIgnoreCase(name)) {
/* 368 */         return keys[i];
/*     */       }
/*     */     } 
/* 371 */     return -121;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getFileStructureForIndex(int idx) {
/* 377 */     return keys[idx];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFileStructureNameForIndex(int idx) {
/* 384 */     return names[idx];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getNumberOfFileStructures() {
/* 390 */     return numberOfEntries;
/*     */   }
/*     */ }

