/*    */ package com.MainFrame.Reader.charIO;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixedLengthCharWriter
/*    */   extends BaseCharWriter
/*    */ {
/*    */   private final int length;
/*    */   private final String font;
/*    */   
/*    */   public FixedLengthCharWriter(int length, String charset) {
/* 40 */     this.length = length;
/* 41 */     this.font = charset;
/*    */   }
/*    */ 
/*    */   
/*    */   public void open(OutputStream outputStream) throws IOException {
/* 46 */     if (this.font == null || this.font.length() == 0) {
/* 47 */       this.w = new OutputStreamWriter(outputStream);
/*    */     } else {
/* 49 */       this.w = new OutputStreamWriter(outputStream, this.font);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(char[] line) throws IOException {
/* 55 */     if (line.length > this.length) {
/* 56 */       this.w.write(line, 0, this.length);
/*    */     } else {
/* 58 */       char[] c = new char[this.length - line.length];
/* 59 */       Arrays.fill(c, ' ');
/* 60 */       this.w.write(line);
/* 61 */       this.w.write(c);
/*    */     } 
/*    */   }
/*    */ }

