/*    */ package com.MainFrame.Reader.charIO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharIOProvider
/*    */ {
/* 31 */   public static final CharIOProvider INSTANCE = new CharIOProvider();
/*    */   
/*    */   public ICharWriter getWriter(int id, String font, String eol, int length) {
/* 34 */     ICharWriter ret = null;
/* 35 */     switch (id) { case 10:
/*    */       case 36:
/* 37 */         ret = new FixedLengthCharWriter(length, font); break;
/*    */       case 38: case 44:
/*    */       case 47:
/*    */       case 90:
/* 41 */         ret = new StandardCharWriter(eol, font);
/*    */         break; }
/*    */     
/* 44 */     return ret;
/*    */   }
/*    */ }

