package com.MainFrame.Reader.charIO;

import java.io.IOException;
import java.io.OutputStream;

public interface ICharWriter {
  void open(String paramString) throws IOException;
  
  void open(OutputStream paramOutputStream) throws IOException;
  
  void write(String paramString) throws IOException;
  
  void write(char[] paramArrayOfchar) throws IOException;
  
  void close() throws IOException;
}

