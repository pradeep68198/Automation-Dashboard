/*     */ package com.MainFrame.Reader.charIO;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsvCharReader
/*     */   implements ICharReader
/*     */ {
/*  49 */   private static final char[] CR_CHARS = new char[] { '\r' };
/*  50 */   private static final char[] CRLF_CHARS = new char[] { '\r', '\n' };
/*  51 */   private static final char[] LF_CHARS = new char[] { '\n' };
/*     */   
/*     */   private boolean useStdEolCheck;
/*     */   
/*  55 */   private static final char[] EMPTY = new char[0];
/*  56 */   private static final char[] NO_EOL = EMPTY;
/*     */   
/*     */   private static final char charLF = '\n';
/*     */   private static final char charCR = '\r';
/*     */   
/*  61 */   private static FindLines NO_EOL_FINDLINES = new FindLines()
/*     */     {
/*     */       public void findLinesInBuffer(int start) {}
/*     */     };
/*     */ 
/*     */   
/*     */   public static final int BUFFER_SIZE = 16384;
/*  68 */   protected final char[] buffer = new char[262144];
/*     */   
/*     */   private final char[] fieldSep;
/*     */   
/*     */   private final char[] quote;
/*     */   private final char[] quoteEsc;
/*     */   private final char[] sepQuote;
/*     */   private final char[] quoteSep;
/*  76 */   private char[] quoteEol = EMPTY;
/*  77 */   private char[] quoteEol2 = EMPTY;
/*  78 */   private char[] eol = null;
/*     */   
/*  80 */   private InputStream inStream = null;
/*  81 */   private Reader in = null;
/*     */   private boolean eof;
/*     */   private boolean eofPending;
/*     */   private int charsInBuffer;
/*  85 */   private final int[] lineArray = new int[16];
/*     */   
/*     */   private int noLines;
/*     */   
/*     */   private int lineNo;
/*     */   
/*     */   private boolean check4cr = false;
/*     */   private boolean check4lf = false;
/*  93 */   protected FindLines findLines = NO_EOL_FINDLINES;
/*     */   
/*     */   public CsvCharReader(String fieldSep, String quote, String quoteEsc, boolean useStdEolCheck) {
/*  96 */     this(null, fieldSep
/*  97 */         .toCharArray(), (quote == null) ? null : quote
/*  98 */         .toCharArray(), (quoteEsc == null) ? null : quoteEsc
/*  99 */         .toCharArray(), useStdEolCheck);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsvCharReader(char[] eol, char[] fieldSep, char[] quote, char[] quoteEsc, boolean useStdEolCheck) {
/* 106 */     this.eol = eol;
/* 107 */     this.fieldSep = fieldSep;
/* 108 */     this.quoteEsc = (quoteEsc == null) ? EMPTY : quoteEsc;
/* 109 */     this.useStdEolCheck = useStdEolCheck;
/*     */     
/* 111 */     if (quote == null || quote.length == 0) {
/* 112 */       this.quote = EMPTY;
/* 113 */       this.sepQuote = EMPTY;
/* 114 */       this.quoteSep = EMPTY;
/*     */     } else {
/* 116 */       this.quote = quote;
/* 117 */       this.sepQuote = new char[fieldSep.length + quote.length];
/* 118 */       this.quoteSep = new char[this.sepQuote.length];
/*     */       
/* 120 */       System.arraycopy(fieldSep, 0, this.sepQuote, 0, fieldSep.length);
/* 121 */       System.arraycopy(quote, 0, this.sepQuote, fieldSep.length, quote.length);
/*     */       
/* 123 */       System.arraycopy(quote, 0, this.quoteSep, 0, quote.length);
/* 124 */       System.arraycopy(fieldSep, 0, this.quoteSep, quote.length, fieldSep.length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(String fileName, String font) throws IOException {
/* 133 */     open(new FileInputStream(fileName), font);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(InputStream inputStream, String font) throws IOException {
/* 141 */     this.inStream = inputStream;
/* 142 */     if (font == null || font.length() == 0) {
/* 143 */       this.in = new InputStreamReader(inputStream);
/*     */     } else {
/* 145 */       this.in = new InputStreamReader(inputStream, font);
/*     */     } 
/* 147 */     this.eof = false;
/*     */ 
/*     */     
/* 150 */     this.charsInBuffer = readBuffer(this.in, this.buffer, 0);
/* 151 */     this.eofPending = (this.charsInBuffer < this.buffer.length);
/*     */ 
/*     */     
/* 154 */     if (this.eol == null) {
/* 155 */       int size = 0;
/*     */       
/* 157 */       if (!this.useStdEolCheck) {
/* 158 */         FindLines eolSearch; char[] qEol1 = new char[this.quote.length + 1];
/* 159 */         char[] qEol2 = new char[this.quote.length + 1];
/* 160 */         char[] qEol3 = new char[this.quote.length + CRLF_CHARS.length];
/*     */         
/* 162 */         SearchDtls searchDtls = new SearchDtls();
/*     */         
/* 164 */         System.arraycopy(this.quote, 0, qEol1, 0, this.quote.length);
/* 165 */         System.arraycopy(CR_CHARS, 0, qEol1, this.quote.length, CR_CHARS.length);
/* 166 */         System.arraycopy(this.quote, 0, qEol2, 0, this.quote.length);
/* 167 */         System.arraycopy(LF_CHARS, 0, qEol2, this.quote.length, LF_CHARS.length);
/* 168 */         System.arraycopy(this.quote, 0, qEol3, 0, this.quote.length);
/* 169 */         System.arraycopy(CRLF_CHARS, 0, qEol3, this.quote.length, CRLF_CHARS.length);
/*     */ 
/*     */         
/* 172 */         if (this.quoteEsc.length == 0) {
/* 173 */           eolSearch = new NoQuoteEsc(qEol1, qEol2, qEol3, searchDtls);
/*     */         } else {
/* 175 */           eolSearch = new QuoteEsc(qEol1, qEol2, qEol3, searchDtls);
/*     */         } 
/* 177 */         eolSearch.findLinesInBuffer(0);
/*     */         
/* 179 */         this.useStdEolCheck = true;
/* 180 */         if (searchDtls.noLines > 0) {
/* 181 */           size = this.lineArray[0] - 1;
/* 182 */           this.useStdEolCheck = false;
/*     */         } 
/*     */       } 
/*     */       
/* 186 */       if (this.useStdEolCheck) {
/* 187 */         while (size < this.charsInBuffer && this.buffer[size] != '\r' && this.buffer[size] != '\n') {
/* 188 */           size++;
/*     */         }
/*     */       }
/*     */       
/* 192 */       if (size >= this.charsInBuffer) {
/* 193 */         this.eol = NO_EOL;
/* 194 */       } else if (this.buffer[size] == '\r') {
/* 195 */         if (size + 1 < this.charsInBuffer && this.buffer[size + 1] == '\n') {
/* 196 */           this.eol = CRLF_CHARS;
/*     */         } else {
/*     */           
/* 199 */           this.eol = CR_CHARS;
/* 200 */           this.check4lf = true;
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 208 */         this.eol = LF_CHARS;
/* 209 */         this.check4cr = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 215 */     setLineSearch();
/*     */     
/* 217 */     findLinesInBuffer(0);
/* 218 */     this.lineNo = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String read() throws IOException {
/* 225 */     if (this.in == null) {
/* 226 */       throw new IOException("File has not been opened");
/*     */     }
/* 228 */     if (this.eof) {
/* 229 */       return null;
/*     */     }
/*     */     
/* 232 */     char[] ret = null;
/* 233 */     int lno = getLineNo();
/* 234 */     int srcPos = this.lineArray[lno];
/*     */     
/* 236 */     if (this.check4lf && srcPos < this.buffer.length && this.buffer[srcPos] == '\n') {
/* 237 */       srcPos++;
/*     */     }
/*     */     
/* 240 */     if (this.eof) {
/* 241 */       if (this.charsInBuffer <= srcPos) {
/* 242 */         return null;
/*     */       }
/* 244 */       ret = new char[this.charsInBuffer - srcPos];
/*     */     } else {
/* 246 */       int eolLength = this.eol.length;
/* 247 */       if (this.check4cr && this.buffer[this.lineArray[lno + 1] - eolLength - 1] == '\r') {
/* 248 */         eolLength++;
/*     */       }
/*     */ 
/*     */       
/* 252 */       ret = new char[this.lineArray[lno + 1] - srcPos - eolLength];
/*     */     } 
/*     */     
/* 255 */     System.arraycopy(this.buffer, srcPos, ret, 0, ret.length);
/*     */ 
/*     */     
/* 258 */     return new String(ret);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 268 */     if (this.in != null) {
/* 269 */       this.inStream.close();
/* 270 */       this.in.close();
/*     */       
/* 272 */       this.in = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLineSearch() {
/* 281 */     this.quoteEol = this.eol;
/*     */     
/* 283 */     if (this.eol.length == 0) {
/* 284 */       this.quoteEol = EMPTY;
/* 285 */     } else if (this.quote.length == 0) {
/* 286 */       this.findLines = new StdFindLines();
/*     */     } else {
/* 288 */       this.quoteEol = new char[this.quote.length + this.eol.length];
/* 289 */       System.arraycopy(this.quote, 0, this.quoteEol, 0, this.quote.length);
/* 290 */       System.arraycopy(this.eol, 0, this.quoteEol, this.quote.length, this.eol.length);
/*     */       
/* 292 */       if (this.check4lf) {
/* 293 */         this.quoteEol2 = new char[this.quote.length + 2];
/* 294 */         System.arraycopy(this.quote, 0, this.quoteEol2, 0, this.quote.length);
/* 295 */         this.quoteEol2[this.quote.length] = '\n';
/* 296 */         this.quoteEol2[this.quote.length + 1] = '\r';
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 308 */       if (this.quoteEsc.length == 0) {
/*     */ 
/*     */         
/* 311 */         this.findLines = new NoQuoteEsc();
/*     */       }
/*     */       else {
/*     */         
/* 315 */         this.findLines = new QuoteEsc();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getLineNo() throws IOException {
/* 339 */     this.lineNo++;
/* 340 */     if (this.lineNo == this.noLines - 1) {
/* 341 */       if (this.eofPending && this.noLines < this.lineArray.length) {
/* 342 */         this.eof = true;
/*     */       } else {
/* 344 */         findLinesInBuffer(this.lineArray[this.lineNo]);
/* 345 */         if (this.noLines == 1) {
/* 346 */           if (this.eofPending) {
/* 347 */             this.eof = true;
/*     */           } else {
/* 349 */             int len = this.charsInBuffer - this.lineArray[this.lineNo];
/* 350 */             System.arraycopy(this.buffer, this.lineArray[this.lineNo], this.buffer, 0, len);
/*     */             
/* 352 */             this.charsInBuffer = readBuffer(this.in, this.buffer, len);
/* 353 */             this.eofPending = (this.charsInBuffer < this.buffer.length);
/*     */             
/* 355 */             findLinesInBuffer(0);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 361 */     return this.lineNo;
/*     */   }
/*     */   
/*     */   private void findLinesInBuffer(int start) {
/* 365 */     this.lineArray[0] = start;
/* 366 */     this.noLines = 1;
/* 367 */     this.lineNo = 0;
/* 368 */     this.findLines.findLinesInBuffer(start);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean checkFor(int pos, char[] search) {
/* 427 */     if (pos < search.length - 1 || search.length == 0) {
/* 428 */       return false;
/*     */     }
/*     */     
/* 431 */     int bufferStart = pos - search.length + 1;
/* 432 */     for (int i = 0; i < search.length; i++) {
/* 433 */       if (search[i] != this.buffer[bufferStart + i]) {
/* 434 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 438 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private static interface FindLines
/*     */   {
/*     */     void findLinesInBuffer(int param1Int);
/*     */   }
/*     */ 
/*     */   
/*     */   private class StdFindLines
/*     */     implements FindLines
/*     */   {
/*     */     private StdFindLines() {}
/*     */     
/*     */     public void findLinesInBuffer(int start) {
/* 454 */       char last = Character.MIN_VALUE;
/* 455 */       int idx = CsvCharReader.this.eol.length - 1;
/*     */       
/* 457 */       while (CsvCharReader.this.noLines < CsvCharReader.this.lineArray.length && start < CsvCharReader.this.charsInBuffer && start >= 0) {
/* 458 */         if (CsvCharReader.this.buffer[start] == CsvCharReader.this.eol[idx] && (CsvCharReader.this.eol.length == 1 || last == CsvCharReader.this.eol[0])) {
/* 459 */           CsvCharReader.this.lineArray[CsvCharReader.this.noLines] = start + 1;
/* 460 */           CsvCharReader.this.noLines = CsvCharReader.this.noLines + 1;
/*     */         } 
/*     */         
/* 463 */         last = CsvCharReader.this.buffer[start];
/* 464 */         start++;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private class NoQuoteEsc
/*     */     implements FindLines
/*     */   {
/*     */     private final char[] quoteEol1;
/*     */     private final char[] quoteEol2;
/*     */     private final char[] quoteEol3;
/*     */     private final CsvCharReader.ILineNoDtls dtls;
/*     */     
/*     */     public NoQuoteEsc() {
/* 478 */       this(CsvCharReader.this.quoteEol, CsvCharReader.this.quoteEol2, CsvCharReader.EMPTY, new CsvCharReader.StdLineNoDtls());
/*     */     }
/*     */ 
/*     */     
/*     */     public NoQuoteEsc(char[] quoteEol, char[] quoteEol2, char[] quoteEol3, CsvCharReader.ILineNoDtls dtls) {
/* 483 */       this.quoteEol1 = quoteEol;
/* 484 */       this.quoteEol2 = quoteEol2;
/* 485 */       this.quoteEol3 = quoteEol3;
/* 486 */       this.dtls = dtls;
/*     */     }
/*     */ 
/*     */     
/*     */     public void findLinesInBuffer(int start) {
/* 491 */       int lineStart = start;
/* 492 */       int fieldStart = start;
/* 493 */       boolean inQuote = false;
/*     */ 
/*     */       
/* 496 */       while (this.dtls.getNoLines() < CsvCharReader.this.lineArray.length && start < CsvCharReader.this.charsInBuffer && start >= 0) {
/* 497 */         if (CsvCharReader.this.checkFor(start, CsvCharReader.this.sepQuote) || (lineStart == start - CsvCharReader.this
/* 498 */           .quote.length + 1 && CsvCharReader.this.checkFor(start, CsvCharReader.this.quote))) {
/*     */           
/* 500 */           inQuote = true;
/* 501 */         } else if ((inQuote && fieldStart != start - CsvCharReader.this
/* 502 */           .quoteSep.length + 1 && CsvCharReader.this
/* 503 */           .checkFor(start, CsvCharReader.this.quoteSep)) || (!inQuote && CsvCharReader.this
/* 504 */           .checkFor(start, CsvCharReader.this.fieldSep))) {
/* 505 */           fieldStart = start + 1;
/* 506 */           inQuote = false;
/* 507 */         } else if ((CsvCharReader.this.checkFor(start, this.quoteEol1) && fieldStart != start - this.quoteEol1.length + 1) || (CsvCharReader.this
/* 508 */           .checkFor(start, this.quoteEol2) && fieldStart != start - this.quoteEol2.length + 1) || (CsvCharReader.this
/* 509 */           .checkFor(start, this.quoteEol3) && fieldStart != start - this.quoteEol3.length + 1) || (!inQuote && this.dtls
/* 510 */           .isEol(start))) {
/* 511 */           lineStart = start + 1;
/* 512 */           fieldStart = lineStart;
/* 513 */           CsvCharReader.this.lineArray[this.dtls.getNoLines()] = lineStart;
/* 514 */           this.dtls.incNoLines();
/* 515 */           inQuote = false;
/* 516 */         } else if (CsvCharReader.this.check4cr && CsvCharReader.this.buffer[start] == '\r' && lineStart == start) {
/*     */           
/* 518 */           fieldStart = ++lineStart;
/*     */         } 
/*     */         
/* 521 */         start++;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private class QuoteEsc
/*     */     implements FindLines
/*     */   {
/*     */     private final char[] quoteEol1;
/*     */     private final char[] quoteEol2;
/*     */     private final char[] quoteEol3;
/*     */     private final CsvCharReader.ILineNoDtls dtls;
/*     */     
/*     */     public QuoteEsc() {
/* 535 */       this(CsvCharReader.this.quoteEol, CsvCharReader.this.quoteEol2, CsvCharReader.EMPTY, new CsvCharReader.StdLineNoDtls());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public QuoteEsc(char[] quoteEol, char[] quoteEol2, char[] quoteEol3, CsvCharReader.ILineNoDtls dtls) {
/* 541 */       this.quoteEol1 = quoteEol;
/* 542 */       this.quoteEol2 = quoteEol2;
/* 543 */       this.quoteEol3 = quoteEol3;
/* 544 */       this.dtls = dtls;
/*     */     }
/*     */     
/*     */     public void findLinesInBuffer(int start) {
/* 548 */       int lineStart = start;
/* 549 */       int fieldStart = start;
/* 550 */       boolean inQuote = false;
/*     */       
/* 552 */       int quoteEscPos = -121;
/*     */       
/* 554 */       while (this.dtls.getNoLines() < CsvCharReader.this.lineArray.length && start < CsvCharReader.this.charsInBuffer && start >= 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 575 */         if (CsvCharReader.this.checkFor(start, CsvCharReader.this.sepQuote) || (lineStart == start - CsvCharReader.this
/* 576 */           .quote.length + 1 && CsvCharReader.this.checkFor(start, CsvCharReader.this.quote))) {
/* 577 */           inQuote = true;
/* 578 */         } else if (!this.dtls.isQuoteEscEol(quoteEscPos, start) && (quoteEscPos < start - CsvCharReader.this
/* 579 */           .fieldSep.length || 
/* 580 */           !CsvCharReader.this.checkFor(start, CsvCharReader.this.fieldSep)) && (quoteEscPos <= start - CsvCharReader.this
/* 581 */           .quoteEsc.length || 
/* 582 */           !CsvCharReader.this.checkFor(start, CsvCharReader.this.quote))) {
/*     */           
/* 584 */           if (inQuote && fieldStart <= start - CsvCharReader.this
/* 585 */             .quoteEsc.length - CsvCharReader.this.quote.length + 1 && CsvCharReader.this
/* 586 */             .checkFor(start, CsvCharReader.this.quoteEsc)) {
/*     */ 
/*     */ 
/*     */             
/* 590 */             quoteEscPos = start;
/* 591 */           } else if ((inQuote && CsvCharReader.this.checkFor(start, CsvCharReader.this.quoteSep) && fieldStart != start - CsvCharReader.this.quoteSep.length + 1) || (!inQuote && CsvCharReader.this
/* 592 */             .checkFor(start, CsvCharReader.this.fieldSep))) {
/*     */             
/* 594 */             fieldStart = start + 1;
/* 595 */             inQuote = false;
/* 596 */           } else if ((CsvCharReader.this.checkFor(start, this.quoteEol1) && fieldStart != start - this.quoteEol1.length + 1) || (CsvCharReader.this
/* 597 */             .checkFor(start, this.quoteEol2) && fieldStart != start - this.quoteEol2.length + 1) || (CsvCharReader.this
/* 598 */             .checkFor(start, this.quoteEol3) && fieldStart != start - this.quoteEol3.length + 1) || (!inQuote && this.dtls
/* 599 */             .isEol(start))) {
/* 600 */             lineStart = start + 1;
/* 601 */             fieldStart = lineStart;
/* 602 */             CsvCharReader.this.lineArray[this.dtls.getNoLines()] = lineStart;
/* 603 */             this.dtls.incNoLines();
/* 604 */             inQuote = false;
/*     */           
/*     */           }
/* 607 */           else if (CsvCharReader.this.check4cr && CsvCharReader.this.buffer[start] == '\r' && lineStart == start) {
/*     */ 
/*     */             
/* 610 */             lineStart++;
/* 611 */             fieldStart++;
/*     */           } 
/*     */         } 
/* 614 */         start++;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int readBuffer(Reader in, char[] buf, int total) throws IOException {
/* 623 */     int num = in.read(buf, total, buf.length - total);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 628 */     while (num >= 0 && total + num < buf.length) {
/* 629 */       total += num;
/* 630 */       num = in.read(buf, total, buf.length - total);
/*     */     } 
/*     */     
/* 633 */     if (num > 0) {
/* 634 */       total += num;
/*     */     }
/*     */     
/* 637 */     return total;
/*     */   }
/*     */   
/*     */   public String getEol() {
/* 641 */     return new String(this.eol);
/*     */   }
/*     */ 
/*     */   
/*     */   private static interface ILineNoDtls
/*     */   {
/*     */     int getNoLines();
/*     */     
/*     */     void incNoLines();
/*     */     
/*     */     boolean isQuoteEscEol(int param1Int1, int param1Int2);
/*     */     
/*     */     boolean isEol(int param1Int);
/*     */   }
/*     */   
/*     */   private class StdLineNoDtls
/*     */     implements ILineNoDtls
/*     */   {
/*     */     private StdLineNoDtls() {}
/*     */     
/*     */     public int getNoLines() {
/* 662 */       return CsvCharReader.this.noLines;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void incNoLines() {
/* 670 */       CsvCharReader.this.noLines = CsvCharReader.this.noLines + 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isQuoteEscEol(int quoteEscPos, int start) {
/* 682 */       return (quoteEscPos == start - CsvCharReader.this.eol.length && CsvCharReader.this
/* 683 */         .checkFor(start, CsvCharReader.this.eol));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEol(int start) {
/* 689 */       return CsvCharReader.this.checkFor(start, CsvCharReader.this.eol);
/*     */     }
/*     */   }
/*     */   
/*     */   private class SearchDtls
/*     */     implements ILineNoDtls {
/* 695 */     int noLines = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getNoLines() {
/* 702 */       return this.noLines;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void incNoLines() {
/* 710 */       this.noLines++;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isQuoteEscEol(int quoteEscPos, int start) {
/* 718 */       return ((quoteEscPos == start - CsvCharReader.LF_CHARS.length && (CsvCharReader.this
/* 719 */         .checkFor(start, CsvCharReader.LF_CHARS) || CsvCharReader.this.checkFor(start, CsvCharReader.CR_CHARS))) || (quoteEscPos == start - CsvCharReader
/* 720 */         .CRLF_CHARS.length && CsvCharReader.this.checkFor(start, CsvCharReader.CRLF_CHARS)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEol(int start) {
/* 727 */       return (CsvCharReader.this.checkFor(start, CsvCharReader.LF_CHARS) || CsvCharReader.this
/* 728 */         .checkFor(start, CsvCharReader.CR_CHARS));
/*     */     }
/*     */     
/*     */     private SearchDtls() {}
/*     */   }
/*     */ }
