/*    */ package com.MainFrame.Reader.charIO;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardCharWriter
/*    */   extends BaseCharWriter
/*    */ {
/*    */   private final String eol;
/*    */   private final String font;
/*    */   
/*    */   public StandardCharWriter(String eol, String charset) {
/* 39 */     this.eol = eol;
/* 40 */     this.font = charset;
/*    */   }
/*    */ 
/*    */   
/*    */   public void open(OutputStream outputStream) throws IOException {
/* 45 */     if (this.font == null || this.font.length() == 0) {
/* 46 */       this.w = new OutputStreamWriter(outputStream);
/*    */     } else {
/* 48 */       this.w = new OutputStreamWriter(outputStream, this.font);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(char[] line) throws IOException {
/* 55 */     this.w.write(line);
/* 56 */     this.w.write(this.eol);
/*    */   }
/*    */ }

