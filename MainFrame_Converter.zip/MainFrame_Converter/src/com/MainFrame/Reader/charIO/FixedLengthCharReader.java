/*    */ package com.MainFrame.Reader.charIO;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixedLengthCharReader
/*    */   extends BaseCharReader
/*    */ {
/*    */   private final int length;
/*    */   private boolean eofPending = false;
/*    */   
/*    */   public FixedLengthCharReader(int length) {
/* 46 */     this.length = length;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String read() throws IOException {
/* 54 */     if (this.eofPending) return null;
/*    */     
/* 56 */     char[] c = new char[this.length];
/*    */     
/* 58 */     int l = this.reader.read(c, 0, this.length);
/* 59 */     if (l < 0) {
/* 60 */       return null;
/*    */     }
/*    */     
/* 63 */     int read = l;
/* 64 */     while (read < this.length && (l = this.reader.read(c, read, this.length - read)) >= 0) {
/* 65 */       read += l;
/*    */     }
/* 67 */     this.eofPending = (l < 0);
/* 68 */     if (read < this.length) {
/* 69 */       char[] tmp = new char[read];
/* 70 */       System.arraycopy(c, 0, tmp, 0, read);
/* 71 */       c = tmp;
/*    */     } 
/*    */     
/* 74 */     return new String(c);
/*    */   }
/*    */ }
