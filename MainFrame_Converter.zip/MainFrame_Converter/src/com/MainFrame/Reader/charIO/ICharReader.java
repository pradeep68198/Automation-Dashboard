package com.MainFrame.Reader.charIO;

import java.io.IOException;
import java.io.InputStream;

public interface ICharReader {
  void open(String paramString1, String paramString2) throws IOException;
  
  void open(InputStream paramInputStream, String paramString) throws IOException;
  
  String read() throws IOException;
  
  void close() throws IOException;
}

