/*    */ package com.MainFrame.Reader.charIO;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseCharReader
/*    */   implements ICharReader
/*    */ {
/*    */   protected BufferedReader reader;
/*    */   
/*    */   public void open(String fileName, String font) throws IOException {
/* 41 */     open(new FileInputStream(fileName), font);
/*    */   }
/*    */ 
/*    */   
/*    */   public void open(InputStream inputStream, String font) throws IOException {
/*    */     InputStreamReader stdReader;
/* 47 */     if (font == null || font.length() == 0) {
/* 48 */       stdReader = new InputStreamReader(inputStream);
/*    */     } else {
/*    */       try {
/* 51 */         stdReader = new InputStreamReader(inputStream, font);
/* 52 */       } catch (Exception e) {
/* 53 */         stdReader = new InputStreamReader(inputStream);
/*    */       } 
/*    */     } 
/*    */     
/* 57 */     this.reader = new BufferedReader(stdReader);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 63 */     this.reader.close();
/*    */   }
/*    */ }

