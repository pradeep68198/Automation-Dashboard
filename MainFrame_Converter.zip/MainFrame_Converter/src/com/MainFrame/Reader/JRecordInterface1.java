
package com.MainFrame.Reader;

import com.MainFrame.Reader.def.IO.builders.*;
import com.MainFrame.Reader.def.IO.builders.recordDeciders.*;
import com.MainFrame.Reader.IO.builders.*;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.External.*;
import com.MainFrame.Reader.IO.builders.recordDeciders.*;

public class JRecordInterface1
{
    public static final ICobolCopybookIOProvider COBOL;
    public static final Icb2xmlIOProvider CB2XML;
    public static final IIOCopybookProvider SCHEMA_XML;
    public static final JRecordInterface1.SchemaIOBuilderProvider SCHEMA;
    public static final JRecordInterface1.CsvIOBuilderProvider CSV;
    public static final JRecordInterface1.FixedWidthIOBuilderProvider FIXED_WIDTH;
    public static final IRecordDeciderBuilder RECORD_DECIDER_BUILDER;
    
    static {
        COBOL = (ICobolCopybookIOProvider)new FileSchemaBuilder(1);
        CB2XML = (Icb2xmlIOProvider)new FileSchemaBuilder(0);
        SCHEMA_XML = (IIOCopybookProvider)new FileSchemaBuilder(CopybookLoaderFactory.RECORD_EDITOR_XML_LOADER);
        SCHEMA = new JRecordInterface1.SchemaIOBuilderProvider();
        CSV = new JRecordInterface1.CsvIOBuilderProvider();
        FIXED_WIDTH = new JRecordInterface1.FixedWidthIOBuilderProvider();
        RECORD_DECIDER_BUILDER = (IRecordDeciderBuilder)new RecordDeciderBuilder();
    }
    
    public static class CsvIOBuilderProvider
    {
        public ICsvIOBuilder newIOBuilder() {
            return CsvIOBuilder.newCsvIOBuilder();
        }
        
        public ICsvIOBuilder newIOBuilder(final String delimiter, final String quote) {
            return CsvIOBuilder.newCsvIOBuilder(delimiter, quote);
        }
    }
    
    public static class FixedWidthIOBuilderProvider
    {
        public IFixedWidthIOBuilder newIOBuilder() {
            return FixedWidthIOBuilder.newFixedWidthIOBuilder();
        }
    }
    
    public static class SchemaIOBuilderProvider
    {
        public ISchemaIOBuilder newIOBuilder(final LayoutDetail schema) {
            return SchemaIOBuilder.newSchemaIOBuilder(schema);
        }
    }
}