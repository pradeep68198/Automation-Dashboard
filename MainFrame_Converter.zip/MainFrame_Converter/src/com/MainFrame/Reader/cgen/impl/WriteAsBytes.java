
package com.MainFrame.Reader.cgen.impl;

import java.io.IOException;
import java.io.OutputStream;

import com.MainFrame.Reader.ByteIO.AbstractByteWriter;
import com.MainFrame.Reader.ByteIO.ByteIOProvider;
import com.MainFrame.Reader.Common.IBasicFileSchema;
import com.MainFrame.Reader.cgen.def.ISerializer;
import com.MainFrame.Reader.cgen.def.IWriter;


public class WriteAsBytes<T> implements IWriter<T> {
	
	private final ISerializer<T> serializer;
	private final AbstractByteWriter writer;

	public WriteAsBytes(IBasicFileSchema schema, ISerializer<T> serializer) {
		this.serializer = serializer;
		this.writer = ByteIOProvider.getInstance().getByteWriter(schema);
	}
	
	public WriteAsBytes<T> open(String fileName) throws IOException {
		writer.open(fileName);
		return this;
	}
	
	public WriteAsBytes<T> open(OutputStream in) throws IOException {
		writer.open(in);
		return this;
	}
	
	
	@Override
	public void write(T record) throws IOException {
		writer.write(serializer.serialize(record));
	}

	@Override
	public void close() throws IOException {
		writer.close();
	}

	public static <TT extends Object> WriteAsBytes<TT> newReader(IBasicFileSchema schema, ISerializer<TT> serializer) {
		return new WriteAsBytes<TT>(schema, serializer);
	}
}
