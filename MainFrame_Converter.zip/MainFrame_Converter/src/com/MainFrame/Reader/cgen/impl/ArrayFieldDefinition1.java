
package com.MainFrame.Reader.cgen.impl;

import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Common.RecordException;
import com.MainFrame.Reader.cgen.def.IArray1Dimension;
import com.MainFrame.Reader.cgen.def.IArray2Dimension;
import com.MainFrame.Reader.cgen.def.IArray3Dimension;
import com.MainFrame.Reader.cgen.def.IArrayExtended;
import com.MainFrame.Reader.cgen.def.IIndex;

public class ArrayFieldDefinition1 implements IArray1Dimension, IArray2Dimension, IArray3Dimension, IArrayExtended {

	private final int[]  lengths, numberOfElements;
	private FieldDetail[] fields;

	
	public ArrayFieldDefinition1(int[] arrayLengths) {
		this(arrayLengths, new FieldDetail[calcArraySize(arrayLengths)]);
	}
	
	private static int calcArraySize(int[] arrayLengths) {
		int size = 1;
		for (int aSize : arrayLengths) {
			size *= aSize;
		}
		return size;
	}

	public ArrayFieldDefinition1(int[] arrayLengths, FieldDetail[] fd) {

		this.lengths = arrayLengths;// new int[fd.length - 1];
		numberOfElements = new int[lengths.length];
		this.fields = fd;
		
		int num = 1;
		
		for (int i = numberOfElements.length-1; i >=0; i--) {
			numberOfElements[i] = num;
			num = num * (lengths[i]);
		}
	}

	
	
	@Override
	public void setField(IIndex index, FieldDetail fieldDefinition) {
		this.fields[calcIndex(index)] = fieldDefinition;
	}
	


	
	@Override
	public IFieldDetail getField(IIndex index) {
		return this.fields[calcIndex(index)];
	}
	
	
	@Override
	public IFieldDetail getFirstField() {
		return this.fields[0];
	}

	private int calcIndex(IIndex index) {
		int idx = 0;
		
		for (int i = 0; i < numberOfElements.length; i++) {
			idx += index.getIndex(i) * numberOfElements[i];
		}
		return idx;
	}

	
	@Override
	public IFieldDetail get(int index1, int index2, int index3) {
		return getField(index1, index2, index3);
	}

	
	@Override
	public IFieldDetail get(int index1, int index2) {
		return getField(index1, index2);
	}
	@Override
	public IFieldDetail getField(int... indexs) {
		if (indexs.length != numberOfElements.length) { 
			throw new RecordException("You must supply " + numberOfElements.length + " indexs");
		}
		int idx = 0;
		
		for (int i = 0; i < indexs.length; i++) {
			idx += indexs[i] * numberOfElements[i];
		}
		
//		if (indexs.length > 1 && idx > lengths[lengths.length - 1] ) {
//			System.out.println(" --> " + idx + " " + indexs[0] + ", " + indexs[1] + " " + this.fields[idx].getName());
//		}
		
		return this.fields[idx];
	}
	
	

	
	@Override
	public IFieldDetail get(int indexs) {
		return getField(indexs);
	}


//	private DependingOnDtls getDependingOnDtls(int[] indexs) {
//		if (dependingOnDtls == null || cmp(dependingOnDtls, indexs)) {
//			return dependingOnDtls;
////		} else if (lastDependingOnDtls == null || (! cmp(lastDependingOnDtls, indexs))) {
////			lastDependingOnDtls = bld(dependingOnDtls, indexs.length - 1, indexs);
////		} 
////		return lastDependingOnDtls;
//		}
//		return bld(dependingOnDtls, indexs.length - 1, indexs);
//	}
//	
//	private DependingOnDtls bld(DependingOnDtls d, int lvl, int[] indexs) {
//		if (lvl < 0 || d == null) { 
//			return null;
//		} 
//		
//		return new DependingOnDtls(d.dependingOn, indexs[lvl], bld(d, lvl-1, indexs), false);
//	}
//	
//	private boolean cmp(DependingOnDtls d, int[] indexs) {
//		for (int i = indexs.length- 1; i >= 0 && d != null; i--) {
//			if (d.index != indexs[i]) {
//				return false;
//			}
//			d = d.parent;
//		}
//		return true;
//	}
//	
	/**
	 * get the Array length
	 * @param indexNumber array index number
	 * @return array length
	 */
	@Override
	public int getArrayLength(int indexNumber) {
		return lengths[indexNumber];
	}

	@Override
	public int getArrayElementSize(int indexNumber) {
		return lengths[indexNumber] * this.fields[0].getLen();
	}
	
	
	@Override
	public int getIndexCount() {
		return lengths.length;
	}

	
	@Override
	public IArray1Dimension asOneDimensionArray() {
		if (lengths.length == 1) {
			return this;
		}
		return null;
	}

	
	@Override
	public IArray2Dimension asTwoDimensionArray() {
		if (lengths.length == 2) {
			return this;
		}
		return null;
	}

	
	@Override
	public IArray3Dimension asThreeDimensionArray() {
		if (lengths.length == 3) {
			return this;
		}
		return null;
	}	
}
