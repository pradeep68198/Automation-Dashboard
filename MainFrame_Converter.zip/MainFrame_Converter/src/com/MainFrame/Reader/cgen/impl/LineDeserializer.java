package com.MainFrame.Reader.cgen.impl;

import com.MainFrame.Reader.cgen.def.IDeserializer;
import com.MainFrame.Reader.cgen.defJr.IAsPojoSetData;

public class LineDeserializer<Line> implements IDeserializer<Line> {

	public static <Line> LineDeserializer<Line> create(IAsPojoSetData<Line> line)  {
		return new LineDeserializer<Line>(line);
	}
	private final IAsPojoSetData<Line> line;
	
	
	protected LineDeserializer(IAsPojoSetData<Line> line) {
		super();
		this.line = line;
	}


	@Override
	public Line deserialize(byte[] rec) {
		line.setData(rec);
		return line.asPojo();
	}

}
