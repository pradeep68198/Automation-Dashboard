package com.MainFrame.Reader.cgen.impl;

import java.io.IOException;


import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.IO.AbstractLineReader;
import com.MainFrame.Reader.cgen.def.IReader;
import com.MainFrame.Reader.cgen.defJr.IToPojo;


public class PojoLineReader<Pojo> implements IReader<Pojo>{
	private final AbstractLineReader lineReader;
	private final IToPojo<Pojo> copy;
	protected AbstractLine nextLine;
	
	public PojoLineReader(AbstractLineReader lineReader, AbstractLine firstLine, IToPojo<Pojo> toPojo) throws IOException {

		this.lineReader = lineReader;

		this.nextLine = firstLine;
		this.copy = toPojo;
	}

	@Override
	public Pojo read() throws IOException {
		if (nextLine == null) {
			return null;
		}
		AbstractLine line = nextLine;
		nextLine = lineReader.read();
		
		return  copy.toPojo(line);
	}

	@Override
	public void close() throws IOException {
		lineReader.close();
	}
}
