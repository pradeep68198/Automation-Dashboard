

package com.MainFrame.Reader.cgen.impl;

import com.MainFrame.Reader.cgen.def.IFieldName1Dimension;
import com.MainFrame.Reader.cgen.def.IFieldName2Dimension;
import com.MainFrame.Reader.cgen.def.IFieldName3Dimension;
import com.MainFrame.Reader.cgen.def.IFieldName4Dimension;

public class ArrayFieldName implements IFieldName1Dimension, IFieldName2Dimension, IFieldName3Dimension , IFieldName4Dimension {

	private final String name;
	
	
	public ArrayFieldName(String name) {
		this.name = name;
	}


	
	@Override
	public String get(int index1) {
		return genName(index1);
	}

	
	@Override
	public String get(int index1, int index2) {
		return genName(index1, index2);
	}

	
	@Override
	public String get(int index1, int index2, int index3) {
		return genName(index1, index2, index3);
	}

	@Override
	public String get(int index1, int index2, int index3, int index4) {
		return genName(index1, index2, index3, index4);
	}

	private String genName(int... indexs) {
		StringBuilder b = new StringBuilder(name);
		String sep = " (";
		
		for (int idx : indexs) {
			b.append(sep).append(idx);
			sep = ", ";
		}
		return b.append(')').toString();
	}
}
