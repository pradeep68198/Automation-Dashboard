package com.MainFrame.Reader.cgen.impl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.MainFrame.Reader.ByteIO.ByteIOProvider;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Details.RecordDecider;
import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
import com.MainFrame.Reader.IO.AbstractLineReader;
import com.MainFrame.Reader.IO.AbstractLineWriter;
import com.MainFrame.Reader.cgen.def.IReader;
import com.MainFrame.Reader.cgen.def.IWriter;
import com.MainFrame.Reader.cgen.defJr.IPojoConverter;
import com.MainFrame.Reader.def.IO.builders.IIOBuilder;
import com.MainFrame.Reader.def.IO.builders.Icb2xmlLoadOptions;



public class IoBuilder<Pojo> {

	
	private final IPojoConverter<Pojo> pojoConverter;
	private final boolean useByteIo;
	private final IIOBuilder builder;
	private final Icb2xmlLoadOptions recordSelectionDtls;
	private final LayoutDetail schema;
	
	public <T extends IIOBuilder & Icb2xmlLoadOptions> IoBuilder(IPojoConverter<Pojo> pojoConverter, T builder) throws IOException {
		this.pojoConverter = pojoConverter;
		this.builder = builder;
		this.recordSelectionDtls = builder;
		this.schema = builder.getLayout();
		this.useByteIo = ByteIOProvider.getInstance().getByteReader(schema) != null;
	}

	
	public IReader<Pojo> newReader(String filename) throws FileNotFoundException, IOException {
		if (useByteIo) {
			ReadFromBytes<Pojo> r =  new ReadFromBytes<Pojo>(schema, pojoConverter);
			r.open(filename);
			return r;
		}
		
		return new ReadLine<Pojo>(builder.newReader(filename), pojoConverter);
	}
	

	public IReader<Pojo> newReader(InputStream in) throws FileNotFoundException, IOException {
		if (useByteIo) {
			ReadFromBytes<Pojo> r =  new ReadFromBytes<Pojo>(schema, pojoConverter);
			r.open(in);
			return r;
		}
		
		return new ReadLine<Pojo>(builder.newReader(in), pojoConverter);
	}

	
	public IWriter<Pojo> newWriter(String filename) throws IOException {
		if (useByteIo) {
			WriteAsBytes<Pojo> w =  new WriteAsBytes<Pojo>(schema, pojoConverter);
			w.open(filename);
			return w;
		}
		
		return new WriteLine<Pojo>(builder.newWriter(filename), pojoConverter, builder.newLine());
	}
	
	
	public IWriter<Pojo> newWriter(OutputStream out) throws IOException {
		if (useByteIo) {
			WriteAsBytes<Pojo> w =  new WriteAsBytes<Pojo>(schema, pojoConverter);
			w.open(out);
			return w;
		}
		
		return new WriteLine<Pojo>(builder.newWriter(out), pojoConverter, builder.newLine());
	}
	
	
	public IoBuilder<Pojo> setRecordSelection(String recordName, ExternalSelection selectionCriteria) {
		recordSelectionDtls.setRecordSelection(recordName, selectionCriteria);
		
		return this;
	}

	
	public IoBuilder<Pojo> setRecordDecider(RecordDecider recordDecider) {
		recordSelectionDtls.setRecordDecider(recordDecider);
		
		return this;
	}


	
	private static class ReadLine<Pojo> implements IReader<Pojo> {

		final AbstractLineReader reader;
		private final IPojoConverter<Pojo> pojoConverter;	/* Used to convert a JRecord line to a Pojo */
		
		
		public ReadLine(AbstractLineReader reader, IPojoConverter<Pojo> pojoConverter) {
			super();
			this.reader = reader;
			this.pojoConverter = pojoConverter;
		}

		@Override
		public Pojo read() throws IOException {
			AbstractLine line = reader.read();
			
			return line == null ? null : pojoConverter.toPojo(line);
		}

		@Override
		public void close() throws IOException {
			reader.close();
		}
	}
	
	
	
	private static class WriteLine<Pojo> implements IWriter<Pojo> {
		final AbstractLineWriter writer;
		private final IPojoConverter<Pojo> pojoConverter; /* used to convert a Pojo into a JRecord line */ 
		final AbstractLine l;
		
		
		public WriteLine(AbstractLineWriter writer, IPojoConverter<Pojo> pojoConverter, AbstractLine line) {
			super();
			this.writer = writer;
			this.pojoConverter = pojoConverter;
			this.l = line;
		}

		@Override
		public void write(Pojo pojo) throws IOException {
			pojoConverter.updateLine(l, pojo);
			writer.write(l);
		}

		@Override
		public void close() throws IOException {
			writer.close();
		}
	}
}
