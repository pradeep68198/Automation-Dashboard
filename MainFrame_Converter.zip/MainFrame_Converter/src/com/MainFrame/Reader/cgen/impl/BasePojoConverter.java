package com.MainFrame.Reader.cgen.impl;


import java.io.IOException;

import com.MainFrame.Reader.Common.RecordException;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.cgen.defJr.IPojoConverter;
import com.MainFrame.Reader.def.IO.builders.INewLineCreator;



public abstract class BasePojoConverter<Pojo> implements IPojoConverter<Pojo>, INewLineCreator {

	private final AbstractLine tmpLine;
	private final INewLineCreator lineCreator;
	
	public BasePojoConverter(INewLineCreator lineCreator) {
		this.lineCreator = lineCreator;
		try {
			this.tmpLine = lineCreator.newLine();
		} catch (IOException e) {
			throw new RecordException("Error creating line", e);
		}
	}

	@Override
	public Pojo deserialize(byte[] rec) {
		tmpLine.setData(rec);
		return toPojo(tmpLine);
	}

	@Override
	public byte[] serialize(Pojo rec) {
		updateLine(tmpLine, rec);
		return tmpLine.getData();
	}
	
	public AbstractLine toLine(Pojo pojo) {
		AbstractLine line;
		try {
			line = lineCreator.newLine();
		} catch (IOException e) {
			throw new RecordException("Error creating line", e);
		}
		
		updateLine(line, pojo);
		return line;
	}

	public AbstractLine newLine() throws IOException {
		return lineCreator.newLine();
	}

}
