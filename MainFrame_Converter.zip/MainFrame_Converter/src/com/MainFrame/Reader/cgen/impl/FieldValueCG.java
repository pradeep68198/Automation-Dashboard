

package com.MainFrame.Reader.cgen.impl;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Details.IGetByteData;
import com.MainFrame.Reader.Details.fieldValue.BaseFieldValue;
import com.MainFrame.Reader.Types.Type;
import com.MainFrame.Reader.Types.TypeManager;


public class FieldValueCG extends BaseFieldValue {

	private final IGetByteData dataSource;
	private final IFieldDetail fieldDetails;
	private final Type type;
	
	
	public FieldValueCG(IGetByteData dataSource, IFieldDetail fieldDetails) {
		super(fieldDetails);
		
		this.dataSource = dataSource;
		this.fieldDetails = fieldDetails;
		this.type = TypeManager.getInstance().getType(fieldDetails.getType());
	}

	
	@Override
	protected Object getValue() {
		return type.getField(dataSource.getData(), fieldDetails.getPos(), fieldDetails);
	}

	
	@Override
	public void set(Object value) {
		dataSource.setData(type.setField(dataSource.getData(), fieldDetails.getPos(), fieldDetails, value));
	}
}
