
package com.MainFrame.Reader.cgen.impl;

import java.io.IOException;
import java.io.InputStream;

import com.MainFrame.Reader.ByteIO.AbstractByteReader;
import com.MainFrame.Reader.ByteIO.ByteIOProvider;
import com.MainFrame.Reader.Common.IBasicFileSchema;
import com.MainFrame.Reader.cgen.def.IDeserializer;
import com.MainFrame.Reader.cgen.def.IReader;


public class ReadFromBytes<T> implements IReader<T> {

	public final IDeserializer<T> deserializer;
	public final AbstractByteReader reader;
	
	public ReadFromBytes(IBasicFileSchema schema, IDeserializer<T> deserializer) {
		this.deserializer = deserializer;
		this.reader = ByteIOProvider.getInstance().getByteReader(schema);
	}
	
	public ReadFromBytes<T> open(String fileName) throws IOException {
		reader.open(fileName);
		return this;
	}
	
	public ReadFromBytes<T> open(InputStream in) throws IOException {
		reader.open(in);
		return this;
	}
	
	@Override
	public T read()  throws IOException {
		byte[] value = reader.read();
		if (value == null) {
			return null;
		}
		return deserializer.deserialize(value);
	}

	@Override
	public void close() throws IOException {
		reader.close();
	}
	
	public static <TT extends Object> ReadFromBytes<TT> newReader(IBasicFileSchema schema, IDeserializer<TT> deserializer) {
		return new ReadFromBytes<TT>(schema, deserializer);
	}
}
