package com.MainFrame.Reader.cgen.impl;

import java.io.IOException;

import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.IO.AbstractLineWriter;
import com.MainFrame.Reader.cgen.def.IWriter;
import com.MainFrame.Reader.cgen.defJr.IUpdateLine;


public class PojoLineWriter<Pojo> implements IWriter<Pojo> {
	private final AbstractLineWriter lineWriter;
	//private final LineRecBarDTAR020JR wrapper = new LineRecBarDTAR020JR();
	private final AbstractLine line;
	private final IUpdateLine<Pojo> copy;

	public PojoLineWriter(AbstractLineWriter lineWriter, AbstractLine line, IUpdateLine<Pojo> updateLine) {
		super();
		this.lineWriter = lineWriter;
		this.line = line;
		this.copy = updateLine;
	}
	
	@Override
	public void write(Pojo record) throws IOException {

	    copy.updateLine(line, record);
		
		lineWriter.write(line);
	}
	
	@Override
	public void close() throws IOException {
		lineWriter.close();
	}
}
