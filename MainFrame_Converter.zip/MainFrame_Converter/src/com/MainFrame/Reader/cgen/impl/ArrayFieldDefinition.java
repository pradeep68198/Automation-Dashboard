
package com.MainFrame.Reader.cgen.impl;

import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Details.RecordDetail;
import com.MainFrame.Reader.External.Def.DependingOnDtls;
import com.MainFrame.Reader.Types.Type;
import com.MainFrame.Reader.cgen.def.IArray1Dimension;
import com.MainFrame.Reader.cgen.def.IArray2Dimension;
import com.MainFrame.Reader.cgen.def.IArray3Dimension;
import com.MainFrame.Reader.cgen.def.IArrayAnyDimension;

public class ArrayFieldDefinition implements IArray1Dimension, IArray2Dimension, IArray3Dimension, IArrayAnyDimension {

	private final int[] sizeAdj, lengths;
	private final IFieldDetail firstField;
	private final RecordDetail record;
	private final DependingOnDtls dependingOnDtls;
	//private DependingOnDtls lastDependingOnDtls;
	
	public ArrayFieldDefinition(RecordDetail rec, int firstArrayLength, IFieldDetail... fd) {
		this.record = rec;
		sizeAdj = new int[fd.length - 1];
		lengths = new int[fd.length - 1];
		firstField =  fd[sizeAdj.length];
		lengths[0] = firstArrayLength;
		sizeAdj[0] = fd[0].getPos() - firstField.getPos();
		for (int i = 1; i < sizeAdj.length; i++) {
			sizeAdj[i] = fd[i].getPos() - firstField.getPos();
			lengths[i] = sizeAdj[i - 1] / sizeAdj[i];
		}
		

		DependingOnDtls depOn = null;
		if (firstField instanceof FieldDetail) {
			depOn = ((FieldDetail) firstField).getDependingOnDtls();
		}
		dependingOnDtls = depOn;
	}
	
	public ArrayFieldDefinition(RecordDetail rec, String name, int pos, int size, int[] maxIdx, int[] elementSizes) {
		this.record = rec;
		sizeAdj = new int[size];
		lengths = new int[size];
		dependingOnDtls = null;
		firstField = FieldDetail.newFixedWidthField(name + " (0)", Type.ftChar, pos, elementSizes[size - 1], 0, "");
		for (int i = 0; i < size; i++) {
			sizeAdj[i] = elementSizes[i];
			lengths[i] = maxIdx[i];
		}
	}

	
	@Override
	public IFieldDetail get(int index1, int index2, int index3) {
		return getField(index1, index2, index3);
	}

	
	@Override
	public IFieldDetail get(int index1, int index2) {
		return getField(index1, index2);
	}

	
	@Override
	public IFieldDetail get(int indexs) {
		return getField(indexs);
	}

	@Override
	public IFieldDetail getField(int... indexs) {
		if (indexs == null || indexs.length != sizeAdj.length) {
			throw new RuntimeException("Expected: " + sizeAdj.length + " indexes, but recieved: "
					+ (indexs == null? 0 : indexs.length));
		}
		int p = indexs[0] * sizeAdj[0] + firstField.getPos();
		String name = firstField.getName();
		int np = name.indexOf('(');
		if (np > 0) {
			name = name.substring(0, np-1);
		}
		StringBuilder b = new StringBuilder(name)
								.append(" (")
								.append(Integer.toString((indexs[0])));
		for (int i = 1; i < sizeAdj.length; i++) {
			p += indexs[i] * sizeAdj[i]; 
			b.append(", ").append(Integer.toString((indexs[i])));
		}
		b.append(")");
	
		
		FieldDetail f =  FieldDetail.newFixedWidthField(
				b.toString(), firstField.getType(), 
				p, firstField.getLen(), firstField.getDecimal(), firstField.getFontName());
		f.setRecord(record);
		f.setDependingOnDtls(getDependingOnDtls(indexs));
		
		return f;
	}
	
	
	@Override
	public IFieldDetail getFirstField() {
		return firstField;
	}

	private DependingOnDtls getDependingOnDtls(int[] indexs) {
		if (dependingOnDtls == null || cmp(dependingOnDtls, indexs)) {
			return dependingOnDtls;
//		} else if (lastDependingOnDtls == null || (! cmp(lastDependingOnDtls, indexs))) {
//			lastDependingOnDtls = bld(dependingOnDtls, indexs.length - 1, indexs);
//		} 
//		return lastDependingOnDtls;
		}
		return bld(dependingOnDtls, indexs.length - 1, indexs);
	}
	
	private DependingOnDtls bld(DependingOnDtls d, int lvl, int[] indexs) {
		if (lvl < 0 || d == null) { 
			return null;
		} 
		
		return new DependingOnDtls(d.dependingOn, indexs[lvl], bld(d, lvl-1, indexs), false);
	}
	
	private boolean cmp(DependingOnDtls d, int[] indexs) {
		for (int i = indexs.length- 1; i >= 0 && d != null; i--) {
			if (d.index != indexs[i]) {
				return false;
			}
			d = d.parent;
		}
		return true;
	}
	
	/**
	 * get the Array length
	 * @param indexNumber array index number
	 * @return array length
	 */
	@Override
	public int getArrayLength(int indexNumber) {
		return lengths[indexNumber];
	}

	@Override
	public int getArrayElementSize(int indexNumber) {
		return sizeAdj[indexNumber];
	}
	
	
	@Override
	public int getIndexCount() {
		return lengths.length;
	}
	
	
	@Override
	public IArray1Dimension asOneDimensionArray() {
		if (lengths.length == 1) {
			return this;
		}
		return null;
	}

	
	@Override
	public IArray2Dimension asTwoDimensionArray() {
		if (lengths.length == 2) {
			return this;
		}
		return null;
	}

	
	@Override
	public IArray3Dimension asThreeDimensionArray() {
		if (lengths.length == 3) {
			return this;
		}
		return null;
	}	
}
