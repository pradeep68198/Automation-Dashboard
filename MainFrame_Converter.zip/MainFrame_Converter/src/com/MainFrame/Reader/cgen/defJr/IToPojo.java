package com.MainFrame.Reader.cgen.defJr;

import com.MainFrame.Reader.Details.AbstractLine;

public interface IToPojo<Pojo> {
	
	public Pojo toPojo(AbstractLine line);

}
