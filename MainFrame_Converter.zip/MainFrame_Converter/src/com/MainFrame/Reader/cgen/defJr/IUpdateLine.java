package com.MainFrame.Reader.cgen.defJr;

import com.MainFrame.Reader.Details.AbstractLine;

public interface IUpdateLine<Pojo> {
	
	
	public void updateLine(AbstractLine line, Pojo pojo);

}
