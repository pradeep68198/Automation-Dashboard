

package com.MainFrame.Reader.cgen.defJr;

public interface IAsPojo<Line> {

	public abstract Line asPojo();
}