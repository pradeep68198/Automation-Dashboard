package com.MainFrame.Reader.cgen.defJr;

import com.MainFrame.Reader.cgen.def.IDeserializer;
import com.MainFrame.Reader.cgen.def.ISerializer;


public interface IPojoConverter<Pojo> extends ISerializer<Pojo>, IDeserializer<Pojo>, IToPojo<Pojo>, IUpdateLine<Pojo> {

}
