
package com.MainFrame.Reader.cgen.defJr;

public interface IAsPojoSetData<Line> extends IAsPojo<Line>{

	public abstract void setData(byte[] bytes);
//	public abstract void getData();
}