package com.MainFrame.Reader.cgen.def;

import com.MainFrame.Reader.Common.IFieldDetail;

public interface IArray3Dimension {
  IFieldDetail get(int paramInt1, int paramInt2, int paramInt3);
  
  int getArrayLength(int paramInt);
}

