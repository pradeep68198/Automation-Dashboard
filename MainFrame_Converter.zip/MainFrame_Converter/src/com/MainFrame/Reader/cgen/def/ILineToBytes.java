package com.MainFrame.Reader.cgen.def;

import com.MainFrame.Reader.Common.IGetData;

public interface ILineToBytes<Line> extends IGetData {
  void set(Line paramLine);
}

