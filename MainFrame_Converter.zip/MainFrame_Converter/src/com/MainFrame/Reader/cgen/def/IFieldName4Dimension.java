package com.MainFrame.Reader.cgen.def;

public interface IFieldName4Dimension {
  String get(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}

