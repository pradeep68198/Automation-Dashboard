package com.MainFrame.Reader.cgen.def;

import com.MainFrame.Reader.Common.IFieldDetail;

public interface IArrayAnyDimension {
  IFieldDetail getField(int... paramVarArgs);
  
  IFieldDetail getFirstField();
  
  int getArrayLength(int paramInt);
  
  int getArrayElementSize(int paramInt);
  
  int getIndexCount();
  
  IArray1Dimension asOneDimensionArray();
  
  IArray2Dimension asTwoDimensionArray();
  
  IArray3Dimension asThreeDimensionArray();
}

