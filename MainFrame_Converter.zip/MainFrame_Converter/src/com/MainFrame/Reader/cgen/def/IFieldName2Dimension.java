package com.MainFrame.Reader.cgen.def;

public interface IFieldName2Dimension {
  String get(int paramInt1, int paramInt2);
}

