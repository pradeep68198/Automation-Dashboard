package com.MainFrame.Reader.cgen.def;

public interface IFieldName1Dimension {
  String get(int paramInt);
}

