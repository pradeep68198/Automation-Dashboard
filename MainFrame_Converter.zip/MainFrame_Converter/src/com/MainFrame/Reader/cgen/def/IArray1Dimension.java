package com.MainFrame.Reader.cgen.def;

import com.MainFrame.Reader.Common.IFieldDetail;

public interface IArray1Dimension {
  IFieldDetail get(int paramInt);
  
  int getArrayLength(int paramInt);
}

