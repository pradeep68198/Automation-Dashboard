package com.MainFrame.Reader.cgen.def;

import java.util.List;
import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Option.IRecordPositionOption;
import com.MainFrame.Reader.detailsBasic.CsvCharDetails;
import com.MainFrame.Reader.detailsBasic.IItemDetails;
import com.MainFrame.Reader.detailsSelection.RecordSelection;

public interface IRecordDetail4gen {
  int getFieldCount();
  
  FieldDetail getField(int paramInt);
  
  String getRecordName();
  
  RecordSelection getRecordSelection();
  
  IRecordPositionOption getRecordPositionOption();
  
  int getRecordType();
  
  int getRecordStyle();
  
  CsvCharDetails getQuoteDefinition();
  
  List<? extends IItemDetails> getCobolItems();
}

