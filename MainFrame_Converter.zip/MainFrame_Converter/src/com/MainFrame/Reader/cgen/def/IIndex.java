package com.MainFrame.Reader.cgen.def;

public interface IIndex {
  int getIndex(int paramInt);
}

