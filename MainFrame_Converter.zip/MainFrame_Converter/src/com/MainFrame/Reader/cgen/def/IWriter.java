package com.MainFrame.Reader.cgen.def;

import java.io.IOException;

public interface IWriter<Line> {
  void write(Line paramLine) throws IOException;
  
  void close() throws IOException;
}

