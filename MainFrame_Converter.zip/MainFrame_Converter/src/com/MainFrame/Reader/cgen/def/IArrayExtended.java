package com.MainFrame.Reader.cgen.def;

import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Common.IFieldDetail;

public interface IArrayExtended extends IArrayAnyDimension {
  IFieldDetail getField(IIndex paramIIndex);
  
  void setField(IIndex paramIIndex, FieldDetail paramFieldDetail);
}

