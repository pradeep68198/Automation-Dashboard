package com.MainFrame.Reader.cgen.def;

import com.MainFrame.Reader.detailsBasic.CsvCharDetails;

public interface ILayoutDetails4gen {
  int getFileStructure();
  
  int getLayoutType();
  
  String getLayoutName();
  
  int getRecordCount();
  
  IRecordDetail4gen getRecord(int paramInt);
  
  boolean isCsvLayout();
  
  CsvCharDetails getDelimiterDetails();
}

