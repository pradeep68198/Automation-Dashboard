package com.MainFrame.Reader.cgen.def;

import java.io.IOException;

public interface IReader<Line> {
  Line read() throws IOException;
  
  void close() throws IOException;
}

