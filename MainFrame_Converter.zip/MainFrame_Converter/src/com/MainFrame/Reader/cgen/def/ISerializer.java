package com.MainFrame.Reader.cgen.def;

public interface ISerializer<Line> {
  byte[] serialize(Line paramLine);
}

