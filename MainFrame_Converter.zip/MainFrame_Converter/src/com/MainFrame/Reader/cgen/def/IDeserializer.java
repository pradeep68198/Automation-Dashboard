package com.MainFrame.Reader.cgen.def;

public interface IDeserializer<Line> {
  Line deserialize(byte[] paramArrayOfbyte);
}

