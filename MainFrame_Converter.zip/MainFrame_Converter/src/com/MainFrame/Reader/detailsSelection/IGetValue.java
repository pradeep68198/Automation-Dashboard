package com.MainFrame.Reader.detailsSelection;

import java.util.List;
import com.MainFrame.Reader.Common.AbstractIndexedLine;

public interface IGetValue {
  boolean isNumeric();
  
  Object getValue(AbstractIndexedLine paramAbstractIndexedLine);
  
  boolean isIncluded(AbstractIndexedLine paramAbstractIndexedLine);
  
  Object getValue(List<? extends AbstractIndexedLine> paramList);
}

