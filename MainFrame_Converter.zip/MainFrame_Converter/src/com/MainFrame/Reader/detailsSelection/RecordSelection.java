/*     */ package com.MainFrame.Reader.detailsSelection;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import com.MainFrame.Reader.Common.AbstractIndexedLine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordSelection
/*     */ {
/*     */   private RecordSel recSel;
/*     */   private boolean defaultRecord = false;
/*     */   
/*     */   public int size() {
/*  67 */     if (this.recSel == null) {
/*  68 */       return 0;
/*     */     }
/*  70 */     return this.recSel.getSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getElementCount() {
/*  79 */     if (this.recSel == null) {
/*  80 */       return 0;
/*     */     }
/*  82 */     return this.recSel.getElementCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldSelect getFirstField() {
/*  87 */     return this.recSel.getFirstField();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RecordSelectionResult isSelected(AbstractIndexedLine line) {
/* 128 */     RecordSelectionResult ret = RecordSelectionResult.NO;
/*     */     
/* 130 */     if (this.recSel == null) {
/* 131 */       if (this.defaultRecord) {
/* 132 */         ret = RecordSelectionResult.DEFAULT;
/*     */       }
/*     */     }
/* 135 */     else if (this.recSel.isSelected(line)) {
/* 136 */       if (this.defaultRecord) {
/* 137 */         ret = RecordSelectionResult.DEFAULT;
/*     */       } else {
/* 139 */         ret = RecordSelectionResult.YES;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 144 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefaultRecord() {
/* 160 */     return this.defaultRecord;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultRecord(boolean defaultRecord) {
/* 168 */     this.defaultRecord = defaultRecord;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRecSel(RecordSel recSel) {
/* 175 */     this.recSel = recSel;
/*     */   }
/*     */   
/*     */   public List<FieldSelect> getAllFields() {
/* 179 */     List<FieldSelect> fields = new ArrayList<FieldSelect>();
/*     */     
/* 181 */     if (this.recSel != null) {
/* 182 */       this.recSel.getAllFields(fields);
/*     */     }
/*     */     
/* 185 */     return fields;
/*     */   }
/*     */   
/*     */   public enum RecordSelectionResult {
/* 189 */     NO,
/* 190 */     DEFAULT,
/* 191 */     YES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final RecordSel getRecSel() {
/* 198 */     return this.recSel;
/*     */   }
/*     */ }

