/*    */ package com.MainFrame.Reader.detailsSelection;
/*    */ 
/*    */ import java.util.List;
/*    */ import com.MainFrame.Reader.Common.AbstractIndexedLine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AndSelection
/*    */   extends AbsGroup
/*    */ {
/*    */   public AndSelection() {
/* 35 */     this(10);
/*    */   }
/*    */   
/*    */   public AndSelection(int size) {
/* 39 */     super(size);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSelected(List<? extends AbstractIndexedLine> line) {
/* 53 */     if (size() > 0) {
/*    */       
/* 55 */       for (int i = 0; i < size(); i++) {
/* 56 */         RecordSel sel = (RecordSel)get(i);
/*    */         
/* 58 */         if (!sel.isSelected(line)) {
/* 59 */           return false;
/*    */         }
/*    */       } 
/* 62 */       return true;
/*    */     } 
/* 64 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSelected(AbstractIndexedLine line) {
/* 73 */     if (size() > 0) {
/*    */       
/* 75 */       for (int i = 0; i < size(); i++) {
/* 76 */         RecordSel sel = (RecordSel)get(i);
/*    */         
/* 78 */         if (!sel.isSelected(line)) {
/* 79 */           return false;
/*    */         }
/*    */       } 
/* 82 */       return true;
/*    */     } 
/* 84 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isIncluded(AbstractIndexedLine line) {
/* 92 */     return true;
/*    */   }
/*    */ }

