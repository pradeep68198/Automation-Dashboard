/*     */ package com.MainFrame.Reader.detailsSelection;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import com.MainFrame.Reader.Common.AbstractIndexedLine;
/*     */ import com.MainFrame.Reader.Common.IEmptyTest;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalFieldSelection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FieldSelect
/*     */   extends ExternalFieldSelection
/*     */   implements RecordSel
/*     */ {
/*     */   protected IGetValue getValue;
/*     */   
/*     */   public FieldSelect(String name, String value, String op, IGetValue getValue) {
/*  44 */     super(name, value, op);
/*  45 */     this.getValue = getValue;
/*  46 */     if (getValue == null) {
/*  47 */       this.getValue = new IGetValue()
/*     */         {
/*     */           public boolean isNumeric()
/*     */           {
/*  51 */             return false;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getValue(List<? extends AbstractIndexedLine> lines) {
/*  56 */             return null;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getValue(AbstractIndexedLine line) {
/*  61 */             return null;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public boolean isIncluded(AbstractIndexedLine line) {
/*  69 */             return true;
/*     */           }
/*     */         };
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getAllFields(List<FieldSelect> fields) {
/*  84 */     fields.add(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldSelect getFirstField() {
/*  95 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getElementCount() {
/* 107 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSelected(List<? extends AbstractIndexedLine> lines) {
/* 113 */     return isSelected(this.getValue.getValue(lines));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIncluded(AbstractIndexedLine line) {
/* 123 */     return this.getValue.isIncluded(line);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSelected(AbstractIndexedLine line) {
/* 137 */     return isSelected(this.getValue.getValue(line));
/*     */   }
/*     */   
/*     */   public abstract boolean isSelected(Object paramObject);
/*     */   
/*     */   public static class Contains
/*     */     extends FieldSelect {
/*     */     protected Contains(String name, String value, IGetValue getValue) {
/* 145 */       super(name, value, "Contains", getValue);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(Object o) {
/* 155 */       if (isCaseSensitive() || o == null) {
/* 156 */         return (o != null && o
/* 157 */           .toString().indexOf(getFieldValue()) >= 0);
/*     */       }
/* 159 */       return (o.toString().toLowerCase().indexOf(getFieldValue()) >= 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DoesntContain
/*     */     extends FieldSelect {
/*     */     protected DoesntContain(String name, String value, IGetValue fieldDef) {
/* 166 */       super(name, value, "Doesnt_Contain", fieldDef);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(Object o) {
/* 177 */       if (isCaseSensitive() || o == null) {
/* 178 */         return (o == null || o
/* 179 */           .toString().indexOf(getFieldValue()) < 0);
/*     */       }
/* 181 */       return (o.toString().toLowerCase().indexOf(getFieldValue()) < 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class StartsWith
/*     */     extends FieldSelect {
/*     */     protected StartsWith(String name, String value, IGetValue fieldDef) {
/* 188 */       super(name, value, "Doesnt_Contain", fieldDef);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(Object o) {
/* 199 */       if (isCaseSensitive() || o == null) {
/* 200 */         return (o != null && o
/* 201 */           .toString().startsWith(getFieldValue()));
/*     */       }
/* 203 */       return o.toString().toLowerCase().startsWith(getFieldValue());
/*     */     } }
/*     */   
/*     */   public static class RegularEx extends FieldSelect {
/*     */     final Pattern pattern;
/*     */     
/*     */     protected RegularEx(String name, String value, IGetValue fieldDef) {
/* 210 */       super(name, value, "Doesnt_Contain", fieldDef);
/* 211 */       this.pattern = Pattern.compile(value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(Object value) {
/* 218 */       return (value != null && this.pattern.matcher(value.toString()).matches());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Empty
/*     */     extends FieldSelect
/*     */   {
/*     */     protected Empty(String name, String value, IGetValue fieldDef) {
/* 227 */       super(name, value, "Is Empty", fieldDef);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(Object o) {
/* 237 */       return (o == null || o
/* 238 */         .toString() == null || o
/* 239 */         .toString().trim().length() == 0 || (o instanceof IEmptyTest && ((IEmptyTest)o)
/* 240 */         .isEmpty()));
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TrueSelect
/*     */     extends FieldSelect {
/*     */     protected TrueSelect() {
/* 247 */       super("", "", "True", (IGetValue)null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(Object o) {
/* 256 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFieldDetail getFieldDetail() {
/* 266 */     if (this.getValue instanceof GetValue) {
/* 267 */       return ((GetValue)this.getValue).fieldDetail;
/*     */     }
/* 269 */     return null;
/*     */   }
/*     */ }

