/*     */ package com.MainFrame.Reader.detailsSelection;
/*     */ 
/*     */ import java.util.List;
/*     */ import com.MainFrame.Reader.Common.AbstractIndexedLine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrSelection
/*     */   extends AbsGroup
/*     */ {
/*     */   public OrSelection() {
/*  35 */     this(10);
/*     */   }
/*     */   
/*     */   public OrSelection(int size) {
/*  39 */     super(size);
/*  40 */     setType(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSelected(List<? extends AbstractIndexedLine> lines) {
/*  53 */     if (size() > 0) {
/*     */ 
/*     */       
/*  56 */       for (int i = 0; i < size(); i++) {
/*  57 */         RecordSel sel = (RecordSel)get(i);
/*     */         
/*  59 */         if (sel.isSelected(lines)) {
/*  60 */           return true;
/*     */         }
/*     */       } 
/*     */     } else {
/*  64 */       return true;
/*     */     } 
/*  66 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSelected(AbstractIndexedLine line) {
/*  75 */     if (size() > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  80 */       for (int i = 0; i < size(); i++) {
/*  81 */         RecordSel sel = (RecordSel)get(i);
/*     */         
/*  83 */         if (sel.isSelected(line))
/*     */         {
/*  85 */           return true;
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/*  90 */       return true;
/*     */     } 
/*  92 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIncluded(AbstractIndexedLine line) {
/* 101 */     return true;
/*     */   }
/*     */ }

