/*     */ package com.MainFrame.Reader.detailsSelection;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.List;
/*     */ import com.MainFrame.Reader.Common.AbstractIndexedLine;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.Types.TypeManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GetValue
/*     */   implements IGetValue
/*     */ {
/*     */   public static final int GT_FIELD = 0;
/*     */   public static final int GT_FIRST = 1;
/*     */   public static final int GT_LAST = 2;
/*     */   public static final int GT_MAX = 3;
/*     */   public static final int GT_MIN = 4;
/*     */   public static final int GT_SUM = 5;
/*     */   public static final int GT_AVE = 6;
/*     */   public static final int GT_MAXIMUM_ID = 6;
/*     */   protected final IFieldDetail fieldDetail;
/*     */   private final int recordIdx;
/*     */   
/*     */   public static GetValue get(int type, IFieldDetail fieldDetail, int recordIdx) {
/*  53 */     switch (type) { case 0:
/*  54 */         return new FieldValue(fieldDetail, recordIdx);
/*  55 */       case 1: return new First(fieldDetail, recordIdx);
/*  56 */       case 2: return new Last(fieldDetail, recordIdx);
/*  57 */       case 4: return new Min(fieldDetail, recordIdx);
/*  58 */       case 3: return new Max(fieldDetail, recordIdx);
/*  59 */       case 5: return new Sum(fieldDetail, recordIdx, false);
/*  60 */       case 6: return new Sum(fieldDetail, recordIdx, true); }
/*     */     
/*  62 */     throw new RuntimeException("Invalid Accumulator: " + type);
/*     */   }
/*     */   
/*     */   private static BigDecimal getNum(Object o) {
/*  66 */     if (o == null)
/*  67 */       return null; 
/*  68 */     if (o instanceof BigDecimal) {
/*  69 */       return (BigDecimal)o;
/*     */     }
/*     */     try {
/*  72 */       return new BigDecimal(o.toString());
/*  73 */     } catch (Exception exception) {
/*     */ 
/*     */       
/*  76 */       return null;
/*     */     } 
/*     */   }
/*     */   private static String getString(Object o) {
/*  80 */     if (o == null) {
/*  81 */       return null;
/*     */     }
/*  83 */     return o.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GetValue(IFieldDetail fieldDetail, int recordIdx) {
/*  96 */     this.fieldDetail = fieldDetail;
/*  97 */     this.recordIdx = recordIdx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNumeric() {
/* 105 */     return (this.fieldDetail != null && TypeManager.getInstance().getType(this.fieldDetail.getType()).isNumeric());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(AbstractIndexedLine line) {
/* 114 */     if (this.fieldDetail != null && (this.recordIdx < 0 || this.recordIdx == line.getPreferredLayoutIdx()))
/*     */     {
/* 116 */       return line.getField(this.fieldDetail);
/*     */     }
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIncluded(AbstractIndexedLine line) {
/* 126 */     return (this.recordIdx < 0 || this.recordIdx == line.getPreferredLayoutIdx());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFieldDetail getFieldDetail() {
/* 133 */     return this.fieldDetail;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class FieldValue
/*     */     extends GetValue
/*     */   {
/*     */     public FieldValue(IFieldDetail fieldDetail, int recordIdx) {
/* 141 */       super(fieldDetail, recordIdx);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getValue(List<? extends AbstractIndexedLine> lines) {
/* 149 */       throw new RuntimeException("passed a list of lines");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Max
/*     */     extends GetValue {
/*     */     public Max(IFieldDetail fieldDetail, int recordIdx) {
/* 156 */       super(fieldDetail, recordIdx);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getValue(List<? extends AbstractIndexedLine> lines) {
/* 166 */       if (TypeManager.getInstance().getType(this.fieldDetail.getType()).isNumeric()) {
/* 167 */         BigDecimal max = null;
/*     */         
/* 169 */         for (AbstractIndexedLine l : lines) {
/* 170 */           BigDecimal c = GetValue.getNum(getValue(l));
/* 171 */           if (c != null && (max == null || c.compareTo(max) > 0)) {
/* 172 */             max = c;
/*     */           }
/*     */         } 
/* 175 */         return max;
/*     */       } 
/*     */       
/* 178 */       String maxStr = null;
/* 179 */       for (AbstractIndexedLine l : lines) {
/* 180 */         String s = GetValue.getString(getValue(l));
/* 181 */         if (s != null && (maxStr == null || s.compareTo(maxStr) > 0)) {
/* 182 */           maxStr = s;
/*     */         }
/*     */       } 
/* 185 */       return maxStr;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Min
/*     */     extends GetValue
/*     */   {
/*     */     public Min(IFieldDetail fieldDetail, int recordIdx) {
/* 193 */       super(fieldDetail, recordIdx);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getValue(List<? extends AbstractIndexedLine> lines) {
/* 203 */       if (TypeManager.getInstance().getType(this.fieldDetail.getType()).isNumeric()) {
/* 204 */         BigDecimal max = null;
/*     */         
/* 206 */         for (AbstractIndexedLine l : lines) {
/* 207 */           BigDecimal c = GetValue.getNum(getValue(l));
/* 208 */           if (c != null && (max == null || c.compareTo(max) < 0)) {
/* 209 */             max = c;
/*     */           }
/*     */         } 
/* 212 */         return max;
/*     */       } 
/*     */       
/* 215 */       String maxStr = null;
/* 216 */       for (AbstractIndexedLine l : lines) {
/* 217 */         String s = GetValue.getString(getValue(l));
/* 218 */         if (s != null && (maxStr == null || s.compareTo(maxStr) < 0)) {
/* 219 */           maxStr = s;
/*     */         }
/*     */       } 
/* 222 */       return maxStr;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class First
/*     */     extends GetValue
/*     */   {
/*     */     public First(IFieldDetail fieldDetail, int recordIdx) {
/* 230 */       super(fieldDetail, recordIdx);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getValue(List<? extends AbstractIndexedLine> lines) {
/* 239 */       for (int i = 0; i < lines.size(); i++) {
/* 240 */         Object o = getValue(lines.get(i));
/* 241 */         if (o != null) {
/* 242 */           return o;
/*     */         }
/*     */       } 
/* 245 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Last
/*     */     extends GetValue
/*     */   {
/*     */     public Last(IFieldDetail fieldDetail, int recordIdx) {
/* 254 */       super(fieldDetail, recordIdx);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getValue(List<? extends AbstractIndexedLine> lines) {
/* 263 */       for (int i = lines.size() - 1; i >= 0; i--) {
/* 264 */         Object o = getValue(lines.get(i));
/* 265 */         if (o != null) {
/* 266 */           return o;
/*     */         }
/*     */       } 
/* 269 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Sum extends GetValue {
/*     */     boolean calcAverage;
/*     */     
/*     */     public Sum(IFieldDetail fieldDetail, int recordIdx, boolean ave) {
/* 277 */       super(fieldDetail, recordIdx);
/*     */       
/* 279 */       this.calcAverage = ave;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getValue(List<? extends AbstractIndexedLine> lines) {
/* 288 */       BigDecimal sum = BigDecimal.ZERO;
/*     */       
/* 290 */       if (TypeManager.getInstance().getType(this.fieldDetail.getType()).isNumeric()) {
/* 291 */         int count = 0;
/* 292 */         for (AbstractIndexedLine l : lines) {
/* 293 */           BigDecimal c = GetValue.getNum(getValue(l));
/* 294 */           if (c != null) {
/* 295 */             sum = sum.add(c);
/* 296 */             count++;
/*     */           } 
/*     */         } 
/* 299 */         if (count > 0 && this.calcAverage) {
/* 300 */           sum = sum.divide(BigDecimal.valueOf(count), 10, 0);
/*     */         }
/*     */       } 
/* 303 */       return sum;
/*     */     }
/*     */   }
/*     */ }

