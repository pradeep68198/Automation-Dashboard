/*    */ package com.MainFrame.Reader.detailsSelection;
/*    */ 
/*    */ import java.util.List;
/*    */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalGroupSelection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbsGroup
/*    */   extends ExternalGroupSelection<RecordSel>
/*    */   implements RecordSel
/*    */ {
/*    */   public AbsGroup(int size) {
/* 36 */     super(size);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FieldSelect getFirstField() {
/* 46 */     FieldSelect s = null;
/*    */     
/* 48 */     for (int i = 0; i < getSize() && s == null; i++) {
/* 49 */       s = ((RecordSel)get(i)).getFirstField();
/*    */     }
/* 51 */     return s;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void getAllFields(List<FieldSelect> fields) {
/* 61 */     for (int i = 0; i < getSize(); i++)
/* 62 */       ((RecordSel)get(i)).getAllFields(fields); 
/*    */   }
/*    */ }

