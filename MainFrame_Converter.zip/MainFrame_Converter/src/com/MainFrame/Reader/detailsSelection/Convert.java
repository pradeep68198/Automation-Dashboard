/*    */ package com.MainFrame.Reader.detailsSelection;
/*    */ 
/*    */ import com.MainFrame.Reader.Common.IGetFieldByName;
/*    */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalFieldSelection;
/*    */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalGroupSelection;
/*    */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Convert
/*    */ {
/*    */   public RecordSel convert(ExternalSelection sel, IGetFieldByName recDef) {
/* 37 */     return convertI(sel, recDef);
/*    */   } private RecordSel convertI(ExternalSelection sel, IGetFieldByName recDef) {
/*    */     ExternalGroupSelection<ExternalSelection> g;
/*    */     ExternalFieldSelection f;
/*    */     AndSelection and;
/*    */     OrSelection or;
/* 43 */     RecordSel ret = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 49 */     switch (sel.getType()) {
/*    */       case 1:
/* 51 */         f = (ExternalFieldSelection)sel;
/*    */ 
/*    */ 
/*    */         
/* 55 */         ret = FieldSelectX.get(f, recDef.getField(f.getFieldName()));
/*    */         break;
/*    */       case 2:
/* 58 */         g = (ExternalGroupSelection<ExternalSelection>)sel;
/*    */         
/* 60 */         and = new AndSelection(g.size());
/* 61 */         copy(g, and, recDef);
/* 62 */         ret = and;
/*    */         break;
/*    */       case 3:
/* 65 */         g = (ExternalGroupSelection<ExternalSelection>)sel;
/*    */         
/* 67 */         or = new OrSelection(g.size());
/* 68 */         ret = copy(g, or, recDef);
/*    */         break;
/*    */     } 
/*    */ 
/*    */     
/* 73 */     return ret;
/*    */   }
/*    */   
/*    */   private RecordSel copy(ExternalGroupSelection<ExternalSelection> g, ExternalGroupSelection<RecordSel> to, IGetFieldByName r) {
/* 77 */     for (int i = 0; i < g.size(); i++) {
/* 78 */       to.add(convertI(g.get(i), r));
/*    */     }
/*    */     
/* 81 */     if (to.size() == 1) {
/* 82 */       return (RecordSel)to.get(0);
/*    */     }
/* 84 */     return (RecordSel)to;
/*    */   }
/*    */ }

