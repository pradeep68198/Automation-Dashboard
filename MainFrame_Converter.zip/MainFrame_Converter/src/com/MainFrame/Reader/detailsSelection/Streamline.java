/*    */ package com.MainFrame.Reader.detailsSelection;
/*    */ 
/*    */ import com.MainFrame.Reader.ExternalRecordSelection.StreamLine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Streamline
/*    */   extends StreamLine<RecordSel>
/*    */ {
/* 32 */   private static final Streamline instance = new Streamline();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Streamline getInstance() {
/* 38 */     return instance;
/*    */   }
/*    */ }

