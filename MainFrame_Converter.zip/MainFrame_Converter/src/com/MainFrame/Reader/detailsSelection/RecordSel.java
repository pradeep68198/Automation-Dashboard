package com.MainFrame.Reader.detailsSelection;

import java.util.List;
import com.MainFrame.Reader.Common.AbstractIndexedLine;
import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;

public interface RecordSel extends ExternalSelection {
  boolean isSelected(List<? extends AbstractIndexedLine> paramList);
  
  boolean isSelected(AbstractIndexedLine paramAbstractIndexedLine);
  
  boolean isIncluded(AbstractIndexedLine paramAbstractIndexedLine);
  
  FieldSelect getFirstField();
  
  void getAllFields(List<FieldSelect> paramList);
  
  int getSize();
}
