/*     */ package com.MainFrame.Reader.detailsSelection;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.List;
/*     */ import com.MainFrame.Reader.Common.AbstractIndexedLine;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.ExternalRecordSelection.ExternalFieldSelection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FieldSelectX
/*     */   extends FieldSelect
/*     */ {
/*     */   public static final String STARTS_WITH = "Starts With";
/*     */   public static final String DOES_NOT_CONTAIN = "Doesn't Contain";
/*     */   public static final String CONTAINS = "Contains";
/*     */   public static final String EMPTY = "Is Empty";
/*     */   public static final String NUM_EQ = "= (Numeric)";
/*     */   public static final String NUM_GT = "> (Numeric)";
/*     */   public static final String NUM_GE = ">= (Numeric)";
/*     */   public static final String NUM_LT = "< (Numeric)";
/*     */   public static final String NUM_LE = "<= (Numeric)";
/*     */   public static final String TEXT_EQ = "= (Text)";
/*     */   public static final String TEXT_GT = "> (Text)";
/*     */   public static final String TEXT_GE = ">= (Text)";
/*     */   public static final String TEXT_LT = "< (Text)";
/*     */   public static final String TEXT_LE = "<= (Text)";
/*     */   public static final int G_FIRST = 1;
/*     */   public static final int G_LAST = 2;
/*     */   public static final int G_MAX = 3;
/*     */   public static final int G_MIN = 4;
/*     */   public static final int G_SUM = 5;
/*     */   public static final int G_AVE = 6;
/*     */   public static final int G_ANY_OF = 7;
/*     */   public static final int G_ALL = 8;
/*     */   public static final int G_HIGHEST_CODE = 8;
/*     */   private boolean numeric;
/*     */   protected BigDecimal num;
/*     */   
/*     */   public FieldSelectX(String name, String value, String op, IGetValue fieldDef) {
/*  66 */     this(name, value, op, fieldDef
/*  67 */         .isNumeric(), fieldDef);
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldSelectX(String name, String value, String op, boolean isNumeric, IGetValue fieldDef) {
/*  72 */     super(name, value, op, fieldDef);
/*  73 */     BigDecimal d = null;
/*     */     
/*  75 */     if (this.getValue == null) {
/*  76 */       this.numeric = false;
/*     */     } else {
/*  78 */       this.numeric = isNumeric;
/*     */       
/*  80 */       if (this.numeric) {
/*  81 */         d = new BigDecimal(value);
/*     */       }
/*     */     } 
/*  84 */     this.num = d;
/*     */   }
/*     */   public static FieldSelect get(ExternalFieldSelection fs, IFieldDetail fieldDef) {
/*  87 */     return get(fs.getFieldName(), fs.getFieldValue(), fs.getOperator(), -1, fieldDef, fs.isCaseSensitive());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RecordSel get(String name, String value, String op, int groupId, int recordIdx, IFieldDetail fieldDef, boolean caseSensitive) {
/*     */     FieldSelect r;
/* 110 */     switch (groupId) {
/*     */       case 7:
/*     */       case 8:
/* 113 */         r = get(name, value, op, recordIdx, fieldDef, caseSensitive);
/* 114 */         return new AnyAllOf(r, (groupId == 7));
/*     */     } 
/* 116 */     GetValue g = GetValue.get(groupId, fieldDef, recordIdx);
/* 117 */     if (g != null) {
/* 118 */       FieldSelect rs = get(name, value, op, g, caseSensitive);
/* 119 */       rs.setCaseSensitive(caseSensitive);
/* 120 */       return rs;
/*     */     } 
/*     */     
/* 123 */     throw new RuntimeException("No valid grouping function !!!");
/*     */   }
/*     */   
/*     */   public static FieldSelect get(String name, String value, String op, IFieldDetail fieldDef) {
/* 127 */     return get(name, value, op, new GetValue.FieldValue(fieldDef, -1), false);
/*     */   }
/*     */   
/*     */   public static FieldSelect get(String name, String value, String op, int recordIdx, IFieldDetail fieldDef, boolean caseSensitive) {
/* 131 */     return get(name, value, op, new GetValue.FieldValue(fieldDef, recordIdx), caseSensitive);
/*     */   }
/*     */   
/*     */   public static FieldSelect get(String name, String value, String op, IGetValue fieldDef, boolean caseSensitive) {
/*     */     FieldSelect ret;
/* 136 */     if (op != null) {
/* 137 */       op = op.trim();
/*     */     }
/* 139 */     if ("!=".equals(op) || "<>".equals(op) || "ne".equalsIgnoreCase(op)) {
/* 140 */       ret = new NotEqualsSelect(name, value, fieldDef);
/* 141 */     } else if ("Contains".equalsIgnoreCase(op)) {
/* 142 */       ret = new FieldSelect.Contains(name, value, fieldDef);
/* 143 */     } else if ("Is Empty".equalsIgnoreCase(op)) {
/* 144 */       ret = new FieldSelect.Empty(name, value, fieldDef);
/* 145 */     } else if ("Doesn't Contain".equalsIgnoreCase(op)) {
/* 146 */       ret = new FieldSelect.DoesntContain(name, value, fieldDef);
/* 147 */     } else if ("Starts With".equalsIgnoreCase(op)) {
/* 148 */       ret = new FieldSelect.StartsWith(name, value, fieldDef);
/* 149 */     } else if ("Regular Expression".equalsIgnoreCase(op)) {
/* 150 */       ret = new FieldSelect.RegularEx(name, value, fieldDef);
/*     */     } else {
/* 152 */       ret = getBasic(name, value, op, fieldDef, caseSensitive);
/*     */     } 
/*     */     
/* 155 */     if (ret == null) {
/* 156 */       if ("= (Numeric)".equalsIgnoreCase(op) || "<> (Numeric)".equalsIgnoreCase(op) || "> (Numeric)"
/* 157 */         .equalsIgnoreCase(op) || ">= (Numeric)".equalsIgnoreCase(op) || "< (Numeric)"
/* 158 */         .equalsIgnoreCase(op) || "<= (Numeric)".equalsIgnoreCase(op)) {
/* 159 */         FieldSelectX ret1 = getBasic(name, value, op.substring(0, 2).trim(), fieldDef, caseSensitive);
/* 160 */         ret1.setNumeric(true);
/* 161 */         ret = ret1;
/* 162 */       } else if ("= (Text)".equalsIgnoreCase(op) || "<> (Text)".equalsIgnoreCase(op) || "> (Text)"
/* 163 */         .equalsIgnoreCase(op) || ">= (Text)".equalsIgnoreCase(op) || "< (Text)"
/* 164 */         .equalsIgnoreCase(op) || "<= (Text)".equalsIgnoreCase(op)) {
/* 165 */         FieldSelectX ret1 = getBasic(name, value, op.substring(0, 2).trim(), fieldDef, caseSensitive);
/* 166 */         ret1.setNumeric(false);
/* 167 */         ret = ret1;
/*     */       } else {
/* 169 */         ret = new EqualsSelect(name, value, fieldDef);
/*     */       } 
/*     */     }
/*     */     
/* 173 */     return ret;
/*     */   }
/*     */   
/*     */   public static FieldSelect getTrueSelection() {
/* 177 */     return new FieldSelect.TrueSelect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static FieldSelectX getBasic(String name, String value, String op, IGetValue fieldDef, boolean caseSensitive) {
/* 185 */     FieldSelectX ret = null;
/* 186 */     if ("=".equals(op)) {
/* 187 */       ret = new EqualsSelect(name, value, fieldDef);
/* 188 */     } else if (">".equals(op) || "gt".equalsIgnoreCase(op)) {
/* 189 */       ret = new GreaterThan(name, value, ">", fieldDef);
/* 190 */     } else if (">=".equals(op) || "ge".equalsIgnoreCase(op)) {
/* 191 */       ret = new GreaterThan(name, value, ">=", fieldDef);
/* 192 */     } else if ("<".equals(op) || "lt".equalsIgnoreCase(op)) {
/* 193 */       ret = new LessThan(name, value, "<", fieldDef);
/* 194 */     } else if ("<=".equals(op) || "le".equalsIgnoreCase(op)) {
/* 195 */       ret = new LessThan(name, value, "<=", fieldDef);
/* 196 */     } else if ("<>".equals(op)) {
/* 197 */       ret = new NotEqualsSelect(name, value, fieldDef);
/*     */     } 
/*     */     
/* 200 */     if (ret != null) {
/* 201 */       ret.setCaseSensitive(caseSensitive);
/*     */     }
/* 203 */     return ret;
/*     */   }
/*     */   
/*     */   protected final int compare(Object o, int defaultVal) {
/* 207 */     int res = defaultVal;
/* 208 */     if (o == null || o.toString() == null) return -121; 
/* 209 */     if (this.numeric) {
/* 210 */       if (o instanceof BigDecimal) {
/* 211 */         res = ((BigDecimal)o).compareTo(this.num);
/*     */       } else {
/*     */         try {
/* 214 */           res = (new BigDecimal(o.toString())).compareTo(this.num);
/*     */         }
/* 216 */         catch (Exception exception) {}
/*     */       } 
/*     */     } else {
/*     */       
/* 220 */       String fieldValue = getFieldValue();
/* 221 */       if (fieldValue != null)
/*     */       {
/* 223 */         if (isCaseSensitive()) {
/* 224 */           res = o.toString().compareTo(fieldValue);
/*     */         } else {
/* 226 */           res = o.toString().compareToIgnoreCase(fieldValue);
/*     */         }  } 
/*     */     } 
/* 229 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNumeric() {
/* 237 */     return this.numeric;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNumeric(boolean numeric) {
/* 245 */     if (numeric && this.num == null) {
/*     */       try {
/* 247 */         this.num = new BigDecimal(getFieldValue());
/* 248 */         this.numeric = numeric;
/* 249 */       } catch (Exception exception) {}
/*     */     }
/*     */     else {
/*     */       
/* 253 */       this.numeric = numeric;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static final class GreaterThan
/*     */     extends FieldSelectX {
/* 259 */     private int cmpTo = 0;
/*     */     private GreaterThan(String name, String value, String op, IGetValue fieldDef) {
/* 261 */       super(name, value, op, fieldDef);
/*     */       
/* 263 */       if (">".equals(op)) {
/* 264 */         this.cmpTo = 1;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(Object value) {
/* 273 */       return (compare(value, -2) >= this.cmpTo);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class LessThan extends FieldSelectX {
/* 278 */     private int cmpTo = 0;
/*     */     private LessThan(String name, String value, String op, IGetValue fieldDef) {
/* 280 */       super(name, value, op, fieldDef);
/*     */       
/* 282 */       if ("<".equals(op)) {
/* 283 */         this.cmpTo = -1;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(Object value) {
/* 292 */       int cmp = compare(value, 2);
/* 293 */       return (cmp <= this.cmpTo && cmp != -121);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class EqualsSelect
/*     */     extends FieldSelectX
/*     */   {
/*     */     protected EqualsSelect(String name, String value, IGetValue fieldDef) {
/* 301 */       super(name, value, "=", fieldDef);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(Object value) {
/* 311 */       return (compare(value, 2) == 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class NotEqualsSelect
/*     */     extends FieldSelectX {
/*     */     protected NotEqualsSelect(String name, String value, IGetValue fieldDef) {
/* 318 */       super(name, value, "!=", fieldDef);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(Object value) {
/* 329 */       return (compare(value, 0) != 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class DelagteRecordSel
/*     */     implements RecordSel
/*     */   {
/*     */     private final RecordSel childSel;
/*     */     
/*     */     public DelagteRecordSel(RecordSel childSel) {
/* 339 */       this.childSel = childSel;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getType() {
/* 347 */       return this.childSel.getType();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getElementCount() {
/* 355 */       return this.childSel.getElementCount();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(AbstractIndexedLine line) {
/* 363 */       return this.childSel.isSelected(line);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isIncluded(AbstractIndexedLine line) {
/* 371 */       return this.childSel.isIncluded(line);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldSelect getFirstField() {
/* 379 */       return this.childSel.getFirstField();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void getAllFields(List<FieldSelect> fields) {
/* 387 */       this.childSel.getAllFields(fields);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getSize() {
/* 395 */       return this.childSel.getSize();
/*     */     } }
/*     */   
/*     */   public static class AnyAllOf extends DelagteRecordSel {
/*     */     private final boolean anyOf;
/*     */     
/*     */     public AnyAllOf(RecordSel childSel, boolean any) {
/* 402 */       super(childSel);
/*     */       
/* 404 */       this.anyOf = any;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(List<? extends AbstractIndexedLine> lines) {
/* 412 */       if (lines == null) return false; 
/* 413 */       for (AbstractIndexedLine l : lines) {
/* 414 */         if (isIncluded(l) && isSelected(l) == this.anyOf) {
/* 415 */           return this.anyOf;
/*     */         }
/*     */       } 
/*     */       
/* 419 */       return !this.anyOf;
/*     */     }
/*     */   }
/*     */ }

