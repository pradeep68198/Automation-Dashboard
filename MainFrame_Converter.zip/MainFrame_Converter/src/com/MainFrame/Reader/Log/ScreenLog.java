/*    */ package com.MainFrame.Reader.Log;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.JTextArea;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScreenLog
/*    */   extends JScrollPane
/*    */   implements AbsSSLogger
/*    */ {
/* 49 */   private JTextArea log = new JTextArea();
/*    */   
/* 51 */   private int currErrorLevel = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ScreenLog(Component parentContainer) {
/* 62 */     setViewportView(this.log);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void logException(int level, Exception ex) {
/* 71 */     if (ex != null && this.currErrorLevel < level) {
/* 72 */       StringBuffer buf = new StringBuffer(this.log.getText());
/*    */       
/* 74 */       CommonCode.append(buf, ex);
/*    */       
/* 76 */       this.log.setText(buf.toString());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void logMsg(int level, String msg) {
/* 87 */     if (this.currErrorLevel < level) {
/* 88 */       this.log.setText(this.log.getText() + "\n\n" + msg);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setReportLevel(int level) {
/* 98 */     this.currErrorLevel = level;
/*    */   }
/*    */ }

