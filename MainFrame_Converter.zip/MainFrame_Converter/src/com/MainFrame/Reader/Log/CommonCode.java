/*    */ package com.MainFrame.Reader.Log;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CommonCode
/*    */ {
/*    */   public static void append(Appendable buf, Exception ex) {
/* 34 */     StackTraceElement[] el = ex.getStackTrace();
/* 35 */     int fin = Math.min(1000, el.length);
/*    */     
/*    */     try {
/* 38 */       buf.append("\n\nClass=");
/* 39 */       buf.append(ex.getClass().getName());
/* 40 */       buf.append("    Error=");
/* 41 */       buf.append(ex.getMessage());
/* 42 */       buf.append("\n");
/*    */       
/* 44 */       for (int i = 0; i < fin; i++) {
/* 45 */         buf.append("\n    ");
/* 46 */         buf.append(el[i].getClassName());
/* 47 */         buf.append("  :  ");
/* 48 */         buf.append(Integer.toString(el[i].getLineNumber()));
/*    */       } 
/* 50 */     } catch (IOException e) {
/* 51 */       printAppendError(e, ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void printAppendError(Exception e, Exception ex) {
/* 57 */     System.err.println();
/* 58 */     System.err.println("Error in Appending: ");
/* 59 */     e.printStackTrace();
/* 60 */     if (ex != null) {
/* 61 */       System.err.println();
/* 62 */       System.err.println("Caused by: ");
/* 63 */       ex.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }

