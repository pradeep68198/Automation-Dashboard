/*    */ package com.MainFrame.Reader.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullLog
/*    */   implements AbsSSLogger
/*    */ {
/*    */   public void setReportLevel(int level) {}
/*    */   
/*    */   public void logException(int level, Exception ex) {}
/*    */   
/*    */   public void logMsg(int level, String msg) {}
/*    */   
/*    */   public static AbsSSLogger getLog(AbsSSLogger log) {
/* 59 */     if (log == null) {
/* 60 */       log = new NullLog();
/*    */     }
/* 62 */     return log;
/*    */   }
/*    */ }

