/*    */ package com.MainFrame.Reader.Log;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AppendableLog
/*    */   implements AbsSSLogger
/*    */ {
/*    */   private final Appendable logStore;
/*    */   
/*    */   public AppendableLog(Appendable logStore) {
/* 46 */     this.logStore = logStore;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setReportLevel(int level) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void logException(int level, Exception ex) {
/*    */     try {
/* 61 */       this.logStore.append('\n');
/*    */       
/* 63 */       if (ex != null) {
/* 64 */         this.logStore.append('\n');
/* 65 */         CommonCode.append(this.logStore, ex);
/*    */       } 
/* 67 */     } catch (IOException e) {
/* 68 */       CommonCode.printAppendError(e, ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void logMsg(int level, String msg) {
/* 76 */     if (msg == null) {
/* 77 */       msg = "null";
/*    */     }
/*    */     try {
/* 80 */       this.logStore.append('\n');
/* 81 */       this.logStore.append(msg);
/* 82 */       this.logStore.append('\n');
/* 83 */     } catch (IOException e) {
/* 84 */       System.err.println();
/* 85 */       System.err.println("Error in Appending: " + msg + ": ");
/* 86 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }

