/*    */ package com.MainFrame.Reader.Log;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextLog
/*    */   implements AbsSSLogger
/*    */ {
/*    */   private final PrintStream outStream;
/*    */   
/*    */   public TextLog() {
/* 45 */     this(System.err);
/*    */   }
/*    */   
/*    */   public TextLog(PrintStream outStream) {
/* 49 */     this.outStream = outStream;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setReportLevel(int level) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void logException(int level, Exception ex) {
/* 63 */     this.outStream.println();
/*    */     
/* 65 */     if (ex != null) {
/* 66 */       this.outStream.println();
/* 67 */       ex.printStackTrace(this.outStream);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void logMsg(int level, String msg) {
/* 75 */     this.outStream.println();
/* 76 */     this.outStream.println(msg);
/*    */   }
/*    */   
/*    */   public static AbsSSLogger getLog(AbsSSLogger log) {
/* 80 */     if (log == null) {
/* 81 */       log = new TextLog();
/*    */     }
/* 83 */     return log;
/*    */   }
/*    */ }

