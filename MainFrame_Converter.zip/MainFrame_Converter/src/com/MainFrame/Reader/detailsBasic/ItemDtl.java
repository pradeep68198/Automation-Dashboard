/*     */ package com.MainFrame.Reader.detailsBasic;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import com.MainFrame.Reader.Common.FieldDetail;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.cgen.def.IArrayAnyDimension;
/*     */ import com.MainFrame.Reader.cgen.def.IArrayExtended;
/*     */ import com.MainFrame.Convert2xml.analysis.BaseItem;
/*     */ import com.MainFrame.Convert2xml.analysis.Item;
/*     */ import com.MainFrame.Convert2xml.def.IItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemDtl
/*     */   extends Item
/*     */   implements IItemDetails
/*     */ {
/*  21 */   public static List<ItemDtl> EMPTY_LIST = Collections.unmodifiableList(new ArrayList<ItemDtl>(0));
/*     */   
/*     */   public enum ItemType {
/*  24 */     GROUP(false, false, false),
/*  25 */     GROUP_ARRAY(false, true, false),
/*  26 */     GROUP_ARRAY_DEFINITION(false, true, true),
/*  27 */     FIELD(true, false, false),
/*  28 */     FIELD_ARRAY(true, true, false),
/*  29 */     FIELD_ARRAY_DEFINITION(true, true, true);
/*     */     public final boolean isField;
/*     */     public final boolean isArray;
/*     */     public final boolean isArrayDefinition;
/*     */     
/*     */     ItemType(boolean isField, boolean isArray, boolean isArrayDefinition) {
/*  35 */       this.isField = isField;
/*  36 */       this.isArray = isArray;
/*  37 */       this.isArrayDefinition = isArrayDefinition;
/*     */     }
/*     */   }
/*  40 */   private static ItemType[] itmTypeValues = ItemType.values();
/*     */   
/*     */   public static ItemType toItemType(boolean isField, boolean isArray, boolean isArrayDefinition) {
/*  43 */     int st = isField ? 3 : 0;
/*     */     
/*  45 */     for (int i = st; i < st + 3; i++) {
/*  46 */       if ((itmTypeValues[i]).isArray == isArray && (itmTypeValues[i]).isArrayDefinition == isArrayDefinition)
/*     */       {
/*  48 */         return itmTypeValues[i];
/*     */       }
/*     */     } 
/*     */     
/*  52 */     throw new RuntimeException("Internal Error: unable to determine the ItemType ??? " + isField + " " + isArray + " " + isArrayDefinition);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ItemType itemType;
/*     */   
/*     */   private final IFieldDetail fieldDefinition;
/*     */   
/*     */   protected final IArrayExtended arrayDefinition;
/*     */   
/*  62 */   private List<ItemDtl> childItems = EMPTY_LIST;
/*     */   
/*     */   public final int levelIndex;
/*     */   
/*     */   public ItemDtl(BaseItem parentItem, IItem baseItem, boolean isArray, IFieldDetail fieldDefinition, IArrayExtended arrayDefinition, int level) {
/*  67 */     super(parentItem, baseItem.getLevelNumber(), baseItem.getLevelString(), baseItem.getFieldName());
/*     */     
/*  69 */     this.itemType = toItemType((baseItem
/*  70 */         .getChildItems() == null || baseItem.getChildItems().size() == 0), isArray, 
/*     */         
/*  72 */         (baseItem.getOccurs() >= 0));
/*  73 */     this.fieldDefinition = fieldDefinition;
/*  74 */     this.arrayDefinition = arrayDefinition;
/*  75 */     this.levelIndex = level;
/*     */     
/*  77 */     if (fieldDefinition instanceof FieldDetail) {
/*  78 */       ((FieldDetail)fieldDefinition).setCobolItem(this);
/*     */     }
/*     */     
/*  81 */     set(baseItem);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ItemDtl> getChildItems() {
/*  89 */     return this.childItems;
/*     */   }
/*     */   
/*     */   public void addItem(Item item) {
/*  93 */     addItem((ItemDtl)item);
/*     */   }
/*     */   
/*     */   public void addItem(ItemDtl item) {
/*  97 */     if (this.childItems == EMPTY_LIST) {
/*  98 */       this.childItems = new ArrayList<ItemDtl>(5);
/*     */     }
/* 100 */     this.childItems.add(item);
/* 101 */     add(item);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFieldDetail getFieldDefinition() {
/* 109 */     return this.fieldDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IArrayExtended getArrayDefinition() {
/* 117 */     return this.arrayDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemType getItemType() {
/* 127 */     return this.itemType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLeaf() {
/* 135 */     return (this.childItems == null || this.childItems.size() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLevelIndex() {
/* 143 */     return this.levelIndex;
/*     */   }
/*     */ }

