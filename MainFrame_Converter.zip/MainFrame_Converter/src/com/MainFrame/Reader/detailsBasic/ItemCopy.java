/*     */ package com.MainFrame.Reader.detailsBasic;


import com.MainFrame.Reader.External.base.*;
import com.MainFrame.Reader.External.Def.*;
import java.util.*;
import com.MainFrame.Convert2xml.analysis.*;
import com.MainFrame.Convert2xml.def.*;
import com.MainFrame.Reader.Common.*;
import com.MainFrame.Reader.cgen.def.*;
public abstract class ItemCopy implements IAddDependingOn
{
    private ArrayList<DependingOn> dependingOn;
    
    public ItemCopy() {
        this.dependingOn = new ArrayList<DependingOn>(6);
    }
    
    public List<ItemDtl> copy(final FieldCreatorHelper fldHelper, final List<? extends IItemJr> items) {
        List<ItemDtl> list = null;
        if (items != null) {
            list = this.copy(fldHelper, null, false, items, ArrayIndexDtls.EMPTY, fldHelper.getInitialLevel());
            this.loadItems(fldHelper, list, ArrayIndexDtls.EMPTY, null, fldHelper.getInitialLevel(), 0);
        }
        return list;
    }
    
    private List<ItemDtl> copy(final FieldCreatorHelper fldHelper, final Item parent, final boolean isArray, final List<? extends IItemJr> items, final ArrayIndexDtls idxDtls, final int level) {
        ArrayList<ItemDtl> itemDtls = null;
        if (items != null) {
            itemDtls = new ArrayList<ItemDtl>();
            for (final IItemJr itm : items) {
                if (itm.getLevelNumber() != 88) {
                    final boolean isArrayItm = isArray || itm.getOccurs() >= 0;
                    final ArrayIndexDtls newIdxDtls = (itm.getOccurs() >= 0) ? new ArrayIndexDtls(idxDtls, itm.getOccurs()) : idxDtls;
                    IFieldDetail fld = null;
                    fldHelper.updateGroup(level, itm.getFieldName());
                    if (!newIdxDtls.inArray) {
                        fld = (IFieldDetail)this.createField(fldHelper, level, itm, idxDtls, null, 0);
                    }
                    final ItemDtl itemDtl = this.createItem(parent, level, itm, isArrayItm, newIdxDtls, fld);
                    this.copy(fldHelper, (Item)itemDtl, isArrayItm, itm.getChildItems(), newIdxDtls, level + 1);
                    itemDtls.add(itemDtl);
                }
            }
        }
        return itemDtls;
    }
    
    protected ItemDtl createItem(final Item parent, final int level, final IItemJr itm, final boolean isArrayItm, final ArrayIndexDtls newIdxDtls, final IFieldDetail fld) {
        final ItemDtl itemDtl = new ItemDtl((BaseItem)parent, (IItem)itm, isArrayItm, fld, this.createArray(itm, newIdxDtls), level);
        if (fld != null) {
            itemDtl.setType(fld.getType());
        }
        return itemDtl;
    }
    
    private void loadItems(final FieldCreatorHelper fldHelper, final List<ItemDtl> itms, final ArrayIndexDtls idxDtls, final DependingOnDtls dependOnParentDtls, final int level, final int basePos) {
        for (final ItemDtl itm : itms) {
            if (itm.getLevelNumber() == 88) {
                continue;
            }
            final List<ItemDtl> childItems = (List<ItemDtl>)itm.getChildItems();
            final int size = childItems.size();
            final String dependingVar = itm.getDependingOn();
            fldHelper.updateGroup(level, itm.getFieldName());
            if (itm.getOccurs() > 0) {
                DependingOn dependOn = null;
                if (dependingVar != null && dependingVar.length() > 0) {
                    dependOn = fldHelper.dependingOnBuilder().setPosition(itm.getPosition() + basePos).setLength(itm.getStorageLength()).setChildOccurs(itm.getOccurs()).newDependingOn((IAddDependingOn)this, dependOnParentDtls, dependingVar);
                }
                final ArrayIndexDtls newIdxDtls = new ArrayIndexDtls(idxDtls, itm.getOccurs());
                if (size == 0) {
                    for (int i = 0; i < itm.getOccurs(); ++i) {
                        newIdxDtls.setIndex(i);
                        itm.arrayDefinition.setField((IIndex)newIdxDtls, this.createField(fldHelper, level, (IItemJr)itm, newIdxDtls, this.createDependingOnDtls(dependOn, dependOnParentDtls, i), basePos + i * itm.getStorageLength()));
                    }
                }
                else {
                    for (int i = 0; i < itm.getOccurs(); ++i) {
                        newIdxDtls.setIndex(i);
                        this.loadItems(fldHelper, childItems, newIdxDtls, this.createDependingOnDtls(dependOn, dependOnParentDtls, i), level + 1, basePos + i * itm.getStorageLength());
                    }
                }
            }
            else {
                if (itm.getOccurs() == 0) {
                    continue;
                }
                if (size == 0) {
                    if (!idxDtls.inArray) {
                        continue;
                    }
                    itm.arrayDefinition.setField((IIndex)idxDtls, this.createField(fldHelper, level, (IItemJr)itm, idxDtls, dependOnParentDtls, basePos));
                }
                else {
                    this.loadItems(fldHelper, childItems, idxDtls, dependOnParentDtls, level + 1, basePos);
                }
            }
        }
    }
    
    public final void addDependingOn(final DependingOn child) {
        this.dependingOn.add(child);
    }
    
    public final ArrayList<DependingOn> getDependingOn() {
        return this.dependingOn;
    }
    
    private DependingOnDtls createDependingOnDtls(final DependingOn dependOn, final DependingOnDtls dependOnParentDtls, final int idx) {
        DependingOnDtls dependOnDtls = dependOnParentDtls;
        if (dependOn != null) {
            dependOnDtls = new DependingOnDtls(dependOn, idx, dependOnParentDtls);
        }
        return dependOnDtls;
    }
    
    public abstract FieldDetail createField(final FieldCreatorHelper p0, final int p1, final IItemJr p2, final ArrayIndexDtls p3, final DependingOnDtls p4, final int p5);
    
    public abstract IArrayExtended createArray(final IItemJr p0, final ArrayIndexDtls p1);
}