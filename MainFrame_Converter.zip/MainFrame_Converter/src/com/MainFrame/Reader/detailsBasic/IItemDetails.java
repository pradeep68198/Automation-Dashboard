package com.MainFrame.Reader.detailsBasic;

import java.util.List;
import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.cgen.def.IArrayAnyDimension;
import com.MainFrame.Convert2xml.def.IItemJr;

public interface IItemDetails extends IItemJr {
  List<? extends IItemDetails> getChildItems();
  
  IFieldDetail getFieldDefinition();
  
  IArrayAnyDimension getArrayDefinition();
  
  ItemDtl.ItemType getItemType();
  
  boolean isLeaf();
  
  int getLevelIndex();
}

