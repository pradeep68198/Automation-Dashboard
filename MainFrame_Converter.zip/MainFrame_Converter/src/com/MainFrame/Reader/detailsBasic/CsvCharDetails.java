/*     */ package com.MainFrame.Reader.detailsBasic;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import com.MainFrame.Reader.Common.Conversion;

public final class CsvCharDetails
{
    private static final byte[] EMPTY_BYTES;
    private static final char[] EMPTY_CHARS;
    public static final CsvCharDetails COMMA_DELIMITER;
    public static final CsvCharDetails TAB_DELIMITER;
    public static final CsvCharDetails DEFAULT_QUOTE;
    public static final CsvCharDetails DEFAULT_DELIMITER;
    public static final CsvCharDetails SINGLE_QUOTE;
    public static final CsvCharDetails DOUBLE_QUOTE;
    public static final CsvCharDetails EMPTY_QUOTE;
    private final String definition;
    private final String strValue;
    private final String font;
    private final byte[] bytes;
    private final char[] chars;
    private final boolean bin;
    
    public static CsvCharDetails newDelimDefinition(final String rawValue, final String font) {
        if (font != null && font.length() == 0) {
            if ("\t".equals(rawValue)) {
                return CsvCharDetails.TAB_DELIMITER;
            }
            if (",".equals(rawValue)) {
                return CsvCharDetails.COMMA_DELIMITER;
            }
        }
        if (rawValue == null || rawValue.length() == 0) {
            return CsvCharDetails.EMPTY_QUOTE;
        }
        return new CsvCharDetails(rawValue, font, '\t');
    }
    
    public static CsvCharDetails newQuoteDefinition(final String rawValue, final String font) {
        if (font != null && font.length() == 0) {
            if ("'".equals(rawValue)) {
                return CsvCharDetails.SINGLE_QUOTE;
            }
            if ("\"".equals(rawValue)) {
                return CsvCharDetails.DOUBLE_QUOTE;
            }
        }
        if (rawValue == null || rawValue.length() == 0) {
            return CsvCharDetails.EMPTY_QUOTE;
        }
        return new CsvCharDetails(rawValue, font, '\t');
    }
    
    public static CsvCharDetails newDef(final byte b, final String font) {
        return new CsvCharDetails(b, font);
    }
    
    private CsvCharDetails(final String rawValue, final String font, final char defaultCh) {
        this.definition = ("\t".equals(rawValue) ? "\\t" : rawValue);
        this.font = font;
        this.bytes = Conversion.getCsvDelimBytes(rawValue, font, defaultCh);
        this.chars = Conversion.decodeChar(rawValue, font, defaultCh);
        this.strValue = new String(this.chars);
        this.bin = Conversion.isHexDefinition(rawValue);
    }
    
    private CsvCharDetails(final byte b, final String font) {
        this.font = font;
        this.bytes = new byte[] { b };
        this.strValue = Conversion.toString(this.bytes, font);
        this.chars = ((this.strValue == null || this.strValue.length() == 0) ? new char[0] : this.strValue.toCharArray());
        this.definition = ("\t".equals(this.strValue) ? "\\t" : this.strValue);
        boolean tbin = true;
        if (this.chars.length == 1 && this.chars[0] >= ' ' && this.chars[0] < '\u0080') {
            tbin = false;
        }
        this.bin = tbin;
    }
    
    private CsvCharDetails() {
        this.definition = "";
        this.font = "";
        this.bytes = CsvCharDetails.EMPTY_BYTES;
        this.chars = CsvCharDetails.EMPTY_CHARS;
        this.strValue = "";
        this.bin = false;
    }
    
    public boolean isBin() {
        return this.bin;
    }
    
    public final byte[] asBytes() {
        return this.bytes;
    }
    
    public final byte asByte() {
        return this.bytes[0];
    }
    
    public final char asChar() {
        return this.chars[0];
    }
    
    public final char[] asChars() {
        return this.chars;
    }
    
    public String asString() {
        return this.strValue;
    }
    
    public String getFont() {
        return this.font;
    }
    
    public String jrDefinition() {
        return this.definition;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof CsvCharDetails) {
            final CsvCharDetails cmp = (CsvCharDetails)obj;
            return this == cmp || this.definition.equals(cmp.definition) || (!this.bin && this.strValue.equals(cmp.strValue)) || (this.bin && Arrays.equals(this.bytes, cmp.bytes));
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return ((this.definition == null) ? 0 : this.definition.hashCode()) + (this.bin ? this.bytes.hashCode() : this.strValue.hashCode());
    }
    
    static {
        EMPTY_BYTES = new byte[0];
        EMPTY_CHARS = new char[0];
        COMMA_DELIMITER = new CsvCharDetails(",", "", '\t');
        TAB_DELIMITER = new CsvCharDetails("\t", "", '\t');
        DEFAULT_QUOTE = new CsvCharDetails("\"", "", '\t');
        DEFAULT_DELIMITER = new CsvCharDetails("\t", "", '\t');
        SINGLE_QUOTE = new CsvCharDetails("'", "", '\"');
        DOUBLE_QUOTE = new CsvCharDetails("\"", "", '\"');
        EMPTY_QUOTE = new CsvCharDetails();
    }
}
