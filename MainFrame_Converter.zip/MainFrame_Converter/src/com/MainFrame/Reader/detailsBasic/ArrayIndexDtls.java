/*     */ package com.MainFrame.Reader.detailsBasic;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import com.MainFrame.Reader.cgen.def.IIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayIndexDtls
/*     */   implements IIndex
/*     */ {
/*  14 */   public static final ArrayIndexDtls EMPTY = new EmptyArrayIndex();
/*     */   
/*     */   public final int occursMax;
/*     */   
/*  18 */   private int index = 0;
/*     */   
/*     */   private String indexStr;
/*     */   
/*     */   public final ArrayList<ArrayIndexDtls> indexList;
/*     */   public final boolean inArray;
/*     */   private int[] indexSizes;
/*     */   
/*     */   private ArrayIndexDtls() {
/*  27 */     this.occursMax = 0;
/*  28 */     this.indexList = new ArrayList<ArrayIndexDtls>(0);
/*  29 */     this.inArray = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayIndexDtls(ArrayIndexDtls prevIndexs, int occursMax) {
/*  38 */     this.occursMax = occursMax;
/*  39 */     this.inArray = true;
/*  40 */     if (prevIndexs == null || prevIndexs.indexList.size() == 0) {
/*  41 */       this.indexList = new ArrayList<ArrayIndexDtls>(1);
/*     */     } else {
/*  43 */       this.indexList = new ArrayList<ArrayIndexDtls>(prevIndexs.indexList.size() + 1);
/*  44 */       this.indexList.addAll(prevIndexs.indexList);
/*     */     } 
/*  46 */     this.indexList.add(this);
/*     */   }
/*     */   
/*     */   public int getNumberOfIndexs() {
/*  50 */     return this.indexList.size();
/*     */   }
/*     */   
/*     */   public int getIndex(int idx) {
/*  54 */     return ((ArrayIndexDtls)this.indexList.get(idx)).index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex() {
/*  61 */     return this.index;
/*     */   }
/*     */   
/*     */   public void incIndex() {
/*  65 */     setIndex(this.index + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndex(int index) {
/*  73 */     this.index = index;
/*  74 */     this.indexStr = Integer.toString(index);
/*     */   }
/*     */   
/*     */   public int[] toIndexSizeArray() {
/*  78 */     if (this.indexSizes == null) {
/*  79 */       this.indexSizes = new int[this.indexList.size()];
/*  80 */       for (int i = 0; i < this.indexSizes.length; i++) {
/*  81 */         this.indexSizes[i] = ((ArrayIndexDtls)this.indexList.get(i)).occursMax;
/*     */       }
/*     */     } 
/*  84 */     return this.indexSizes;
/*     */   }
/*     */   
/*     */   public String toIndexStr() {
/*  88 */     StringBuilder b = new StringBuilder();
/*     */     
/*  90 */     b.append(((ArrayIndexDtls)this.indexList.get(0)).indexStr);
/*  91 */     for (int i = 1; i < this.indexList.size(); i++) {
/*  92 */       b.append(',')
/*  93 */         .append(' ')
/*  94 */         .append(((ArrayIndexDtls)this.indexList.get(i)).indexStr);
/*     */     }
/*     */     
/*  97 */     return b.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class EmptyArrayIndex
/*     */     extends ArrayIndexDtls
/*     */   {
/*     */     public void setIndex(int index) {
/* 108 */       if (index != 0) {
/* 109 */         throw new RuntimeException("You can not update the index for the EMPTY Array Index");
/*     */       }
/* 111 */       super.setIndex(index);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toIndexStr() {
/* 119 */       return "";
/*     */     }
/*     */   }
/*     */ }
