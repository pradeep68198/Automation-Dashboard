
package com.MainFrame.Reader.schema;

import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.schema.jaxb.IItem;

public interface IArrayItemCheck {
	public static final int R_PROCESS = 0;
	public static final int R_SKIP    = 1;
	public static final int R_STOP    = 2;
	
	public int checkItem(AbstractLine line, IItem item, int[] indexs, int index);
	
	public int getCount(AbstractLine line, IItem item, int[] indexs, int defaultCount);
	
	public void updateForCount(AbstractLine line, IItem item, int[] indexs, int count);
}
