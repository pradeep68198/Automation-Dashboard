
package com.MainFrame.Reader.schema;

import java.util.Map;

import com.MainFrame.Reader.schema.jaxb.IItem;


public interface ISchemaInformation {


	public static final int D_NO_DUPLICATES = 1;
	public static final int D_NO_DUPLICATES_IN_RECORD = 2;
	public static final int D_DUPLICATES = 3;

	
	public static final int RO_LEAVE_ASIS = 0;
	public static final int RO_MINUS_TO_UNDERSCORE = 1;
	public static final int RO_CAMEL_CASE = 2;

	
	public abstract Map<String, ? extends IItem> getArrayItems();

	
	public abstract Map<String, Integer> getRecordHierarchyMap();

	
	public abstract int getRecordIndex(String name);

	
	public abstract int getMaxRecordHierarchyLevel();

	
	public abstract int getDuplicateFieldsStatus();

	
	public abstract String updateName(String name);

	
	public abstract IGetRecordFieldByName getFieldLookup();

	
	public abstract boolean isRedefinedBinaryField();

}