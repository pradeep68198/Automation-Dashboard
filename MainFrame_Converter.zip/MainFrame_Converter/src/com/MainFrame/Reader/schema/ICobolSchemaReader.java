
package com.MainFrame.Reader.schema;


import java.io.IOException;

import javax.xml.bind.JAXBException;

import com.MainFrame.Reader.Details.RecordDecider;
import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
import com.MainFrame.Reader.Option.IRecordPositionOption;
import com.MainFrame.Reader.def.IO.builders.ISchemaIOBuilder;
import com.MainFrame.Reader.def.IO.builders.Icb2xmlLoadOptions;



public interface ICobolSchemaReader  extends  Icb2xmlLoadOptions  {

	
	public abstract ICobolSchemaReader setDialect(int dialect);

	public abstract ICobolSchemaReader setFont(String font);

	@Override public abstract ICobolSchemaReader setInitToSpaces(boolean initToSpaces);

	@Override public abstract ICobolSchemaReader setRecordSelection(String recordName, ExternalSelection selectionCriteria);

	@Override public abstract ICobolSchemaReader setRecordDecider(RecordDecider recordDecider);
	
	
	@Override public abstract ICobolSchemaReader setRecordPositionCode(String recordName,
			IRecordPositionOption positionOption);

	
	public abstract ICobolSchemaReader setCopybookFileFormat(int copybookFileFormat);

	@Override public abstract ICobolSchemaReader setDropCopybookNameFromFields(boolean dropCopybookNameFromFields);

	
	public abstract ICobolSchemaReader setTagFormat(int tagFormat);

	
	
	public abstract ICobolSchemaReader setRecordParent(String recordName, String parentName);
	


	
	public abstract ISchemaIOBuilder asIOBuilder();

	
	public abstract CobolSchemaDetails getCobolSchemaDetails() throws IOException,
			JAXBException;



}
