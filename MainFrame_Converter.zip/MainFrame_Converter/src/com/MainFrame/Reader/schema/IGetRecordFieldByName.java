
package com.MainFrame.Reader.schema;

import com.MainFrame.Reader.Common.IFieldDetail;


public interface IGetRecordFieldByName {
	
	
	public abstract IFieldDetail getField(String recordName, String fieldName, int[] indexs);
}
