
package com.MainFrame.Reader.schema.jaxb;

import java.util.List;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.cgen.def.IArrayAnyDimension;
import com.MainFrame.Reader.schema.IArrayItemCheck;

public interface IItem {

	public static final int TYPE_GROUP = 1;
	public static final int TYPE_FIELD = 2;
	public static final int TYPE_ARRAY = 3;

	public abstract List<? extends IItem> getChildItems();

	
	public abstract Integer getAssumedDigits();

	
	public abstract String getDependingOn();

	
	public abstract int getDisplayLength();

	
	public abstract String getLevel();

	
	public abstract String getName();

	
	public abstract Boolean isNumeric();

	
	public abstract Integer getOccurs();

	
	public abstract Integer getOccursMin();

	
	public abstract String getPicture();

	
	public abstract int getPosition();

	
	public abstract int getPosition(int[] indexs);

	
	public abstract String getRedefined();

	
	public abstract String getRedefines();

	
	public abstract Integer getScale();

	
	public abstract String getSignPosition();

	
	public abstract Boolean isSignSeparate();

	
	public abstract Boolean isSigned();

	
	public abstract int getStorageLength();

	
	public abstract Boolean isSync();

	
	public abstract String getUsage();

	
	public abstract String getValue();

	
	public abstract int getItemType();

	
	public abstract IFieldDetail getFieldDefinition();

	
	public abstract IArrayAnyDimension getArrayDefinition();

	
	public abstract String getNameToUse();

	
	public abstract String getFieldName();

	
	public abstract boolean isFieldRedefined();

	public abstract IArrayItemCheck getArrayValidation();

	
	@Deprecated
	public int getSaveIndex();

	
	@Deprecated
	public int getODArraySizeIdx();

}