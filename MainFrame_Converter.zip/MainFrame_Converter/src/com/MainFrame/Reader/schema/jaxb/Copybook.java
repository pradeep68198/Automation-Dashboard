
package com.MainFrame.Reader.schema.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;



@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "item"
})
@XmlRootElement(name = "copybook")
public class Copybook implements ICopybook {

    @XmlElement(required = true)
    protected List<Item> item;
    @XmlAttribute(name = "filename", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String filename;

    
    @Override
	public List<Item> getCobolItems() {
        if (item == null) {
            item = new ArrayList<Item>();
        }
        return this.item;
    }

    
    @Override
	public String getFilename() {
        return filename;
    }

   
    public void setFilename(String value) {
        this.filename = value;
    }

}
