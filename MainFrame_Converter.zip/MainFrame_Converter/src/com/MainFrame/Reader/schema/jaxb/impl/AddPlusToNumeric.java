package com.MainFrame.Reader.schema.jaxb.impl;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Types.TypeManager;
import com.MainFrame.Reader.schema.jaxb.IItem;
import com.MainFrame.Reader.schema.jaxb.interfaces.IFormatField;

public class AddPlusToNumeric implements IFormatField {
	
	public static final AddPlusToNumeric INSTANCE = new AddPlusToNumeric();

	
	@Override
	public String format(IItem itemDef, IFieldDetail fieldDef, String value) {
		if (TypeManager.isNumeric(fieldDef.getType()) 
		&&  TypeManager.isSignLeading(fieldDef.getType()) 
		&&  value != null && value.length() > 0 
		&& (value.charAt(0) != '-') && (value.charAt(0) != '+')) {
			value = '+' + value.trim();
		}
		return value;
	}

	
}
