package com.MainFrame.Reader.schema.jaxb;

import java.util.Arrays;

import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.fieldValue.IFieldValue;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.External.Def.DependingOnDefinition;



public class LineItemHelper {
	private AbstractLine line;
	private final int[] sizes;
	
	public LineItemHelper(LayoutDetail schema) {
		
		int numArraySizeFields = 0;
		for (int i = 0; i < schema.getRecordCount(); i++) {
			DependingOnDefinition dependingOn = schema.getRecord(i).getDependingOn();
			if (dependingOn != null) {
				numArraySizeFields = Math.max(numArraySizeFields, dependingOn.getSizeFieldCount());
			}
		}
		
		int[] sizes = null;
		if (numArraySizeFields > 0) {
			sizes = new int[numArraySizeFields];
		}
		this.sizes = sizes;
	}
	
	
	public IFieldValue getFieldValue(IItem item, int[] indexs) {
		IFieldValue ret;
		if (indexs == null || indexs.length == 0) {
			ret = line.getFieldValue(item.getFieldDefinition());
		} else {
			ret = line.getFieldValue(item.getArrayDefinition().getField(indexs));
		}
		@SuppressWarnings("deprecation")
		int idx = item.getSaveIndex();
		if (ret.isNumeric() && idx >= 0) {
			try {
				sizes[idx] = ret.asInt();
			} catch (Exception e) {
				System.err.println();
				System.err.print(">> " + item.getName() + " ~ " + ret.asString() + " - " + idx + " : ");
				if (indexs != null) {
					for (int i = 0; i < indexs.length; i++) {
						System.err.print("\t" + indexs[i]);
					}
				}
				System.err.println();
				System.err.println();
				//e.printStackTrace();
			}
		}
		
		return ret;
	}
	
	public int checkArrayIndex( IItem item, int[] indexs, int index) {
		return item.getArrayValidation().checkItem(line, item, indexs, index);
	}
	
	public int getArrayCount(IItem item, int[] indexs) {
		int num = item.getOccurs();
		
		@SuppressWarnings("deprecation")
		int idx = item.getODArraySizeIdx();
		if (sizes != null && idx >= 0 && sizes[idx] >= 0) {
			num = sizes[idx];
		} /*else {
			String dependingOn = item.getDependingOn();
			if (dependingOn != null && dependingOn.length() > 0) {
				
			}
		}*/
		if (item.getArrayValidation() != null) {
			num = item.getArrayValidation().getCount(line, item, indexs, num);
		}
		
		return num;
	}
	
	
	
	public final AbstractLine getLine() {
		return line;
	}
	
	public final LineItemHelper setLine(AbstractLine line) {
		this.line = line;
		if (sizes != null) {
			Arrays.fill(sizes, -1);
		}
		
		return this;
	}
}
