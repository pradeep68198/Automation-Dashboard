
package com.MainFrame.Reader.schema.jaxb;

import javax.xml.bind.annotation.XmlRegistry;



@XmlRegistry
public class ObjectFactory {


    
    public ObjectFactory() {
    }

    public Condition createCondition() {
        return new Condition();
    }

    public Item createItem() {
        return new Item();
    }

    
    public Copybook createCopybook() {
        return new Copybook();
    }

}
