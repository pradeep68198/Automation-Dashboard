
package com.MainFrame.Reader.schema.jaxb;

import java.util.List;

public interface ICopybook {

	
	public abstract List<? extends IItem> getCobolItems();

	
	public abstract String getFilename();

}