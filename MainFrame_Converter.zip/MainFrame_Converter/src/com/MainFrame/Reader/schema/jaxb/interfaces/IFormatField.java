package com.MainFrame.Reader.schema.jaxb.interfaces;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.schema.jaxb.IItem;

public interface IFormatField {
	public String format(IItem itemDef, IFieldDetail fieldDef, String value);
}
