package com.MainFrame.Reader.schema.jaxb.impl;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.schema.jaxb.IItem;
import com.MainFrame.Reader.schema.jaxb.interfaces.IFormatField;

public class DoNothingFormat implements IFormatField {
	public static final DoNothingFormat INSTANCE = new DoNothingFormat();
	
	@Override
	public String format(IItem itemDef, IFieldDetail fieldDef, String value) {
		return value;
	}

}
