
package com.MainFrame.Reader.schema.jaxb;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.MainFrame.Convert2xml.def.ICondition;



@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "condition"
})
@XmlRootElement(name = "condition")
public class Condition implements ICondition{

    protected List<Condition> condition;
    @XmlAttribute(name = "name")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String name;
    @XmlAttribute(name = "through")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String through;
    @XmlAttribute(name = "value")
    @XmlSchemaType(name = "anySimpleType")
    protected String value;

    public Condition() {
    }
    

    public Condition(ICondition cond) {
    	name = cond.getName();
    	through = cond.getThrough();
    	value = cond.getValue();
    	
    	condition = toConditionList(cond.getChildConditions());
    }


	
	protected static List<Condition> toConditionList(List<? extends ICondition> childConditions) {
		List<Condition> newChildConds = null;
    	
    	if (childConditions != null && childConditions.size() > 0) {
    		newChildConds = new ArrayList<Condition>(childConditions.size());
    		
    		for (ICondition c : newChildConds) {
    			newChildConds.add(new Condition(c));
    		}
    	}
    	return newChildConds;
	}
    
   
    
    public List<Condition> getChildConditions() {
        if (condition == null) {
            condition = new ArrayList<Condition>();
        }
        return this.condition;
    }

    
    public String getName() {
        return name;
    }

    
    public void setName(String value) {
        this.name = value;
    }

    
    public String getThrough() {
        return through;
    }

    
    public void setThrough(String value) {
        this.through = value;
    }

   
    public String getValue() {
        return value;
    }

    
    public void setValue(String value) {
        this.value = value;
    }

}
