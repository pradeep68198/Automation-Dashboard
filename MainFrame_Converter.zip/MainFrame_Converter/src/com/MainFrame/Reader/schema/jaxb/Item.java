

package com.MainFrame.Reader.schema.jaxb; 

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.External.Def.DependingOnDefinition;
import com.MainFrame.Reader.cgen.def.IArrayAnyDimension;
import com.MainFrame.Reader.detailsBasic.IItemDetails;
import com.MainFrame.Reader.schema.IArrayItemCheck;
import com.MainFrame.Convert2xml.def.ICondition;



@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "condition", "item" })
@XmlRootElement(name = "item")
public class Item implements IItem
{
    @XmlTransient
    public int itemType;
    @XmlTransient
    public IFieldDetail fieldDefinition;
    @XmlTransient
    public IArrayAnyDimension arrayDefinition;
    @XmlTransient
    public List<String> names;
    @XmlTransient
    public String nameToUse;
    @XmlTransient
    public String fieldName;
    @XmlTransient
    public IArrayItemCheck arrayValidation;
    @XmlTransient
    public boolean fieldRedefined;
    @XmlTransient
    public DependingOnDefinition.SizeField saveDtls;
    @XmlTransient
    public DependingOnDefinition.SizeField arraySizeField;
    protected List<Condition> condition;
    protected List<Item> item;
    @XmlAttribute(name = "assumed-digits")
    protected Integer assumedDigits;
    @XmlAttribute(name = "depending-on")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String dependingOn;
    @XmlAttribute(name = "display-length", required = true)
    protected int displayLength;
    @XmlAttribute(name = "editted-numeric")
    protected Boolean edittedNumeric;
    @XmlAttribute(name = "inherited-usage")
    protected Boolean inheritedUsage;
    @XmlAttribute(name = "insert-decimal-point")
    protected Boolean insertDecimalPoint;
    @XmlAttribute(name = "justified")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String justified;
    @XmlAttribute(name = "level", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String level;
    @XmlAttribute(name = "name", required = true)
    @XmlSchemaType(name = "anySimpleType")
    protected String name;
    @XmlAttribute(name = "numeric")
    protected Boolean numeric;
    @XmlAttribute(name = "occurs")
    protected Integer occurs;
    @XmlAttribute(name = "occurs-min")
    protected Integer occursMin;
    @XmlAttribute(name = "picture")
    @XmlSchemaType(name = "anySimpleType")
    protected String picture;
    @XmlAttribute(name = "position", required = true)
    protected int position;
    @XmlAttribute(name = "redefined")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String redefined;
    @XmlAttribute(name = "redefines")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String redefines;
    @XmlAttribute(name = "scale")
    protected Integer scale;
    @XmlAttribute(name = "sign-position")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String signPosition;
    @XmlAttribute(name = "sign-separate")
    protected Boolean signSeparate;
    @XmlAttribute(name = "signed")
    protected Boolean signed;
    @XmlAttribute(name = "storage-length", required = true)
    protected int storageLength;
    @XmlAttribute(name = "sync")
    protected Boolean sync;
    @XmlAttribute(name = "usage")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String usage;
    @XmlAttribute(name = "value")
    @XmlSchemaType(name = "anySimpleType")
    protected String value;
    
    public void initFields(final String name, final List<Item> childItems) {
        this.fieldName = name;
        this.nameToUse = name;
        this.name = name;
        this.fieldRedefined = false;
        this.itemType = 1;
        this.position = 1;
        this.storageLength = 0;
        this.displayLength = 0;
        for (final Item ii : childItems) {
            this.storageLength += ii.storageLength;
            this.displayLength += ii.displayLength;
        }
        this.item = childItems;
        this.level = "00";
    }
    
    public Item() {
        this.itemType = 1;
        this.fieldDefinition = null;
        this.arrayDefinition = null;
        this.names = null;
        this.arrayValidation = null;
        this.fieldRedefined = false;
    }
    
    public Item(final IItemDetails itm) {
        this.itemType = 1;
        this.fieldDefinition = null;
        this.arrayDefinition = null;
        this.names = null;
        this.arrayValidation = null;
        this.fieldRedefined = false;
        this.arrayDefinition = itm.getArrayDefinition();
        this.condition = (List<Condition>)Condition.toConditionList(itm.getConditions());
        this.dependingOn = itm.getDependingOn();
        this.displayLength = itm.getDisplayLength();
        this.fieldDefinition = itm.getFieldDefinition();
        this.fieldName = itm.getFieldName();
        this.name = this.fieldName;
        this.nameToUse = this.fieldName;
        final List<? extends IItemDetails> childItems = (List<? extends IItemDetails>)itm.getChildItems();
        if (childItems == null || childItems.size() == 0) {
            this.itemType = 2;
        }
        else {
            this.item = new ArrayList<Item>(childItems.size());
            for (final IItemDetails ci : childItems) {
                this.item.add(new Item(ci));
            }
        }
        this.justified = itm.getJustified().getName();
        this.level = itm.getLevelString();
        this.edittedNumeric = itm.getNumericClass().editNumeric;
        this.numeric = itm.getNumericClass().numeric;
        this.occurs = itm.getOccurs();
        this.occursMin = itm.getOccursMin();
        this.picture = itm.getPicture();
        this.position = itm.getPosition();
        this.redefines = itm.getRedefinesFieldName();
        this.redefined = (itm.isFieldRedefined() ? "T" : "");
        this.fieldRedefined = itm.isFieldRedefined();
        this.scale = itm.getScale();
        this.storageLength = itm.getStorageLength();
        this.signSeparate = itm.getSignClause().signSeparate;
        this.signPosition = itm.getSignClause().signPosition.getName();
        this.sync = (itm.isSync() ? true : null);
        this.usage = itm.getUsage().getName();
    }
    
    public List<? extends ICondition> getCondition() {
        if (this.condition == null) {
            this.condition = new ArrayList<Condition>();
        }
        return (List<? extends ICondition>)this.condition;
    }
    
    public List<Item> getChildItems() {
        if (this.item == null) {
            this.item = new ArrayList<Item>();
        }
        return this.item;
    }
    
    public Integer getAssumedDigits() {
        return this.assumedDigits;
    }
    
    public void setAssumedDigits(final Integer value) {
        this.assumedDigits = value;
    }
    
    public String getDependingOn() {
        return this.dependingOn;
    }
    
    public int getSaveIndex() {
        return (this.saveDtls == null) ? -1 : this.saveDtls.fieldNumber;
    }
    
    public int getODArraySizeIdx() {
        return (this.arraySizeField != null) ? this.arraySizeField.fieldNumber : -1;
    }
    
    public void setDependingOn(final String value) {
        this.dependingOn = value;
    }
    
    public int getDisplayLength() {
        return this.displayLength;
    }
    
    public void setDisplayLength(final int value) {
        this.displayLength = value;
    }
    
    public Boolean isEdittedNumeric() {
        return this.edittedNumeric;
    }
    
    public Boolean isInsertDecimalPoint() {
        return this.insertDecimalPoint;
    }
    
    public void setInsertDecimalPoint(final Boolean value) {
        this.insertDecimalPoint = value;
    }
    
    public String getJustified() {
        return this.justified;
    }
    
    public String getLevel() {
        return this.level;
    }
    
    public void setLevel(final String value) {
        this.level = value;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String value) {
        this.name = value;
    }
    
    public Boolean isNumeric() {
        return this.numeric;
    }
    
    public void setNumeric(final Boolean value) {
        this.numeric = value;
    }
    
    public Integer getOccurs() {
        return this.occurs;
    }
    
    public void setOccurs(final Integer value) {
        this.occurs = value;
    }
    
    public Integer getOccursMin() {
        return this.occursMin;
    }
    
    public void setOccursMin(final Integer value) {
        this.occursMin = value;
    }
    
    public String getPicture() {
        return this.picture;
    }
    
    public void setPicture(final String value) {
        this.picture = value;
    }
    
    public int getPosition() {
        return this.position;
    }
    
    public int getPosition(final int[] indexs) {
        int p = this.position;
        if (indexs != null && this.arrayDefinition != null) {
            for (int i = 0; i < indexs.length; ++i) {
                p += this.arrayDefinition.getArrayElementSize(i) * indexs[i];
            }
        }
        return p;
    }
    
    public void setPosition(final int value) {
        this.position = value;
    }
    
    public String getRedefined() {
        return this.redefined;
    }
    
    public void setRedefined(final String value) {
        this.redefined = value;
    }
    
    public String getRedefines() {
        return this.redefines;
    }
    
    public void setRedefines(final String value) {
        this.redefines = value;
    }
    
    public Integer getScale() {
        return this.scale;
    }
    
    public void setScale(final Integer value) {
        this.scale = value;
    }
    
    public String getSignPosition() {
        return this.signPosition;
    }
    
    public void setSignPosition(final String value) {
        this.signPosition = value;
    }
    
    public Boolean isSignSeparate() {
        return this.signSeparate;
    }
    
    public void setSignSeparate(final Boolean value) {
        this.signSeparate = value;
    }
    
    public Boolean isSigned() {
        return this.signed;
    }
    
    public void setSigned(final Boolean value) {
        this.signed = value;
    }
    
    public int getStorageLength() {
        return this.storageLength;
    }
    
    public void setStorageLength(final int value) {
        this.storageLength = value;
    }
    
    public Boolean isSync() {
        return this.sync;
    }
    
    public void setSync(final Boolean value) {
        this.sync = value;
    }
    
    public String getUsage() {
        return this.usage;
    }
    
    public void setUsage(final String value) {
        this.usage = value;
    }
    
    public String getValue() {
        return this.value;
    }
    
    public void setValue(final String value) {
        this.value = value;
    }
    
    public final int getItemType() {
        return this.itemType;
    }
    
    public final IFieldDetail getFieldDefinition() {
        return this.fieldDefinition;
    }
    
    public final IArrayAnyDimension getArrayDefinition() {
        return this.arrayDefinition;
    }
    
    public final IArrayItemCheck getArrayValidation() {
        return this.arrayValidation;
    }
    
    public final String getNameToUse() {
        return this.nameToUse;
    }
    
    public final String getFieldName() {
        return this.fieldName;
    }
    
    public final boolean isFieldRedefined() {
        return this.fieldRedefined;
    }
}
