
package com.MainFrame.Reader.schema;

import java.util.List;

import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.IO.builders.SchemaIOBuilder;
import com.MainFrame.Reader.def.IO.builders.ISchemaIOBuilder;
import com.MainFrame.Reader.schema.jaxb.ItemRecordDtls;


public final class CobolSchemaDetails {

	
	public final LayoutDetail schema;
	
	public final List<ItemRecordDtls> recordItems;
	
	
	
//	public final ICopybook cobolCopybook;
	
	
	public final ISchemaIOBuilder ioBuilder;
	
	
	public final ISchemaInformation copybookInformation;
	
	
	protected CobolSchemaDetails(LayoutDetail schema,
			List<ItemRecordDtls> cobolItems, //ICopybook cobolCopybook, 
			ISchemaIOBuilder ioBuilder,
			ISchemaInformation copybookDetails) {
		super();
		this.schema = schema;
		this.recordItems = cobolItems;
//		this.cobolCopybook = cobolCopybook;
		this.ioBuilder = ioBuilder;
		this.copybookInformation = copybookDetails;
	}
	
	public final ISchemaIOBuilder newIOBuilder() {
		return SchemaIOBuilder.newSchemaIOBuilder(schema);
	}
}
