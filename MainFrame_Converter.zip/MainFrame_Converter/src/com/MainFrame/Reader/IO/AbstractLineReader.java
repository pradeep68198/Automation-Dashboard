
package com.MainFrame.Reader.IO;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.DefaultLineProvider;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Details.LineProvider;
import com.MainFrame.Reader.Details.SpecialRecordIds;
import com.MainFrame.Reader.External.ExternalRecord;

public abstract class AbstractLineReader implements IReadLine {

    public static final String NOT_OPEN_MESSAGE = "File has not been opened";
    
    private static final int RT_FIRST_RECORD = 1;
    private static final int RT_MIDDLE_RECORD = 2;
    private static final int RT_LAST_RECORD = 3;
    private static final int RT_FINISHED = 4;

	private LineProvider lineProvider;
	private LayoutDetail layout = null;
	private IReadLine filter = null;


	
	public AbstractLineReader() {
	    this(new DefaultLineProvider());
	}


	public AbstractLineReader(final LineProvider provider) {
	    super();
	    lineProvider = provider;

	    if (provider == null) {
	    	lineProvider = new DefaultLineProvider();
	    }
	}

	
	 public void open(String fileName) throws IOException {
		 open(fileName, (LayoutDetail) null);
	 }
    
    public void open(String fileName, LayoutDetail pLayout) throws IOException {
        open(new FileInputStream(fileName), pLayout);

        if (layout == null) {
            setLayout(pLayout);
        }
    }
    

    
    
    public void open(InputStream inputStream, ExternalRecord recordLayout) 
    throws IOException {
    	LayoutDetail pLayout = recordLayout.asLayoutDetail();
    	open(inputStream, pLayout);

        if (layout == null) {
        	setLayout(pLayout);
        }
    }


   
    public abstract void open(InputStream inputStream, LayoutDetail pLayout)
    throws IOException;



   
    public final AbstractLine read() throws IOException {
    	if (filter == null) {
    		return readImplementation();
    	}
    	return filter.read();
    }

   
    public abstract AbstractLine readImplementation() throws IOException;

   
    public abstract void close() throws IOException;



	
	protected final int readBuffer(final InputStream in,
	        					   final byte[] buf)
				throws IOException {
	    int num;
	    int total;

	    num = in.read(buf);
	    total = num;

	    while (num >= 0 && total < buf.length) {
	        num = in.read(buf, total, buf.length - total);
	        total += num;
	    }

	    return total;
	}


	@SuppressWarnings("deprecation")
	protected final AbstractLine getLine(byte[] record) {
	    AbstractLine ret = lineProvider.getLine(layout, record);

	    ret.setLineProvider(lineProvider);
	    return ret;
	}


	
	@SuppressWarnings("deprecation")
	protected final AbstractLine getLine(String record) {
	    AbstractLine ret = lineProvider.getLine(layout, record);

	    ret.setLineProvider(lineProvider);
	    return ret;
	}


	
	public final LayoutDetail getLayout() {
	    return layout;
	}

	
    public final void setLayout(LayoutDetail pLayout) {
        this.layout = pLayout;
        
        filter = null;
        if (layout != null && layout.hasHeaderTrailerRecords()) {
        	filter = new HeaderTrailerDelagate(this, layout);
        }
    }


	
	public final LineProvider getLineProvider() {
		return lineProvider;
	}
	
	private static class HeaderTrailerDelagate implements IReadLine {
		private final AbstractLineReader parent;
		private int recordId = RT_FIRST_RECORD;
		private int firstRecordId = -1,
				    middleRecordId = -1,
				    lastRecordId = -1;
		private AbstractLine next = null;

		

		protected HeaderTrailerDelagate(AbstractLineReader parent, LayoutDetail l) {
			super();
			this.parent = parent;
			SpecialRecordIds sr = l.getPositionRecordId();
			firstRecordId = sr.headerId;
			middleRecordId = sr.middleId;
			lastRecordId = sr.trailerId;
		}



		
		@Override
		public AbstractLine read() throws IOException {
			AbstractLine ret = next;
			int id = -1;
			switch (recordId) {
			case RT_FINISHED:
			case RT_FIRST_RECORD:
				ret = parent.readImplementation();
				if (ret == null) {
					return null;
				}
				id = firstRecordId;

				recordId = RT_MIDDLE_RECORD;
				next = parent.readImplementation();
				if (next == null) {
					recordId = RT_LAST_RECORD;
				}
				break;
			case RT_MIDDLE_RECORD:
				id = middleRecordId; 
				next = parent.readImplementation();
				if (next == null) {
					recordId = RT_LAST_RECORD;
					id = lastRecordId;
				}
				break;
			case RT_LAST_RECORD:
				recordId = RT_FINISHED;
				return null;
			}
			if (id >= 0) {
				ret.setWriteLayout(id);
			}
			return ret;
		}

	}
}
