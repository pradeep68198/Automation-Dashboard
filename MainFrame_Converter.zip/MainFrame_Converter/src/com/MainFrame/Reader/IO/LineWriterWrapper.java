
package com.MainFrame.Reader.IO;

import java.io.IOException;
import java.io.OutputStream;

import com.MainFrame.Reader.ByteIO.AbstractByteWriter;


public class LineWriterWrapper extends LineByteRecordWriterWrapper<AbstractByteWriter> {

    
    public LineWriterWrapper(AbstractByteWriter byteWriter) {
        super(byteWriter);
    }

    
    public void open(OutputStream outputStream) throws IOException {
        writer.open(outputStream);
    }

	
	
	public final void setWriter(AbstractByteWriter writer) {
		this.writer = writer;
	}
}
