
package com.MainFrame.Reader.IO;

import java.io.InputStream;
import java.util.Arrays;

import com.MainFrame.Reader.Common.Constants;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Details.LineProvider;


public class Binary4680LineReader extends ContinuousLineReader {



	private byte[] recSep;
	private int[] lengthsSorted;


	
	public Binary4680LineReader() {
	    super();
	}


	
	public Binary4680LineReader(final LineProvider provider) {
	    super(provider);
	}


    
    public void open(InputStream inputStream, LayoutDetail layout) {

    	super.open(inputStream, layout);
  
		lengthsSorted = new int[layout.getRecordCount()];

		recSep = layout.getRecordSep();

		for (int i = 0; i < lengthsSorted.length; i++) {
			lengthsSorted[i] = lengths[i];
		}


		Arrays.sort(lengthsSorted);
    }



 


	
    protected final int findLength(AbstractLine tmpLine, int maxLength) {
		int i, rl, pref;
		int recLen = 1;
		int start = 0;
		boolean search;
		byte[] buffer = tmpLine.getData();

		search = true;
//		lineNumber += 1;
//		//System.out.print("Line " + lineNumber + " " + start);

		
		pref = tmpLine.getPreferredLayoutIdxAlt();
		if (pref != Constants.NULL_INTEGER) {
		    //System.out.print(" pref " + pref);
		    rl = lengths[pref];
		    if (isEqual(buffer, start + rl + 1)) {
		        recLen = rl;
		        search = false;
		        //System.out.print("  found 1 " + recLen + " " + maxLength);
		    }
		}

		i = 0;
		while (search && (i < lengthsSorted.length)) {
		    if ((start + lengthsSorted[i] < maxLength)
		    && isEqual(buffer, start + lengthsSorted[i] + 1)) {
		        search = false;
		        recLen = lengthsSorted[i];
		        //System.out.print("  found 2 " + recLen + " " + maxLength);
		    } else {
		        i += 1;
		    }
		}

		if (search) {
		    recLen = maxLength;
		    if (recSep.length > 0) {
		        for (i = recSep.length; (i <= maxLength && recLen == maxLength); i++) {
		        	if (isEqual(buffer, start + i)) {
		        	    recLen = i - 1;
		        	    break;
		        	}
		        }
		    }

		    //System.out.print("  found 3 " + recLen + " " + maxLength);
		}

		//System.out.println();
		return recLen;
	}



	
	private boolean isEqual(final byte[] rec, final int fin) {
		int i;
		int st = fin - recSep.length - 1;
		boolean ret = st >= 0;

		for (i = 0; ret && (i < recSep.length); i++) {
			ret = (recSep[i] == rec[st + i]);
		}

		return ret;
	}
}
