
package com.MainFrame.Reader.IO;

import com.MainFrame.Reader.ByteIO.AbstractByteReader;
import com.MainFrame.Reader.ByteIO.AbstractByteWriter;
import com.MainFrame.Reader.ByteIO.BinaryByteWriter;
import com.MainFrame.Reader.ByteIO.ByteIOProvider;
import com.MainFrame.Reader.ByteIO.ByteTextReader;
import com.MainFrame.Reader.ByteIO.CsvByteReader;
import com.MainFrame.Reader.ByteIO.IByteReader;
import com.MainFrame.Reader.Common.AbstractManager;
import com.MainFrame.Reader.Common.CommonBits;
import com.MainFrame.Reader.Common.Constants;
import com.MainFrame.Reader.Common.Conversion;
import com.MainFrame.Reader.Common.IBasicFileSchema;
import com.MainFrame.Reader.Details.CharLineProvider;
import com.MainFrame.Reader.Details.DefaultLineProvider;
import com.MainFrame.Reader.Details.LineProvider;
import com.MainFrame.Reader.Details.XmlLineProvider;
import com.MainFrame.Reader.External.Def.BasicConversion;
import com.MainFrame.Reader.charIO.CsvCharReader;
import com.MainFrame.Reader.charIO.ICharReader;
import com.MainFrame.Reader.charIO.StandardCharReader;


public class LineIOProvider implements AbstractManager {

    private static final LineProvider CHAR_LINE_PROVIDER = new CharLineProvider();
    private static final LineProvider DEFAULT_PROVIDER   = new DefaultLineProvider();
    private static LineIOProvider ioProvider = null;
    
    
    private LineProvider provider = DEFAULT_PROVIDER;
    private XmlLineProvider xmlProvider = null;

    
    @Deprecated
    public static final int[] FILE_STRUCTURE_ID = {
    	Constants.IO_DEFAULT,
    	Constants.IO_FIXED_LENGTH,
    	Constants.IO_BINARY_IBM_4680,
    	Constants.IO_VB,
    	Constants.IO_VB_DUMP,
    	Constants.IO_VB_FUJITSU,
    	Constants.IO_VB_GNU_COBOL};
   
    @Deprecated
    public static final String[] FILE_STRUCTURE_NAME;

   static {
	   String rdDefault = "Default";
	   String rdFixed = "Fixed Length Binary";
	   String rdLineBin = "Line based Binary";
	   String rdVb = "Mainframe VB (rdw based) Binary";
	   String rdVbDump = "Mainframe VB Dump: includes Block length";
	   String rdOcVb = "GNU Cobol VB";

	   FILE_STRUCTURE_NAME = new String[] {
			   rdDefault,
			   rdFixed,
			   rdLineBin,
			   rdVb,
			   rdVbDump,
		        "Fujitsu Cobol VB",
		        rdOcVb
		    };
    }

   @Deprecated
    public static final String[] FILE_STRUCTURE = {
        "Default Reader",
        "Fixed Length Binary",
        "Line based Binary",
        "Mainframe VB (rdw based) Binary",
        "Mainframe VB Dump: includes Block length",
        "Fujitsu Cobol VB"
    };


   
    public LineIOProvider(final LineProvider lineProvider) {
        super();

        provider = lineProvider;
        if (lineProvider == null) {
            provider = DEFAULT_PROVIDER;
        }
    }


   
    public LineIOProvider() {
        super();
        provider = DEFAULT_PROVIDER;
    }

    
	@Override
	public String getManagerName() {
		return "Line_IO_Names";
	}

   
    public AbstractLineReader getLineReader(int fileStructure) {
        return getLineReader(fileStructure, getLineProvider(fileStructure, null));
    }

    
    public AbstractLineReader getLineReader(IBasicFileSchema fs) {
		return getLineReader(fs, getLineProvider(fs.getFileStructure(), fs.getFontName()));
    }
    
   
    public AbstractLineReader getLineReader(IBasicFileSchema fs, LineProvider lineProvider) {
    	int fileStructure = fs.getFileStructure();
    	if (lineProvider == null) { 
    		lineProvider = getLineProvider(fileStructure, fs.getFontName());
    	}
		switch (fileStructure) {
		case Constants.IO_TEXT_BYTE_ENTER_FONT:
		case Constants.IO_BIN_TEXT:		return new LineReaderWrapper(new ByteTextReader(fs.getFontName()));
//       	case Constants.IO_BIN_TEXT:		return new BinTextReader(lLineProvider,  false);
       	case Constants.IO_BIN_NAME_1ST_LINE:
       									return new BinTextReader(lineProvider,  true, new ByteTextReader(fs.getFontName()));
		case Constants.IO_CSV:			return new LineReaderWrapper(getCsvReader(fs, false));
		case Constants.IO_UNICODE_CSV:	return new TextLineReader(lineProvider, false, getCsvCharReader(fs, false));
		case Constants.IO_BIN_CSV:		return new BinTextReader(lineProvider,  false, getCsvReader(fs, false));

		case Constants.IO_UNICODE_CSV_NAME_1ST_LINE: 
			return  new TextLineReader(lineProvider, true, getCsvCharReader(fs, true));
		case Constants.IO_CSV_NAME_1ST_LINE:
		case Constants.IO_BIN_CSV_NAME_1ST_LINE:
			return new BinTextReader(lineProvider,  true, getCsvReader(fs, true));
		default:
			return getLineReader(fileStructure, lineProvider);
		}

//		return getLineReader(fileStructure, lineProvider);
    }

    

	private static IByteReader getCsvReader(IBasicFileSchema schema, boolean namesOnFirstLine) {
		String quote = schema.getQuoteDetails().asString();
		if (quote == null || quote.length() == 0) {
			return new ByteTextReader(schema.getFontName());
		}
		return new CsvByteReader(schema.getFontName(), 
				schema.getDelimiterDetails().asBytes(), schema.getQuoteDetails().asBytes(), 
				quote + quote, namesOnFirstLine);
	}

	private static ICharReader getCsvCharReader(IBasicFileSchema schema, boolean namesOnFirstLine) {
		String quote = schema.getQuoteDetails().asString();;
		if (quote == null || quote.length() == 0) {
			return new StandardCharReader();
		}
		return new CsvCharReader(schema.getDelimiterDetails().asString(), quote, quote + quote, namesOnFirstLine);
	}

    
    public AbstractLineReader getLineReader(int fileStructure,
            						   LineProvider lineProvider) {
        LineProvider lLineProvider = lineProvider;

        if (lLineProvider == null) {
            lLineProvider = provider;
        }

		//System.out.println(" ~~ IOProvider ~ " + fileStructure + " " + Constants.IO_GENERIC_CSV);

       	switch (fileStructure) {
    	case Constants.IO_CONTINOUS_NO_LINE_MARKER:	return new ContinuousLineReader(lLineProvider);
    	case Constants.IO_BINARY_IBM_4680:			return new Binary4680LineReader(lLineProvider);

		case Constants.IO_FIXED_CHAR_ENTER_FONT:
    	case Constants.IO_FIXED_LENGTH_CHAR:		return new FixedLengthTextReader(lLineProvider);

    	case Constants.IO_XML_BUILD_LAYOUT:
       	case Constants.IO_XML_USE_LAYOUT:			return new XmlLineReader(fileStructure == Constants.IO_XML_BUILD_LAYOUT);

		case Constants.IO_TEXT_BYTE_ENTER_FONT:
       	case Constants.IO_BIN_TEXT:					return new BinTextReader(lLineProvider, false);
       	case Constants.IO_BIN_NAME_1ST_LINE:		return new BinTextReader(lLineProvider, true);

       	case Constants.IO_NAME_1ST_LINE:
       	case Constants.IO_CSV_NAME_1ST_LINE:
       	case Constants.IO_UNICODE_NAME_1ST_LINE:	return new TextLineReader(lLineProvider, true);
       	case Constants.IO_UNICODE_TEXT:				return new TextLineReader(CHAR_LINE_PROVIDER, false);
       	default:
       		AbstractByteReader byteReader
       				= ByteIOProvider.getInstance().getByteReader(fileStructure);

	        if (byteReader != null) {
	            return new LineReaderWrapper(lLineProvider, byteReader);
	        }
	 	}

        return new TextLineReader(lLineProvider, false);
    }


   
    public AbstractLineWriter getLineWriter(int fileStructure) {
    	return getLineWriter(fileStructure, null);
    }

    
    public AbstractLineWriter getLineWriter(IBasicFileSchema schema) {
    	return getLineWriter(schema.getFileStructure(), schema.getFontName());
    }

    
    public AbstractLineWriter getLineWriter(int fileStructure, String charset) {


    	switch (fileStructure) {
    	case Constants.IO_CONTINOUS_NO_LINE_MARKER:	return new ContinuousLineWriter();
    	case Constants.IO_BINARY_IBM_4680:			return new LineWriterWrapper(new BinaryByteWriter());
    	
    	case Constants.IO_FIXED_BYTE_ENTER_FONT:
    	case Constants.IO_FIXED_LENGTH:				return new FixedLengthWriter();

    	case Constants.IO_FIXED_CHAR_ENTER_FONT:
      	case Constants.IO_FIXED_LENGTH_CHAR:		return new LineWriterWrapperChar(fileStructure);
    	case Constants.IO_XML_BUILD_LAYOUT:
       	case Constants.IO_XML_USE_LAYOUT:			return new XmlLineWriter();

    	case Constants.IO_TEXT_BYTE_ENTER_FONT:
       	case Constants.IO_CSV:
       	case Constants.IO_BIN_CSV:
      	case Constants.IO_BIN_TEXT:					return new BinTextWriter(false);
       	case Constants.IO_BIN_NAME_1ST_LINE:		return new BinTextWriter(true);
    	case Constants.IO_TEXT_CHAR_ENTER_FONT:
       	case Constants.IO_UNICODE_TEXT:
       	case Constants.IO_UNICODE_CSV:				return new TextLineWriter(false);
       	case Constants.IO_NAME_1ST_LINE:
       	case Constants.IO_CSV_NAME_1ST_LINE:      		
       	case Constants.IO_UNICODE_CSV_NAME_1ST_LINE:
       	case Constants.IO_UNICODE_NAME_1ST_LINE:	return new TextLineWriter(true);
       	default:
            AbstractByteWriter byteWriter = ByteIOProvider.getInstance().getByteWriter(fileStructure, charset);

	        if (byteWriter != null) {
	            return new LineWriterWrapper(byteWriter);
	        }
	 	}

        return new TextLineWriter(false);
    }


   
    public boolean isCopyBookFileRequired(int fileStructure) {
    	return ! ( fileStructure == Constants.IO_XML_BUILD_LAYOUT
    			|| fileStructure == Constants.IO_GENERIC_CSV
    			|| fileStructure == Constants.IO_NAME_1ST_LINE
    			|| fileStructure == Constants.IO_CSV_NAME_1ST_LINE);
    }


    
    public String getStructureName(int fileStructure) {
    	return BasicConversion.getStructureName(fileStructure);
    }

   
    public int getStructure(String name) {
    	return BasicConversion.getStructure(name);
    }


   
    public LineProvider getLineProvider() {
        return provider;
    }

    public LineProvider getLineProvider(IBasicFileSchema schema) {
    	return getLineProvider(schema.getFileStructure(), schema.getFontName(), schema.useByteRecord());
    }

   
    public LineProvider getLineProvider(int fileStructure, String charset) {
    	return getLineProvider(fileStructure, charset, false);
    }
    
    private LineProvider getLineProvider(int fileStructure, String charset, boolean binary) {

    	switch (fileStructure) {
    	case Constants.IO_XML_BUILD_LAYOUT:
    	case Constants.IO_XML_USE_LAYOUT:
       		if (xmlProvider == null) {
       			xmlProvider = new XmlLineProvider();
       		}
       		return xmlProvider;
//    	case Constants.IO_FIXED_LENGTH_CHAR:
//    	case Constants.IO_UNICODE_CSV:
//    	case Constants.IO_UNICODE_CSV_NAME_1ST_LINE:
//    	case Constants.IO_UNICODE_NAME_1ST_LINE:
//    	case Constants.IO_UNICODE_TEXT:
//    		return CHAR_LINE_PROVIDER;
    		
    	case Constants.IO_FIXED_BYTE_ENTER_FONT:
    	case Constants.IO_TEXT_BYTE_ENTER_FONT:
       	case Constants.IO_FIXED_LENGTH:
    		return DEFAULT_PROVIDER;
//    	case Constants.IO_VB:	
//    	case Constants.IO_VB_DUMP:	
//    	case Constants.IO_VB_FUJITSU:	
//    	case Constants.IO_VB_GNU_COBOL:	
//    		return DEFAULT_PROVIDER;
      	}
    	if (CommonBits.getLineType(fileStructure) == CommonBits.LT_TEXT) {
    		return CHAR_LINE_PROVIDER;
    	}
       	if ((! binary) && (charset != null) && Conversion.isMultiByte(charset)) {
       		return CHAR_LINE_PROVIDER;
       	}
        return provider;

    }

//    public final static ArrayList<BasicKeyedField> getFileStructures() {
//    	ArrayList<BasicKeyedField> ret = new ArrayList<BasicKeyedField>();
//    	BasicKeyedField fld;
//
//    	for (int i = 0; i < names.length &&  names[i] != null; i++) {
// 			fld = new BasicKeyedField();
//			fld.key = keys[i];
//			fld.name = names[i];
//			ret.add(fld);
//    	}
//
//    	return ret;
//    }


    
	@Override
	public int getKey(int idx) {
		return BasicConversion.getFileStructureForIndex(idx);
	}


	
	@Override
	public String getName(int idx) {
		return BasicConversion.getFileStructureNameForIndex(idx);
	}


	
	@Override
	public int getNumberOfEntries() {
		return BasicConversion.getNumberOfFileStructures();
	}


	
    public static LineIOProvider getInstance() {
        if (ioProvider == null) {
            ioProvider = new LineIOProvider();
        }

        return ioProvider;
    }

    
    public static void setInstance(LineIOProvider newProvider) {
        ioProvider = newProvider;
    }
}
