
package com.MainFrame.Reader.IO;

import java.io.IOException;
import java.io.InputStream;

//import com.MainFrame.Reader.ByteIO.AbstractByteReader;
import com.MainFrame.Reader.ByteIO.IByteReader;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Details.LineProvider;


public class LineReaderWrapper extends LineByteRecordReaderWrapper<IByteReader> {


  
    public LineReaderWrapper(IByteReader byteReader) {
        super(byteReader);
    }

   
    public LineReaderWrapper(LineProvider provider, IByteReader byteReader) {
        super(provider, byteReader);
    }

    
    public void open(InputStream inputStream, LayoutDetail pLayout)
            throws IOException {

        super.open(inputStream, pLayout);
        reader.setLineLength(pLayout.getMaximumRecordLength());
        reader.open(inputStream);
    }


	
	public final void setReader(IByteReader reader) {
		this.reader = reader;
	}
}
