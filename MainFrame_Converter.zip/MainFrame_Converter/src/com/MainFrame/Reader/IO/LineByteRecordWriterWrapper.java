
package com.MainFrame.Reader.IO;

import java.io.IOException;
import java.io.OutputStream;

import com.MainFrame.Reader.ByteIO.IByteRecordWriter;
import com.MainFrame.Reader.Details.AbstractLine;

public class LineByteRecordWriterWrapper<Writer extends IByteRecordWriter> extends AbstractLineWriter {

    Writer writer;

   
    public LineByteRecordWriterWrapper(Writer byteWriter) {
        super();

        writer = byteWriter;
    }


    
    public void open(OutputStream outputStream) throws IOException {
    }


    public void write(AbstractLine line) throws IOException {
        writer.write(line.getData());
    }


    
    public void close() throws IOException {
    	if (writer != null) {
    		writer.close();
    	}
    }

	
	public final Writer getWriter() {
		return writer;
	}
//
//	
//	public final void setWriter(AbstractByteWriter writer) {
//		this.writer = writer;
//	}
}
