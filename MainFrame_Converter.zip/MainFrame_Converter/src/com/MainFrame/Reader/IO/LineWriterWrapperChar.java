
package com.MainFrame.Reader.IO;

import java.io.IOException;
import java.io.OutputStream;

import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.charIO.CharIOProvider;
import com.MainFrame.Reader.charIO.ICharWriter;


public class LineWriterWrapperChar extends AbstractLineWriter {

	private static final CharIOProvider ioProvider = new CharIOProvider();
	
    private ICharWriter writer = null;
    private final int fileStructure;
    private OutputStream outputStream = null;

   
    public LineWriterWrapperChar(int fileStructure) {
        super();
        this.fileStructure = fileStructure;
    }

    
    public void open(OutputStream outputStream) throws IOException {
    	this.outputStream = outputStream;
    }

    
    public void write(AbstractLine line) throws IOException {
    	if (writer == null) {
    		LayoutDetail layout = line.getLayout();
			writer = ioProvider.getWriter(
					fileStructure, 
					layout.getFontName(), layout.getEolString(), layout.getMaximumRecordLength());
    		writer.open(outputStream);
    	}
        writer.write(line.getFullLine());
    }


   
    public void close() throws IOException {
    	if (writer != null) {
    		writer.close();
    	} 
    	if (outputStream != null) {
    		outputStream.close();
    	}
    	writer = null;
    	outputStream = null;
    }
}
