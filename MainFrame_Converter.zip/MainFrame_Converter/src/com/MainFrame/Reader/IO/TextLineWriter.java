
package com.MainFrame.Reader.IO;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import com.MainFrame.Reader.Common.Constants;
import com.MainFrame.Reader.CsvParser.ICsvCharLineParser;
import com.MainFrame.Reader.CsvParser.BasicCsvLineParser;
import com.MainFrame.Reader.CsvParser.CsvDefinition;
import com.MainFrame.Reader.CsvParser.CsvParserManagerChar;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Details.RecordDetail;


public class TextLineWriter extends AbstractLineWriter {

	private static final int BUFFER_SIZE = 16384;

    private OutputStream outStream;
	private OutputStreamWriter stdWriter;
	private BufferedWriter writer = null;
	private boolean namesInFile = false;
	private boolean writeNames;


	
	public TextLineWriter(final boolean namesOn1stLine) {
	    super();
	    namesInFile = namesOn1stLine;
	}



    public void open(OutputStream outputStream) throws IOException {

        outStream = outputStream;

        writeNames = namesInFile;
    }


    
    @SuppressWarnings("deprecation")
	public void write(AbstractLine line) throws IOException  {

    	LayoutDetail layout =  line.getLayout();
	    String sep = Constants.LINE_SEPERATOR;
	    if (layout != null) {
	    	sep = layout.getEolString();
	    }

	    if (stdWriter == null) {
	    	if (layout == null || "".equals(layout.getFontName())) {
	    		stdWriter = new OutputStreamWriter(outStream);
			} else {
				stdWriter = new OutputStreamWriter(outStream, layout.getFontName());
			}
	        writer = new BufferedWriter(stdWriter, BUFFER_SIZE);

	        if (writeNames) {
	            writeLayout(writer, line.getLayout());
	        }
	    }

        if (writer == null) {
            throw new IOException(AbstractLineWriter.NOT_OPEN_MESSAGE);
        }


		writer.write(line.getField(0, Constants.FULL_LINE).toString());
		writer.write(sep);
    }

   
    public void setLayout(LayoutDetail layout) {
        try {
            if (writeNames && writer != null) {
                writeLayout(writer, layout);
            }
        } catch (Exception e) {
        }
    }

   
    public void writeLayout(BufferedWriter pWriter,
            				LayoutDetail layout)
    throws IOException {

        int i;
       // FieldDetail[] fields = layout.getRecord(0).getFields();
        RecordDetail rec = layout.getRecord(0);
        ICsvCharLineParser parser = CsvParserManagerChar.getInstance().get(layout.getRecord(0).getRecordStyle());
        String delim = layout.getRecord(0).getDelimiter();

        String quote = "";

        ArrayList<String> colNames = new ArrayList<String>();

        if (parser == null) {
        	parser = BasicCsvLineParser.getInstance();
        } else if (parser.isQuoteInColumnNames()) {
        	quote = layout.getRecord(0).getQuoteDefinition().asString();
        }

        for (i = 0; i < rec.getFieldCount(); i++) {
        	colNames.add(rec.getField(i).getName());
        }

        pWriter.write(parser.getColumnNameLine(colNames, new CsvDefinition(delim, quote))
        		+ layout.getEolString());

        writeNames = false;
    }


    
    public void close() throws IOException {

    	if (writer != null) {
    		writer.close();
    		stdWriter.close();
    	}
        outStream.close();

        writer    = null;
        stdWriter = null;
        outStream = null;
     }
}
