
package com.MainFrame.Reader.IO;

import java.io.IOException;
import java.io.OutputStream;

import com.MainFrame.Reader.ByteIO.ByteTextWriter;
import com.MainFrame.Reader.ByteIO.BinaryByteWriter;
import com.MainFrame.Reader.Common.Conversion;
import com.MainFrame.Reader.CsvParser.CsvParserManagerChar;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Details.RecordDetail;



public class BinTextWriter extends LineWriterWrapper {

	private OutputStream oStream = null;
	boolean toOpen = true;
	boolean names1stLine = false;
	
	public BinTextWriter(boolean nameOn1stLine) {
		super(null);
		names1stLine = nameOn1stLine;
	}

	
	@Override
	public void open(OutputStream outputStream) throws IOException {
		oStream = outputStream;
		toOpen = true;
	}

	
	@Override
	public void write(AbstractLine line) throws IOException {
		if (toOpen) {
			BinaryByteWriter writer = new BinaryByteWriter(false, false, line.getLayout().getRecordSep());
			toOpen = false;
			super.setWriter(writer);
			super.open(oStream);
			
			if (names1stLine) {
				LayoutDetail layout =  line.getLayout();
				RecordDetail rec = layout.getRecord(0);
				if (rec != null && rec.getFieldCount() > 0) {
					byte[] seperator = layout.getDelimiterDetails().asBytes();
					byte[] quote = layout.getQuoteDetails().asBytes();
					boolean addQuotes = false;
					if (quote != null && quote.length > 0 
					&& CsvParserManagerChar.getInstance().get(rec.getRecordStyle()).isQuoteInColumnNames()) {
						addQuotes = true;
					}
					if (addQuotes) {
						byte[] sep = {};
						for (int i = 0; i < rec.getFieldCount(); i++) {
							oStream.write(sep);
							oStream.write(quote);
							oStream.write(Conversion.getBytes(rec.getField(i).getName(), layout.getFontName()));
							oStream.write(quote);
							sep = seperator;
						}
					} else {
						oStream.write(Conversion.getBytes(rec.getField(0).getName(), layout.getFontName()));
						for (int i = 1; i < rec.getFieldCount(); i++) {
							oStream.write(seperator);
							oStream.write(Conversion.getBytes(rec.getField(i).getName(), layout.getFontName()));
						}
					}
				}
				oStream.write(layout.getRecordSep());
			}
			oStream = null;
		}
		super.write(line);
	}
	
	
}
