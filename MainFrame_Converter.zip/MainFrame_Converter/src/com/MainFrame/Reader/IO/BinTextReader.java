package com.MainFrame.Reader.IO;

import com.MainFrame.Reader.ByteIO.*;
import java.io.*;
import com.MainFrame.Reader.detailsBasic.*;
import com.MainFrame.Reader.Common.*;
import com.MainFrame.Reader.detailsSelection.*;
import com.MainFrame.Reader.Details.*;
import com.MainFrame.Reader.CsvParser.*;
import java.util.*;

public class BinTextReader extends LineReaderWrapper
{
    private String defaultQuote;
    private boolean readNames;
    
    public BinTextReader(final LineProvider provider, final boolean nameOn1stLine) {
        this(provider, nameOn1stLine, (IByteReader)new ByteTextReader());
    }
    
    public BinTextReader(final LineProvider provider, final boolean nameOn1stLine, final IByteReader reader) {
        super(provider, reader);
        this.defaultQuote = "'";
        this.readNames = nameOn1stLine;
    }
    
    public void open(final InputStream inputStream, final LayoutDetail layout) throws IOException {
        super.open(inputStream, layout);
        if (this.readNames) {
            this.createLayout(super.rawRead());
        }
    }
    
    protected void createLayout(final byte[] line) throws IOException {
        RecordDetail rec = null;
        int fieldType = 0;
        int decimal = 0;
        int format = 0;
        int parser = 0;
        int structure = 51;
        String param = "";
        String font = "";
        byte[] recordSep = Constants.SYSTEM_EOL_BYTES;
        boolean embeddedCr = false;
        boolean binCsv = false;
        CsvCharDetails delim = CsvCharDetails.newDelimDefinition("<tab>", font);
        CsvCharDetails quote = CsvCharDetails.newQuoteDefinition(this.defaultQuote, font);
        try {
            final LayoutDetail suppliedLayout = this.getLayout();
            final int ts = suppliedLayout.getFileStructure();
            if (ts != 52) {
                structure = ts;
            }
            delim = suppliedLayout.getDelimiterDetails();
            rec = suppliedLayout.getRecord(0);
            binCsv = suppliedLayout.isBinCSV();
            quote = rec.getQuoteDefinition();
            parser = rec.getRecordStyle();
            fieldType = rec.getField(0).getType();
            decimal = rec.getField(0).getDecimal();
            format = rec.getField(0).getFormat();
            param = rec.getField(0).getParamater();
            recordSep = suppliedLayout.getRecordSep();
            font = suppliedLayout.getFontName();
            embeddedCr = rec.isEmbeddedNewLine();
        }
        catch (Exception ex) {}
        final LayoutDetail layout = createLayout(line, rec, binCsv, recordSep, font, delim, parser, fieldType, decimal, format, param, quote, structure, embeddedCr);
        if (layout != null) {
            this.setLayout(layout);
        }
    }
    
    public static LayoutDetail createLayout(final byte[] line, final RecordDetail rec, final boolean binCsv, final byte[] recordSep, final String fontName, final CsvCharDetails delimiter, final int parser, int fieldType, final int decimal, final int format, final String param, final CsvCharDetails quote, final int structure, final boolean embeddedCr) throws IOException {
        LayoutDetail ret = null;
        if (line != null) {
            if (fieldType < 0) {
                fieldType = 0;
            }
            ICsvDefinition csvDef;
            if (rec != null) {
                csvDef = (ICsvDefinition)rec;
            }
            else {
                csvDef = (ICsvDefinition)new CsvDefinition(delimiter, quote, false);
            }
            final List<String> fieldList = CsvParserManagerByte.getInstance().get(parser, binCsv).getFieldList(line, csvDef);
            final int len = fieldList.size();
            final FieldDetail[] flds = new FieldDetail[len];
            final RecordDetail[] recs = { null };
            for (int i = 0; i < len; ++i) {
                (flds[i] = createField(rec, fontName, fieldType, decimal, format, param, fieldList.get(i))).setPosOnly(i + 1);
            }
            recs[0] = new RecordDetail("", 2, delimiter.jrDefinition(), quote.jrDefinition(), fontName, flds, parser, (RecordSelection)null, embeddedCr);
            try {
                ret = new LayoutDetail("", recs, "", 2, recordSep, "", fontName, (RecordDecider)null, structure);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        return ret;
    }
    
    protected static FieldDetail createField(final RecordDetail rec, final String fontName, final int fieldType, final int decimal, final int format, final String param, final String s) {
        int fldType = fieldType;
        final int idx;
        if (rec != null && (idx = rec.getFieldIndex(s)) >= 0) {
            fldType = rec.getField(idx).getType();
        }
        final FieldDetail f = new FieldDetail(s, s, fldType, decimal, fontName, format, param);
        return f;
    }
}

