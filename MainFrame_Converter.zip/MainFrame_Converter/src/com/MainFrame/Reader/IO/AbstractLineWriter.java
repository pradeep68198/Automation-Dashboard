
package com.MainFrame.Reader.IO;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.LayoutDetail;



public abstract class AbstractLineWriter {

    public static final String NOT_OPEN_MESSAGE = "File has not been opened";


    public void open(String fileName) throws IOException {
        open(new FileOutputStream(fileName));
    }


   
    public abstract void open(OutputStream outputStream)
    throws IOException;


   
    public abstract void write(AbstractLine line) throws IOException;


   
    public abstract void close() throws IOException;

   
    public void setLayout(LayoutDetail layout) {

    }
}
