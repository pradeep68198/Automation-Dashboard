
package com.MainFrame.Reader.IO;

import java.io.IOException;
import java.io.InputStream;

import com.MainFrame.Reader.Common.CommonBits;
import com.MainFrame.Reader.Common.IBasicFileSchema;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Details.LineProvider;
import com.MainFrame.Reader.External.CobolCopybookLoader;
import com.MainFrame.Reader.External.CopybookLoader;
import com.MainFrame.Reader.IO.builders.CblIOBuilderMultiSchema;
import com.MainFrame.Reader.Numeric.ICopybookDialects;
import com.MainFrame.Reader.def.IO.builders.ICobolIOBuilder;



public class CobolIoProvider {

    private static CobolIoProvider instance = new CobolIoProvider();
    private CopybookLoader copybookInt = new CobolCopybookLoader();

   
	public ICobolIOBuilder newIOBuilder(String copybookFileame) {
    	return newIOBuilder(copybookFileame, ICopybookDialects.FMT_MAINFRAME);
    }
    
   
	public ICobolIOBuilder newIOBuilder(String copybookFilename, int cobolDialect) {
		return new CblIOBuilderMultiSchema(copybookFilename, new CobolCopybookLoader(), cobolDialect);
//    	return new CblIOBuilderSchemaFilename(copybookFileame, new CobolCopybookLoader(), cobolDialect);
    }

   
	public ICobolIOBuilder newIOBuilder(InputStream cobolCopybookStream, String copybookName) throws IOException {
    	return newIOBuilder(cobolCopybookStream, copybookName, ICopybookDialects.FMT_MAINFRAME);
    }
    
   
	public ICobolIOBuilder newIOBuilder(InputStream cobolCopybookStream, String copybookName, int cobolDialect) {
    	return new CblIOBuilderMultiSchema(cobolCopybookStream, copybookName, new CobolCopybookLoader(), cobolDialect);
//    	return new CblIOBuilderSchemaStream(cobolCopybookStream, copybookName, new CobolCopybookLoader(), cobolDialect);
    }
    

    
    public AbstractLineReader getLineReader(int fileStructure,
			   int numericType, int splitOption, int copybookFormat,
			   String copybookName, String filename)
    throws Exception {
        return getLineReader(fileStructure,
 			   numericType, splitOption, copybookFormat,
			   copybookName, filename,
			   null);
    }

    public AbstractLineReader getLineReader(int fileStructure,
			   int numericType, int splitOption,
			   String copybookName, String filename)
					   throws Exception {
     return getLineReader(fileStructure,
			   numericType, splitOption,
			   copybookName, filename,
			   null);
 }

    
    public AbstractLineReader getLineReader(int fileStructure,
 			   int numericType, int splitOption,
 			   String copybookName, String filename,
 			   LineProvider provider)
     throws Exception {
    	return getLineReader(fileStructure, numericType, splitOption, CommonBits.getDefaultCobolTextFormat(), copybookName, filename, provider);
    }
    
    
    public AbstractLineReader getLineReader(int fileStructure,
			   int numericType, int splitOption, int copybookFormat,
			   String copybookName, String filename,
			   LineProvider provider)
    throws Exception {
        AbstractLineReader ret;
        String font = "";
        if (numericType == ICopybookDialects.FMT_MAINFRAME) {
            font = "cp037";
        }
       	LayoutDetail copyBook = 
       	     copybookInt.loadCopyBook(
                        copybookName,
                        splitOption, 0, font,
                        copybookFormat,
                        numericType, 0, null
                ).setFileStructure(fileStructure)
       	     	 .asLayoutDetail()
        ;

//       	if (provider == null) {
//       		provider = LineIOProvider.getInstance().getLineProvider(fileStructure, font);
//       	}
       	ret = LineIOProvider.getInstance()
       				.getLineReader(copyBook, provider);
       	ret.open(filename, copyBook);

       	return ret;

    }


   @Deprecated
    public AbstractLineWriter getLineWriter(int fileStructure, String outputFileName)
    throws IOException {
        AbstractLineWriter ret = LineIOProvider.getInstance()
        			.getLineWriter(fileStructure);
        ret.open(outputFileName);
        return ret;
    }

 

    
     public AbstractLineWriter getLineWriter(IBasicFileSchema schema, String outputFileName)
     throws IOException {
         AbstractLineWriter ret = LineIOProvider.getInstance()
         			.getLineWriter(schema);
         ret.open(outputFileName);
         return ret;
     }


    
    public static CobolIoProvider getInstance() {
        return instance;
    }
}
