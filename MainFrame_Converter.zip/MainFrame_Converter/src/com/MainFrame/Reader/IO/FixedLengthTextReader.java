
package com.MainFrame.Reader.IO;

import java.io.IOException;
import java.io.InputStream;

import com.MainFrame.Reader.Common.RecordException;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Details.LineProvider;
import com.MainFrame.Reader.charIO.FixedLengthCharReader;


public class FixedLengthTextReader extends BasicTextLineReader {

	public FixedLengthTextReader(LineProvider provider) {
		super(provider);
	}


    
    public void open(InputStream inputStream, LayoutDetail layout)
    throws IOException {
		if (layout == null) { throw new RecordException("You must supply a layout (schema)"); }
		
		String font = layout.getFontName();
    	
    	super.open(new FixedLengthCharReader(layout.getMaximumRecordLength()), inputStream, layout, font);
    }
}
