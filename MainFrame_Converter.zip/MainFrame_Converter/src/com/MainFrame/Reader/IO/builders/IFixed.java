
package com.MainFrame.Reader.IO.builders;

import com.MainFrame.Reader.def.IO.builders.IDefineFixedFieldsByLength;
import com.MainFrame.Reader.def.IO.builders.IDefineFixedFieldsByPosition;
import com.MainFrame.Reader.def.IO.builders.IFixedWidthIOBuilder;

public interface IFixed  extends IFixedWidthIOBuilder, IDefineFixedFieldsByPosition, IDefineFixedFieldsByLength {

}
