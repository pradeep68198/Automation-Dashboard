
package com.MainFrame.Reader.IO.builders;

import com.MainFrame.Reader.External.ICopybookLoaderStream;
import com.MainFrame.Reader.Log.AbsSSLogger;

public interface IGetLoader {

	
	public abstract ICopybookLoaderStream getLoader();

	public abstract boolean isDropCopybookNameFromFields();
	
	public abstract String getFont();

	public abstract int getDialect();

	public abstract AbsSSLogger getLog();

	public abstract int getCopybookFileFormat();
}