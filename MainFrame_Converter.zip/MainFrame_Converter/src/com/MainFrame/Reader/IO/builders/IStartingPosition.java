package com.MainFrame.Reader.IO.builders;

public interface IStartingPosition {
	public abstract int calculateStartingPosition();
}
