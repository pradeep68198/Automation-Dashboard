
package com.MainFrame.Reader.IO.builders;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;
import java.util.TreeMap;

import com.MainFrame.Reader.ByteIO.IByteRecordReader;
import com.MainFrame.Reader.ByteIO.IByteRecordWriter;
import com.MainFrame.Reader.Common.CommonBits;
import com.MainFrame.Reader.Common.Constants;
import com.MainFrame.Reader.Common.Conversion;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.CharLineProvider;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Details.LineProvider;
import com.MainFrame.Reader.Details.RecordDecider;
import com.MainFrame.Reader.External.CopybookLoader;
import com.MainFrame.Reader.External.ExternalRecord;
import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
import com.MainFrame.Reader.IO.AbstractLineReader;
import com.MainFrame.Reader.IO.AbstractLineWriter;
import com.MainFrame.Reader.IO.LineByteRecordReaderWrapper;
import com.MainFrame.Reader.IO.LineByteRecordWriterWrapper;
import com.MainFrame.Reader.IO.LineIOProvider;
import com.MainFrame.Reader.Log.AbsSSLogger;
import com.MainFrame.Reader.Log.TextLog;
import com.MainFrame.Reader.Option.IRecordPositionOption;



public abstract class CblIOBuilderBase<IOB> /*implements ISchemaIOBuilder*/  {

	private static final TextLog DEFAULT_LOG = new TextLog();
	
	@SuppressWarnings("unchecked")
	protected final IOB self = (IOB) this;
	private LayoutDetail layout = null;
	private LineProvider lineProvider;
	private RecordDecider recordDecider=null;
	Map<String, RecordUpdate> recordSelectionMap = null;

	int dialect;
    //final int copybookType;

	int splitCopybook = CopybookLoader.SPLIT_NONE;
	private String defaultFont = null;
	private String font = null;
	int copybookFileFormat = 1; // actually Cb2xmlConstants.USE_STANDARD_COLUMNS;
	int fileOrganization = Constants.NULL_INTEGER;
//	int defaultFileOrganization = Constants.NULL_INTEGER;
	boolean dropCopybookNameFromFields = false;
	Boolean initToSpaces = null;
	int recordLength = -1;
	 
	
    AbsSSLogger log = DEFAULT_LOG; 
    
	protected CblIOBuilderBase(int dialect) {
		super();
		this.dialect = dialect;
	}

 
	protected CblIOBuilderBase(LayoutDetail schema) {
		super();
		//this.copybookType = copybookType;
		this.layout = schema;
		this.lineProvider = LineIOProvider.getInstance().getLineProvider(layout);
	}


	
	public final IOB setDialect(int dialect) {
		this.dialect = dialect;
		clearLayout();
		return self;
	}




	public IOB setSplitCopybook(int splitCopybook) {
		this.splitCopybook = splitCopybook;
		clearLayout();
		return self;
	}

	
	public IOB setFont(String font) {
		this.font = font;
		this.defaultFont = font;
		clearLayout();
		return self;
	}

	public IOB setDefaultFont(String defaultFont) {
		this.defaultFont = defaultFont;
		clearLayout();
		return self;
	}


	public final IOB setCopybookFileFormat(int copybookFileFormat) {
		this.copybookFileFormat = copybookFileFormat;
		clearLayout();
		return self;
	}

	

	
	protected int getFileOrganization() {
//		if (fileOrganization < 0 && defaultFileOrganization >= 0) {
//			return defaultFileOrganization;
//		}
		return fileOrganization;
	}
//
//	public IOB setDefaultFileOrganization(int defaultFileOrganization) {
//		this.defaultFileOrganization = defaultFileOrganization;
//		clearLayout();
//		return self;
//	}


	
	public IOB setFileOrganization(int fileOrganization) {
		this.fileOrganization = fileOrganization;
		clearLayout();
		return self;
	}




	/**
	 * @return the dropCopybookNameFromFields
	 */
	public final boolean isDropCopybookNameFromFields() {
		return dropCopybookNameFromFields;
	}


	/**
	 * @param dropCopybookNameFromFields the dropCopybookNameFromFields to set
	 */
	public final IOB setDropCopybookNameFromFields(
			boolean dropCopybookNameFromFields) {
		this.dropCopybookNameFromFields = dropCopybookNameFromFields;
		clearLayout();
		return self;
	}




	
	public final IOB setLog(AbsSSLogger log) {
		this.log = log;
		clearLayout();
		return self;
	} 
	
	
   
	public AbstractLine newLine() throws IOException {
		LayoutDetail schema = getLayout();
		
		return lineProvider.getLine(schema);
	}


	public AbstractLine newLine(byte[] data) throws IOException {
		LayoutDetail schema = getLayout();
		
		return lineProvider.getLine(schema, data);
	}


	
	public final AbstractLineReader newReader(String filename) throws FileNotFoundException, IOException {
		//checkOk(true);
		return newReader(new FileInputStream(filename));
	}
	
   
	public final AbstractLineReader newReader(InputStream datastream) throws IOException {
		checkOk(true);
		LayoutDetail schema = getLayout();
		AbstractLineReader r = LineIOProvider.getInstance().getLineReader(schema);
		
		r.open(datastream, schema);
		return r;
	}
	
	public final AbstractLineReader newReader(IByteRecordReader reader) throws IOException {
		checkOk(true);
		LayoutDetail schema = getLayout();
		
		return new LineByteRecordReaderWrapper<IByteRecordReader>(lineProvider, reader, schema);
	}
	
	
	public final AbstractLineWriter newWriter(String filename) throws FileNotFoundException, IOException {
		checkOk(false);
		return newWriter(new FileOutputStream(filename));
	}

	
	public final AbstractLineWriter newWriter(IByteRecordWriter writer) throws IOException {
		checkOk(false);
		//LayoutDetail schema = getLayout();

		return new LineByteRecordWriterWrapper<IByteRecordWriter>(writer);
	}
	
	
	public final AbstractLineWriter newWriter(OutputStream datastream) throws IOException {
		checkOk(false);
		LayoutDetail schema = getLayout();
		AbstractLineWriter r = LineIOProvider.getInstance().getLineWriter(schema);
		
		r.open(datastream);
		return r;
	}
	
	
	protected void checkOk(boolean input) {
		
	}
	
	 @Deprecated
	public final Object[] getAllAttributes() {
		Object[] r = {
				dialect, 
				splitCopybook,
				copybookFileFormat,// actually Cb2xmlConstants.USE_STANDARD_COLUMNS;
				fileOrganization,
				getFont(),
				dropCopybookNameFromFields,
				//defaultFileOrganization,
				defaultFont
				
		};
		 
		return r;

	}
	
	
	
	
	public IOB setRecordSelection(String recordName, ExternalSelection selectionCriteria) {
		getRecordUpdate(recordName).selection = selectionCriteria;
		clearLayout();

		return self;
	}


	public IOB setRecordPositionCode(String recordName, IRecordPositionOption positionOption) {
		getRecordUpdate(recordName).positionCode = positionOption;
		clearLayout();

		return self;
	}


	public IOB setRecordParent(String recordName, String parentName) {
		getRecordUpdate(recordName).parentName = parentName;
		clearLayout();

		return self;
	}


	
	public final IOB setRecordDecider(RecordDecider recordDecider) {
		this.recordDecider = recordDecider;
		clearLayout();

		return self;
	}

	
	public IOB setRecordLength(int recordLength) {
		this.recordLength = recordLength;
		clearLayout();

		return self;
	}


	
	public final IOB setInitToSpaces(boolean initToSpaces) {
		this.initToSpaces = Boolean.valueOf(initToSpaces);
		clearLayout();

		return self;
	}


	public String getFont() {
		return deriveActualFont(font == null ? defaultFont : font);
	}
	
//	public String getDefaultFont() {	
//		return deriveActualFont(defaultFont);
//	}
//

	private String deriveActualFont(String f) {
		
		if (f == null) {
			f = "";
			if (Conversion.DEFAULT_CHARSET_DETAILS.isMultiByte
			&&  CommonBits.getLineType(fileOrganization) == CommonBits.LT_BYTE) {
				f = Conversion.getDefaultSingleByteCharacterset();
			}
		}
		return f;
	}

	public final ExternalRecord getExternalRecord() throws IOException  {			
		ExternalRecord schema =  getExternalRecordImpl();
				
		schema.setRecordDecider(recordDecider);
		schema.setRecordLength(recordLength);
		//schema.setFontName(getFont());
		
		if (font != null) {
			schema.setFontName(font);
		}
		
		if (fileOrganization >= 0) {
			schema.setFileStructure(fileOrganization);
//		} else if (defaultFileOrganization >= 0 && schema.getFileStructure() <= 0 
//				&& schema.isFileStructureUpdated() == false) {
//			schema.setFileStructure(defaultFileOrganization);
		}
		
		if (initToSpaces == null) {
			schema.setInitToSpaces(! schema.isBinary());
		} else {
			schema.setInitToSpaces(initToSpaces);
		}
		
		if (recordSelectionMap != null) {
			for (int i = 0; i < schema.getNumberOfRecords(); i++) {
				ExternalRecord record = schema.getRecord(i);
				RecordUpdate recUpdate = recordSelectionMap.get(record.getRecordName().toLowerCase());
				if (recUpdate != null) {
					if (recUpdate.selection != null) {	
						record.setRecordSelection(recUpdate.selection);
					}
		
					if (recUpdate.positionCode != null) {
						record.setRecordPositionOption(recUpdate.positionCode);
					}
					
					if (recUpdate.parentName != null) {
						record.setParentName(recUpdate.parentName);
					}
				}
			}
		}

		return schema; 
	}
	
	private RecordUpdate getRecordUpdate(String recordName) {
		RecordUpdate rec;
		if (recordSelectionMap == null) {
			recordSelectionMap = new TreeMap<String, RecordUpdate>();
		}
		
		String key = recordName.toLowerCase();
		rec = recordSelectionMap.get(key);
		if (rec == null) {
			rec = new RecordUpdate();
			recordSelectionMap.put(key, rec);
		}

		return rec;
	}
	
	protected abstract ExternalRecord getExternalRecordImpl() throws IOException;

	protected void clearLayout() {
		layout = null;
	}


	
	public final LayoutDetail getLayout() throws IOException {
		if (layout == null) {
			layout = getExternalRecord().asLayoutDetail();
			lineProvider = LineIOProvider.getInstance().getLineProvider(layout);
		}
		
		if (layout.hasBinaryField()) {
			if (CommonBits.getLineType(layout.getFileStructure()) != CommonBits.LT_BYTE) {
				throw new RuntimeException("This is a binary Layout (Schema) but you have selected a Character file Organisation,"
						+ " you must use you must Byte based Organisation");
			}
			if (lineProvider instanceof CharLineProvider) {
				throw new RuntimeException("This is a binary schema (requires byte based line-provider), but the line provider is a Text Based Line provider");
			}
		}

		return layout;
	}

	
	
	private static class RecordUpdate {
		ExternalSelection selection = null;
		String parentName = null;
		IRecordPositionOption positionCode = null;
	}
	
}
