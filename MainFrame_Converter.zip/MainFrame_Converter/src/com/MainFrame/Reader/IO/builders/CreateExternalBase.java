
package com.MainFrame.Reader.IO.builders;

import com.MainFrame.Reader.External.CopybookLoader;
import com.MainFrame.Reader.External.ExternalRecord;
import com.MainFrame.Reader.External.ICopybookLoaderStream;
import com.MainFrame.Reader.External.ISetDropCopybookName;
import com.MainFrame.Reader.External.Def.ExternalField;
import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;

public abstract class CreateExternalBase {
	final IGetLoader parent;
	private final String recordName;
	private ExternalRecord lastExternalRecord;
	
	private boolean optimizeTypes = true;
	
	int splitCopybook = CopybookLoader.SPLIT_NONE;
	private ExternalSelection recordSelection = null;
	private IStartingPosition startPosition = new IStartingPosition() {		
		@Override public int calculateStartingPosition() {
			return 0;
		}
	};
	

	protected CreateExternalBase(IGetLoader parent, String name) {
		super();
		this.parent = parent;
		this.recordName = name;
	}

	
	
	public final void setSplitCopybook(int split) {
		this.splitCopybook = split;
		doCheck();
	}
	
	
	public final void setRecordSelection(ExternalSelection recordSelection) {
		this.recordSelection = recordSelection;
		doCheck();
	}
	
	
	
	public final void setStartPosition(IStartingPosition startPosition) {
		this.startPosition = startPosition;
	}


	private void doCheck() {
		if (recordSelection != null && splitCopybook != CopybookLoader.SPLIT_NONE) {
			throw new RuntimeException("A record selection can only be specified when split=None");
		}
	}
	

	public ExternalRecord createExternalRecord() throws Exception {
		
		ICopybookLoaderStream loader = parent.getLoader();
		if (loader instanceof ISetDropCopybookName) { 
			((ISetDropCopybookName) loader).setDropCopybookFromFieldNames(parent.isDropCopybookNameFromFields());
		}

		lastExternalRecord = createExternalRecordImp();
		lastExternalRecord.setOptimizeTypes(optimizeTypes);
		
		if (recordSelection != null) {
			lastExternalRecord.setRecordSelection(recordSelection);			
		}
		int startAdj = startPosition.calculateStartingPosition();
		if (startAdj > 0) {
			adjustFields(lastExternalRecord, startAdj);
		}
		
		return lastExternalRecord;
	}
	
	
	
	public ExternalRecord getLastExternalRecord() {
		return lastExternalRecord;
	}

	public void clearLastRecord() {
		lastExternalRecord = null;
	}

	public String getRecordName() {
		return recordName;
	}


	private void adjustFields(ExternalRecord r, int adj) {
		for (int i = 0; i < r.getNumberOfRecords(); i++) {
			adjustFields(r.getRecord(i), adj);
		}
		for (int i = 0; i < r.getNumberOfRecordFields(); i++) {
			ExternalField f = r.getRecordField(i);
			f.setPos(f.getPos() + adj);
		}
	}
	
	protected abstract ExternalRecord createExternalRecordImp() throws Exception;


	
	public void setOptimizeTypes(boolean optimizeTypes) {
		this.optimizeTypes = optimizeTypes;
	}
}
