
package com.MainFrame.Reader.IO.builders;

import java.io.IOException;

import com.MainFrame.Reader.External.ExternalRecord;
import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;

public interface ICreateExternal {

	
	public abstract ExternalRecord createExternalRecord()
			throws Exception;

	public abstract void setSplitCopybook(int splitCopybook);
	
	public abstract void setRecordSelection(ExternalSelection recordSelection);
	
	public abstract void setStartPosition(IStartingPosition startPosition);
	
	public abstract String getRecordName();
	
	public abstract ExternalRecord getLastExternalRecord();
	
	public abstract void clearLastRecord();
	
	public void setOptimizeTypes(boolean optimizeTypes);
}