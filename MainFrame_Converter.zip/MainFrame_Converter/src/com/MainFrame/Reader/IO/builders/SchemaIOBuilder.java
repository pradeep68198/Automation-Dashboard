
package com.MainFrame.Reader.IO.builders;

import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.External.ExternalRecord;
import com.MainFrame.Reader.def.IO.builders.ISchemaIOBuilder;


public class SchemaIOBuilder extends CblIOBuilderBase<ISchemaIOBuilder> implements ISchemaIOBuilder {

	public static ISchemaIOBuilder newSchemaIOBuilder(LayoutDetail schema) { 
		return new SchemaIOBuilder(schema);
	}
	
	private SchemaIOBuilder(LayoutDetail schema) {
		super(schema);
	}

	
	@Override
	protected ExternalRecord getExternalRecordImpl()  {
		throw new RuntimeException("Error: this method should not get called in SchemaIOBuilder");
	}

}
