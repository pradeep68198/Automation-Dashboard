
package com.MainFrame.Reader.IO.builders;

import java.io.IOException;

import com.MainFrame.Reader.Common.Constants;
import com.MainFrame.Reader.Common.RecordException;
import com.MainFrame.Reader.External.ExternalRecord;
import com.MainFrame.Reader.def.IO.builders.ICsvIOBuilder;
import com.MainFrame.Reader.def.IO.builders.IDefineCsvFields;

public class CsvIOBuilder extends CblIOBuilderBase<ICsvIOBuilder> implements ICsvIOBuilder, IDefineCsvFields {

	private ExternalRecord record = new ExternalRecord();
	private boolean definedField = false;
	
//	private int parser = 0;

	
	private CsvIOBuilder(String delim, String quote) {

		super(0);
		super.setFileOrganization(Constants.IO_UNICODE_NAME_1ST_LINE);
		super.setFont("");

		record.setQuote(quote);
		record.setDelimiter(delim);
		record.setRecordType(Constants.rtDelimitedAndQuote);
	}

	@Override
	protected ExternalRecord getExternalRecordImpl() throws IOException {
	
		record.setFontName(super.getFont());
		return record;
	}

	
	

	
	@Override
	public ICsvIOBuilder setDelimiter(String val) {
		record.setDelimiter(val);
		super.clearLayout();
		return this;
	}

	
	@Override
	public ICsvIOBuilder setQuote(String val) {
		record.setQuote(val);
		super.clearLayout();
		record.setRecordType(Constants.rtDelimitedAndQuote);
		if (val == null || val.length() == 0) {
			record.setRecordType(Constants.rtDelimited);
		}
		return this;
	}

	
	
	@Override
	public ICsvIOBuilder setParser(int csvParser) {
		record.setRecordStyle(csvParser);
		return this;
	}

	
	@Override
	protected void checkOk(boolean input) {
		if (definedField) {
		} else if (input) {
			switch (super.getFileOrganization()) {
			case Constants.IO_UNICODE_NAME_1ST_LINE:
			case Constants.IO_UNICODE_CSV_NAME_1ST_LINE:
			case Constants.IO_NAME_1ST_LINE:
			case Constants.IO_CSV_NAME_1ST_LINE:
			case Constants.IO_BIN_NAME_1ST_LINE:
			case Constants.IO_BIN_CSV_NAME_1ST_LINE:
				break;
			default:
				throw new RecordException("Unless you are reading from a file with field names on the first line, "
							+ "You must define fields (or columns) using the defineFields() method !! ");
			}		
		} else {
			throw new RecordException("For Output files, You must define fields (or columns) using the defineFields() method !! ");
		}
	}

//	
//	@Override
//	public AbstractLine newLine() throws IOException {
//		LayoutDetail layout = getLayout();
//		if (layout.)
//		return new CsvLine(layout);
//	}

	public IDefineCsvFields defineFields() {
		return this;
	}

	

	
	@Override
	public IDefineCsvFields addCsvField(String name, int type, int decimal) {
		definedField = true;
		record.addCsvField(name, type, decimal);
		super.clearLayout();
		return this;
	}

	
	@Override
	public CsvIOBuilder endOfRecord() {
		return this;
	}

	
	public static ICsvIOBuilder newCsvIOBuilder() {
		return new CsvIOBuilder(",", "\"");
	}
	
	
	public static ICsvIOBuilder newCsvIOBuilder(String delim, String quote) {
		return new CsvIOBuilder(delim, quote);
	}
}
