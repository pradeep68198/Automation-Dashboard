
package com.MainFrame.Reader.IO.builders;

import java.io.IOException;
import java.io.InputStream;

import com.MainFrame.Reader.Common.Conversion;
import com.MainFrame.Reader.External.ICopybookLoaderStream;
import com.MainFrame.Reader.def.IO.builders.ICobolMultiCopybookIOBuilder;
import com.MainFrame.Reader.def.IO.builders.IFileIOBuilder;
import com.MainFrame.Reader.def.IO.builders.Icb2xmlMultiFileIOBuilder;

public class CblIOBuilderMultiSchema extends CblIOBuilderMultiSchemaBase<CblIOBuilderMultiSchema>
implements ICobolMultiCopybookIOBuilder, Icb2xmlMultiFileIOBuilder, IFileIOBuilder {

	
	public CblIOBuilderMultiSchema(String copybookFilename, ICopybookLoaderStream loader, int cobolDialect) {
		super(Conversion.getCopyBookId(copybookFilename), loader, cobolDialect);

		copybooks.add(new CreateExternalFromFile(this, copybookFilename));
	}


	
	public CblIOBuilderMultiSchema(InputStream copybookStream, String copybookName, ICopybookLoaderStream loader, int cobolDialect) {
		super(copybookName, loader, cobolDialect);

		copybooks.add(new CreateExternalFromStream(this, copybookStream, copybookName));
	} 

	
	public CblIOBuilderMultiSchema(String copybookname, ICopybookLoaderStream loader) {
		super(copybookname, loader);
	}
}
