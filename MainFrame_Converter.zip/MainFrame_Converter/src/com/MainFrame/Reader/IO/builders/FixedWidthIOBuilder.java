
package com.MainFrame.Reader.IO.builders;

import com.MainFrame.Reader.Common.Constants;
import com.MainFrame.Reader.External.ExternalRecord;
import com.MainFrame.Reader.def.IO.builders.IDefineFixedFieldsByLength;
import com.MainFrame.Reader.def.IO.builders.IDefineFixedFieldsByPosition;
import com.MainFrame.Reader.def.IO.builders.IFixedWidthIOBuilder;


public class FixedWidthIOBuilder extends CblIOBuilderBase<IFixed> 
implements IFixed /*, IFixedWidthIOBuilder, IDefineFixedFieldsByPosition, IDefineFixedFieldsByLength*/ {

	private ExternalRecord record = new ExternalRecord();
	private boolean definedField = false;

	
	
	private FixedWidthIOBuilder() {
		super(0);
		setFileOrganization(Constants.IO_STANDARD_TEXT_FILE);
	}

	@Override
	protected ExternalRecord getExternalRecordImpl() {
		record.setFontName(super.getFont());
		return record;
	} 


	
	@Override
	protected void checkOk(boolean input) {
		if (! definedField) {
			throw new RuntimeException("You must define Fields before getting a Reader/Writer");
		}
	}

	
	@Override
	public IDefineFixedFieldsByPosition defineFieldsByPosition() {
		return this;
	}
	
	
	@Override
	public IDefineFixedFieldsByLength defineFieldsByLength() {
		return this;
	}


		 
	public IDefineFixedFieldsByPosition addFieldByPosition(String name, int type, int pos, int decimal) {
		record.addFieldByPosition(name, type, pos, decimal);
		super.clearLayout();
		return this;
	}
	
	
	@Override
	public IDefineFixedFieldsByPosition skipFieldPosition(int pos) {
		record.skipFieldPosition(pos);
		super.clearLayout();
		return this;
	}

	@Override
	public IDefineFixedFieldsByLength addFieldByLength(String name, int type, int length, int decimal) {
		record.addFieldByLength(name, type, length, decimal);
		super.clearLayout();

		return this;
	}
	
	
	@Override
	public IDefineFixedFieldsByLength skipBytes(int numberOfBytes) {
		record.skipBytes(numberOfBytes);
		super.clearLayout();
		return this;			
	}

	
	@Override
	public FixedWidthIOBuilder endOfRecord() {
		definedField = true;
		return this;
	}


	
	@Override
	public FixedWidthIOBuilder endOfRecord(int position) {
		record.skipFieldPosition(position);
		definedField = true;
		return this;
	}
		
		
	
	
	public static IFixedWidthIOBuilder newFixedWidthIOBuilder() {
		return new FixedWidthIOBuilder();
	}
}
