
package com.MainFrame.Reader.IO.builders;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.MainFrame.Reader.External.CopybookLoaderFactory;
import com.MainFrame.Reader.External.ExternalRecord;
import com.MainFrame.Reader.External.ICopybookLoaderStream;
import com.MainFrame.Reader.External.base.RecordEditorXmlWriter;
import com.MainFrame.Reader.Log.TextLog;
import com.MainFrame.Reader.Numeric.ICopybookDialects;
import com.MainFrame.Reader.def.IO.builders.ICobolCopybookIOProvider;
import com.MainFrame.Reader.def.IO.builders.IIOCopybookProvider;
import com.MainFrame.Reader.def.IO.builders.Icb2xmlIOProvider;


public class FileSchemaBuilder implements ICobolCopybookIOProvider, IIOCopybookProvider, Icb2xmlIOProvider {
	private static final CopybookLoaderFactory lf = CopybookLoaderFactory.getInstance();
	private static final String STANDARD_FONT = "UTF-8";

	
	private final int schemaType;
	private boolean indentXml = false;

	public FileSchemaBuilder(int schemaType) {
		super();
		this.schemaType = schemaType;
	}
	
	
	@Override
	public CblIOBuilderMultiSchema newIOBuilder(String copybookFilename) {
    	try {
    		return new CblIOBuilderMultiSchema(copybookFilename, (ICopybookLoaderStream) lf.getLoader(schemaType), ICopybookDialects.FMT_MAINFRAME);
		} catch (ReflectiveOperationException e) {
			throw new RuntimeException(e);
		}
    }

	
	
	@Override
	public CblIOBuilderMultiSchema newIOBuilder(InputStream cobolCopybookStream, String copybookName) {
    	try {
    		return new CblIOBuilderMultiSchema(
    				cobolCopybookStream, copybookName, 
    				(ICopybookLoaderStream) lf.getLoader(schemaType), 
					ICopybookDialects.FMT_MAINFRAME);
//			return new CblIOBuilderSchemaStream( 
//					cobolCopybookStream, copybookName,
//					(ICopybookLoaderStream) lf.getLoader(schemaType), 
//					ICopybookDialects.FMT_MAINFRAME);
		} catch (ReflectiveOperationException e) {
			throw new RuntimeException(e);
		}
    }
	
	

	
	@Override
	public CblIOBuilderMultiSchema newIOBuilder(Reader copybookReader, String copybookName) {
		try {
			CblIOBuilderMultiSchema ret = new CblIOBuilderMultiSchema(
					 copybookName, 
					(ICopybookLoaderStream) lf.getLoader(schemaType));
			ret.addCopyBook(copybookReader, copybookName);
			return ret;
		} catch (ReflectiveOperationException e) {
			throw new RuntimeException(e);
		}
	}

	
	@Override 
	public CblIOBuilderMultiSchema newMultiCopybookIOBuilder(String copybookname) {
		try {
			return new CblIOBuilderMultiSchema(copybookname, (ICopybookLoaderStream) lf.getLoader(schemaType));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	
	@Override
	public FileSchemaBuilder setIndentXml(boolean indentXml) {
		this.indentXml = indentXml;
		
		return this;
	}


	
	@Override
	public void export(String fileName, ExternalRecord schema) 
	throws XMLStreamException, UnsupportedEncodingException, FactoryConfigurationError, IOException {
		export(new BufferedOutputStream(new FileOutputStream(fileName)), schema);
	}

	
	@Override
	public void export(OutputStream outStream, ExternalRecord schema)
	throws XMLStreamException, FactoryConfigurationError, IOException {
		RecordEditorXmlWriter writer = new RecordEditorXmlWriter();
		
		if (indentXml) {
			export(new OutputStreamWriter(outStream, STANDARD_FONT), schema);
		} else {
			writer.writeCopyBook(outStream, schema, new TextLog());
		}
	}
	
	
	@Override
	public void export(Writer writer, ExternalRecord schema)
			throws XMLStreamException, UnsupportedEncodingException, FactoryConfigurationError {
		if (indentXml) {
			XMLStreamWriter xmlStreamWriter =
					new com.MainFrame.Convert2xml.util.IndentXmlWriter(
							javax.xml.stream.XMLOutputFactory.newInstance()
								 .createXMLStreamWriter(writer)
			);

			export(xmlStreamWriter, schema);
		} else {
			export(
					javax.xml.stream.XMLOutputFactory.newInstance()
					 	.createXMLStreamWriter(writer), 
					schema);
		}
	}

	@Override
	public void export(XMLStreamWriter writer, ExternalRecord schema) throws XMLStreamException  {
		new RecordEditorXmlWriter()	
				.writeCopyBook(writer, schema);
	}

	
} 
