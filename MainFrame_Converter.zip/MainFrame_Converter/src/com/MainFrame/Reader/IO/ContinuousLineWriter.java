
package com.MainFrame.Reader.IO;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.RecordDetail;



public class ContinuousLineWriter extends AbstractLineWriter {
    private OutputStream outStream = null;

    private boolean toInit = true;
    private byte fillByte = 0;
    

    
    public ContinuousLineWriter() {
        super();
    }


  

   
    public void open(OutputStream outputStream) throws IOException {

        outStream = outputStream;
        if (! (outStream instanceof BufferedOutputStream)) {
        	outStream = new BufferedOutputStream(outStream);
        }
    }


    
    public void write(AbstractLine line) throws IOException {

        if (outStream == null) {
            throw new IOException(AbstractLineWriter.NOT_OPEN_MESSAGE);
        } else if (line == null) {
        	return;
        }

        byte[] rec = line.getData();
        int pref = line.getPreferredLayoutIdx();
        int prefLength;
        
        if (pref < 0 || ((prefLength = findLength(pref, line)) == rec.length) ) {
        	outStream.write(rec);    	
        } else if (prefLength < rec.length) {
        	outStream.write(rec, 0, prefLength);
        } else {
        	if (toInit) {
        		toInit = false;

        		if ((! line.getLayout().isBinary()) ) {
					fillByte = line.getLayout().getSpaceByte();
        		}
        	}
    		outStream.write(rec);

    		for (int i = rec.length; i < prefLength; i++) {
    			outStream.write(fillByte);
    		}
        }
    }

    
	private int findLength(int pref, AbstractLine line) {
		
		RecordDetail rec = line.getLayout().getRecord(pref);
		if (rec.hasDependingOn()) {
			FieldDetail f =  rec.getField(rec.getFieldCount() - 1);
			int len = rec.calculateActualPosition(line, f.getDependingOnDtls(), f.getEnd() + 1) - 1;
			return len;
		}
		return rec.getLength();
	}


    
    public void close() throws IOException {

        outStream.close();
        outStream = null;
    }
}
