
package com.MainFrame.Reader.IO;

import java.io.IOException;
import java.io.InputStream;

//import com.MainFrame.Reader.ByteIO.AbstractByteReader;
import com.MainFrame.Reader.ByteIO.IByteRecordReader;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Details.LineProvider;


public class LineByteRecordReaderWrapper<Reader extends IByteRecordReader> extends AbstractLineReader {

    Reader reader;
    int i = 0;

   
    LineByteRecordReaderWrapper(Reader byteReader) {
        super();

        reader = byteReader;
    }

    LineByteRecordReaderWrapper(LineProvider provider, Reader byteReader) {
        super(provider);

        reader = byteReader;
    }

    public LineByteRecordReaderWrapper(LineProvider provider, Reader byteReader, LayoutDetail pLayout) {
        super(provider);

        reader = byteReader;
//        reader.setLineLength(pLayout.getMaximumRecordLength());
        super.setLayout(pLayout);
    }


    
    public void open(InputStream inputStream, LayoutDetail pLayout)
            throws IOException {

//        reader.setLineLength(pLayout.getMaximumRecordLength());
//        reader.open(inputStream);
        super.setLayout(pLayout);
    }


   
    public AbstractLine readImplementation() throws IOException {
        byte bytes[] = reader.read();

        if (bytes == null) {
            return null;
        }
        return getLine(bytes);
    }

    protected byte[] rawRead() throws IOException {
    	return reader.read();
    }
    
    public void close() throws IOException {
        reader.close();
    }

	
	public final Reader getReader() {
		return reader;
	}
}
