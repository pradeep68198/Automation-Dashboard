
package com.MainFrame.Reader.IO;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.Details.LineProvider;
import com.MainFrame.Reader.Details.RecordDetail;



public class ContinuousLineReader extends AbstractLineReader {


	private static final int BUFFER_SIZE = 16384;

 	private BufferedInputStream stream = null;
	//private LayoutDetail recordLayout;

	private int maxSize;

	private byte[] buffer;

	protected int[] lengths;
	private AbstractLine tmpLine;

	//private ArrayList lineBuffer = new ArrayList();

//	private int lineNumber = 0;



	
	public ContinuousLineReader() {
	    super();
	}


	
	public ContinuousLineReader(final LineProvider provider) {
	    super(provider);
	}


  
    public void open(InputStream inputStream, LayoutDetail layout) {

        int i;

        stream = new BufferedInputStream(inputStream, BUFFER_SIZE);
        setLayout(layout);

		lengths = new int[layout.getRecordCount()];

		maxSize = 0;

		for (i = 0; i < lengths.length; i++) {
			lengths[i] = layout.getRecord(i).getLength();

			maxSize = java.lang.Math.max(maxSize, lengths[i]);
		}

		tmpLine = getLine(new byte[maxSize]);

		//lineBuffer.clear();

		buffer = new byte[maxSize];
    }



    
    public AbstractLine readImplementation() throws IOException {
        AbstractLine ret = null;
        int recordSize, bytesRead;
        byte[] rec;

        if (stream == null) {
            throw new IOException(AbstractLineReader.NOT_OPEN_MESSAGE);
        }

        stream.mark(maxSize);
        bytesRead = readBuffer(stream, buffer);

        if (bytesRead <= 0) {
            return null;
        }
        if (bytesRead < buffer.length) {
            bytesRead += 1;
        }
        tmpLine.replace(buffer, 0, bytesRead);
        recordSize = findLength(tmpLine, bytesRead);
        stream.reset();
        rec = new byte[recordSize];

        readBuffer(stream, rec);
        ret = getLine(rec);


        return ret;
    }


	
	protected int findLength(AbstractLine tmpLine, int maxLength) {
		int pref = tmpLine.getPreferredLayoutIdxAlt();
		
		if (pref < 0) {
		    throw new RuntimeException("Can Not Determine Record Type: " + tmpLine.getFullLine());
		}

		RecordDetail rec = super.getLayout().getRecord(pref);
		if (rec.hasDependingOn()) {
			FieldDetail f =  rec.getField(rec.getFieldCount() - 1);
			int len = rec.calculateActualPosition(tmpLine, f.getDependingOnDtls(), f.getEnd() + 1) - 1;
			return len;
		}
		return lengths[pref];
	}


   
    public void close() throws IOException {

        stream.close();
        buffer = null;
        stream = null;
    }

}
