
package com.MainFrame.Reader.IO;

import java.io.IOException;

import com.MainFrame.Reader.Details.AbstractLine;

public interface IReadLine {

	public abstract AbstractLine read() throws IOException;
}
