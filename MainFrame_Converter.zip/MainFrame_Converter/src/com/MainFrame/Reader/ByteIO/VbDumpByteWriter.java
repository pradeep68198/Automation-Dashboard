/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VbDumpByteWriter
/*     */   extends AbstractByteWriter
/*     */ {
/*     */   private static final int DEFAULT_BUFFER_SIZE = 27998;
/*  83 */   private OutputStream outStream = null;
/*  84 */   private ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
/*     */   
/*     */   private int blockSize;
/*     */   
/*  88 */   private byte[] rdw = new byte[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VbDumpByteWriter() {
/*  96 */     this(27998);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VbDumpByteWriter(int pBlockSize) {
/* 109 */     this.blockSize = pBlockSize;
/* 110 */     this.rdw[2] = 0;
/* 111 */     this.rdw[3] = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(OutputStream outputStream) throws IOException {
/* 120 */     this.outStream = outputStream;
/* 121 */     this.byteStream.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] rec) throws IOException {
/* 130 */     if (this.outStream == null) {
/* 131 */       throw new IOException("File has not been opened");
/*     */     }
/*     */ 
/*     */     
/* 135 */     if (this.byteStream.size() + rec.length + 4 >= this.blockSize) {
/* 136 */       writeBlock();
/*     */     }
/*     */     
/* 139 */     updateRDW(rec.length + 4, this.rdw);
/* 140 */     this.byteStream.write(this.rdw);
/*     */ 
/*     */     
/* 143 */     this.byteStream.write(rec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeBlock() throws IOException {
/* 154 */     updateRDW(this.byteStream.size() + 4, this.rdw);
/* 155 */     this.outStream.write(this.rdw);
/* 156 */     this.byteStream.writeTo(this.outStream);
/* 157 */     this.byteStream.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateRDW(int length, byte[] word) {
/* 168 */     byte[] bytes = BigInteger.valueOf(length).toByteArray();
/*     */     
/* 170 */     word[1] = bytes[bytes.length - 1];
/* 171 */     word[0] = 0;
/* 172 */     if (bytes.length > 1) {
/* 173 */       word[0] = bytes[bytes.length - 2];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 182 */     if (this.byteStream.size() > 0) {
/* 183 */       writeBlock();
/*     */     }
/*     */     
/* 186 */     this.outStream.close();
/* 187 */     this.outStream = null;
/*     */   }
/*     */ }

