/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import com.MainFrame.Reader.Common.Constants;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseByteTextReader
/*     */   extends AbstractByteReader
/*     */ {
/*  45 */   protected byte[] crBytes = Constants.CR_BYTES;
/*  46 */   protected byte[] lfBytes = Constants.LF_BYTES;
/*  47 */   protected byte[] lfcrBytes = Constants.CRLF_BYTES;
/*     */   
/*  49 */   protected byte byteLF = 10;
/*  50 */   protected byte byteCR = 13;
/*     */   
/*  52 */   protected static final byte[] EMPTY = new byte[0];
/*     */ 
/*     */ 
/*     */   
/*  56 */   private static FindLines NO_EOL_FINDLINES = new FindLines()
/*     */     {
/*     */       public void findLinesInBuffer(int start) {}
/*     */     };
/*     */ 
/*     */   
/*  62 */   private static int MAX_LINE_SIZE = 131072;
/*  63 */   private static final byte[] NO_EOL = EMPTY;
/*  64 */   protected byte[] eol = null; protected byte[] altEol = EMPTY;
/*     */ 
/*     */ 
/*     */   
/*  68 */   protected final byte[] buffer = new byte[MAX_LINE_SIZE];
/*     */   protected int bytesInBuffer;
/*  70 */   protected final int[] lineArray = new int[16];
/*     */   protected int noLines;
/*     */   protected int lineNo;
/*  73 */   private InputStream in = null; private boolean eof;
/*     */   private boolean eofPending;
/*  75 */   private long bytesRead = 0L;
/*     */   
/*     */   protected boolean check4cr = false;
/*     */   
/*     */   protected boolean check4lf = false;
/*  80 */   protected FindLines findLines = NO_EOL_FINDLINES;
/*     */   
/*     */   public BaseByteTextReader() {
/*  83 */     this("");
/*     */   }
/*     */   
/*     */   public BaseByteTextReader(String charSet) {
/*  87 */     setLfCr(charSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public void open(InputStream inputStream) throws IOException {
/*  92 */     this.in = inputStream;
/*  93 */     this.eof = false;
/*  94 */     this.check4lf = false;
/*  95 */     this.check4cr = false;
/*     */ 
/*     */ 
/*     */     
/*  99 */     this.bytesInBuffer = readBuffer(this.in, this.buffer);
/* 100 */     this.eofPending = (this.bytesInBuffer < this.buffer.length);
/*     */ 
/*     */     
/* 103 */     if (this.eol == null) {
/* 104 */       int eolPos = getEolPosition();
/*     */       
/* 106 */       if (eolPos >= this.bytesInBuffer) {
/* 107 */         this.eol = NO_EOL;
/* 108 */       } else if (this.buffer[eolPos] == this.byteCR) {
/* 109 */         if (eolPos + 1 < this.bytesInBuffer && this.buffer[eolPos + 1] == this.byteLF) {
/* 110 */           this.eol = this.lfcrBytes;
/* 111 */           this.altEol = this.lfBytes;
/*     */         } else {
/*     */           
/* 114 */           this.eol = this.crBytes;
/* 115 */           this.check4lf = true;
/*     */         } 
/*     */       } else {
/* 118 */         this.eol = this.lfBytes;
/* 119 */         this.altEol = this.lfcrBytes;
/* 120 */         this.check4cr = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 126 */     setLineSearch();
/*     */     
/* 128 */     findLinesInBuffer(0);
/* 129 */     this.lineNo = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getEolPosition() {
/* 134 */     int pos = 0;
/* 135 */     while (pos < this.bytesInBuffer && this.buffer[pos] != this.byteCR && this.buffer[pos] != this.byteLF) {
/* 136 */       pos++;
/*     */     }
/*     */     
/* 139 */     return pos;
/*     */   }
/*     */   
/*     */   protected void setLineSearch() {
/* 143 */     if (this.eol.length > 0) {
/* 144 */       this.findLines = new StdFindLines();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] read() throws IOException {
/* 151 */     if (this.in == null) {
/* 152 */       throw new IOException("File has not been opened");
/*     */     }
/* 154 */     if (this.eof) {
/* 155 */       return null;
/*     */     }
/*     */     
/* 158 */     byte[] ret = null;
/* 159 */     int lno = getLineNo();
/*     */     
/* 161 */     int srcPos = this.lineArray[lno];
/*     */     
/* 163 */     if (srcPos < this.buffer.length && ((this.check4cr && this.buffer[srcPos] == this.byteCR) || (this.check4lf && this.buffer[srcPos] == this.byteLF))) {
/* 164 */       srcPos++;
/* 165 */       this.bytesRead++;
/*     */     } 
/* 167 */     if (this.eof) {
/* 168 */       if (this.bytesInBuffer <= srcPos) {
/* 169 */         return null;
/*     */       }
/* 171 */       ret = new byte[this.bytesInBuffer - srcPos];
/*     */     } else {
/* 173 */       int eolLength = this.eol.length;
/* 174 */       if (this.check4cr && lno + 1 < this.lineArray.length && this.lineArray[lno + 1] - eolLength - 1 < this.buffer.length && this.buffer[this.lineArray[lno + 1] - eolLength - 1] == this.byteCR)
/*     */       {
/*     */         
/* 177 */         eolLength++;
/*     */       }
/* 179 */       if (lno + 1 < this.lineArray.length) {
/*     */         
/* 181 */         ret = new byte[this.lineArray[lno + 1] - srcPos - eolLength];
/*     */       } else {
/* 183 */         ret = new byte[this.buffer.length - srcPos];
/*     */       } 
/* 185 */       this.bytesRead += eolLength;
/*     */     } 
/* 187 */     System.arraycopy(this.buffer, srcPos, ret, 0, ret.length);
/* 188 */     this.bytesRead += ret.length;
/*     */     
/* 190 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void close() throws IOException {
/* 196 */     if (this.in != null) {
/* 197 */       this.in.close();
/*     */     }
/* 199 */     this.in = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BaseByteTextReader setEol(byte[] eol) {
/* 206 */     this.eol = eol;
/* 207 */     if (Arrays.equals(eol, this.lfBytes)) {
/* 208 */       this.altEol = this.lfcrBytes;
/* 209 */       this.check4cr = true;
/* 210 */     } else if (Arrays.equals(eol, this.lfcrBytes)) {
/* 211 */       this.altEol = this.lfBytes;
/* 212 */     } else if (Arrays.equals(eol, this.crBytes)) {
/* 213 */       this.check4cr = true;
/*     */     } 
/* 215 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   private int getLineNo() throws IOException {
/* 220 */     this.lineNo++;
/* 221 */     if (this.lineNo == this.noLines - 1) {
/* 222 */       if (this.eofPending && this.noLines < this.lineArray.length) {
/* 223 */         this.eof = true;
/*     */       } else {
/* 225 */         findLinesInBuffer(this.lineArray[this.lineNo]);
/* 226 */         if (this.noLines == 1) {
/* 227 */           if (this.eofPending) {
/* 228 */             this.eof = true;
/*     */           } else {
/* 230 */             int len = this.bytesInBuffer - this.lineArray[this.lineNo];
/* 231 */             System.arraycopy(this.buffer, this.lineArray[this.lineNo], this.buffer, 0, len);
/*     */             
/* 233 */             this.bytesInBuffer = readBuffer(this.in, this.buffer, len);
/* 234 */             this.eofPending = (this.bytesInBuffer < this.buffer.length);
/*     */             
/* 236 */             findLinesInBuffer(0);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 242 */     return this.lineNo;
/*     */   }
/*     */   
/*     */   private void findLinesInBuffer(int start) {
/* 246 */     this.lineArray[0] = start;
/* 247 */     this.noLines = 1;
/* 248 */     this.lineNo = 0;
/* 249 */     this.findLines.findLinesInBuffer(start);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] getEol() {
/* 257 */     return this.eol;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setLfCr(String charSet) {
/* 263 */     byte[] b = Conversion.getBytes("\r\n", charSet);
/*     */     
/* 265 */     if (b[0] != this.byteLF || b[1] != this.byteCR) {
/* 266 */       this.byteCR = b[0];
/* 267 */       this.byteLF = b[1];
/*     */       
/* 269 */       this.crBytes = new byte[] { this.byteCR };
/* 270 */       this.lfBytes = new byte[] { this.byteLF };
/* 271 */       this.lfcrBytes = b;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getBytesRead() {
/* 280 */     return this.bytesRead;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static interface FindLines
/*     */   {
/*     */     void findLinesInBuffer(int param1Int);
/*     */   }
/*     */ 
/*     */   
/*     */   protected class StdFindLines
/*     */     implements FindLines
/*     */   {
/*     */     public void findLinesInBuffer(int start) {
/* 294 */       byte last = Byte.MIN_VALUE;
/* 295 */       int idx = BaseByteTextReader.this.eol.length - 1;
/*     */       
/* 297 */       while (BaseByteTextReader.this.noLines < BaseByteTextReader.this.lineArray.length && start < BaseByteTextReader.this.bytesInBuffer && start >= 0) {
/* 298 */         if (BaseByteTextReader.this.buffer[start] == BaseByteTextReader.this.eol[idx] && (BaseByteTextReader.this.eol.length == 1 || last == BaseByteTextReader.this.eol[0])) {
/* 299 */           BaseByteTextReader.this.lineArray[BaseByteTextReader.this.noLines] = start + 1;
/* 300 */           BaseByteTextReader.this.noLines++;
/*     */         } 
/*     */         
/* 303 */         last = BaseByteTextReader.this.buffer[start];
/* 304 */         start++;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }
