/*    */ package com.MainFrame.Reader.ByteIO;
import java.util.*;
import java.io.*;

public class ByteTextReader extends BaseByteTextReader
{
    public ByteTextReader() {
    }
    
    public ByteTextReader(final String charSet) {
        super(charSet);
    }
    
    public static List<byte[]> readStream(final String charSet, final InputStream in, final int maxNoLines) throws IOException {
        final ArrayList<byte[]> ret = new ArrayList<byte[]>();
        final boolean all = maxNoLines < 0;
        final ByteTextReader r = new ByteTextReader(charSet);
        r.open(in);
        byte[] b;
        while ((all || ret.size() < maxNoLines) && (b = r.read()) != null) {
            ret.add(b);
        }
        r.close();
        return ret;
    }
}