/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FixedLengthByteReader
/*     */   extends AbstractByteReader
/*     */ {
/*     */   private InputStream inStream;
/*  53 */   private BufferedInputStream stream = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int lineLength;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FixedLengthByteReader(int recordength) {
/*  67 */     this.lineLength = recordength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(InputStream inputStream) {
/*  77 */     this.inStream = inputStream;
/*     */     
/*  79 */     if (inputStream instanceof BufferedInputStream) {
/*  80 */       this.stream = (BufferedInputStream)inputStream;
/*     */     } else {
/*  82 */       this.stream = new BufferedInputStream(inputStream, 16384);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] read() throws IOException {
/*  92 */     byte[] ret = null;
/*  93 */     byte[] inBytes = new byte[this.lineLength];
/*     */     
/*  95 */     if (this.stream == null) {
/*  96 */       throw new IOException("File has not been opened");
/*     */     }
/*     */     
/*  99 */     if (readBuffer(this.stream, inBytes) > 0) {
/* 100 */       ret = inBytes;
/*     */     }
/*     */     
/* 103 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 112 */     if (this.inStream != null) {
/* 113 */       this.inStream.close();
/*     */     }
/* 115 */     this.stream = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineLength(int newLineLength) {
/* 124 */     this.lineLength = newLineLength;
/*     */   }
/*     */ }
