/*    */ package com.MainFrame.Reader.ByteIO;
/*    */ 
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractByteWriter
/*    */   implements IByteRecordWriter
/*    */ {
/*    */   public static final String NOT_OPEN_MESSAGE = "File has not been opened";
/*    */   
/*    */   public void open(String fileName) throws IOException {
/* 60 */     open(new FileOutputStream(fileName));
/*    */   }
/*    */   
/*    */   public abstract void open(OutputStream paramOutputStream) throws IOException;
/*    */   
/*    */   public abstract void write(byte[] paramArrayOfbyte) throws IOException;
/*    */   
/*    */   public abstract void close() throws IOException;
/*    */ }

