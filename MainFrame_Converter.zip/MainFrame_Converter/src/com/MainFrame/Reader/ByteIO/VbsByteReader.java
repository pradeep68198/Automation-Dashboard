/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VbsByteReader
/*     */   extends AbstractByteReader
/*     */ {
/*     */   private InputStream inStream;
/*  61 */   private BufferedInputStream stream = null;
/*     */   
/*  63 */   private int lineNumber = 0;
/*  64 */   private int rdwAdjust = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private byte[] rdw = new byte[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private byte[] nextRecord = null;
/*     */   
/*  86 */   private ArrayList<byte[]> subLines = (ArrayList)new ArrayList<byte[]>(5);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VbsByteReader(boolean includesBlockLength, boolean lengthIncludesRDW) {
/*  94 */     if (lengthIncludesRDW) {
/*  95 */       this.rdwAdjust = 4;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(InputStream inputStream) {
/* 104 */     this.inStream = inputStream;
/*     */     
/* 106 */     if (inputStream instanceof BufferedInputStream) {
/* 107 */       this.stream = (BufferedInputStream)inputStream;
/*     */     } else {
/* 109 */       this.stream = new BufferedInputStream(inputStream, 16384);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] read() throws IOException {
/* 120 */     byte[] ret = this.nextRecord;
/*     */     
/* 122 */     if (ret != null) {
/* 123 */       this.nextRecord = null;
/* 124 */       return ret;
/*     */     } 
/*     */     
/* 127 */     if (this.stream == null) {
/* 128 */       throw new IOException("File has not been opened");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 133 */     this.lineNumber++;
/* 134 */     ret = readLinePart();
/* 135 */     if (this.rdw[2] != 0 && ret != null) {
/* 136 */       byte[] t = ret;
/* 137 */       this.subLines.clear();
/*     */       while (true) {
/* 139 */         this.subLines.add(t);
/* 140 */         t = readLinePart();
/* 141 */         if (this.rdw[2] == 0) {
/* 142 */           this.nextRecord = t;
/* 143 */           return join(this.subLines);
/*     */         } 
/*     */         
/* 146 */         if (this.rdw[2] == 2) {
/* 147 */           this.subLines.add(t);
/* 148 */           ret = join(this.subLines); break;
/*     */         } 
/*     */       } 
/* 151 */     }  return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final byte[] join(ArrayList<byte[]> lineParts) {
/* 163 */     int len = 0;
/*     */     
/* 165 */     for (byte[] b : lineParts) {
/* 166 */       len += b.length;
/*     */     }
/*     */     
/* 169 */     byte[] ret = new byte[len];
/* 170 */     int pos = 0;
/*     */     
/* 172 */     for (byte[] b : lineParts) {
/* 173 */       System.arraycopy(b, 0, ret, pos, b.length);
/* 174 */       pos += b.length;
/*     */     } 
/*     */     
/* 177 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] readLinePart() throws IOException {
/* 186 */     byte[] ret = null;
/* 187 */     if (readBuffer(this.stream, this.rdw) > 0) {
/* 188 */       int lineLength = ((this.rdw[0] & 0xFF) << 8) + (this.rdw[1] & 0xFF) - this.rdwAdjust;
/* 189 */       if (this.rdw[2] < 0 || this.rdw[2] > 3 || this.rdw[3] != 0)
/*     */       {
/* 191 */         throw new IOException("Invalid Record Descriptor word at line " + this.lineNumber + " " + lineLength + "\tRDW=" + this.rdw[2] + ", " + this.rdw[3]);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 197 */       if (lineLength < 0) {
/* 198 */         throw new IOException("Invalid Line Length: " + lineLength + " For line " + this.lineNumber);
/*     */       }
/* 200 */       byte[] inBytes = new byte[lineLength];
/*     */       
/* 202 */       if (readBuffer(this.stream, inBytes) >= 0) {
/* 203 */         ret = inBytes;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 247 */     this.inStream.close();
/* 248 */     this.stream = null;
/*     */   }
/*     */ }

