package com.MainFrame.Reader.ByteIO;

import java.io.IOException;

public interface IByteRecordReader {
  byte[] read() throws IOException;
  
  void close() throws IOException;
}

