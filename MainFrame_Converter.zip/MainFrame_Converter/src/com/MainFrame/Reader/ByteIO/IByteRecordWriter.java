package com.MainFrame.Reader.ByteIO;

import java.io.IOException;

public interface IByteRecordWriter {
  void write(byte[] paramArrayOfbyte) throws IOException;
  
  void close() throws IOException;
}

