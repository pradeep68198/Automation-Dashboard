/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FujitsuVbByteReader
/*     */   extends AbstractByteReader
/*     */ {
/*     */   private InputStream inStream;
/*  57 */   private BufferedInputStream stream = null;
/*     */   
/*  59 */   private int lineNumber = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private byte[] rdw = new byte[4];
/*  67 */   private byte[] rdwLength = new byte[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FujitsuVbByteReader() {
/*  77 */     this.rdwLength[0] = 0;
/*  78 */     this.rdwLength[1] = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(InputStream inputStream) {
/*  87 */     this.inStream = inputStream;
/*     */     
/*  89 */     if (inputStream instanceof BufferedInputStream) {
/*  90 */       this.stream = (BufferedInputStream)inputStream;
/*     */     } else {
/*  92 */       this.stream = new BufferedInputStream(inputStream, 16384);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] read() throws IOException {
/* 102 */     byte[] ret = null;
/*     */     
/* 104 */     if (this.stream == null) {
/* 105 */       throw new IOException("File has not been opened");
/*     */     }
/*     */     
/* 108 */     this.lineNumber++;
/* 109 */     if (readBuffer(this.stream, this.rdw) > 0) {
/* 110 */       if (this.rdw[2] != 0 || this.rdw[3] != 0) {
/* 111 */         throw new IOException("Invalid Record Descriptor word at line " + this.lineNumber);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 117 */       this.rdwLength[2] = this.rdw[1];
/* 118 */       this.rdwLength[3] = this.rdw[0];
/*     */       
/* 120 */       int lineLength = (new BigInteger(this.rdwLength)).intValue();
/* 121 */       byte[] inBytes = new byte[lineLength];
/*     */       
/* 123 */       if (readBuffer(this.stream, inBytes) > 0) {
/* 124 */         ret = inBytes;
/*     */         
/* 126 */         if (readBuffer(this.stream, this.rdw) < this.rdw.length) {
/* 127 */           throw new IOException("Line missing End of line length");
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 132 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 140 */     this.inStream.close();
/* 141 */     this.stream.close();
/* 142 */     this.stream = null;
/*     */   }
/*     */ }

