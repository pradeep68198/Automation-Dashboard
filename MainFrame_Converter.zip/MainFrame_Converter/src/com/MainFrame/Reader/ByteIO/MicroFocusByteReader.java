/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.math.BigInteger;
public class MicroFocusByteReader extends AbstractByteReader
{
    private MicroFocusFileHeader headerRecord;
    private BufferedInputStream instream;
    private boolean eof;
    private byte[] relativeAttr;
    private int lineNumber;
    byte[] len1;
    
    public MicroFocusByteReader() {
        this.eof = true;
        this.relativeAttr = new byte[2];
        this.lineNumber = 1;
    }
    
    public void open(final InputStream inputStream) throws IOException {
        this.instream = new BufferedInputStream(inputStream, 8192);
        final byte[] headerRec = new byte[128];
        final int ii = this.readBuffer((InputStream)this.instream, headerRec);
        if (!(this.eof = (ii <= 0))) {
            this.headerRecord = new MicroFocusFileHeader(headerRec);
            if (this.headerRecord.getCompression() > 0) {
                throw new IOException("Compression is not supported");
            }
            if (this.headerRecord.getMaxLength() < 4095) {
                this.len1 = new byte[2];
            }
            else {
                this.len1 = new byte[4];
            }
        }
    }
    
    public byte[] read() throws IOException {
        boolean readnext = true;
        while (!this.eof && this.readBuffer((InputStream)this.instream, this.len1) > 0) {
            final int tmp = this.len1[0];
            final int attr = (tmp & 0xF0) >> 4;
            this.len1[0] = (byte)(tmp & 0xF);
            final int len = new BigInteger(this.len1).intValue();
            readnext = (attr != 4 && attr != 5 && attr != 7 && attr != 8);
            if (len > 1000000) {
                throw new IOException("Record Length to Big: " + len + " record number: " + this.lineNumber);
            }
            final byte[] rec = new byte[len];
            final int bytesRead;
            if ((bytesRead = this.readBuffer((InputStream)this.instream, rec)) < len) {
                throw new IOException("Length of Record (" + bytesRead + ") < Expected (" + len + ") record number: " + this.lineNumber);
            }
            switch (this.headerRecord.getFileFormat()) {
                case 1:
                case 2: {
                    final int remainder = len % 4;
                    if (remainder != 0) {
                        this.readBuffer((InputStream)this.instream, new byte[4 - remainder]);
                        break;
                    }
                    break;
                }
                case 3: {
                    if (len < this.headerRecord.getMaxLength()) {
                        this.readBuffer((InputStream)this.instream, new byte[this.headerRecord.getMaxLength() - len]);
                    }
                    this.readBuffer((InputStream)this.instream, this.relativeAttr);
                    readnext |= (this.relativeAttr[0] == 13 && this.relativeAttr[1] == 10);
                    break;
                }
            }
            if (!readnext) {
                ++this.lineNumber;
                return rec;
            }
        }
        this.eof = true;
        return null;
    }
    
    public void close() throws IOException {
        this.instream.close();
    }
    
    public MicroFocusFileHeader getHeaderRecord() {
        return this.headerRecord;
    }
    
    public boolean canWrite() {
        return this.headerRecord == null || this.headerRecord.getFileFormat() == 1;
    }
}