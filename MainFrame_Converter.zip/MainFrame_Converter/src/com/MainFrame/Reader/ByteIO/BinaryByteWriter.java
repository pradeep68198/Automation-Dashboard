/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryByteWriter
/*     */   extends AbstractByteWriter
/*     */ {
/*  47 */   private OutputStream outStream = null;
/*     */   
/*     */   private boolean addLength = false;
/*  50 */   private byte[] rdw = new byte[4];
/*  51 */   private byte[] eol = null;
/*     */   
/*  53 */   private int rdwAdjust = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BinaryByteWriter() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BinaryByteWriter(boolean includeRDW, boolean addRdwToLength, byte[] eolByte) {
/*  90 */     this.addLength = includeRDW;
/*  91 */     this.eol = eolByte;
/*  92 */     this.rdw[2] = 0;
/*  93 */     this.rdw[3] = 0;
/*     */     
/*  95 */     if (!addRdwToLength) {
/*  96 */       this.rdwAdjust = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(OutputStream outputStream) throws IOException {
/* 106 */     this.outStream = outputStream;
/* 107 */     if (!(outputStream instanceof BufferedOutputStream)) {
/* 108 */       this.outStream = new BufferedOutputStream(outputStream, 16384);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] line) throws IOException {
/* 118 */     if (this.outStream == null) {
/* 119 */       throw new IOException("File has not been opened");
/*     */     }
/* 121 */     byte[] rec = line;
/*     */     
/* 123 */     if (this.addLength) {
/* 124 */       byte[] bytes = BigInteger.valueOf((rec.length + this.rdwAdjust)).toByteArray();
/*     */       
/* 126 */       this.rdw[1] = bytes[bytes.length - 1];
/* 127 */       this.rdw[0] = 0;
/* 128 */       if (bytes.length > 1) {
/* 129 */         this.rdw[0] = bytes[bytes.length - 2];
/*     */       }
/* 131 */       this.outStream.write(this.rdw);
/*     */     } 
/*     */     
/* 134 */     this.outStream.write(rec);
/*     */     
/* 136 */     if (this.eol != null) {
/* 137 */       this.outStream.write(this.eol);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 147 */     this.outStream.close();
/* 148 */     this.outStream = null;
/*     */   }
/*     */ }
