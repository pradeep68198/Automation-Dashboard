/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FujitsuVbByteWriter
/*     */   extends AbstractByteWriter
/*     */ {
/*  61 */   private OutputStream outStream = null;
/*     */ 
/*     */   
/*  64 */   private byte[] rdw = new byte[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(OutputStream outputStream) throws IOException {
/*  73 */     this.outStream = outputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] rec) throws IOException {
/*  83 */     if (this.outStream == null) {
/*  84 */       throw new IOException("File has not been opened");
/*     */     }
/*     */     
/*  87 */     updateRDW(rec.length, this.rdw);
/*     */     
/*  89 */     this.outStream.write(this.rdw);
/*  90 */     this.outStream.write(rec);
/*  91 */     this.outStream.write(this.rdw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateRDW(int length, byte[] word) {
/* 102 */     byte[] bytes = BigInteger.valueOf(length).toByteArray();
/*     */ 
/*     */     
/*     */     int i;
/*     */     
/* 107 */     for (i = 3; i >= bytes.length; i--) {
/* 108 */       word[i] = 0;
/*     */     }
/*     */     int j;
/* 111 */     for (i = bytes.length - 1, j = 0; i >= 0; i--, j++) {
/* 112 */       word[i] = bytes[j];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 121 */     this.outStream.close();
/* 122 */     this.outStream = null;
/*     */   }
/*     */ }

