/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VbByteReader
/*     */   extends AbstractByteReader
/*     */ {
/*     */   private static final int LAST_7_BITS_SET = 127;
/*     */   public static final int MODE_NO_BLOCK_LENGTH = 0;
/*     */   public static final int MODE_ORIG_BLOCK_LENGTH = 1;
/*     */   public static final int MODE_BLOCK_LENGTH_2 = 2;
/*     */   private InputStream inStream;
/*  65 */   private BufferedInputStream stream = null;
/*     */   
/*  67 */   private int lineNumber = 0;
/*  68 */   private int rdwAdjust = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   private byte[] rdw = new byte[4];
/*     */ 
/*     */ 
/*     */   
/*  80 */   private int blockMode = 0;
/*  81 */   private byte[] bdw = new byte[4];
/*     */ 
/*     */ 
/*     */   
/*  85 */   private int blockLength = -1;
/*  86 */   private int bytesReadFromBlock = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VbByteReader() {
/*  96 */     this(0, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VbByteReader(boolean includesBlockLength) {
/* 109 */     this(includesBlockLength, true);
/*     */   }
/*     */   
/*     */   public VbByteReader(boolean includesBlockLength, boolean lengthIncludesRDW) {
/* 113 */     this(includesBlockLength ? 1 : 0, lengthIncludesRDW);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public VbByteReader(int includesBlockLength, boolean lengthIncludesRDW) {
/* 119 */     this.blockMode = includesBlockLength;
/* 120 */     if (lengthIncludesRDW) {
/* 121 */       this.rdwAdjust = 4;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(InputStream inputStream) {
/* 130 */     this.inStream = inputStream;
/*     */     
/* 132 */     if (inputStream instanceof BufferedInputStream) {
/* 133 */       this.stream = (BufferedInputStream)inputStream;
/*     */     } else {
/* 135 */       this.stream = new BufferedInputStream(inputStream, 16384);
/*     */     } 
/*     */     
/* 138 */     checkForBlockLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] read() throws IOException {
/* 146 */     byte[] ret = null;
/*     */     
/* 148 */     if (this.stream == null) {
/* 149 */       throw new IOException("File has not been opened");
/*     */     }
/*     */     
/* 152 */     checkForBlockLength();
/*     */     
/* 154 */     this.lineNumber++;
/* 155 */     if (readBuffer(this.stream, this.rdw) > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 160 */       int lineLength = ((this.rdw[0] & 0xFF) << 8) + (this.rdw[1] & 0xFF) - this.rdwAdjust;
/* 161 */       if (this.rdw[2] != 0 || this.rdw[3] != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 167 */         byte[] b = new byte[256];
/* 168 */         readBuffer(this.stream, b);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 180 */         throw new IOException("Invalid Record Descriptor word at line " + this.lineNumber + " " + lineLength + "\t" + this.rdw[2] + " " + this.rdw[3]);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 186 */       if (lineLength < 0) {
/* 187 */         throw new IOException("Invalid Line Length: " + lineLength + " For line " + this.lineNumber);
/*     */       }
/* 189 */       byte[] inBytes = new byte[lineLength];
/*     */       
/* 191 */       if (readBuffer(this.stream, inBytes) >= 0) {
/* 192 */         ret = inBytes;
/*     */         
/* 194 */         if (this.blockMode > 0) {
/* 195 */           this.bytesReadFromBlock += lineLength + 4;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 200 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkForBlockLength() {
/* 209 */     if (this.blockMode > 0 && this.bytesReadFromBlock >= this.blockLength) {
/*     */       try {
/* 211 */         this.bytesReadFromBlock = 4;
/* 212 */         if (readBuffer(this.stream, this.bdw) > 0) {
/* 213 */           if (this.bdw[0] >= 0 || this.blockMode == 2)
/*     */           {
/*     */ 
/*     */ 
/*     */             
/* 218 */             this.blockLength = ((this.bdw[0] & 0xFF) << 8) + (this.bdw[1] & 0xFF);
/*     */           
/*     */           }
/*     */           else
/*     */           {
/*     */             
/* 224 */             this.bdw[0] = (byte)(this.bdw[0] & Byte.MAX_VALUE);
/* 225 */             this.blockLength = ((this.bdw[0] & 0xFF) << 24) + ((this.bdw[1] & 0xFF) << 16) + ((this.bdw[2] & 0xFF) << 8) + (this.bdw[3] & 0xFF);
/*     */           
/*     */           }
/*     */ 
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 233 */       catch (Exception e) {
/* 234 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 244 */     this.inStream.close();
/* 245 */     this.stream = null;
/*     */   }
/*     */ }
