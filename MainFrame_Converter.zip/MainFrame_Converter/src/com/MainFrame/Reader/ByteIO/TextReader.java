/*    */ package com.MainFrame.Reader.ByteIO;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import com.MainFrame.Reader.Common.Conversion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextReader
/*    */   extends AbstractByteReader
/*    */ {
/*    */   private InputStream inStream;
/*    */   private InputStreamReader stdReader;
/*    */   private String font;
/* 40 */   private BufferedReader reader = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TextReader(String font) {
/* 47 */     this.font = font;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void open(InputStream inputStream) throws IOException {
/* 53 */     this.inStream = inputStream;
/*    */     
/* 55 */     if (this.font == null || "".equals(this.font)) {
/* 56 */       this.stdReader = new InputStreamReader(inputStream);
/*    */     } else {
/*    */       try {
/* 59 */         this.stdReader = new InputStreamReader(inputStream, this.font);
/* 60 */       } catch (Exception e) {
/* 61 */         this.stdReader = new InputStreamReader(inputStream);
/*    */       } 
/*    */     } 
/* 64 */     this.reader = new BufferedReader(this.stdReader);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] read() throws IOException {
/* 70 */     return Conversion.getBytes(this.reader.readLine(), this.font);
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 75 */     this.stdReader.close();
/* 76 */     this.inStream.close();
/*    */   }
/*    */ }

