/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import com.MainFrame.Reader.Common.IBasicFileSchema;
/*     */ import com.MainFrame.Reader.Common.RecordException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteIOProvider
/*     */ {
/*  59 */   private static ByteIOProvider ioProvider = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_RECORD_LENGTH = 80;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractByteReader getByteReader(int fileStructure) {
/*  74 */     return getByteReader(fileStructure, 80);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractByteReader getByteReader(IBasicFileSchema schema) {
/*  84 */     int fileStructure = schema.getFileStructure();
/*  85 */     switch (fileStructure) {
/*     */       case 9:
/*     */       case 37:
/*  88 */         return new ByteTextReader(schema.getFontName());
/*     */     } 
/*  90 */     return getByteReader(fileStructure, schema.getMaximumRecordLength());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractByteReader getByteReader(int fileStructure, int length) {
/* 105 */     switch (fileStructure) { case 2:
/*     */       case 35:
/* 107 */         return new FixedLengthByteReader(length);
/* 108 */       case 12: return new VbsByteReader(false, true);
/* 109 */       case 4: return new VbByteReader(0, true);
/* 110 */       case 5: return new VbDumpByteReader();
/* 111 */       case 14: return new VbByteReader(2, true);
/* 112 */       case 7: return new FujitsuVbByteReader();
/* 113 */       case 8: return new VbByteReader(0, false);
/*     */       case 9: case 37:
/* 115 */         return new ByteTextReader();
/* 116 */       case 31: return new MicroFocusByteReader(); }
/*     */     
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractByteWriter getByteWriter(int fileStructure) {
/* 130 */     return getByteWriter(fileStructure, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractByteWriter getByteWriter(IBasicFileSchema schema) {
/* 139 */     int fileStructure = schema.getFileStructure();
/* 140 */     switch (fileStructure) { case 2:
/* 141 */         return new FixedLengthByteWriter(schema.getMaximumRecordLength()); }
/*     */     
/* 143 */     return getByteWriter(fileStructure, schema.getFontName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractByteWriter getByteWriter(int fileStructure, String characterSet) {
/* 157 */     switch (fileStructure) {
/*     */       case 12:
/* 159 */         throw new RecordException("Writing VBS files is not supported; use IO_VB");
/* 160 */       case 4: return new VbByteWriter();
/*     */       case 5: case 14:
/* 162 */         return new VbDumpByteWriter();
/* 163 */       case 7: return new FujitsuVbByteWriter();
/* 164 */       case 8: return new VbByteWriter(false);
/*     */       case 9:
/* 166 */         if (characterSet != null && characterSet.length() > 0) {
/*     */           try {
/* 168 */             return new ByteTextWriter("\n".getBytes(characterSet));
/* 169 */           } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */         }
/*     */         
/* 172 */         return new ByteTextWriter();
/*     */     } 
/*     */ 
/*     */     
/* 176 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteIOProvider getInstance() {
/* 185 */     if (ioProvider == null) {
/* 186 */       ioProvider = new ByteIOProvider();
/*     */     }
/*     */     
/* 189 */     return ioProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setInstance(ByteIOProvider newProvider) {
/* 197 */     ioProvider = newProvider;
/*     */   }
/*     */ }
