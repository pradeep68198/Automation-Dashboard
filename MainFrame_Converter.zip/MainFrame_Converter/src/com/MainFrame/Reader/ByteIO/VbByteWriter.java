/*    */ package com.MainFrame.Reader.ByteIO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VbByteWriter
/*    */   extends BinaryByteWriter
/*    */ {
/*    */   public VbByteWriter() {
/* 57 */     super(true, true, null);
/*    */   }
/*    */   
/*    */   public VbByteWriter(boolean addRdwToLength) {
/* 61 */     super(true, addRdwToLength, null);
/*    */   }
/*    */ }
