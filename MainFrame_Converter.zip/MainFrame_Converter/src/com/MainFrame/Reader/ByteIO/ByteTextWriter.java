/*    */ package com.MainFrame.Reader.ByteIO;
/*    */ 
/*    */ import com.MainFrame.Reader.Common.Constants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteTextWriter
/*    */   extends BinaryByteWriter
/*    */ {
/*    */   public ByteTextWriter() {
/* 43 */     super(false, false, Constants.SYSTEM_EOL_BYTES);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteTextWriter(String eol) {
/* 51 */     super(false, false, eol.getBytes());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteTextWriter(byte[] eol) {
/* 59 */     super(false, false, eol);
/*    */   }
/*    */ }
