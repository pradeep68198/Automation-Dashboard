/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FixedLengthByteWriter
/*     */   extends AbstractByteWriter
/*     */ {
/*  46 */   private OutputStream outStream = null;
/*     */   
/*     */   private final int recordLength;
/*     */   private final int fillByte;
/*     */   
/*     */   public FixedLengthByteWriter(int recordLength) {
/*  52 */     this.recordLength = recordLength;
/*  53 */     this.fillByte = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FixedLengthByteWriter(int recordLength, int fillByte) {
/*  76 */     this.recordLength = recordLength;
/*  77 */     this.fillByte = fillByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(OutputStream outputStream) throws IOException {
/*  87 */     this.outStream = outputStream;
/*  88 */     if (!(outputStream instanceof BufferedOutputStream)) {
/*  89 */       this.outStream = new BufferedOutputStream(outputStream, 16384);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] rec) throws IOException {
/*  99 */     if (this.outStream == null) {
/* 100 */       throw new IOException("File has not been opened");
/*     */     }
/*     */ 
/*     */     
/* 104 */     if (rec.length != this.recordLength) {
/* 105 */       if (rec.length > this.recordLength) {
/* 106 */         this.outStream.write(rec, 0, this.recordLength);
/*     */       } else {
/* 108 */         this.outStream.write(rec);
/* 109 */         for (int i = this.recordLength - rec.length; i > 0; i--) {
/* 110 */           this.outStream.write(this.fillByte);
/*     */         }
/*     */       } 
/*     */     } else {
/* 114 */       this.outStream.write(rec);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 124 */     this.outStream.close();
/* 125 */     this.outStream = null;
/*     */   }
/*     */ }
