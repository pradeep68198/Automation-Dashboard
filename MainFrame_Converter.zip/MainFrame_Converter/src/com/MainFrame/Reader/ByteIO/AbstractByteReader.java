/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractByteReader
/*     */   implements IByteReader
/*     */ {
/*     */   public static final String NOT_OPEN_MESSAGE = "File has not been opened";
/*     */   public static final int BUFFER_SIZE = 16384;
/*  52 */   private long bytesRead = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(String fileName) throws IOException {
/*  69 */     open(new FileInputStream(fileName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int readBuffer(InputStream in, byte[] buf) throws IOException {
/*  88 */     return readBuffer(in, buf, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int readBuffer(InputStream in, byte[] buf, int inTotal) throws IOException {
/* 106 */     int total = inTotal;
/* 107 */     int num = in.read(buf, total, buf.length - total);
/*     */     
/* 109 */     while (num >= 0 && total + num < buf.length) {
/* 110 */       total += num;
/* 111 */       num = in.read(buf, total, buf.length - total);
/*     */     } 
/*     */     
/* 114 */     if (num > 0) {
/* 115 */       total += num;
/*     */     }
/*     */     
/* 118 */     incBytesRead((total - inTotal));
/*     */     
/* 120 */     return total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineLength(int lineLength) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/* 136 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getBytesRead() {
/* 145 */     return this.bytesRead;
/*     */   }
/*     */   
/*     */   protected final void incBytesRead(long amount) {
/* 149 */     this.bytesRead += amount;
/*     */   }
/*     */ }
