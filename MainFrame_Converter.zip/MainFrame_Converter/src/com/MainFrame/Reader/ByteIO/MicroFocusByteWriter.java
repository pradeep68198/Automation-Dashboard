/*    */ package com.MainFrame.Reader.ByteIO;
/*    */ 
/*    */ import java.io.BufferedOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import com.MainFrame.Reader.Common.Conversion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MicroFocusByteWriter
/*    */   extends AbstractByteWriter
/*    */ {
/* 36 */   private MicroFocusFileHeader header = null;
/* 37 */   private OutputStream outStream = null;
/*    */ 
/*    */   
/*    */   private byte[] len;
/*    */ 
/*    */   
/*    */   public void open(OutputStream outputStream) throws IOException {
/* 44 */     this.outStream = new BufferedOutputStream(outputStream, 8192);
/*    */   }
/*    */   
/*    */   public void writeHeader(MicroFocusFileHeader fileHeader) throws IOException {
/* 48 */     this.header = fileHeader;
/* 49 */     this.outStream.write(this.header.getHeaderRec());
/*    */     
/* 51 */     if (this.header.getMaxLength() < 4095) {
/* 52 */       this.len = new byte[2];
/*    */     } else {
/* 54 */       this.len = new byte[4];
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(byte[] bytes) throws IOException {
/* 62 */     if (this.header == null) {
/* 63 */       throw new IOException("Microfocus Header has not been written");
/*    */     }
/*    */     
/* 66 */     if (bytes.length > this.header.getMaxLength()) {
/* 67 */       throw new IOException("Record Length is greater than that specified");
/*    */     }
/*    */     try {
/* 70 */       if (this.header.getMaxLength() < 4095) {
/* 71 */         Conversion.setLong(this.len, 0, 2, bytes.length, true);
/*    */       } else {
/* 73 */         Conversion.setLong(this.len, 0, 4, bytes.length, true);
/*    */       } 
/* 75 */     } catch (Exception e) {
/* 76 */       e.printStackTrace();
/* 77 */       throw new IOException("Error Setting Microfocus Record Length");
/*    */     } 
/*    */ 
/*    */     
/* 81 */     int tmp = this.len[0];
/* 82 */     tmp |= 0x40;
/*    */     
/* 84 */     this.len[0] = (byte)tmp;
/*    */     
/* 86 */     this.outStream.write(this.len);
/* 87 */     this.outStream.write(bytes);
/*    */     
/* 89 */     int remainder = bytes.length % 4;
/*    */     
/* 91 */     if (remainder != 0) {
/* 92 */       this.outStream.write(new byte[4 - remainder]);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 98 */     this.header = null;
/* 99 */     this.outStream.close();
/*    */   }
/*    */ }
