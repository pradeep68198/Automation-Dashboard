/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ import com.MainFrame.Reader.Common.CommonBits;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsvByteReader
/*     */   extends BaseByteTextReader
/*     */ {
/*     */   private final byte[] fieldSep;
/*     */   private final byte[] quote;
/*     */   private final byte[] quoteEsc;
/*     */   private final byte[] sepQuote;
/*     */   private final byte[] quoteSep;
/*  49 */   private byte[] quoteEol = EMPTY;
/*  50 */   private byte[] quoteEol2 = EMPTY;
/*     */   
/*     */   private boolean useStdEolCheck;
/*     */ 
/*     */   
/*     */   public CsvByteReader(String charSet, byte[] fieldSep, byte[] quote, String quoteEsc, boolean useStdEolCheck) {
/*  56 */     this((byte[])null, fieldSep, quote, 
/*     */ 
/*     */         
/*  59 */         Conversion.getBytes(quoteEsc, charSet), useStdEolCheck);
/*     */ 
/*     */     
/*  62 */     setLfCr(charSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public CsvByteReader(byte[] eol, byte[] fieldSep, byte[] quote, byte[] quoteEsc, boolean useStdEolCheck) {
/*  67 */     setEol(eol);
/*  68 */     this.fieldSep = fieldSep;
/*  69 */     this.quoteEsc = (quoteEsc == null) ? EMPTY : quoteEsc;
/*  70 */     this.useStdEolCheck = useStdEolCheck;
/*     */     
/*  72 */     if (quote == null || quote.length == 0) {
/*  73 */       this.quote = EMPTY;
/*  74 */       this.sepQuote = EMPTY;
/*  75 */       this.quoteSep = EMPTY;
/*     */     } else {
/*  77 */       this.quote = quote;
/*  78 */       this.sepQuote = new byte[fieldSep.length + quote.length];
/*  79 */       this.quoteSep = new byte[this.sepQuote.length];
/*     */       
/*  81 */       System.arraycopy(fieldSep, 0, this.sepQuote, 0, fieldSep.length);
/*  82 */       System.arraycopy(quote, 0, this.sepQuote, fieldSep.length, quote.length);
/*     */       
/*  84 */       System.arraycopy(quote, 0, this.quoteSep, 0, quote.length);
/*  85 */       System.arraycopy(fieldSep, 0, this.quoteSep, quote.length, fieldSep.length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getEolPosition() {
/* 105 */     if (!this.useStdEolCheck) {
/* 106 */       BaseByteTextReader.FindLines eolSearch; byte[] qEol1 = new byte[this.quote.length + 1];
/* 107 */       byte[] qEol2 = new byte[this.quote.length + 1];
/* 108 */       byte[] qEol3 = new byte[this.quote.length + this.lfcrBytes.length];
/*     */       
/* 110 */       SearchDtls searchDtls = new SearchDtls();
/*     */       
/* 112 */       System.arraycopy(this.quote, 0, qEol1, 0, this.quote.length);
/* 113 */       System.arraycopy(this.crBytes, 0, qEol1, this.quote.length, this.crBytes.length);
/* 114 */       System.arraycopy(this.quote, 0, qEol2, 0, this.quote.length);
/* 115 */       System.arraycopy(this.lfBytes, 0, qEol2, this.quote.length, this.lfBytes.length);
/* 116 */       System.arraycopy(this.quote, 0, qEol3, 0, this.quote.length);
/* 117 */       System.arraycopy(this.lfcrBytes, 0, qEol3, this.quote.length, this.lfcrBytes.length);
/*     */ 
/*     */       
/* 120 */       if (this.quoteEsc.length == 0) {
/* 121 */         eolSearch = new NoQuoteEsc(qEol1, qEol2, qEol3, searchDtls);
/*     */       } else {
/* 123 */         eolSearch = new QuoteEsc(qEol1, qEol2, qEol3, searchDtls);
/*     */       } 
/* 125 */       eolSearch.findLinesInBuffer(0);
/*     */       
/* 127 */       if (searchDtls.noLines > 0) {
/* 128 */         return this.lineArray[0] - 1;
/*     */       }
/*     */     } 
/* 131 */     return super.getEolPosition();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLineSearch() {
/* 140 */     this.quoteEol = this.eol;
/* 141 */     this.quoteEol2 = EMPTY;
/*     */     
/* 143 */     if (this.eol.length == 0) {
/* 144 */       this.quoteEol = EMPTY;
/* 145 */     } else if (this.quote.length == 0) {
/* 146 */       this.findLines = new BaseByteTextReader.StdFindLines();
/*     */     } else {
/* 148 */       this.quoteEol = new byte[this.quote.length + this.eol.length];
/* 149 */       System.arraycopy(this.quote, 0, this.quoteEol, 0, this.quote.length);
/* 150 */       System.arraycopy(this.eol, 0, this.quoteEol, this.quote.length, this.eol.length);
/*     */ 
/*     */       
/* 153 */       if (this.check4lf) {
/* 154 */         this.quoteEol2 = new byte[this.quote.length + this.eol.length + 1];
/* 155 */         System.arraycopy(this.quote, 0, this.quoteEol2, 0, this.quote.length);
/* 156 */         this.quoteEol2[this.quote.length] = this.byteLF;
/* 157 */         System.arraycopy(this.eol, 0, this.quoteEol2, this.quote.length + 1, this.eol.length);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 168 */       if (this.quoteEsc.length == 0) {
/*     */ 
/*     */         
/* 171 */         this.findLines = new NoQuoteEsc();
/*     */       }
/*     */       else {
/*     */         
/* 175 */         this.findLines = new QuoteEsc();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean checkFor(int pos, byte[] search) {
/* 260 */     return CommonBits.checkFor(this.buffer, pos, search);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class NoQuoteEsc
/*     */     implements BaseByteTextReader.FindLines
/*     */   {
/*     */     private final byte[] quoteEol1;
/*     */ 
/*     */ 
/*     */     
/*     */     private final byte[] quoteEol2;
/*     */ 
/*     */ 
/*     */     
/*     */     private final byte[] quoteEol3;
/*     */ 
/*     */     
/*     */     private final CsvByteReader.ILineNoDtls dtls;
/*     */ 
/*     */ 
/*     */     
/*     */     public NoQuoteEsc() {
/* 285 */       this(CsvByteReader.this.quoteEol, CsvByteReader.this.quoteEol2, BaseByteTextReader.EMPTY, new CsvByteReader.StdLineNoDtls());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public NoQuoteEsc(byte[] quoteEol, byte[] quoteEol2, byte[] quoteEol3, CsvByteReader.ILineNoDtls dtls) {
/* 291 */       this.quoteEol1 = quoteEol;
/* 292 */       this.quoteEol2 = quoteEol2;
/* 293 */       this.quoteEol3 = quoteEol3;
/* 294 */       this.dtls = dtls;
/*     */     }
/*     */     
/*     */     public void findLinesInBuffer(int start) {
/* 298 */       int lineStart = start;
/* 299 */       int fieldStart = start;
/* 300 */       boolean inQuote = false;
/*     */ 
/*     */       
/* 303 */       while (this.dtls.getNoLines() < CsvByteReader.this.lineArray.length && start < CsvByteReader.this.bytesInBuffer && start >= 0) {
/* 304 */         if (CsvByteReader.this.checkFor(start, CsvByteReader.this.sepQuote) || (lineStart == start - CsvByteReader.this
/* 305 */           .quote.length + 1 && CsvByteReader.this.checkFor(start, CsvByteReader.this.quote))) {
/*     */           
/* 307 */           inQuote = true;
/* 308 */         } else if ((inQuote && fieldStart != start - CsvByteReader.this
/* 309 */           .quoteSep.length + 1 && CsvByteReader.this
/* 310 */           .checkFor(start, CsvByteReader.this.quoteSep)) || (!inQuote && CsvByteReader.this
/* 311 */           .checkFor(start, CsvByteReader.this.fieldSep))) {
/* 312 */           fieldStart = start + 1;
/* 313 */           inQuote = false;
/* 314 */         } else if ((CsvByteReader.this.checkFor(start, this.quoteEol1) && fieldStart != start - this.quoteEol1.length + 1) || (CsvByteReader.this
/* 315 */           .checkFor(start, this.quoteEol2) && fieldStart != start - this.quoteEol2.length + 1) || (CsvByteReader.this
/* 316 */           .checkFor(start, this.quoteEol3) && fieldStart != start - this.quoteEol3.length + 1) || (!inQuote && this.dtls
/* 317 */           .isEol(start))) {
/* 318 */           lineStart = start + 1;
/* 319 */           fieldStart = lineStart;
/* 320 */           CsvByteReader.this.lineArray[this.dtls.getNoLines()] = lineStart;
/* 321 */           this.dtls.incNoLines();
/* 322 */           inQuote = false;
/* 323 */         } else if (CsvByteReader.this.check4cr && CsvByteReader.this.buffer[start] == CsvByteReader.this.byteCR && lineStart == start) {
/*     */           
/* 325 */           fieldStart = ++lineStart;
/*     */         } 
/*     */         
/* 328 */         start++;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private class QuoteEsc
/*     */     implements BaseByteTextReader.FindLines
/*     */   {
/*     */     private final byte[] quoteEol1;
/*     */     private final byte[] quoteEol2;
/*     */     private final byte[] quoteEol3;
/*     */     private final CsvByteReader.ILineNoDtls dtls;
/*     */     
/*     */     public QuoteEsc() {
/* 342 */       this(CsvByteReader.this.quoteEol, CsvByteReader.this.quoteEol2, BaseByteTextReader.EMPTY, new CsvByteReader.StdLineNoDtls());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public QuoteEsc(byte[] quoteEol, byte[] quoteEol2, byte[] quoteEol3, CsvByteReader.ILineNoDtls dtls) {
/* 348 */       this.quoteEol1 = quoteEol;
/* 349 */       this.quoteEol2 = quoteEol2;
/* 350 */       this.quoteEol3 = quoteEol3;
/* 351 */       this.dtls = dtls;
/*     */     }
/*     */     
/*     */     public void findLinesInBuffer(int start) {
/* 355 */       int lineStart = start;
/* 356 */       int fieldStart = start;
/* 357 */       boolean inQuote = false;
/*     */       
/* 359 */       int quoteEscPos = -121;
/*     */       
/* 361 */       while (this.dtls.getNoLines() < CsvByteReader.this.lineArray.length && start < CsvByteReader.this.bytesInBuffer && start >= 0) {
/* 362 */         if (CsvByteReader.this.checkFor(start, CsvByteReader.this.sepQuote) || (lineStart == start - CsvByteReader.this
/* 363 */           .quote.length + 1 && CsvByteReader.this.checkFor(start, CsvByteReader.this.quote))) {
/* 364 */           inQuote = true;
/* 365 */         } else if (!this.dtls.isQuoteEscEol(quoteEscPos, start) && (quoteEscPos < start - CsvByteReader.this
/* 366 */           .fieldSep.length || 
/* 367 */           !CsvByteReader.this.checkFor(start, CsvByteReader.this.fieldSep)) && (quoteEscPos <= start - CsvByteReader.this
/* 368 */           .quoteEsc.length || 
/* 369 */           !CsvByteReader.this.checkFor(start, CsvByteReader.this.quote))) {
/*     */           
/* 371 */           if (inQuote && fieldStart <= start - CsvByteReader.this
/* 372 */             .quoteEsc.length - CsvByteReader.this.quote.length + 1 && CsvByteReader.this
/* 373 */             .checkFor(start, CsvByteReader.this.quoteEsc)) {
/*     */ 
/*     */ 
/*     */             
/* 377 */             quoteEscPos = start;
/* 378 */           } else if ((inQuote && CsvByteReader.this.checkFor(start, CsvByteReader.this.quoteSep) && fieldStart != start - CsvByteReader.this.quoteSep.length + 1) || (!inQuote && CsvByteReader.this
/* 379 */             .checkFor(start, CsvByteReader.this.fieldSep))) {
/* 380 */             fieldStart = start + 1;
/* 381 */             inQuote = false;
/* 382 */           } else if ((CsvByteReader.this.checkFor(start, this.quoteEol1) && fieldStart != start - this.quoteEol1.length + 1) || (CsvByteReader.this
/* 383 */             .checkFor(start, this.quoteEol2) && fieldStart != start - this.quoteEol2.length + 1) || (CsvByteReader.this
/* 384 */             .checkFor(start, this.quoteEol3) && fieldStart != start - this.quoteEol3.length + 1) || (!inQuote && this.dtls
/* 385 */             .isEol(start))) {
/* 386 */             lineStart = start + 1;
/* 387 */             fieldStart = lineStart;
/* 388 */             CsvByteReader.this.lineArray[this.dtls.getNoLines()] = lineStart;
/* 389 */             this.dtls.incNoLines();
/* 390 */             inQuote = false;
/* 391 */           } else if (CsvByteReader.this.check4cr && CsvByteReader.this.buffer[start] == CsvByteReader.this.byteCR && lineStart == start) {
/* 392 */             lineStart++;
/* 393 */             fieldStart++;
/*     */           } 
/*     */         } 
/* 396 */         start++;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static interface ILineNoDtls
/*     */   {
/*     */     int getNoLines();
/*     */     
/*     */     void incNoLines();
/*     */     
/*     */     boolean isQuoteEscEol(int param1Int1, int param1Int2);
/*     */     
/*     */     boolean isEol(int param1Int);
/*     */   }
/*     */   
/*     */   private class StdLineNoDtls
/*     */     implements ILineNoDtls
/*     */   {
/*     */     private StdLineNoDtls() {}
/*     */     
/*     */     public int getNoLines() {
/* 419 */       return CsvByteReader.this.noLines;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void incNoLines() {
/* 427 */       CsvByteReader.this.noLines++;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isQuoteEscEol(int quoteEscPos, int start) {
/* 439 */       return (quoteEscPos == start - CsvByteReader.this.eol.length && CsvByteReader.this
/* 440 */         .checkFor(start, CsvByteReader.this.eol));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEol(int start) {
/* 446 */       return CsvByteReader.this.checkFor(start, CsvByteReader.this.eol);
/*     */     }
/*     */   }
/*     */   
/*     */   private class SearchDtls
/*     */     implements ILineNoDtls {
/* 452 */     int noLines = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getNoLines() {
/* 459 */       return this.noLines;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void incNoLines() {
/* 467 */       this.noLines++;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isQuoteEscEol(int quoteEscPos, int start) {
/* 475 */       return ((quoteEscPos == start - CsvByteReader.this.lfBytes.length && (CsvByteReader.this
/* 476 */         .checkFor(start, CsvByteReader.this.lfBytes) || CsvByteReader.this.checkFor(start, CsvByteReader.this.crBytes))) || (quoteEscPos == start - CsvByteReader.this.lfcrBytes.length && CsvByteReader.this
/* 477 */         .checkFor(start, CsvByteReader.this.lfcrBytes)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEol(int start) {
/* 484 */       return (CsvByteReader.this.checkFor(start, CsvByteReader.this.lfBytes) || CsvByteReader.this
/* 485 */         .checkFor(start, CsvByteReader.this.crBytes));
/*     */     }
/*     */     
/*     */     private SearchDtls() {}
/*     */   }
/*     */ }