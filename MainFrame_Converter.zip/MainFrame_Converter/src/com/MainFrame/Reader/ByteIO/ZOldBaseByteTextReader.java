/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import com.MainFrame.Reader.Common.Constants;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ZOldBaseByteTextReader
/*     */   extends AbstractByteReader
/*     */ {
/*  44 */   protected byte[] crBytes = Constants.CR_BYTES;
/*  45 */   protected byte[] lfBytes = Constants.LF_BYTES;
/*  46 */   protected byte[] lfcrBytes = Constants.CRLF_BYTES;
/*     */   
/*  48 */   protected byte byteLF = 10;
/*  49 */   protected byte byteCR = 13;
/*     */   
/*  51 */   protected static final byte[] EMPTY = new byte[0];
/*     */ 
/*     */ 
/*     */   
/*  55 */   private static FindLines NO_EOL_FINDLINES = new FindLines()
/*     */     {
/*     */       public void findLinesInBuffer(int start) {}
/*     */     };
/*     */ 
/*     */   
/*  61 */   private static int MAX_LINE_SIZE = 131072;
/*  62 */   private static final byte[] NO_EOL = EMPTY;
/*  63 */   protected byte[] eol = null;
/*     */ 
/*     */   
/*  66 */   protected final byte[] buffer = new byte[MAX_LINE_SIZE];
/*     */   protected int bytesInBuffer;
/*  68 */   protected final int[] lineArray = new int[16];
/*     */   protected int noLines;
/*     */   protected int lineNo;
/*  71 */   private InputStream in = null;
/*     */   private boolean eof;
/*  73 */   private long bytesRead = 0L;
/*     */   
/*     */   private boolean eofPending;
/*     */   protected boolean check4cr = false;
/*     */   protected boolean check4lf = false;
/*  78 */   protected FindLines findLines = NO_EOL_FINDLINES;
/*     */   
/*     */   public ZOldBaseByteTextReader() {
/*  81 */     this("");
/*     */   }
/*     */   
/*     */   public ZOldBaseByteTextReader(String charSet) {
/*  85 */     setLfCr(charSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public void open(InputStream inputStream) throws IOException {
/*  90 */     this.in = inputStream;
/*  91 */     this.eof = false;
/*  92 */     this.check4lf = false;
/*  93 */     this.check4cr = false;
/*     */ 
/*     */     
/*  96 */     this.bytesInBuffer = readBuffer(this.in, this.buffer);
/*  97 */     this.eofPending = (this.bytesInBuffer < this.buffer.length);
/*     */ 
/*     */     
/* 100 */     if (this.eol == null) {
/* 101 */       int eolPos = getEolPosition();
/*     */       
/* 103 */       if (eolPos >= this.bytesInBuffer) {
/* 104 */         this.eol = NO_EOL;
/* 105 */       } else if (this.buffer[eolPos] == this.byteCR) {
/* 106 */         this.eol = this.crBytes;
/* 107 */         this.check4lf = true;
/*     */       }
/* 109 */       else if (eolPos + 1 < this.bytesInBuffer && this.buffer[eolPos + 1] == this.byteCR) {
/* 110 */         this.eol = this.lfcrBytes;
/*     */       } else {
/* 112 */         this.eol = this.lfBytes;
/* 113 */         this.check4cr = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 118 */     setLineSearch();
/*     */     
/* 120 */     findLinesInBuffer(0);
/* 121 */     this.lineNo = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getEolPosition() {
/* 126 */     int pos = 0;
/* 127 */     while (pos < this.bytesInBuffer && this.buffer[pos] != this.byteCR && this.buffer[pos] != this.byteLF) {
/* 128 */       pos++;
/*     */     }
/*     */     
/* 131 */     return pos;
/*     */   }
/*     */   
/*     */   protected void setLineSearch() {
/* 135 */     if (this.eol.length > 0) {
/* 136 */       this.findLines = new StdFindLines();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] read() throws IOException {
/* 143 */     if (this.in == null) {
/* 144 */       throw new IOException("File has not been opened");
/*     */     }
/* 146 */     if (this.eof) {
/* 147 */       return null;
/*     */     }
/*     */     
/* 150 */     byte[] ret = null;
/* 151 */     int lno = getLineNo();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     int srcPos = this.lineArray[lno];
/*     */     
/* 159 */     if (this.check4cr && srcPos < this.buffer.length && this.buffer[srcPos] == this.byteCR) {
/* 160 */       srcPos++;
/* 161 */       this.bytesRead++;
/*     */     } 
/* 163 */     if (this.eof) {
/* 164 */       if (this.bytesInBuffer <= srcPos) {
/* 165 */         return null;
/*     */       }
/* 167 */       ret = new byte[this.bytesInBuffer - srcPos];
/*     */     } else {
/* 169 */       int eolLength = this.eol.length;
/* 170 */       if (this.check4lf && this.buffer[this.lineArray[lno + 1] - eolLength - 1] == this.byteLF) {
/* 171 */         eolLength++;
/*     */       }
/* 173 */       if (lno + 1 < this.lineArray.length) {
/* 174 */         ret = new byte[this.lineArray[lno + 1] - srcPos - eolLength];
/*     */       } else {
/* 176 */         ret = new byte[this.buffer.length - srcPos];
/*     */       } 
/* 178 */       this.bytesRead += eolLength;
/*     */     } 
/* 180 */     System.arraycopy(this.buffer, srcPos, ret, 0, ret.length);
/* 181 */     this.bytesRead += ret.length;
/*     */     
/* 183 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void close() throws IOException {
/* 189 */     if (this.in != null) {
/* 190 */       this.in.close();
/*     */     }
/* 192 */     this.in = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ZOldBaseByteTextReader setEol(byte[] eol) {
/* 199 */     this.eol = eol;
/* 200 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   private int getLineNo() throws IOException {
/* 205 */     this.lineNo++;
/* 206 */     if (this.lineNo == this.noLines - 1) {
/* 207 */       if (this.eofPending && this.noLines < this.lineArray.length) {
/* 208 */         this.eof = true;
/*     */       } else {
/* 210 */         findLinesInBuffer(this.lineArray[this.lineNo]);
/* 211 */         if (this.noLines == 1) {
/* 212 */           if (this.eofPending) {
/* 213 */             this.eof = true;
/*     */           } else {
/* 215 */             int len = this.bytesInBuffer - this.lineArray[this.lineNo];
/* 216 */             System.arraycopy(this.buffer, this.lineArray[this.lineNo], this.buffer, 0, len);
/*     */             
/* 218 */             this.bytesInBuffer = readBuffer(this.in, this.buffer, len);
/* 219 */             this.eofPending = (this.bytesInBuffer < this.buffer.length);
/*     */             
/* 221 */             findLinesInBuffer(0);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 227 */     return this.lineNo;
/*     */   }
/*     */   
/*     */   private void findLinesInBuffer(int start) {
/* 231 */     this.lineArray[0] = start;
/* 232 */     this.noLines = 1;
/* 233 */     this.lineNo = 0;
/* 234 */     this.findLines.findLinesInBuffer(start);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] getEol() {
/* 242 */     return this.eol;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setLfCr(String charSet) {
/* 248 */     byte[] b = Conversion.getBytes("\r\n", charSet);
/*     */     
/* 250 */     if (b[0] != this.byteLF || b[1] != this.byteCR) {
/* 251 */       this.byteLF = b[0];
/* 252 */       this.byteCR = b[1];
/*     */       
/* 254 */       this.crBytes = new byte[] { this.byteCR };
/* 255 */       this.lfBytes = new byte[] { this.byteLF };
/* 256 */       this.lfcrBytes = b;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getBytesRead() {
/* 265 */     return this.bytesRead;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static interface FindLines
/*     */   {
/*     */     void findLinesInBuffer(int param1Int);
/*     */   }
/*     */ 
/*     */   
/*     */   protected class StdFindLines
/*     */     implements FindLines
/*     */   {
/*     */     public void findLinesInBuffer(int start) {
/* 279 */       byte last = Byte.MIN_VALUE;
/* 280 */       int idx = ZOldBaseByteTextReader.this.eol.length - 1;
/*     */       
/* 282 */       while (ZOldBaseByteTextReader.this.noLines < ZOldBaseByteTextReader.this.lineArray.length && start < ZOldBaseByteTextReader.this.bytesInBuffer && start >= 0) {
/* 283 */         if (ZOldBaseByteTextReader.this.buffer[start] == ZOldBaseByteTextReader.this.eol[idx] && (ZOldBaseByteTextReader.this.eol.length == 1 || last == ZOldBaseByteTextReader.this.eol[0])) {
/* 284 */           ZOldBaseByteTextReader.this.lineArray[ZOldBaseByteTextReader.this.noLines] = start + 1;
/* 285 */           ZOldBaseByteTextReader.this.noLines++;
/*     */         } 
/*     */         
/* 288 */         last = ZOldBaseByteTextReader.this.buffer[start];
/* 289 */         start++;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }
