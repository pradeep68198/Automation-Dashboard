package com.MainFrame.Reader.ByteIO;

import java.io.IOException;
import java.io.InputStream;

public interface IByteReader extends IByteRecordReader {
  void open(String paramString) throws IOException;
  
  void open(InputStream paramInputStream) throws IOException;
  
  boolean canWrite();
  
  void setLineLength(int paramInt);
  
  long getBytesRead();
}

