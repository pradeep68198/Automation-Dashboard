/*     */ package com.MainFrame.Reader.ByteIO;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MicroFocusFileHeader
/*     */ {
/*     */   public static final int MIN_4_BYTE_LENGTH = 4095;
/*     */   public static final byte FORMAT_SEQUENTIAL = 1;
/*     */   public static final byte FORMAT_INDEXED = 2;
/*     */   public static final byte FORMAT_RELATIVE = 3;
/*     */   public static final byte RECORD_FIXED_LENGTH = 0;
/*     */   public static final byte RECORD_VARIABLE_LENGTH = 1;
/*  42 */   public static final byte[] DATE_TIME = new byte[] { 48, 48, 48, 49, 48, 49, 48, 48, 48, 48, 48, 48, 48, 48 };
/*     */   
/*     */   private final byte[] headerRec;
/*     */   
/*     */   private final int minLength;
/*     */   
/*     */   private final int maxLength;
/*     */   
/*     */   public MicroFocusFileHeader(byte[] headerRecord) {
/*  51 */     this.headerRec = headerRecord;
/*  52 */     this.maxLength = getLength(54);
/*  53 */     this.minLength = getLength(58);
/*     */   }
/*     */ 
/*     */   
/*     */   public MicroFocusFileHeader(int org, int minRecLength, int maxRecLength) {
/*  58 */     byte[] tmp = new byte[128];
/*     */ 
/*     */ 
/*     */     
/*  62 */     for (int i = 2; i < 128; i++) {
/*  63 */       tmp[i] = 0;
/*     */     }
/*     */     
/*  66 */     tmp[0] = 48;
/*  67 */     if (maxRecLength < 4095) {
/*  68 */       tmp[1] = 126;
/*     */     } else {
/*  70 */       tmp[3] = 124;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     tmp[37] = 62;
/*  79 */     tmp[39] = (byte)org;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  86 */       Conversion.setLong(tmp, 54, 4, maxRecLength, true);
/*  87 */       Conversion.setLong(tmp, 58, 4, minRecLength, true);
/*  88 */     } catch (Exception e) {
/*  89 */       System.out.println("Error Setting Min max length in Microfocus Header");
/*     */     } 
/*     */ 
/*     */     
/*  93 */     tmp[48] = 1;
/*     */ 
/*     */     
/*  96 */     this.minLength = minRecLength;
/*  97 */     this.maxLength = maxRecLength;
/*  98 */     this.headerRec = tmp;
/*     */   }
/*     */   
/*     */   private int getLength(int start) {
/* 102 */     byte[] len = new byte[4];
/*     */     
/* 104 */     System.arraycopy(this.headerRec, start, len, 0, 4);
/* 105 */     return (new BigInteger(len)).intValue();
/*     */   }
/*     */   
/*     */   public byte[] getHeaderRec() {
/* 109 */     return this.headerRec;
/*     */   }
/*     */   
/*     */   public byte getFileFormat() {
/* 113 */     return this.headerRec[39];
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getCompression() {
/* 118 */     return this.headerRec[41];
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValidFile() {
/* 123 */     return (this.headerRec[6] == 0 && this.headerRec[7] == 0);
/*     */   }
/*     */   
/*     */   public byte getRecordFormat() {
/* 127 */     return this.headerRec[48];
/*     */   }
/*     */   
/*     */   public int getMinLength() {
/* 131 */     return this.minLength;
/*     */   }
/*     */   
/*     */   public int getMaxLength() {
/* 135 */     return this.maxLength;
/*     */   }
/*     */ }

