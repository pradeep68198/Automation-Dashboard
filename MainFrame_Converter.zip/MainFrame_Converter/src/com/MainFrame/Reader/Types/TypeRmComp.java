/*    */ package com.MainFrame.Reader.Types;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import com.MainFrame.Reader.Common.IFieldDetail;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeRmComp
/*    */   extends TypeNum
/*    */ {
/*    */   public static final int POSITIVE = 11;
/*    */   public static final int NEGATIVE = 13;
/*    */   
/*    */   public TypeRmComp() {
/* 38 */     super(false, true, true, false, true, true, false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getField(byte[] record, int position, IFieldDetail currField) {
/* 46 */     long retL = getRmComp(record, position, currField.getLen() - 1);
/*    */     
/* 48 */     if (record.length >= position + currField.getLen() - 1 && record[position + currField
/* 49 */         .getLen() - 2] == 13) {
/* 50 */       retL *= -1L;
/*    */     }
/*    */     
/* 53 */     Object ret = Long.valueOf(retL);
/*    */     
/* 55 */     if (currField.getDecimal() > 0) {
/* 56 */       ret = new BigDecimal(BigInteger.valueOf(retL), currField.getDecimal());
/*    */     }
/*    */     
/* 59 */     return ret;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 67 */     String val = toNumberString(value);
/* 68 */     long l = getBigDecimal(field, val).longValue();
/*    */     
/* 70 */     checkValue(field, val);
/*    */     
/* 72 */     record[position + field.getLen() - 2] = 11;
/* 73 */     if (l < 0L) {
/* 74 */       l *= -1L;
/* 75 */       record[position + field.getLen() - 2] = 13;
/*    */     } 
/*    */     
/* 78 */     return setRmComp(record, position, field.getLen() - 1, l);
/*    */   }
/*    */ }

