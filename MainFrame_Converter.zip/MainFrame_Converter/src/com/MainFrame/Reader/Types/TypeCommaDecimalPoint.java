/*    */ package com.MainFrame.Reader.Types;
/*    */ 
/*    */ import java.text.NumberFormat;
/*    */ import java.util.Locale;
/*    */ import com.MainFrame.Reader.Common.Conversion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeCommaDecimalPoint
/*    */   extends TypeNum
/*    */ {
/* 37 */   private static final NumberFormat GERMAN_NUM_FORMAT = NumberFormat.getIntegerInstance(Locale.GERMAN);
/*    */   
/*    */   public TypeCommaDecimalPoint(int typeId, boolean isPositive) {
/* 40 */     super(typeId, isPositive, ',');
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected NumberFormat getNumberFormat() {
/* 48 */     return GERMAN_NUM_FORMAT;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String addDecimalPoint(String s, int decimal) {
/* 57 */     s = s.trim();
/* 58 */     int pos = s.lastIndexOf(',');
/*    */     
/* 60 */     if (pos >= 0) {
/* 61 */       s = s.substring(0, pos) + '.' + s.substring(pos + 1);
/*    */     }
/*    */ 
/*    */     
/* 65 */     return Conversion.numTrim(s);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public char getDecimalChar() {
/* 83 */     return ',';
/*    */   }
/*    */ }

