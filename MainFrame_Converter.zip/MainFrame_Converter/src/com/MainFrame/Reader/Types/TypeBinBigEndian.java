/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeBinBigEndian
/*     */   extends TypeNum
/*     */ {
/*     */   private final boolean positiveStorage;
/*     */   
/*     */   public TypeBinBigEndian(boolean isPositive) {
/*  66 */     super(false, true, true, isPositive, true, true, false);
/*  67 */     this.positiveStorage = isPositive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinBigEndian(boolean isPositive, boolean positiveStore) {
/*  79 */     super(false, true, true, isPositive, true, true, false);
/*  80 */     this.positiveStorage = positiveStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail field) {
/*  89 */     int pos = position - 1;
/*  90 */     int end = position + field.getLen() - 1;
/*  91 */     int min = Math.min(end, record.length);
/*     */ 
/*     */     String s;
/*  94 */     if (pos >= min) {
/*  95 */       s = "0";
/*  96 */     } else if (this.positiveStorage) {
/*  97 */       s = Conversion.getPositiveBigInt(record, pos, min - pos).toString();
/*     */     } else {
/*  99 */       s = Conversion.getBigInt(record, pos, min - pos).toString();
/*     */     } 
/*     */     
/* 102 */     s = addDecimalPoint(s, field.getDecimal());
/*     */     
/* 104 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 115 */     Conversion.setBigInt(record, position - 1, field.getLen(), formatAsBigInt(field, value), this.positiveStorage);
/* 116 */     return record;
/*     */   }
/*     */ }

