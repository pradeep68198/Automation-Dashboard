/*    */ package com.MainFrame.Reader.Types;
/*    */ 
/*    */ import com.MainFrame.Reader.Common.IFieldDetail;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeCharNullTerminated
/*    */   extends TypeChar
/*    */ {
/* 47 */   private byte padByte = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeCharNullTerminated() {
/* 54 */     super(true, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int getFieldEnd(int position, IFieldDetail currField, byte[] record) {
/* 62 */     int ret = position - 1;
/* 63 */     int end = Math.min(ret + currField.getLen(), record.length);
/*    */     
/* 65 */     while (ret < end && record[ret] != this.padByte) {
/* 66 */       ret++;
/*    */     }
/*    */     
/* 69 */     return ret;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected byte getPadByte(String font) {
/* 77 */     return this.padByte;
/*    */   }
/*    */ }

