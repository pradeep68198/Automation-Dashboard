/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.Common.RecordException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeChar
/*     */   implements Type
/*     */ {
/*     */   private final boolean leftJust;
/*     */   private final boolean binary;
/*     */   private boolean numeric = false;
/*     */   private final boolean hasPadByteOveride;
/*     */   private final boolean trim;
/*     */   
/*     */   public TypeChar(boolean leftJustified) {
/*  73 */     this(leftJustified, false, false, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeChar(boolean leftJustified, boolean padByteOveride) {
/*  85 */     this(leftJustified, padByteOveride, false, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeChar(boolean leftJustified, boolean binaryField, boolean num) {
/* 103 */     this(leftJustified, false, binaryField, num, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeChar(boolean leftJustified, boolean padByteOveride, boolean binaryField, boolean num, boolean trim) {
/* 109 */     this.leftJust = leftJustified;
/* 110 */     this.binary = binaryField;
/* 111 */     this.numeric = num;
/* 112 */     this.hasPadByteOveride = padByteOveride;
/* 113 */     this.trim = trim;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String formatValueForRecord(IFieldDetail field, String val) {
/* 122 */     if (val == null) {
/* 123 */       val = "";
/* 124 */     } else if (val.length() < field.getLen() && !this.leftJust) {
/* 125 */       char[] c = new char[field.getLen()];
/* 126 */       int toIndex = c.length - val.length();
/* 127 */       Arrays.fill(c, 0, toIndex, ' ');
/*     */       
/* 129 */       System.arraycopy(val.toCharArray(), 0, c, toIndex, val.length());
/* 130 */       val = new String(c);
/*     */     } 
/* 132 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail currField) {
/* 142 */     return getFieldText(record, position, currField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getFieldText(byte[] record, int position, IFieldDetail currField) {
/* 159 */     if (record == null || isHexZero(record, position, currField.getLen())) {
/* 160 */       return "";
/*     */     }
/* 162 */     String s = Conversion.getString(record, position - 1, 
/* 163 */         getFieldEnd(position, currField, record), currField
/* 164 */         .getFontName());
/* 165 */     String pad = " ";
/*     */     
/* 167 */     if (this.trim && s.endsWith(pad)) {
/* 168 */       int idx = s.length() - 1;
/* 169 */       char ch = pad.charAt(0);
/* 170 */       while (idx >= 0 && s.charAt(idx) == ch) {
/* 171 */         idx--;
/*     */       }
/* 173 */       s = s.substring(0, idx + 1);
/*     */     } 
/* 175 */     return s;
/*     */   }
/*     */   
/*     */   public static boolean isHexZero(byte[] record, int position, int len) {
/* 179 */     int e = Math.min(record.length, position + len - 1);
/* 180 */     for (int i = position - 1; i < e; i++) {
/* 181 */       if (record[i] != 0) {
/* 182 */         return false;
/*     */       }
/*     */     } 
/* 185 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getFieldEnd(int position, IFieldDetail currField, byte[] record) {
/* 196 */     int ret = Math.min(position + currField.getLen() - 1, record.length);
/* 197 */     String fontName = currField.getFontName();
/*     */     
/* 199 */     if (this.trim && (this.hasPadByteOveride || Conversion.isSingleByte(fontName))) {
/* 200 */       byte padByte = getPadByte(fontName);
/*     */       
/* 202 */       while (ret > 0 && record[ret - 1] == padByte) {
/* 203 */         ret--;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 227 */     String val = value.toString();
/* 228 */     String font = field.getFontName();
/* 229 */     int pos = position - 1;
/* 230 */     int len = field.getLen();
/*     */     
/* 232 */     if (this.leftJust) {
/* 233 */       byte[] byteVal = getBytes(val, font);
/* 234 */       int length = byteVal.length;
/* 235 */       if (length >= len) {
/* 236 */         System.arraycopy(byteVal, 0, record, pos, len);
/*     */       } else {
/*     */         
/* 239 */         System.arraycopy(byteVal, 0, record, pos, length);
/*     */         
/* 241 */         padByte(record, pos + length, len - length, getPadByte(font));
/*     */       } 
/*     */     } else {
/* 244 */       copyRightJust(record, val, pos, len, " ", font);
/*     */     } 
/*     */     
/* 247 */     return record;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void padWith(byte[] record, int start, int len, String padCh, String font) {
/* 264 */     byte padByte = getBytes(padCh, font)[0];
/*     */     
/* 266 */     padByte(record, start, len, padByte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte getPadByte(String font) {
/* 278 */     return getBytes(" ", font)[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void padByte(byte[] record, int start, int len, byte padByte) {
/* 297 */     for (int i = start; i < start + len; i++) {
/* 298 */       record[i] = padByte;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void copyRightJust(byte[] record, String val, int pos, int len, String pad, String font) {
/* 319 */     int l = val.length();
/*     */     
/* 321 */     byte[] bytes = getBytes(val, font);
/* 322 */     if (l == len)
/*     */     
/* 324 */     { System.arraycopy(bytes, 0, record, pos, len); }
/* 325 */     else { if (l > len) {
/* 326 */         throw new RecordException("Character Field is to big: " + val + " Field Length: " + len);
/*     */       }
/* 328 */       padWith(record, pos, len - val.length(), pad, font);
/* 329 */       System.arraycopy(bytes, 0, record, pos + len - val
/* 330 */           .length(), val.length()); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final byte[] getBytes(String s, String fontName) {
/* 344 */     return Conversion.getBytes(s, fontName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isBinary() {
/* 354 */     return this.binary;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLeftJustified() {
/* 363 */     return this.leftJust;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void setNumeric(boolean numeric) {
/* 368 */     this.numeric = numeric;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isNumeric() {
/* 378 */     return this.numeric;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFieldType() {
/* 386 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char getDecimalChar() {
/* 395 */     return '.';
/*     */   }
/*     */ }

