/*     */ package com.MainFrame.Reader.Types.smallBin;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.CommonBits;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.Common.RecordException;
/*     */ import com.MainFrame.Reader.Types.TypeZoned;
/*     */ 
/*     */ 
/*     */ public class TypeZonedAsciiSmall
/*     */   extends TypeBaseXBinary
/*     */ {
/*     */   private TypeZoned typeZoned;
/*  14 */   private static final byte[] NUMERIC_BYTES = "+-.,09aijrAIJR".getBytes();
/*     */ 
/*     */   
/*  17 */   private static final char ch4Byte0 = (char)(NUMERIC_BYTES[4] & 0xFF);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  27 */   private static final char sign1a = (char)(NUMERIC_BYTES[6] & 0xFF);
/*  28 */   private static final char sign9a = (char)(NUMERIC_BYTES[7] & 0xFF);
/*  29 */   private static final char signm1a = (char)(NUMERIC_BYTES[8] & 0xFF);
/*  30 */   private static final char signm9a = (char)(NUMERIC_BYTES[9] & 0xFF);
/*  31 */   private static final char sign1b = (char)(NUMERIC_BYTES[10] & 0xFF);
/*  32 */   private static final char sign9b = (char)(NUMERIC_BYTES[11] & 0xFF);
/*  33 */   private static final char signm1b = (char)(NUMERIC_BYTES[12] & 0xFF);
/*  34 */   private static final char signm9b = (char)(NUMERIC_BYTES[13] & 0xFF);
/*     */   
/*     */   public TypeZonedAsciiSmall(boolean positive) {
/*  37 */     super(positive, false, false);
/*  38 */     this.typeZoned = new TypeZoned(positive);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/*  47 */     if (value == null || value == CommonBits.NULL_VALUE)
/*  48 */       return setUnscaledLong(record, position, field, 0L); 
/*  49 */     if (value instanceof Number) {
/*  50 */       return super.setField(record, position, field, value);
/*     */     }
/*  52 */     return this.typeZoned.setField(record, position, field, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String formatValueForRecord(IFieldDetail field, String val) {
/*  61 */     return this.typeZoned.formatValueForRecord(field, val);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long asUnscaledLong(byte[] record, int position, IFieldDetail field) {
/*  67 */     long val = 0L;
/*  68 */     int en = position + field.getLen() - 2;
/*     */     
/*  70 */     for (int i = position - 1; i < en; i++) {
/*  71 */       int d = record[i] & 0xF;
/*  72 */       if (d > 9) {
/*  73 */         throw new RecordException(field.getName() + ": Invalid Zoned Decimal: " + 
/*  74 */             Conversion.getString(record, position, en, ""));
/*     */       }
/*  76 */       val = val * 10L + d;
/*     */     } 
/*  78 */     char signChar = (char)(record[en] & 0xFF);
/*  79 */     int sign = 1;
/*  80 */     int last = 0;
/*     */     
/*  82 */     if (signChar >= sign1a && signChar <= sign9a) {
/*  83 */       last = signChar - sign1a + 1;
/*  84 */     } else if (signChar >= sign1b && signChar <= sign9b) {
/*  85 */       last = signChar - sign1b + 1;
/*  86 */     } else if (signChar >= signm1a && signChar <= signm9a) {
/*  87 */       last = signChar - signm1a + 1;
/*  88 */       sign = -1;
/*  89 */     } else if (signChar >= signm1b && signChar <= signm9b) {
/*  90 */       last = signChar - signm1b + 1;
/*  91 */       sign = -1;
/*  92 */     } else if (signChar != Conversion.getPositive0EbcdicZoned()) {
/*  93 */       if (signChar == Conversion.getNegative0EbcdicZoned()) {
/*  94 */         sign = -1;
/*  95 */       } else if (signChar >= '0' && signChar <= '9') {
/*  96 */         last = signChar - 48;
/*     */       } else {
/*  98 */         throw new RecordException(field.getName() + ": Invalid Zoned Decimal Sign: " + 
/*  99 */             Conversion.getString(record, position, en + 1, ""));
/*     */       } 
/*     */     } 
/* 102 */     return sign * (val * 10L + last);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setUnscaledLong(byte[] record, int position, IFieldDetail field, long value) {
/* 108 */     int en = position + field.getLen() - 2;
/* 109 */     int pos = position - 1;
/*     */     
/* 111 */     boolean negative = (value < 0L);
/*     */     
/* 113 */     if (negative) {
/* 114 */       value = -value;
/*     */     }
/*     */ 
/*     */     
/* 118 */     long digit = value % 10L;
/*     */     
/* 120 */     if (isPositive()) {
/* 121 */       record[en] = (byte)(int)(digit + ch4Byte0);
/* 122 */     } else if (digit == 0L) {
/* 123 */       char ch = Conversion.getPositive0EbcdicZoned();
/* 124 */       if (negative) {
/* 125 */         ch = Conversion.getNegative0EbcdicZoned();
/*     */       }
/* 127 */       record[en] = (byte)ch;
/*     */     } else {
/* 129 */       char ch = sign1b;
/* 130 */       if (negative) {
/* 131 */         ch = signm1b;
/*     */       }
/*     */       
/* 134 */       record[en] = (byte)(int)(digit + ch - 1L);
/*     */     } 
/* 136 */     for (int i = en - 1; i >= pos; i--) {
/* 137 */       value /= 10L;
/* 138 */       record[i] = (byte)(int)(value % 10L + ch4Byte0);
/*     */     } 
/* 140 */     return record;
/*     */   }
/*     */ }

