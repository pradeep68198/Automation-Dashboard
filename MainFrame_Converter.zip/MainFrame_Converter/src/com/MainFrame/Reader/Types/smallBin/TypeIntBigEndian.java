/*    */ package com.MainFrame.Reader.Types.smallBin;
/*    */ 
/*    */ import com.MainFrame.Reader.Common.IFieldDetail;
/*    */ import com.MainFrame.Reader.Common.RecordException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeIntBigEndian
/*    */   extends TypeBaseXBinary
/*    */ {
/*    */   private final boolean normal;
/*    */   
/*    */   public TypeIntBigEndian(boolean positive, boolean uInt) {
/* 22 */     super((positive || uInt), true, true);
/* 23 */     this.normal = !uInt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long asUnscaledLong(byte[] record, int position, IFieldDetail field) {
/* 31 */     int pos = position - 1;
/* 32 */     int len = field.getLen();
/* 33 */     if (record.length < pos + len) {
/* 34 */       throw new RecordException("Invalid int (Big endian), record is to short: " + field.getName());
/*    */     }
/*    */     
/* 37 */     long v = (this.normal && record[pos] < 0) ? -1L : 0L;
/*    */     
/* 39 */     switch (len) {
/*    */       case 1:
/* 41 */         if (this.normal) return record[pos]; 
/* 42 */         return (record[pos] & 0xFF);
/* 43 */       case 8: v = v << 8L | (record[pos++] & 0xFF);
/* 44 */       case 7: v = v << 8L | (record[pos++] & 0xFF);
/* 45 */       case 6: v = v << 8L | (record[pos++] & 0xFF);
/* 46 */       case 5: v = v << 8L | (record[pos++] & 0xFF);
/* 47 */       case 4: v = v << 8L | (record[pos++] & 0xFF);
/* 48 */       case 3: v = v << 8L | (record[pos++] & 0xFF);
/* 49 */       case 2: v = (v << 8L | (record[pos++] & 0xFF)) << 8L | (record[pos] & 0xFF);
/*    */         break;
/*    */     } 
/* 52 */     return v;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] setUnscaledLong(byte[] record, int position, IFieldDetail field, long value) {
/* 60 */     int len = field.getLen();
/* 61 */     int pos = position + len - 2;
/* 62 */     long val = value;
/* 63 */     if (record == null || record.length <= pos) {
/* 64 */       throw new RecordException("Invalid Binary Field, record is to short: " + field.getName());
/*    */     }
/*    */     
/* 67 */     switch (len) {
/*    */       case 8:
/* 69 */         record[pos--] = (byte)(int)(val & 0xFFL);
/* 70 */         val >>= 8L;
/*    */       case 7:
/* 72 */         record[pos--] = (byte)(int)(val & 0xFFL);
/* 73 */         val >>= 8L;
/*    */       case 6:
/* 75 */         record[pos--] = (byte)(int)(val & 0xFFL);
/* 76 */         val >>= 8L;
/*    */       case 5:
/* 78 */         record[pos--] = (byte)(int)(val & 0xFFL);
/* 79 */         val >>= 8L;
/*    */       case 4:
/* 81 */         record[pos--] = (byte)(int)(val & 0xFFL);
/* 82 */         val >>= 8L;
/*    */       case 3:
/* 84 */         record[pos--] = (byte)(int)(val & 0xFFL);
/* 85 */         val >>= 8L;
/*    */       case 2:
/* 87 */         record[pos--] = (byte)(int)(val & 0xFFL);
/* 88 */         val >>= 8L;
/*    */       case 1:
/* 90 */         record[pos] = (byte)(int)(val & 0xFFL);
/* 91 */         val >>= 8L;
/*    */         break;
/*    */     } 
/* 94 */     if ((val != 0L && val != -1L) || (this.normal && value > 0L && record[pos] < 0)) {
/* 95 */       throw new RecordException("Value " + value + " is to large for " + field.getName() + " > " + val);
/*    */     }
/*    */     
/* 98 */     return record;
/*    */   }
/*    */ }

