/*     */ package com.MainFrame.Reader.Types.smallBin;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.Common.RecordException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypePackedDecimal9
/*     */   extends TypeBaseXBinary
/*     */ {
/*     */   private static final int POSITIVE_SIGNED_NYBLE = 12;
/*     */   private static final int UNSIGNED_NYBLE = 15;
/*     */   private static final int NEGATIVE_SIGN_NYBLE = 13;
/*  26 */   private static final byte[] toNum = new byte[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, -1, -1, -1, -1, -1, -1, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, -1, -1, -1, -1, -1, -1, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, -1, -1, -1, -1, -1, -1, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, -1, -1, -1, -1, -1, -1, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, -1, -1, -1, -1, -1, -1, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, -1, -1, -1, -1, -1, -1, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, -1, -1, -1, -1, -1, -1, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, -1, -1, -1, -1, -1, -1, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   private static final byte[] toPD = new byte[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, Byte.MIN_VALUE, -127, -126, -125, -124, -123, -122, -121, -120, -119, -112, -111, -110, -109, -108, -107, -106, -105, -104, -103 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypePackedDecimal9() {
/*  63 */     super(false, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypePackedDecimal9(boolean positive) {
/*  70 */     super(positive, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long asUnscaledLong(byte[] record, int position, IFieldDetail field) {
/*  84 */     int v, pos = position - 1;
/*  85 */     if (record.length < pos + field.getLen()) {
/*  86 */       throw new RecordException("Invalid Packed Decimal, record is to short: " + field.getName());
/*     */     }
/*     */     
/*  89 */     long ret = 0L;
/*     */ 
/*     */     
/*  92 */     switch (field.getLen()) {
/*     */       case 9:
/*  94 */         v = toNum[record[pos++] & 0xFF];
/*  95 */         if (v < 0) invalidMessage(field, pos + 2 - position); 
/*  96 */         ret = v;
/*     */       case 8:
/*  98 */         v = toNum[record[pos++] & 0xFF];
/*  99 */         if (v < 0) invalidMessage(field, pos + 2 - position); 
/* 100 */         ret = ret * 100L + v;
/*     */       case 7:
/* 102 */         v = toNum[record[pos++] & 0xFF];
/* 103 */         if (v < 0) invalidMessage(field, pos + 2 - position); 
/* 104 */         ret = ret * 100L + v;
/*     */       case 6:
/* 106 */         v = toNum[record[pos++] & 0xFF];
/* 107 */         if (v < 0) invalidMessage(field, pos + 2 - position); 
/* 108 */         ret = ret * 100L + v;
/*     */       case 5:
/* 110 */         v = toNum[record[pos++] & 0xFF];
/* 111 */         if (v < 0) invalidMessage(field, pos + 2 - position); 
/* 112 */         ret = ret * 100L + v;
/*     */       case 4:
/* 114 */         v = toNum[record[pos++] & 0xFF];
/* 115 */         if (v < 0) invalidMessage(field, pos + 2 - position); 
/* 116 */         ret = ret * 100L + v;
/*     */       case 3:
/* 118 */         v = toNum[record[pos++] & 0xFF];
/* 119 */         if (v < 0) invalidMessage(field, pos + 2 - position); 
/* 120 */         ret = ret * 100L + v;
/*     */       case 2:
/* 122 */         v = toNum[record[pos++] & 0xFF];
/* 123 */         if (v < 0) invalidMessage(field, pos + 2 - position); 
/* 124 */         ret = ret * 100L + v;
/*     */         break;
/*     */     } 
/* 127 */     ret = ret * 10L + ((record[pos] & 0xF0) >> 4);
/* 128 */     int signNyble = record[pos] & 0xF;
/* 129 */     if (signNyble == 13) {
/* 130 */       ret = -ret;
/* 131 */     } else if (signNyble < 10) {
/* 132 */       throw new RecordException("Invalid sign in field: " + field.getName() + " " + signNyble + " > " + 
/* 133 */           Conversion.getDecimalSB(record, position - 1, position + field.getLen() - 1));
/*     */     } 
/*     */     
/* 136 */     return ret;
/*     */   }
/*     */   
/*     */   private void invalidMessage(IFieldDetail field, int pos) {
/* 140 */     throw new RecordException("Invalid Packed decimal at: " + pos + " in field: " + field.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setUnscaledLong(byte[] record, int position, IFieldDetail field, long value) {
/* 152 */     int pos = position + field.getLen() - 2;
/* 153 */     int signNyble = 12;
/* 154 */     long oValue = value;
/* 155 */     if (value < 0L) {
/* 156 */       signNyble = 13;
/* 157 */       value = -value;
/* 158 */     } else if (isPositive()) {
/* 159 */       signNyble = 15;
/*     */     } 
/*     */     
/* 162 */     record[pos--] = (byte)(int)((value % 10L << 4L) + signNyble);
/* 163 */     value /= 10L;
/*     */     
/* 165 */     switch (field.getLen()) {
/*     */       case 9:
/* 167 */         record[pos--] = toPD[(int)(value % 100L)];
/* 168 */         value /= 100L;
/*     */       case 8:
/* 170 */         record[pos--] = toPD[(int)(value % 100L)];
/* 171 */         value /= 100L;
/*     */       case 7:
/* 173 */         record[pos--] = toPD[(int)(value % 100L)];
/* 174 */         value /= 100L;
/*     */       case 6:
/* 176 */         record[pos--] = toPD[(int)(value % 100L)];
/* 177 */         value /= 100L;
/*     */       case 5:
/* 179 */         record[pos--] = toPD[(int)(value % 100L)];
/* 180 */         value /= 100L;
/*     */       case 4:
/* 182 */         record[pos--] = toPD[(int)(value % 100L)];
/* 183 */         value /= 100L;
/*     */       case 3:
/* 185 */         record[pos--] = toPD[(int)(value % 100L)];
/* 186 */         value /= 100L;
/*     */       case 2:
/* 188 */         record[pos--] = toPD[(int)(value % 100L)];
/* 189 */         value /= 100L;
/*     */         break;
/*     */     } 
/* 192 */     if (value > 0L) {
/* 193 */       throw new RecordException("Value " + oValue + " is to big for the field: " + field.getName());
/*     */     }
/*     */     
/* 196 */     return record;
/*     */   }
/*     */ }

