package com.MainFrame.Reader.Types.smallBin;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Types.Type;

public interface ITypeBinaryExtendedNumeric extends Type {
  long asUnscaledLong(byte[] paramArrayOfbyte, int paramInt, IFieldDetail paramIFieldDetail);
  
  byte[] setUnscaledLong(byte[] paramArrayOfbyte, int paramInt, IFieldDetail paramIFieldDetail, long paramLong);
}

