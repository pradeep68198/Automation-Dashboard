/*     */ package com.MainFrame.Reader.Types.smallBin;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import com.MainFrame.Reader.Common.CommonBits;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.Common.RecordException;
/*     */ import com.MainFrame.Reader.Types.TypeNum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TypeBaseXBinary
/*     */   extends TypeNum
/*     */   implements ITypeBinaryExtendedNumeric
/*     */ {
/*  26 */   private static long[] pot = new long[] { 1L, 10L, 100L, 1000L, 10000L, 100000L, 1000000L, 10000000L, 100000000L, 1000000000L, 10000000000L, 100000000000L, 1000000000000L, 10000000000000L, 100000000000000L, 1000000000000000L, 10000000000000000L, 100000000000000000L, 1000000000000000000L };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  34 */   private static BigDecimal BD_MAX_LONG = BigDecimal.valueOf(Long.MAX_VALUE);
/*  35 */   private static BigDecimal BD_MIN_LONG = BigDecimal.valueOf(Long.MIN_VALUE);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBaseXBinary(boolean positive, boolean binary, boolean couldBeHexHero) {
/*  41 */     super(false, true, true, positive, binary, couldBeHexHero, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/*  49 */     if (value == null || value == CommonBits.NULL_VALUE) {
/*  50 */       return setUnscaledLong(record, position, field, 0L);
/*     */     }
/*  52 */     int decimal = field.getDecimal();
/*  53 */     if (value instanceof Number && decimal >= 0 && decimal < pot.length) {
/*  54 */       Number valueNum = (Number)value;
/*  55 */       if (value instanceof BigDecimal) {
/*  56 */         return setUnscaledBigDecimal(record, position, field, ((BigDecimal)value).movePointRight(decimal));
/*     */       }
/*  58 */       if (value instanceof BigInteger) {
/*  59 */         return setUnscaledBigDecimal(record, position, field, new BigDecimal((BigInteger)value, -decimal));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*  64 */       double d = valueNum.doubleValue() * pot[decimal];
/*  65 */       if (d > 9.223372036854776E18D || d < -9.223372036854776E18D) {
/*  66 */         throw new RecordException("Value " + valueNum + " is to big for field: " + field.getName());
/*     */       }
/*     */       
/*  69 */       if (valueNum instanceof Double) {
/*  70 */         return setUnscaledLong(record, position, field, (long)((d >= 0.0D) ? (d + 0.5D) : (d - 0.5D)));
/*     */       }
/*  72 */       if (valueNum instanceof Float) {
/*  73 */         float f = valueNum.floatValue() * (float)pot[decimal];
/*  74 */         return setUnscaledLong(record, position, field, (long)((f >= 0.0F) ? (f + 0.5D) : (f - 0.5D)));
/*     */       } 
/*  76 */       if (decimal == 0) {
/*  77 */         return setUnscaledLong(record, position, field, valueNum.longValue());
/*     */       }
/*     */     } 
/*  80 */     String valStr = value.toString();
/*  81 */     if ("".equals(valStr)) {
/*  82 */       return setUnscaledLong(record, position, field, 0L);
/*     */     }
/*  84 */     return setUnscaledBigDecimal(record, position, field, (new BigDecimal(valStr))
/*     */ 
/*     */         
/*  87 */         .movePointRight(decimal));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail field) {
/* 103 */     long unscaled = asUnscaledLong(record, position, field);
/* 104 */     int decimal = field.getDecimal();
/* 105 */     if (decimal != 0) {
/* 106 */       return BigDecimal.valueOf(unscaled, decimal);
/*     */     }
/* 108 */     return Long.valueOf(unscaled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] setUnscaledBigDecimal(byte[] record, int position, IFieldDetail field, BigDecimal value) {
/* 116 */     if (value.compareTo(BD_MIN_LONG) < 0 || value.compareTo(BD_MAX_LONG) > 0) {
/* 117 */       throw new RecordException("Value " + value + " is to big to be stored in field: " + field.getName());
/*     */     }
/* 119 */     return setUnscaledLong(record, position, field, value.longValue());
/*     */   }
/*     */ }

