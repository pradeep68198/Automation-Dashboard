/*    */ package com.MainFrame.Reader.Types.smallBin;
/*    */ 
/*    */ import com.MainFrame.Reader.Common.CommonBits;
/*    */ import com.MainFrame.Reader.Common.Conversion;
/*    */ import com.MainFrame.Reader.Common.IFieldDetail;
/*    */ import com.MainFrame.Reader.Common.RecordException;
/*    */ import com.MainFrame.Reader.Types.TypeZoned;
/*    */ 
/*    */ public class TypeZonedEbcdicSmall
/*    */   extends TypeBaseXBinary
/*    */ {
/*    */   private static final int EBCDIC_DIGIT_HIGH_NYBLE = 240;
/* 13 */   private static final byte[] NUMERIC_BYTES = Conversion.getBytes("09", "cp037");
/*    */   
/*    */   private static final int POSITIVE_SIGN_NYBLE = 192;
/*    */   private static final int NEGATIVE_SIGN_NYBLE = 208;
/*    */   private TypeZoned typeZoned;
/*    */   
/*    */   public TypeZonedEbcdicSmall(boolean positive) {
/* 20 */     super(positive, false, false);
/* 21 */     this.typeZoned = new TypeZoned(positive);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 30 */     if (value == null || value == CommonBits.NULL_VALUE || value instanceof Number) {
/* 31 */       return super.setField(record, position, field, value);
/*    */     }
/* 33 */     return this.typeZoned.setField(record, position, field, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String formatValueForRecord(IFieldDetail field, String val) {
/* 42 */     return this.typeZoned.formatValueForRecord(field, val);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public long asUnscaledLong(byte[] record, int position, IFieldDetail field) {
/* 48 */     long val = 0L;
/* 49 */     int en = position + field.getLen() - 1;
/*    */     
/* 51 */     for (int i = position - 1; i < en; i++) {
/* 52 */       int d = record[i] & 0xF;
/* 53 */       if (d > 9) {
/* 54 */         throw new RecordException(field.getName() + ": Invalid Zoned Decimal: " + 
/* 55 */             Conversion.getString(record, position, en, "cp037"));
/*    */       }
/* 57 */       val = val * 10L + d;
/*    */     } 
/* 59 */     int xx = record[en - 1] & 0xF0;
/* 60 */     byte signNyble = (byte)xx;
/* 61 */     switch (signNyble) {
/*    */       case -128:
/*    */       case -48:
/* 64 */         val = -val;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/*    */       case -112:
/*    */       case -64:
/*    */       case -16:
/* 76 */         return val;
/*    */     } 
/*    */     if (record[en - 1] < NUMERIC_BYTES[0] || record[en - 1] > NUMERIC_BYTES[1])
/*    */       throw new RecordException(field.getName() + ": Invalid Zoned Decimal: " + Conversion.getString(record, position, en, "cp037")); 
/*    */
return signNyble;   }
/*    */   public byte[] setUnscaledLong(byte[] record, int position, IFieldDetail field, long value) {
/* 82 */     int en = position + field.getLen() - 2;
/* 83 */     int pos = position - 1;
/* 84 */     int signNyble = 192;
/*    */     
/* 86 */     if (value < 0L) {
/* 87 */       value = -value;
/* 88 */       signNyble = 208;
/* 89 */     } else if (isPositive()) {
/* 90 */       signNyble = 240;
/*    */     } 
/*    */     
/* 93 */     record[en] = (byte)(int)(value % 10L | signNyble);
/* 94 */     for (int i = en - 1; i >= pos; i--) {
/* 95 */       value /= 10L;
/* 96 */       record[i] = (byte)(int)(value % 10L | 0xF0L);
/*    */     } 
/* 98 */     return record;
/*    */   }
/*    */ }
