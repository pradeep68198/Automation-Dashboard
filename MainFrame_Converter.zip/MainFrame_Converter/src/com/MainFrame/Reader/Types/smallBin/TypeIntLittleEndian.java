/*    */ package com.MainFrame.Reader.Types.smallBin;
/*    */ 
/*    */ import com.MainFrame.Reader.Common.IFieldDetail;
/*    */ import com.MainFrame.Reader.Common.RecordException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeIntLittleEndian
/*    */   extends TypeBaseXBinary
/*    */ {
/*    */   private final boolean normal;
/*    */   
/*    */   public TypeIntLittleEndian(boolean positive, boolean uInt) {
/* 22 */     super((positive || uInt), true, true);
/* 23 */     this.normal = !uInt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long asUnscaledLong(byte[] record, int position, IFieldDetail field) {
/* 31 */     int len = field.getLen();
/* 32 */     int pos = position + len - 2;
/* 33 */     if (record.length <= pos) {
/* 34 */       throw new RecordException("Invalid int (little endian, record is to short: " + field.getName());
/*    */     }
/*    */     
/* 37 */     long v = (this.normal && record[pos] < 0) ? -1L : 0L;
/*    */     
/* 39 */     switch (len) {
/*    */       case 1:
/* 41 */         if (this.normal) return record[pos]; 
/* 42 */         return (record[pos] & 0xFF);
/* 43 */       case 8: v = v << 8L | (record[pos--] & 0xFF);
/* 44 */       case 7: v = v << 8L | (record[pos--] & 0xFF);
/* 45 */       case 6: v = v << 8L | (record[pos--] & 0xFF);
/* 46 */       case 5: v = v << 8L | (record[pos--] & 0xFF);
/* 47 */       case 4: v = v << 8L | (record[pos--] & 0xFF);
/* 48 */       case 3: v = v << 8L | (record[pos--] & 0xFF);
/* 49 */       case 2: v = (v << 8L | (record[pos--] & 0xFF)) << 8L | (record[pos] & 0xFF);
/*    */         break;
/*    */     } 
/* 52 */     return v;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] setUnscaledLong(byte[] record, int position, IFieldDetail field, long value) {
/* 60 */     int pos = position - 1;
/* 61 */     int len = field.getLen();
/* 62 */     if (record == null || record.length < pos + len) {
/* 63 */       throw new RecordException("Invalid Binary Field, record is to short: " + field.getName());
/*    */     }
/*    */     
/* 66 */     switch (len) {
/*    */       case 8:
/* 68 */         record[pos++] = (byte)(int)(value & 0xFFL);
/* 69 */         value >>= 8L;
/*    */       case 7:
/* 71 */         record[pos++] = (byte)(int)(value & 0xFFL);
/* 72 */         value >>= 8L;
/*    */       case 6:
/* 74 */         record[pos++] = (byte)(int)(value & 0xFFL);
/* 75 */         value >>= 8L;
/*    */       case 5:
/* 77 */         record[pos++] = (byte)(int)(value & 0xFFL);
/* 78 */         value >>= 8L;
/*    */       case 4:
/* 80 */         record[pos++] = (byte)(int)(value & 0xFFL);
/* 81 */         value >>= 8L;
/*    */       case 3:
/* 83 */         record[pos++] = (byte)(int)(value & 0xFFL);
/* 84 */         value >>= 8L;
/*    */       case 2:
/* 86 */         record[pos++] = (byte)(int)(value & 0xFFL);
/* 87 */         value >>= 8L;
/*    */       case 1:
/* 89 */         record[pos] = (byte)(int)(value & 0xFFL);
/*    */         break;
/*    */     } 
/* 92 */     return record;
/*    */   }
/*    */ }

