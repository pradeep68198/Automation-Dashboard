/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeBinLittleEndian
/*     */   extends TypeNum
/*     */ {
/*     */   private final boolean positiveStorage;
/*     */   
/*     */   public TypeBinLittleEndian(boolean isPositive) {
/*  69 */     super(false, true, true, isPositive, true, true, false);
/*  70 */     this.positiveStorage = isPositive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinLittleEndian(boolean isPositive, boolean positiveStorage) {
/*  84 */     super(false, true, true, isPositive, true, true, false);
/*  85 */     this.positiveStorage = positiveStorage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail field) {
/*  94 */     int pos = position - 1;
/*  95 */     int end = position + field.getLen() - 1;
/*  96 */     int min = Math.min(end, record.length);
/*     */ 
              String s;

/*     */ 
/*     */     
/* 100 */     if (this.positiveStorage) {
/* 101 */       s = Conversion.getPostiveBinary(record, pos, min);
/*     */     } else {
/* 103 */       s = Conversion.getBinaryInt(record, pos, min);
/*     */     } 
/*     */     
/* 106 */      s = addDecimalPoint(s, field.getDecimal());
/*     */     
/* 108 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 134 */     Conversion.setBigIntLE(record, position - 1, field
/* 135 */         .getLen(), 
/* 136 */         formatAsBigInt(field, value), this.positiveStorage);
/*     */ 
/*     */     
/* 139 */     return record;
/*     */   }
/*     */ }

