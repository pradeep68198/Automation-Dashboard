/*    */ package com.MainFrame.Reader.Types;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import com.MainFrame.Reader.Common.IFieldDetail;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeRmCompPositive
/*    */   extends TypeNum
/*    */ {
/*    */   public TypeRmCompPositive() {
/* 36 */     super(false, true, true, true, true, true, false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getField(byte[] record, int position, IFieldDetail currField) {
/* 44 */     long retL = getRmComp(record, position, currField.getLen());
/*    */     
/* 46 */     Object ret = Long.valueOf(retL);
/*    */     
/* 48 */     if (currField.getDecimal() > 0) {
/* 49 */       ret = new BigDecimal(BigInteger.valueOf(retL), currField.getDecimal());
/*    */     }
/*    */     
/* 52 */     return ret;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 59 */     String val = toNumberString(value);
/*    */     
/* 61 */     checkValue(field, val);
/*    */     
/* 63 */     return setRmComp(record, position, field.getLen(), Math.abs(getBigDecimal(field, val).longValue()));
/*    */   }
/*    */ }

