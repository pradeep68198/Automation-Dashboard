/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import com.MainFrame.Reader.Common.CommonBits;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeDecimalHex
/*     */   extends TypeNum
/*     */ {
/*     */   private final boolean isNumeric;
/*     */   
/*     */   public TypeDecimalHex(int typeId) {
/*  77 */     super(false, true, true, true, true, true, false);
/*     */     
/*  79 */     this.isNumeric = (typeId == 11);
/*  80 */     setNumeric(this.isNumeric);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail field) {
/*  91 */     int endOfField = record.length;
/*  92 */     int end = position + field.getLen() - 1;
/*  93 */     if (field.getType() != 81 && end < endOfField) {
/*  94 */       endOfField = end;
/*     */     }
/*     */     
/*  97 */     String s = Conversion.getDecimalSB(record, position - 1, endOfField).toString();
/*     */     
/*  99 */     if (this.isNumeric) {
/* 100 */       s = addDecimalPoint(s, field.getDecimal());
/*     */     }
/* 102 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 114 */     int pos = position - 1;
/* 115 */     int len = field.getLen();
/* 116 */     String val = toNumberString(value);
/*     */     
/* 118 */     if (field.getType() == 81) {
/* 119 */       len = record.length - field.getPos();
/*     */     }
/*     */     
/* 122 */     if (this.isNumeric) {
/* 123 */       val = checkValue(field, val);
/* 124 */     } else if (value == CommonBits.NULL_VALUE) {
/* 125 */       val = "0";
/*     */     } 
/* 127 */     Conversion.setBigInt(record, pos, len, new BigInteger(val, 16), true);
/*     */     
/* 129 */     return record;
/*     */   }
/*     */ }

