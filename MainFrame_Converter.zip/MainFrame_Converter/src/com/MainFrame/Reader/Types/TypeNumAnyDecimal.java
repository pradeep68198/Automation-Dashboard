/*    */ package com.MainFrame.Reader.Types;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import com.MainFrame.Reader.Common.Conversion;
/*    */ import com.MainFrame.Reader.Common.IFieldDetail;
/*    */ import com.MainFrame.Reader.Common.RecordException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeNumAnyDecimal
/*    */   extends TypeNum
/*    */ {
/*    */   public TypeNumAnyDecimal(boolean isPositive, boolean couldBeEmpty) {
/* 37 */     super(false, false, true, isPositive, false, false, couldBeEmpty);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String addDecimalPoint(String s, int decimal) {
/* 46 */     return (s == null) ? "" : s.trim();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 54 */     return setFieldToVal(record, position, field, formatValueForRecord(field, toNumberString(value)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String formatValueForRecord(IFieldDetail field, String val) {
/* 64 */     if (this.couldBeEmpty && (val == null || val.trim().length() == 0)) {
/* 65 */       return "";
/*    */     }
/*    */     
/*    */     try {
/* 69 */       new BigDecimal(Conversion.numTrim(val));
/* 70 */     } catch (Exception ex) {
/* 71 */       throw new RecordException("Invalid Number: " + val + " >" + Conversion.numTrim(val) + "<", ex.getMessage());
/*    */     } 
/*    */     
/* 74 */     if (isPositive() && val.indexOf('-') >= 0) {
/* 75 */       throw new RecordException("Only positive numbers are allowed: " + val);
/*    */     }
/*    */     
/* 78 */     return val.trim();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasFloatingDecimal() {
/* 87 */     return true;
/*    */   }
/*    */ }

