/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeFloat
/*     */   extends TypeNum
/*     */ {
/*     */   private static final int LENGTH_OF_DOUBLE = 8;
/*     */   private static final int LENGTH_OF_FLOAT = 4;
/*     */   
/*     */   public TypeFloat() {
/*  70 */     super(true, false, false, false, true, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail field) {
/*  79 */     Object val = "";
/*     */     
/*  81 */     int fldLength = field.getLen();
/*  82 */     int pos = position - 1;
/*     */     
/*  84 */     if (fldLength == 4) {
/*  85 */       val = Float.toString(Float.intBitsToFloat(Conversion.getLittleEndianBigInt(record, pos, pos + fldLength).intValue()));
/*     */ 
/*     */     
/*     */     }
/*  89 */     else if (fldLength == 8) {
/*  90 */       val = Double.toString(Double.longBitsToDouble(Conversion.getLittleEndianBigInt(record, pos, pos + fldLength).longValue()));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     return "" + val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 108 */     int len = field.getLen();
/* 109 */     int pos = position - 1;
/* 110 */     double doubleVal = getBigDecimal(field, toNumberString(value)).doubleValue();
/*     */     
/* 112 */     if (len == 4) {
/* 113 */       long l = Float.floatToRawIntBits((float)doubleVal);
/* 114 */       Conversion.setLongLow2High(record, pos, len, l, true);
/* 115 */     } else if (len == 8) {
/* 116 */       long l = Double.doubleToRawLongBits(doubleVal);
/* 117 */       Conversion.setLongLow2High(record, pos, len, l, true);
/*     */     } 
/*     */     
/* 120 */     return record;
/*     */   }
/*     */ }

