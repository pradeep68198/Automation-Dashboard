/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.Common.RecordException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeZoned
/*     */   extends TypeNum
/*     */ {
/*     */   public TypeZoned() {
/*  75 */     super(false, true, true, false, false, false, false);
/*     */   }
/*     */   
/*     */   public TypeZoned(boolean positive) {
/*  79 */     super(false, true, true, positive, false, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail field) {
/*  88 */     String val = getFieldText(record, position, field);
/*  89 */     String zoned = val;
/*     */     char ch;
/*  91 */     if (val.length() != 0 && ((ch = val.charAt(val.length() - 1)) < '0' || ch > '9')) {
/*     */ 
/*     */       
/*  94 */       String charset = field.getFontName();
/*  95 */       if (Conversion.isSingleByteEbcidic(charset)) {
/*  96 */         String sign = "";
/*  97 */         int end = position + field.getLen() - 1;
/*  98 */         byte signByte = record[end - 1];
/*  99 */         if ((byte)(signByte & 0xFFFFFFF0) == -48) {
/* 100 */           sign = "-";
/*     */         }
/* 102 */         byte[] lastDigitBytes = { (byte)(signByte | 0xFFFFFFF0) };
/*     */ 
/*     */ 
/*     */         
/* 106 */         zoned = sign + val.substring(0, val.length() - 1) + Conversion.getString(lastDigitBytes, 0, 1, charset);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 112 */         zoned = Conversion.fromZoned(val);
/*     */       } 
/*     */     } 
/*     */     
/* 116 */     return addDecimalPoint(zoned, field
/*     */         
/* 118 */         .getDecimal());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) throws RecordException {
/* 132 */     if (field.getLen() == 0) {
/* 133 */       return record;
/*     */     }
/*     */     
/* 136 */     String val = checkValue(field, toNumberString(value));
/* 137 */     String charset = field.getFontName();
/* 138 */     if (Conversion.isSingleByteEbcidic(charset)) {
/* 139 */       byteLevelAssign(record, position, field, val);
/* 140 */       return record;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     if (!isPositive()) {
/* 163 */       val = Conversion.toZoned(val);
/*     */     }
/* 165 */     copyRightJust(record, val, position - 1, field
/* 166 */         .getLen(), "0", charset);
/*     */     
/* 168 */     return record;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String formatValueForRecord(IFieldDetail field, String value) {
/* 174 */     String val = checkValue(field, toNumberString(value));
/* 175 */     String charset = field.getFontName();
/* 176 */     if (Conversion.isSingleByteEbcidic(charset)) {
/* 177 */       int len = Math.max(field.getLen(), val.length());
/*     */       
/* 179 */       byte[] record = new byte[len];
/* 180 */       byteLevelAssign(record, 1, field, val);
/* 181 */       String s = Conversion.toString(record, charset);
/* 182 */       if (field.isFixedFormat()) {
/* 183 */         return s;
/*     */       }
/* 185 */       return Conversion.numTrim(s);
/*     */     } 
/*     */     
/* 188 */     if (!isPositive()) {
/* 189 */       val = Conversion.toZoned(val);
/*     */     }
/* 191 */     if (field.isFixedFormat() && val.length() < field.getLen()) {
/* 192 */       return Conversion.padFront(val, field.getLen() - val.length(), '0');
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void byteLevelAssign(byte[] record, int position, IFieldDetail field, String val) {
/* 205 */     byte andByte = -49;
/* 206 */     int len = field.getLen();
/* 207 */     int endPos = len + position - 2;
/* 208 */     if (!field.isFixedFormat()) {
/* 209 */       endPos = record.length - 1;
/* 210 */       len = record.length - position + 1;
/*     */     } 
/*     */     
/* 213 */     if (val.startsWith("-")) {
/* 214 */       andByte = -33;
/* 215 */       val = val.substring(1);
/*     */     } else {
/* 217 */       if (val.startsWith("+")) {
/* 218 */         val = val.substring(1);
/*     */       }
/*     */       
/* 221 */       if (isPositive()) {
/* 222 */         andByte = -16;
/*     */       }
/*     */     } 
/* 225 */     copyRightJust(record, val, position - 1, len, "0", field
/*     */         
/* 227 */         .getFontName());
/*     */     
/* 229 */     if (!isPositive())
/* 230 */       record[endPos] = (byte)(record[endPos] & andByte); 
/*     */   }
/*     */ }

