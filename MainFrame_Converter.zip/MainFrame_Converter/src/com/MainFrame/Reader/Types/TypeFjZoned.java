/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeFjZoned
/*     */   extends TypeNum
/*     */ {
/*  51 */   private static int positiveFjDiff = 16;
/*  52 */   private static int negativeFjDiff = 32;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean overtypePositive;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeFjZoned(boolean overtypePositive) {
/*  63 */     super(false, true, true, false, false, false, false);
/*  64 */     this.overtypePositive = overtypePositive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail field) {
/*  74 */     return addDecimalPoint(
/*  75 */         fromFjZoned(getFieldText(record, position, field)), field
/*  76 */         .getDecimal());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/*  88 */     copyRightJust(record, formatValueForRecord(field, toNumberString(value)), position - 1, field
/*  89 */         .getLen(), "0", field
/*  90 */         .getFontName());
/*  91 */     return record;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String formatValueForRecord(IFieldDetail field, String value) {
/*  97 */     String val = toAsciiZoned(checkValue(field, toNumberString(value)));
/*  98 */     if (field.isFixedFormat()) {
/*  99 */       return Conversion.padFront(val, field.getLen() - val.length(), '0');
/*     */     }
/* 101 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String toAsciiZoned(String num) {
/*     */     String ret;
/* 115 */     if (num == null || (ret = num.trim()).length() == 0 || ret.equals("-") || ret.equals("+")) {
/* 116 */       return "";
/*     */     }
/*     */ 
/*     */     
/* 120 */     char lastChar = ret.substring(ret.length() - 1).charAt(0);
/*     */     
/* 122 */     if (num.startsWith("-")) {
/* 123 */       ret = ret.substring(1);
/*     */       
/* 125 */       if (lastChar >= '0' && lastChar <= '9')
/*     */       {
/*     */         
/* 128 */         lastChar = (char)(lastChar + negativeFjDiff);
/*     */       }
/*     */     } else {
/*     */       
/* 132 */       if (num.startsWith("+")) {
/* 133 */         ret = ret.substring(1);
/*     */       }
/*     */       
/* 136 */       if (lastChar >= '0' && lastChar <= '9')
/*     */       {
/* 138 */         if (this.overtypePositive) {
/* 139 */           lastChar = (char)(lastChar + positiveFjDiff);
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 144 */     ret = ret.substring(0, ret.length() - 1) + lastChar;
/*     */     
/* 146 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String fromFjZoned(String numZoned) {
/* 159 */     String sign = "";
/*     */     
/*     */     String ret;
/* 162 */     if (numZoned == null || (ret = numZoned.trim()).length() == 0 || ret.equals("-")) {
/* 163 */       return "";
/*     */     }
/*     */     
/* 166 */     char lastChar = ret.substring(ret.length() - 1).toUpperCase().charAt(0);
/*     */     
/* 168 */     switch (lastChar) {
/*     */       case '@':
/*     */       case 'A':
/*     */       case 'B':
/*     */       case 'C':
/*     */       case 'D':
/*     */       case 'E':
/*     */       case 'F':
/*     */       case 'G':
/*     */       case 'H':
/*     */       case 'I':
/* 179 */         lastChar = (char)(lastChar - positiveFjDiff);
/*     */         break;
/*     */       case 'P':
/*     */       case 'Q':
/*     */       case 'R':
/*     */       case 'S':
/*     */       case 'T':
/*     */       case 'U':
/*     */       case 'V':
/*     */       case 'W':
/*     */       case 'X':
/*     */       case 'Y':
/* 191 */         sign = "-";
/* 192 */         lastChar = (char)(lastChar - negativeFjDiff);
/*     */         break;
/*     */     } 
/* 195 */     ret = sign + ret.substring(0, ret.length() - 1) + lastChar;
/*     */     
/* 197 */     return ret;
/*     */   }
/*     */ }

