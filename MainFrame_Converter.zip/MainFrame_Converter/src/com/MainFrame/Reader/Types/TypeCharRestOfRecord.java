/*    */ package com.MainFrame.Reader.Types;
/*    */ 
/*    */ import com.MainFrame.Reader.Common.IFieldDetail;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeCharRestOfRecord
/*    */   extends TypeChar
/*    */ {
/* 32 */   private static final byte[] EMPTY = new byte[0];
/*    */   
/*    */   public TypeCharRestOfRecord() {
/* 35 */     super(true, true, false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int getFieldEnd(int position, IFieldDetail currField, byte[] record) {
/* 53 */     return record.length;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 62 */     String val = value.toString();
/* 63 */     String font = field.getFontName();
/* 64 */     int pos = position - 1;
/* 65 */     int len = record.length - pos;
/*    */ 
/*    */     
/* 68 */     byte[] byteVal = getBytes(val, font);
/* 69 */     if (val.length() == len) {
/* 70 */       System.arraycopy(byteVal, 0, record, pos, len);
/* 71 */     } else if (pos + val.length() == 0) {
/* 72 */       record = EMPTY;
/*    */     } else {
/* 74 */       byte[] temp = new byte[pos + val.length()];
/* 75 */       System.arraycopy(record, 0, temp, 0, position);
/* 76 */       System.arraycopy(byteVal, 0, temp, pos, val.length());
/* 77 */       record = temp;
/*    */     } 
/* 79 */     return record;
/*    */   }
/*    */ }

