package com.MainFrame.Reader.Types;

public interface ISizeInformation {
  int getNormalSize();
}

