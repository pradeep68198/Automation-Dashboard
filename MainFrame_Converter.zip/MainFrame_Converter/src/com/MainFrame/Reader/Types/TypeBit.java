/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import com.MainFrame.Reader.Common.CommonBits;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.Common.RecordException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeBit
/*     */   extends TypeChar
/*     */ {
/*     */   public TypeBit() {
/*  62 */     super(true, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail field) {
/*  72 */     int pos = position - 1;
/*  73 */     int end = position + field.getLen() - 1;
/*  74 */     int min = Math.min(end, record.length);
/*     */     
/*  76 */     return Conversion.numTrim(Conversion.getBitField(record, pos, min));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/*     */     BigInteger v;
/*  88 */     int pos = position - 1;
/*  89 */     int len = field.getLen();
/*     */     
/*  91 */     if (value == CommonBits.NULL_VALUE || value == null || "".equals(value) || "0".equals(value)) {
/*  92 */       v = BigInteger.ZERO;
/*     */     } else {
/*  94 */       String val = value.toString();
/*  95 */       v = new BigInteger(val, 2);
/*     */     } 
/*     */     
/*  98 */     Conversion.setBigInt(record, pos, len, v, true);
/*  99 */     return record;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String formatValueForRecord(IFieldDetail field, String val) {
/*     */     try {
/* 108 */       new BigInteger(val, 2);
/* 109 */     } catch (Exception ex) {
/* 110 */       throw new RecordException("Invalid Bit String: {0}", ex.getMessage());
/*     */     } 
/* 112 */     return val;
/*     */   }
/*     */ }

