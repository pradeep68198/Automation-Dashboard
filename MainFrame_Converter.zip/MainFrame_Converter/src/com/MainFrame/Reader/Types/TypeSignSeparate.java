/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.Common.RecordException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeSignSeparate
/*     */   extends TypeNum
/*     */ {
/*     */   private final boolean isLeadingSign;
/*     */   private final boolean isActualDecimal;
/*     */   
/*     */   public TypeSignSeparate(int typeId) {
/*  65 */     super(false, true, true, false, false, false, false);
/*     */     
/*  67 */     this.isLeadingSign = (typeId == 9 || typeId == 44);
/*  68 */     this.isActualDecimal = (typeId == 44 || typeId == 45);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail field) {
/*  79 */     return addDecimalPoint(
/*  80 */         fromSignSeparate(getFieldText(record, position, field)), field
/*  81 */         .getDecimal());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/*  93 */     String val = checkValue(field, toNumberString(value));
/*  94 */     copyRightJust(record, toSignSeparate(val, field), position - 1, field
/*  95 */         .getLen(), "0", field
/*  96 */         .getFontName());
/*  97 */     return record;
/*     */   }
/*     */ 
/*     */   
/*     */   public String formatValueForRecord(IFieldDetail field, String value) {
/* 102 */     return toSignSeparate(checkValue(field, toNumberString(value)), field);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String toSignSeparate(String num, IFieldDetail field) {
/* 119 */     if (num == null || num.length() == 0 || num.equals("-") || num.equals("+"))
/*     */     {
/* 121 */       return paddingString("+", field.getLen(), '0', !this.isLeadingSign);
/*     */     }
/* 123 */     String ret = num.trim();
/* 124 */     String sign = "";
/*     */     
/* 126 */     if (num.startsWith("-")) {
/* 127 */       sign = "-";
/* 128 */       ret = ret.substring(1);
/*     */     } else {
/* 130 */       sign = "+";
/* 131 */       if (num.startsWith("+")) {
/* 132 */         ret = ret.substring(1);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 137 */     int len = field.getLen() - 1;
/* 138 */     int decimal = field.getDecimal();
/* 139 */     if (decimal > 0 && this.isActualDecimal && len > 2) {
/* 140 */       ret = paddingString(ret, len - 1, '0', true);
/*     */       
/* 142 */       ret = ret.substring(0, ret.length() - decimal) + "." + ret.substring(ret.length() - decimal);
/*     */     } else {
/* 144 */       ret = paddingString(ret, len, '0', true);
/*     */     } 
/*     */     
/* 147 */     if (!"+".equals(sign) || ret.length() != field.getLen())
/*     */     {
/* 149 */       if (this.isLeadingSign) {
/* 150 */         ret = sign + ret;
/*     */       } else {
/* 152 */         ret = ret + sign;
/*     */       } 
/*     */     }
/* 155 */     if (ret.length() > field.getLen() && field.isFixedFormat()) {
/* 156 */       throw new RecordException("Value: " + ret + " is too large to fit field: " + field.getLen());
/*     */     }
/*     */     
/* 159 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String fromSignSeparate(String numSignSeparate) {
/* 170 */     if (numSignSeparate == null || numSignSeparate.length() == 0 || numSignSeparate.equals("-"))
/*     */     {
/* 172 */       return "";
/*     */     }
/*     */ 
/*     */     
/* 176 */     String sign = "";
/*     */ 
/*     */     
/* 179 */     String ret = numSignSeparate.trim();
/* 180 */     if (this.isLeadingSign) {
/* 181 */       if (ret.length() > 0 && ret.charAt(0) == '+') {
/* 182 */         ret = ret.substring(1);
/*     */       }
/*     */     } else {
/* 185 */       int lastIdx = ret.length() - 1;
/* 186 */       if (ret.length() > 0 && (ret.charAt(lastIdx) == '+' || ret.charAt(lastIdx) == '-')) {
/* 187 */         sign = ret.substring(lastIdx);
/* 188 */         ret = ret.substring(0, lastIdx);
/*     */       } 
/*     */     } 
/*     */     
/* 192 */     if ("-".equals(sign)) {
/* 193 */       ret = sign + ret;
/*     */     }
/* 195 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String paddingString(String s, int n, char c, boolean paddingLeft) {
/* 211 */     StringBuffer str = new StringBuffer(s);
/* 212 */     int strLength = str.length();
/* 213 */     if (n > 0 && n > strLength) {
/* 214 */       for (int i = 0; i <= n; i++) {
/* 215 */         if (paddingLeft) {
/* 216 */           if (i < n - strLength) {
/* 217 */             str.insert(0, c);
/*     */           }
/*     */         }
/* 220 */         else if (i > strLength) {
/* 221 */           str.append(c);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 226 */     return str.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isLeadingSign() {
/* 234 */     return this.isLeadingSign;
/*     */   }
/*     */ }

