/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.Common.RecordException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZOld_TypeZonedLeading
/*     */   extends TypeNum
/*     */ {
/*     */   public ZOld_TypeZonedLeading() {
/*  75 */     super(false, true, true, false, false, false, false);
/*     */   }
/*     */   
/*     */   public ZOld_TypeZonedLeading(boolean positive) {
/*  79 */     super(false, true, true, positive, false, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail field) {
/*  88 */     String val = getFieldText(record, position, field);
/*  89 */     String zoned = val;
/*     */     char ch;
/*  91 */     if (val.length() != 0 && ((ch = val.charAt(0)) < '0' || ch > '9')) {
/*     */ 
/*     */       
/*  94 */       String charset = field.getFontName();
/*  95 */       if (Conversion.isSingleByteEbcidic(charset)) {
/*  96 */         String sign = "";
/*  97 */         byte signByte = record[position - 1];
/*  98 */         if ((byte)(signByte & 0xFFFFFFF0) == -48) {
/*  99 */           sign = "-";
/*     */         }
/* 101 */         byte[] lastDigitBytes = { (byte)(signByte | 0xFFFFFFF0) };
/*     */ 
/*     */ 
/*     */         
/* 105 */         zoned = sign + Conversion.getString(lastDigitBytes, 0, 1, charset) + val.substring(1);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 111 */         zoned = fromZoned(val);
/*     */       } 
/*     */     } 
/*     */     
/* 115 */     return addDecimalPoint(zoned, field
/*     */         
/* 117 */         .getDecimal());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) throws RecordException {
/* 131 */     if (field.getLen() == 0) {
/* 132 */       return record;
/*     */     }
/*     */     
/* 135 */     String val = checkValue(field, toNumberString(value));
/* 136 */     String charset = field.getFontName();
/* 137 */     if (Conversion.isSingleByteEbcidic(charset)) {
/* 138 */       byteLevelAssign(record, position, field, val);
/*     */     } else {
/* 140 */       String zoned = toZoned(val, field.getLen());
/* 141 */       copyRightJust(record, zoned, position - 1, field
/* 142 */           .getLen(), "0", charset);
/*     */     } 
/*     */     
/* 145 */     return record;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String formatValueForRecord(IFieldDetail field, String value) {
/* 151 */     String val = checkValue(field, toNumberString(value));
/* 152 */     String charset = field.getFontName();
/* 153 */     if (Conversion.isSingleByteEbcidic(charset)) {
/* 154 */       int len = field.getLen();
/* 155 */       if (len <= 0) {
/* 156 */         len = value.length();
/*     */       }
/*     */       
/* 159 */       byte[] record = new byte[len];
/* 160 */       byteLevelAssign(record, 1, field, val);
/* 161 */       String s = Conversion.toString(record, charset);
/* 162 */       if (field.isFixedFormat()) {
/* 163 */         return s;
/*     */       }
/* 165 */       return Conversion.numTrim(s);
/*     */     } 
/*     */     
/* 168 */     val = toZoned(val, field.getLen());
/* 169 */     if (field.isFixedFormat() && val.length() < field.getLen()) {
/* 170 */       return Conversion.padFront(val, field.getLen() - val.length(), '0');
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void byteLevelAssign(byte[] record, int position, IFieldDetail field, String val) {
/* 183 */     byte andByte = -49;
/* 184 */     int len = field.getLen();
/* 185 */     int posM1 = position - 1;
/* 186 */     if (!field.isFixedFormat()) {
/* 187 */       len = record.length - posM1;
/*     */     }
/*     */     
/* 190 */     if (val.startsWith("-")) {
/* 191 */       andByte = -33;
/* 192 */       val = val.substring(1);
/*     */     } else {
/* 194 */       if (val.startsWith("+")) {
/* 195 */         val = val.substring(1);
/*     */       }
/*     */       
/* 198 */       if (isPositive()) {
/* 199 */         andByte = -16;
/*     */       }
/*     */     } 
/* 202 */     copyRightJust(record, val, posM1, len, "0", field
/*     */         
/* 204 */         .getFontName());
/*     */     
/* 206 */     if (!isPositive())
/* 207 */       record[posM1] = (byte)(record[posM1] & andByte); 
/*     */   }
/*     */   
/*     */   private String toZoned(String num, int len) {
/*     */     StringBuilder ret;
/* 212 */     if (num == null) {
/* 213 */       return "";
/*     */     }
/* 215 */     String number = num.trim();
/*     */ 
/*     */     
/* 218 */     if (num.equals("") || num.equals("-") || num.equals("+"))
/*     */     {
/* 220 */       return "";
/*     */     }
/*     */     
/* 223 */     if (len <= 0) {
/* 224 */       len = num.length();
/*     */     }
/*     */     
/* 227 */     char firstChar = number.charAt(0);
/*     */     
/* 229 */     if (firstChar == '-') {
/* 230 */       ret = toBuilder(number, 1, len);
/* 231 */       firstChar = ret.charAt(0);
/* 232 */       if (firstChar == '0') {
/* 233 */         ret.setCharAt(0, Conversion.getNegative0EbcdicZoned());
/*     */       } else {
/* 235 */         ret.setCharAt(0, (char)(firstChar + 25));
/*     */       } 
/*     */     } else {
/* 238 */       int st = 0;
/* 239 */       if (firstChar == '+') {
/* 240 */         st = 1;
/* 241 */         if (number.length() == 1) return ""; 
/*     */       } 
/* 243 */       ret = toBuilder(number, st, len);
/* 244 */       firstChar = ret.charAt(0);
/*     */       
/* 246 */       if (!isPositive() && firstChar >= '0' && firstChar <= '9')
/*     */       {
/* 248 */         if (firstChar == '0') {
/* 249 */           ret.setCharAt(0, Conversion.getPositive0EbcdicZoned());
/* 250 */         } else if (!isPositive()) {
/* 251 */           ret.setCharAt(0, (char)(firstChar + 16));
/*     */         } 
/*     */       }
/*     */     } 
/* 255 */     return ret.toString();
/*     */   }
/*     */   
/*     */   private StringBuilder toBuilder(CharSequence cs, int start, int len) {
/* 259 */     StringBuilder b = new StringBuilder(len);
/*     */     
/* 261 */     int fldStart = len - cs.length() + start; int i;
/* 262 */     for (i = 0; i < fldStart; i++) {
/* 263 */       b.append('0');
/*     */     }
/* 265 */     for (i = Math.max(start, cs.length() - len); i < cs.length(); i++) {
/* 266 */       b.append(cs.charAt(i));
/*     */     }
/*     */     
/* 269 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String fromZoned(String numZoned) {
/* 281 */     String sign = "";
/*     */     
/*     */     String ret;
/* 284 */     if (numZoned == null || (ret = numZoned.trim()).length() == 0 || ret.equals("-")) {
/* 285 */       return "";
/*     */     }
/*     */     
/* 288 */     char firstChar = ret.charAt(0);
/* 289 */     char ucFirstChar = Character.toUpperCase(firstChar);
/*     */ 
/*     */     
/* 292 */     switch (ucFirstChar)
/*     */     { case 'A':
/*     */       case 'B':
/*     */       case 'C':
/*     */       case 'D':
/*     */       case 'E':
/*     */       case 'F':
/*     */       case 'G':
/*     */       case 'H':
/*     */       case 'I':
/* 302 */         firstChar = (char)(ucFirstChar - 16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 324 */         ret = sign + firstChar + ret.substring(1);
/*     */         
/* 326 */         return ret;case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': sign = "-"; firstChar = (char)(ucFirstChar - 25); ret = sign + firstChar + ret.substring(1); return ret; }  if (firstChar == Conversion.getPositive0EbcdicZoned()) { firstChar = '0'; } else if (firstChar == Conversion.getNegative0EbcdicZoned()) { firstChar = '0'; sign = "-"; }  ret = sign + firstChar + ret.substring(1); return ret;
/*     */   }
/*     */ }

