/*    */ package com.MainFrame.Reader.Types;
/*    */ 
/*    */ import com.MainFrame.Reader.Common.IFieldDetail;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeCharRestOfFixedRecord
/*    */   extends TypeChar
/*    */ {
/*    */   public TypeCharRestOfFixedRecord() {
/* 33 */     super(true, true, false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int getFieldEnd(int position, IFieldDetail currField, byte[] record) {
/* 41 */     return record.length;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 50 */     String val = value.toString();
/* 51 */     String font = field.getFontName();
/* 52 */     int pos = position - 1;
/* 53 */     int len = record.length - pos;
/*    */ 
/*    */     
/* 56 */     byte[] byteVal = getBytes(val, font);
/* 57 */     if (val.length() >= len) {
/* 58 */       System.arraycopy(byteVal, 0, record, pos, len);
/*    */     } else {
/* 60 */       System.arraycopy(byteVal, 0, record, pos, val.length());
/*    */       
/* 62 */       padByte(record, pos + val.length(), len - val.length(), getPadByte(font));
/*    */     } 
/* 64 */     return record;
/*    */   }
/*    */ }

