/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.RecordException;
/*     */ import com.MainFrame.Reader.Types.smallBin.ITypeBinaryExtendedNumeric;
/*     */ import com.MainFrame.Reader.Types.smallBin.TypeIntBigEndian;
/*     */ import com.MainFrame.Reader.Types.smallBin.TypeIntLittleEndian;
/*     */ import com.MainFrame.Reader.Types.smallBin.TypePackedDecimal9;
/*     */ import com.MainFrame.Reader.Types.smallBin.TypeZonedAsciiSmall;
/*     */ import com.MainFrame.Reader.Types.smallBin.TypeZonedEbcdicSmall;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeManager
/*     */ {
/*     */   private static final int SHORT_TYPE_SIZE = 30;
/*     */   public static final int SYSTEM_ENTRIES = 250;
/*     */   public static final int INVALID_INDEX = 249;
/*     */   public static final int FIRST_SHORT_BIN = 140;
/*     */   private static final String ASCII_NUM_TST = "09+-.,aAzZ";
/*     */   
/*     */   public enum CharsetType
/*     */   {
/*  71 */     SINGLE_BYTE_EBCDIC,
/*  72 */     SINGLE_BYTE_ASCII,
/*  73 */     OTHER_CHARSET;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private static final byte[] ASCII_NUM_BYTES = Conversion.getBytes("09+-.,aAzZ", Conversion.DEFAULT_ASCII_CHARSET);
/*     */   
/*     */   private Type[] types;
/*  89 */   private ITypeBinaryExtendedNumeric[] shortLengthTypes = new ITypeBinaryExtendedNumeric[30];
/*  90 */   private int[] maxShortSize = new int[30];
/*  91 */   private int[] normalTypetoShortMapping = new int[100];
/*     */   
/*  93 */   private Type charType = new TypeChar(true);
/*     */   
/*     */   private int userSize;
/*     */   
/*  97 */   private static TypeManager systemTypeManager = new TypeManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeManager() {
/* 105 */     this(true, 75);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeManager(boolean addSystemTypes, int numberOfUserTypes) {
/* 122 */     this.userSize = numberOfUserTypes;
/*     */     
/* 124 */     if (this.userSize < 0) {
/* 125 */       this.userSize = 0;
/*     */     }
/*     */     
/* 128 */     this.types = new Type[250 + this.userSize];
/*     */     
/* 130 */     for (int i = 0; i < this.types.length; i++) {
/* 131 */       this.types[i] = this.charType;
/*     */     }
/*     */     
/* 134 */     if (addSystemTypes) {
/* 135 */       this.types[1] = new TypeChar(false);
/* 136 */       this.types[3] = new TypeCharPadded();
/* 137 */       this.types[2] = new TypeCharNullTerminated();
/* 138 */       this.types[82] = new TypeChar(true, false, false, false, false);
/*     */       
/* 140 */       this.types[5] = new TypeNum(5);
/* 141 */       this.types[6] = new TypeNum(6);
/* 142 */       this.types[29] = new TypeNum(29);
/* 143 */       this.types[42] = new TypeCommaDecimalPoint(42, false);
/* 144 */       this.types[43] = new TypeCommaDecimalPoint(43, false);
/* 145 */       this.types[7] = new TypeNum(7);
/* 146 */       this.types[25] = new TypeNum(25, true);
/* 147 */       this.types[24] = new TypeNum(24);
/* 148 */       this.types[8] = new TypeNum(8);
/* 149 */       this.types[22] = new TypeNum(22, true);
/* 150 */       this.types[26] = new TypeCommaDecimalPoint(26, false);
/* 151 */       this.types[27] = new TypeCommaDecimalPoint(27, false);
/* 152 */       this.types[28] = new TypeCommaDecimalPoint(28, true);
/* 153 */       this.types[9] = new TypeSignSeparate(9);
/* 154 */       this.types[10] = new TypeSignSeparate(10);
/* 155 */       this.types[44] = new TypeSignSeparate(44);
/* 156 */       this.types[45] = new TypeSignSeparate(45);
/* 157 */       this.types[32] = new TypeZoned();
/*     */       
/* 159 */       this.types[19] = new TypeNumAnyDecimal(false, false);
/* 160 */       this.types[20] = new TypeNumAnyDecimal(true, false);
/* 161 */       this.types[131] = new TypeNumAnyDecimal(false, true);
/*     */       
/* 163 */       this.types[17] = new TypeFloat();
/* 164 */       this.types[18] = new TypeFloat();
/*     */       
/* 166 */       this.types[31] = new TypePackedDecimal();
/* 167 */       this.types[33] = new TypePackedDecimal(true);
/* 168 */       this.types[11] = new TypeDecimalHex(11);
/* 169 */       this.types[4] = new TypeDecimalHex(4);
/*     */       
/* 171 */       this.types[23] = new TypeBinLittleEndian(true, false);
/* 172 */       this.types[16] = new TypeBinLittleEndian(true);
/* 173 */       this.types[15] = new TypeBinLittleEndian(false);
/* 174 */       this.types[35] = new TypeBinBigEndian(false);
/* 175 */       this.types[39] = new TypeBinBigEndian(true, false);
/* 176 */       this.types[36] = new TypeBinBigEndian(true);
/*     */       
/* 178 */       this.types[37] = new TypeRmComp();
/* 179 */       this.types[38] = new TypeRmCompPositive();
/*     */       
/* 181 */       this.types[21] = new TypeBit();
/*     */       
/* 183 */       this.types[41] = new TypeFjZoned(true);
/* 184 */       this.types[46] = new TypeFjZoned(false);
/*     */ 
/*     */       
/* 187 */       this.types[81] = new TypeCharRestOfRecord();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 192 */       this.shortLengthTypes[0] = (ITypeBinaryExtendedNumeric)new TypePackedDecimal9();
/* 193 */       this.shortLengthTypes[1] = (ITypeBinaryExtendedNumeric)new TypePackedDecimal9(true);
/* 194 */       this.shortLengthTypes[2] = (ITypeBinaryExtendedNumeric)new TypeIntBigEndian(false, false);
/* 195 */       this.shortLengthTypes[3] = (ITypeBinaryExtendedNumeric)new TypeIntBigEndian(true, false);
/* 196 */       this.shortLengthTypes[4] = (ITypeBinaryExtendedNumeric)new TypeIntBigEndian(true, true);
/* 197 */       this.shortLengthTypes[5] = (ITypeBinaryExtendedNumeric)new TypeIntLittleEndian(false, false);
/* 198 */       this.shortLengthTypes[6] = (ITypeBinaryExtendedNumeric)new TypeIntLittleEndian(true, false);
/* 199 */       this.shortLengthTypes[7] = (ITypeBinaryExtendedNumeric)new TypeIntLittleEndian(true, true);
/*     */       
/* 201 */       this.shortLengthTypes[12] = (ITypeBinaryExtendedNumeric)new TypeZonedAsciiSmall(false);
/* 202 */       this.shortLengthTypes[10] = (ITypeBinaryExtendedNumeric)new TypeZonedEbcdicSmall(false);
/* 203 */       this.shortLengthTypes[11] = (ITypeBinaryExtendedNumeric)new TypeZonedEbcdicSmall(true);
/* 204 */       this.shortLengthTypes[13] = (ITypeBinaryExtendedNumeric)new TypeZonedAsciiSmall(true);
/*     */       
/* 206 */       for (int j = 0; j < this.shortLengthTypes.length; j++) {
/* 207 */         if (this.shortLengthTypes[j] != null) {
/* 208 */           this.types[j + 140] = (Type)this.shortLengthTypes[j];
/*     */         }
/*     */       } 
/*     */       
/* 212 */       this.maxShortSize[0] = 9;
/* 213 */       this.maxShortSize[1] = 9;
/* 214 */       this.maxShortSize[2] = 8;
/* 215 */       this.maxShortSize[3] = 8;
/* 216 */       this.maxShortSize[4] = 7;
/* 217 */       this.maxShortSize[5] = 8;
/* 218 */       this.maxShortSize[6] = 8;
/* 219 */       this.maxShortSize[7] = 7;
/*     */       
/* 221 */       Arrays.fill(this.normalTypetoShortMapping, -1);
/* 222 */       this.normalTypetoShortMapping[31] = 140;
/* 223 */       this.normalTypetoShortMapping[33] = 141;
/* 224 */       this.normalTypetoShortMapping[35] = 142;
/* 225 */       this.normalTypetoShortMapping[39] = 143;
/* 226 */       this.normalTypetoShortMapping[36] = 144;
/* 227 */       this.normalTypetoShortMapping[15] = 145;
/* 228 */       this.normalTypetoShortMapping[23] = 146;
/* 229 */       this.normalTypetoShortMapping[16] = 147;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final int getShortType(int typeId, int length, String charset) {
/* 234 */     return getShortType(typeId, length, getCharsetType(charset));
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getShortType(int typeId, int length, CharsetType charsetType) {
/* 239 */     int t = (typeId < 0 || typeId > this.normalTypetoShortMapping.length) ? -1 : this.normalTypetoShortMapping[typeId];
/*     */     
/* 241 */     if (t > 0 && this.maxShortSize[t - 140] >= length) {
/* 242 */       return t;
/*     */     }
/*     */     
/* 245 */     if (length < 18 && 
/* 246 */       typeId == 32) {
/* 247 */       switch (charsetType) { case SINGLE_BYTE_ASCII:
/* 248 */           return 152;
/* 249 */         case SINGLE_BYTE_EBCDIC: return 150; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 259 */     return typeId;
/*     */   }
/*     */ 
/*     */   
/*     */   public CharsetType getCharsetType(String charset) {
/* 264 */     CharsetType charsetType = CharsetType.OTHER_CHARSET;
/* 265 */     if (Conversion.isSingleByteEbcidic(charset)) {
/* 266 */       charsetType = CharsetType.SINGLE_BYTE_EBCDIC;
/* 267 */     } else if (Conversion.DEFAULT_ASCII_CHARSET.equalsIgnoreCase(charset) || (charset
/* 268 */       .length() == 8 && "ISO-8859-".equalsIgnoreCase(charset.substring(0, 7)))) {
/* 269 */       charsetType = CharsetType.SINGLE_BYTE_ASCII;
/* 270 */     } else if (Conversion.isSingleByte(charset)) {
/*     */       try {
/* 272 */         byte[] b = "09+-.,aAzZ".getBytes(charset);
/* 273 */         if (Arrays.equals(ASCII_NUM_BYTES, b)) {
/* 274 */           charsetType = CharsetType.SINGLE_BYTE_ASCII;
/*     */         }
/* 276 */       } catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 280 */     return charsetType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerType(int typeId, Type typeDef) {
/* 291 */     int idx = getIndex(typeId);
/*     */     
/* 293 */     if (idx == 249) {
/* 294 */       throw new RecordException("Invalid Index Supplied {0} Should be between {1} and {2}", new Object[] {
/*     */             
/* 296 */             Integer.valueOf(typeId), Integer.valueOf(1000), Integer.valueOf(1000 + this.userSize)
/*     */           });
/*     */     }
/* 299 */     this.types[idx] = typeDef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType(int typeId) {
/* 312 */     return this.types[getIndex(typeId)];
/*     */   }
/*     */   
/*     */   public ITypeBinaryExtendedNumeric getShortLengthType(int typeId) {
/* 316 */     int t = typeId - 140;
/* 317 */     return (t >= 0 && t < this.shortLengthTypes.length) ? this.shortLengthTypes[t] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getIndex(int type) {
/* 330 */     int idx = 249;
/*     */     
/* 332 */     if (type >= 0 && type < 250) {
/* 333 */       idx = type;
/* 334 */     } else if (type >= 1000 && type < 1000 + this.userSize) {
/*     */       
/* 336 */       idx = type - 1000 + 250;
/*     */     } 
/*     */     
/* 339 */     return idx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getTypeId(int index) {
/* 348 */     int type = index;
/* 349 */     if (index >= 250) {
/* 350 */       type = index - 250 + 1000;
/*     */     }
/* 352 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeManager getInstance() {
/* 361 */     return systemTypeManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeManager getSystemTypeManager() {
/* 370 */     return systemTypeManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNumeric(int typeId) {
/* 379 */     return getInstance().getType(typeId).isNumeric();
/*     */   }
/*     */   
/*     */   public static boolean isSignLeading(int typeId) {
/* 383 */     Type type = getInstance().getType(typeId);
/* 384 */     return (type.isNumeric() && (!(type instanceof TypeSignSeparate) || ((TypeSignSeparate)type)
/*     */       
/* 386 */       .isLeadingSign()));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isBinary(int typeId) {
/* 391 */     Type type = getInstance().getType(typeId);
/* 392 */     return (type.isNumeric() && type instanceof TypeNum && ((TypeNum)type).isBinary());
/*     */   }
/*     */   
/*     */   public static boolean isPackedDecimal(int typeId) {
/* 396 */     return (typeId == 31 || typeId == 140 || typeId == 33 || typeId == 141);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasFloatingDecimal(int typeId) {
/* 405 */     Type type = getInstance().getType(typeId);
/* 406 */     return (type instanceof TypeNum && ((TypeNum)type).hasFloatingDecimal());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setSystemTypeManager(TypeManager pSystemTypeManager) {
/* 416 */     systemTypeManager = pSystemTypeManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getNumberOfTypes() {
/* 421 */     return this.types.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getUserSize() {
/* 429 */     return this.userSize;
/*     */   }
/*     */ }

