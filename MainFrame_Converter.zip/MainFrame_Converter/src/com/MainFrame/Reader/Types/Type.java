package com.MainFrame.Reader.Types;

import com.MainFrame.Reader.Common.IFieldDetail;

public interface Type {
  public static final int BASE_16 = 16;
  
  public static final int USER_RANGE_START = 1000;
  
  public static final int DEFAULT_USER_RANGE_SIZE = 75;
  
  public static final int LAST_SYSTEM_TYPE = 250;
  
  public static final int NULL_INT = -121;
  
  public static final int ftChar = 0;
  
  public static final int ftCharRightJust = 1;
  
  public static final int ftCharNullTerminated = 2;
  
  public static final int ftCharNullPadded = 3;
  
  public static final int ftHex = 4;
  
  public static final int ftNumLeftJustified = 5;
  
  public static final int ftNumRightJustified = 6;
  
  public static final int ftNumZeroPadded = 7;
  
  public static final int ftAssumedDecimal = 8;
  
  public static final int ftSignSeparateLead = 9;
  
  public static final int ftSignSeparateTrail = 10;
  
  public static final int ftSignSepLeadActualDecimal = 44;
  
  public static final int ftSignSepTrailActualDecimal = 45;
  
  public static final int ftDecimal = 11;
  
  public static final int ftBinaryInt = 15;
  
  public static final int ftPostiveBinaryInt = 16;
  
  public static final int ftFloat = 17;
  
  public static final int ftDouble = 18;
  
  public static final int ftNumAnyDecimal = 19;
  
  public static final int ftPositiveNumAnyDecimal = 20;
  
  public static final int ftBit = 21;
  
  public static final int ftAssumedDecimalPositive = 22;
  
  public static final int ftBinaryIntPositive = 23;
  
  public static final int ftNumZeroPaddedPN = 24;
  
  public static final int ftNumZeroPaddedPositive = 25;
  
  public static final int ftNumCommaDecimal = 26;
  
  public static final int ftNumCommaDecimalPN = 27;
  
  public static final int ftNumCommaDecimalPositive = 28;
  
  public static final int ftNumRightJustifiedPN = 29;
  
  public static final int ftPackedDecimal = 31;
  
  public static final int ftZonedNumeric = 32;
  
  public static final int ftPackedDecimalPostive = 33;
  
  public static final int ftBinaryBigEndian = 35;
  
  public static final int ftBinaryBigEndianPositive = 39;
  
  public static final int ftPositiveBinaryBigEndian = 36;
  
  public static final int ftRmComp = 37;
  
  public static final int ftRmCompPositive = 38;
  
  public static final int ftFjZonedNumeric = 41;
  
  public static final int ftNumRightJustCommaDp = 42;
  
  public static final int ftNumRightJustCommaDpPN = 43;
  
  public static final int ftGnuCblZonedNumeric = 46;
  
  @Deprecated
  public static final int ftCharMultiLine = 51;
  
  public static final int ftDate = 71;
  
  public static final int ftDateYMD = 72;
  
  public static final int ftDateYYMD = 73;
  
  public static final int ftDateDMY = 74;
  
  public static final int ftDateDMYY = 75;
  
  public static final int ftCharRestOfFixedRecord = 80;
  
  public static final int ftCharRestOfRecord = 81;
  
  public static final int ftCharNoTrim = 82;
  
  public static final int ftProtoField = 91;
  
  public static final int ftAvroField = 91;
  
  public static final int ftArrayField = 92;
  
  public static final int ftComboItemField = 93;
  
  public static final int ftAvroUnionField = 94;
  
  public static final int ftCheckBoxY = 109;
  
  public static final int ftCheckBoxTrue = 110;
  
  public static final int ftCheckBoxYN = 111;
  
  public static final int ftCheckBoxTF = 112;
  
  public static final int ftCheckBoxBoolean = 114;
  
  public static final int ftCsvArray = 115;
  
  public static final int ftXmlNameTag = 116;
  
  public static final int ftMultiLineEdit = 117;
  
  public static final int ftMultiLineChar = 118;
  
  public static final int ftHtmlField = 119;
  
  public static final int ftRecordEditorType = 130;
  
  public static final int ftNumOrEmpty = 131;
  
  public static final int ftPackedDecimalSmall = 140;
  
  public static final int ftPackedDecimalSmallPostive = 141;
  
  public static final int ftIntBigEndianSmall = 142;
  
  public static final int ftIntBigEndianPositive = 143;
  
  public static final int ftUIntBigEndianSmall = 144;
  
  public static final int ftIntSmall = 145;
  
  public static final int ftIntPositiveSmall = 146;
  
  public static final int ftUIntSmall = 147;
  
  public static final int ftZonedEbcdicSmall = 150;
  
  public static final int ftZonedEbcdicSmallPositive = 151;
  
  public static final int ftZonedAsciiSmall = 152;
  
  public static final int ftZonedAsciiSmallPositive = 153;
  
  public static final int NT_TEXT = 1;
  
  public static final int NT_DATE = 11;
  
  public static final int NT_NUMBER = 21;
  
  Object getField(byte[] paramArrayOfbyte, int paramInt, IFieldDetail paramIFieldDetail);
  
  byte[] setField(byte[] paramArrayOfbyte, int paramInt, IFieldDetail paramIFieldDetail, Object paramObject);
  
  String formatValueForRecord(IFieldDetail paramIFieldDetail, String paramString);
  
  boolean isBinary();
  
  boolean isNumeric();
  
  int getFieldType();
  
  char getDecimalChar();
}

