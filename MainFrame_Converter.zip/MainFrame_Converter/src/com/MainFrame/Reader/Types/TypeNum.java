/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.math.RoundingMode;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Arrays;
/*     */ import com.MainFrame.Reader.Common.AbstractIndexedLine;
/*     */ import com.MainFrame.Reader.Common.CommonBits;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ import com.MainFrame.Reader.Common.RecordException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeNum
/*     */   extends TypeChar
/*     */ {
/*     */   public static final byte HIGH_NYBLE = -16;
/*     */   public static final byte ZONED_POSITIVE_NYBLE_AND = -49;
/*     */   public static final byte ZONED_NEGATIVE_NYBLE_AND = -33;
/*     */   public static final byte ZONED_NEGATIVE_NYBLE_VALUE1 = -48;
/*     */   public static final byte ZONED_POSITIVE_NYBLE_VALUE1 = -64;
/*     */   public static final byte ZONED_NEGATIVE_NYBLE_VALUE2 = -128;
/*     */   public static final byte ZONED_POSITIVE_NYBLE_VALUE2 = -112;
/*     */   private final boolean couldBeHexZero;
/*     */   private final boolean adjustTheDecimal;
/*     */   protected final boolean couldBeEmpty;
/*     */   private final boolean couldBeLong;
/*     */   private final boolean positive;
/*     */   private final boolean usePositiveSign;
/*     */   private final String padChar;
/*     */   private final char decimalPoint;
/*     */   private final int typeIdentifier;
/*     */   
/*     */   public TypeNum(int typeId) {
/* 118 */     this(typeId, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeNum(int typeId, boolean isPositive) {
/* 127 */     this(typeId, isPositive, '.');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeNum(int typeId, boolean isPositive, char decimalPoint) {
/* 136 */     super((typeId == 5), false, true);
/*     */     
/* 138 */     boolean adjDecimal = false;
/* 139 */     this.couldBeHexZero = false;
/* 140 */     setNumeric(true);
/* 141 */     this.positive = isPositive;
/* 142 */     this.decimalPoint = decimalPoint;
/*     */     
/* 144 */     this.typeIdentifier = typeId;
/*     */     
/* 146 */     boolean usePositiveSign = false;
/* 147 */     String padChar = " ";
/* 148 */     switch (typeId) {
/*     */       case 29:
/*     */       case 43:
/* 151 */         usePositiveSign = true;
/*     */         break;
/*     */       case 24:
/*     */       case 27:
/* 155 */         usePositiveSign = true;
/* 156 */         padChar = "0";
/*     */         break;
/*     */       case 8:
/*     */       case 22:
/* 160 */         adjDecimal = true;
/* 161 */         padChar = "0";
/*     */         break;
/*     */       case 7:
/*     */       case 25:
/*     */       case 26:
/*     */       case 28:
/* 167 */         padChar = "0";
/*     */         break;
/*     */     } 
/* 170 */     this.padChar = padChar;
/* 171 */     this.usePositiveSign = usePositiveSign;
/* 172 */     this.adjustTheDecimal = adjDecimal;
/* 173 */     this.couldBeEmpty = false;
/*     */     
/* 175 */     this.couldBeLong = (typeId != 5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeNum(boolean leftJustified, boolean adjustDecimal, boolean couldBeALong, boolean isPositive, boolean binary, boolean couldBeHexHero, boolean numCouldBeEmpty) {
/* 205 */     super(leftJustified, binary, true);
/* 206 */     this.adjustTheDecimal = adjustDecimal;
/* 207 */     this.couldBeLong = couldBeALong;
/* 208 */     this.positive = isPositive;
/* 209 */     this.couldBeHexZero = couldBeHexHero;
/* 210 */     this.couldBeEmpty = numCouldBeEmpty;
/* 211 */     this.decimalPoint = '.';
/* 212 */     this.usePositiveSign = false;
/* 213 */     this.typeIdentifier = 0;
/* 214 */     this.padChar = " ";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail currField) {
/* 231 */     String s = "";
/*     */     
/* 233 */     if (!isHexZero(record, position, currField.getLen())) {
/* 234 */       s = super.getField(record, position, currField).toString();
/*     */     }
/*     */     
/* 237 */     return addDecimalPoint(s, currField.getDecimal());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isDefined(AbstractIndexedLine line, byte[] record, IFieldDetail currField) {
/* 247 */     int pos = currField.calculateActualPosition(line);
/* 248 */     return (record.length >= pos + currField.getLen() && (this.couldBeHexZero || 
/* 249 */       !isHexZero(record, pos, currField.getLen())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String addDecimalPoint(String s, int decimal) {
/* 262 */     String sign = "";
/*     */     
/* 264 */     if (decimal != 0 && this.adjustTheDecimal && 
/*     */       
/* 266 */       !s.endsWith(" ") && Conversion.isInt(s)) {
/* 267 */       if (s.startsWith("-")) {
/* 268 */         s = s.substring(1);
/* 269 */         sign = "-";
/*     */       }
/* 271 */       else if (s.startsWith("+")) {
/* 272 */         s = s.substring(1);
/*     */       } 
/*     */ 
/*     */       
/* 276 */       if (decimal > 0) {
/* 277 */         if (s.length() <= decimal) {
/* 278 */           StringBuilder b = new StringBuilder();
/* 279 */           char[] z = new char[decimal - s.length() + 1];
/* 280 */           Arrays.fill(z, '0');
/* 281 */           s = b.append(z).append(s).toString();
/*     */         } 
/* 283 */         int len = s.length();
/*     */ 
/*     */         
/* 286 */         s = sign + Conversion.numTrim(s.substring(0, len - decimal)) + Conversion.getDecimalchar() + s.substring(len - decimal);
/*     */       } else {
/* 288 */         StringBuilder b = new StringBuilder(s);
/* 289 */         char[] z = new char[-decimal];
/* 290 */         Arrays.fill(z, '0');
/* 291 */         s = Conversion.numTrim(b.append(z).toString());
/*     */       } 
/* 293 */     } else if (s.length() > 0) {
/* 294 */       s = Conversion.numTrim(s);
/*     */     } 
/* 296 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 317 */     return setFieldToVal(record, position, field, checkValue(field, toNumberString(value)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final byte[] setFieldToVal(byte[] record, int position, IFieldDetail field, String val) {
/* 326 */     int len = field.getLen();
/* 327 */     int pos = position - 1;
/* 328 */     String font = field.getFontName();
/*     */     
/* 330 */     if (val == null) {
/* 331 */       val = "";
/*     */     }
/*     */     
/* 334 */     if (val.length() > 0) {
/* 335 */       String v = Conversion.numTrim(val, this.decimalPoint);
/* 336 */       if (v.length() == 0 || v.charAt(0) == '.' || v.charAt(0) == ',' || v.charAt(0) == this.decimalPoint) {
/* 337 */         v = '0' + v;
/*     */       }
/* 339 */       val = v;
/*     */     } 
/*     */     
/* 342 */     checkCharNumLength(val, len);
/*     */     
/* 344 */     if (this.padChar.equals("0") && val.startsWith("-")) {
/* 345 */       copyRightJust(record, val.substring(1), pos, len, "0", font);
/* 346 */       record[pos] = Conversion.getBytes("-", font)[0];
/* 347 */     } else if (this.padChar.equals("0") && this.usePositiveSign && val.length() < len) {
/* 348 */       if (val.startsWith("+")) {
/* 349 */         val = val.substring(1);
/*     */       }
/* 351 */       copyRightJust(record, val, pos, len, "0", font);
/* 352 */       record[pos] = Conversion.getBytes("+", font)[0];
/* 353 */     } else if (this.typeIdentifier == 5) {
/* 354 */       System.arraycopy(getBytes(val, font), 0, record, pos, val.length());
/* 355 */       padWith(record, pos + val.length(), len - val.length(), " ", font);
/* 356 */     } else if (this.padChar.equals(" ") && this.usePositiveSign) {
/* 357 */       if (!val.startsWith("+") && !val.startsWith("-") && val.length() < len) {
/* 358 */         val = "+" + val;
/*     */       }
/* 360 */       copyRightJust(record, val, pos, len, " ", font);
/*     */     } else {
/* 362 */       copyRightJust(record, val, pos, len, this.padChar, font);
/*     */     } 
/*     */     
/* 365 */     return record;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String formatValueForRecord(IFieldDetail field, String val) {
/* 377 */     String ret = checkValue(field, val);
/* 378 */     if (isBinary()) return ret;
/*     */     
/* 380 */     if (field.getLen() < 0) {
/* 381 */       if (this.usePositiveSign && !ret.startsWith("-") && !ret.startsWith("+")) {
/* 382 */         ret = "+" + ret;
/*     */       }
/* 384 */       return ret;
/*     */     } 
/* 386 */     int diff = ret.length() - Math.max(0, field.getLen());
/*     */     
/* 388 */     if (this.padChar.equals("0") && ret.startsWith("-")) {
/* 389 */       ret = padStr(ret.substring(1), field.getLen(), '-', '0');
/* 390 */     } else if (diff != 0) {
/*     */       
/* 392 */       if (diff > 0) {
/* 393 */         if (!ret.startsWith("-"))
/*     */         {
/*     */           
/* 396 */           ret = ret.substring(diff);
/*     */         }
/* 398 */       } else if (this.padChar.equals("0")) {
/* 399 */         char sign = '0';
/* 400 */         if (this.usePositiveSign) {
/* 401 */           sign = '+';
/*     */         }
/*     */         
/* 404 */         ret = padStr(ret, field.getLen(), sign, '0');
/* 405 */       } else if (this.typeIdentifier == 5) {
/* 406 */         ret = ret + Conversion.getCharArray(-diff, ' ');
/* 407 */       } else if (this.padChar.equals(" ") && this.usePositiveSign && !ret.startsWith("+") && !ret.startsWith("-")) {
/* 408 */         StringBuilder b = new StringBuilder();
/* 409 */         if (diff < -1) {
/* 410 */           b.append(Conversion.getCharArray(-diff - 1, ' '));
/*     */         }
/* 412 */         ret = b.append('+').append(ret).toString();
/*     */       } else {
/* 414 */         ret = Conversion.getCharArray(-diff, ' ') + ret;
/*     */       } 
/*     */     } 
/* 417 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String padStr(String s, int len, char firstCh, char padCh) {
/* 434 */     char[] c = new char[len];
/* 435 */     int toIndex = 0;
/*     */     
/* 437 */     c[0] = firstCh;
/* 438 */     if (len > s.length()) {
/* 439 */       toIndex = len - s.length();
/* 440 */       Arrays.fill(c, 1, toIndex, padCh);
/*     */     } 
/* 442 */     System.arraycopy(s.toCharArray(), 0, c, toIndex, s.length());
/* 443 */     return new String(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String checkValue(IFieldDetail field, String value) throws RecordException {
/* 450 */     String val = value;
/* 451 */     if (this.couldBeEmpty && (val == null || val.trim().length() == 0)) {
/* 452 */       return "";
/*     */     }
/* 454 */     if (val == null || val == CommonBits.NULL_VALUE) {
/* 455 */       val = "0";
/*     */     }
/* 457 */     int decimal = field.getDecimal();
/*     */ 
/*     */     
/* 460 */     if (decimal == 0 && this.couldBeLong && val.indexOf('e') < 0 && val.indexOf('E') < 0) {
/*     */       try {
/* 462 */         val = val.trim();
/* 463 */         if (val.startsWith("+")) {
/* 464 */           val = val.substring(1);
/*     */         }
/* 466 */         if (val.lastIndexOf('.') >= 0)
/*     */         {
/*     */           
/* 469 */           val = val.substring(0, val.lastIndexOf('.'));
/*     */         }
/* 471 */         new BigInteger(val);
/* 472 */       } catch (Exception ex) {
/* 473 */         ex.printStackTrace();
/* 474 */         throw new RecordException(field.getName() + " Invalid Integer :" + val + ": ~ " + ex);
/*     */       } 
/*     */     } else {
/*     */       
/*     */       try {
/* 479 */         BigDecimal decimalVal = new BigDecimal(Conversion.numTrim(val));
/*     */         
/* 481 */         NumberFormat nf = getNumberFormat();
/* 482 */         nf.setGroupingUsed(false);
/* 483 */         if ((decimal != 0 && this.adjustTheDecimal) || decimal < 0) {
/* 484 */           decimalVal = adjustForDecimal(field, decimalVal);
/*     */ 
/*     */           
/* 487 */           nf.setMaximumFractionDigits(0);
/*     */         } else {
/* 489 */           nf.setMaximumFractionDigits(decimal);
/* 490 */           nf.setMinimumFractionDigits(decimal);
/*     */         } 
/* 492 */         nf.setRoundingMode(RoundingMode.DOWN);
/* 493 */         val = nf.format(decimalVal);
/* 494 */       } catch (Exception ex) {
/* 495 */         throw new RecordException("Invalid Number: " + ex.getMessage());
/*     */       } 
/*     */     } 
/*     */     
/* 499 */     if (this.positive && val.indexOf('-') >= 0) {
/* 500 */       throw new RecordException("Only positive numbers are allowed: " + value + " ~ " + val);
/*     */     }
/* 502 */     return val;
/*     */   }
/*     */   
/*     */   public final String toNumberString(Object value) {
/* 506 */     if (value == null || value == CommonBits.NULL_VALUE) {
/* 507 */       return "0";
/*     */     }
/* 509 */     return value.toString();
/*     */   }
/*     */   
/*     */   public boolean hasFloatingDecimal() {
/* 513 */     return false;
/*     */   }
/*     */   
/*     */   protected NumberFormat getNumberFormat() {
/* 517 */     return Conversion.getNumberformat();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BigDecimal getBigDecimal(IFieldDetail field, String val) {
/* 530 */     return adjustForDecimal(field, new BigDecimal(Conversion.numTrim(val)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BigDecimal adjustForDecimal(IFieldDetail field, BigDecimal decimalVal) {
/* 540 */     if (field.getDecimal() != 0 && this.adjustTheDecimal)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 547 */       decimalVal = decimalVal.scaleByPowerOfTen(field.getDecimal());
/*     */     }
/*     */     
/* 550 */     return decimalVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkCharNumLength(String val, int length) throws RecordException {
/* 563 */     if (val.length() > length) {
/* 564 */       throw new RecordException("Value {0} is to big !! {1} > {2}", new Object[] { val, 
/*     */             
/* 566 */             Integer.valueOf(val.length()), Integer.valueOf(length) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPositive() {
/* 579 */     return this.positive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPadChar() {
/* 586 */     return this.padChar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFieldType() {
/* 593 */     return 21;
/*     */   }
/*     */ 
/*     */   
/*     */   protected long getRmComp(byte[] record, int position, int len) {
/* 598 */     long retL = 0L;
/*     */     
/* 600 */     position--;
/* 601 */     if (record != null && record.length >= position) {
/* 602 */       int en = position + Math.min(len, record.length - position);
/*     */       int i;
/* 604 */       for (i = position; i < en; i++) {
/* 605 */         retL = record[i] + retL * 10L;
/*     */       }
/*     */       
/* 608 */       if (len > record.length - position) {
/* 609 */         for (i = len - record.length + position; i > 0; i--) {
/* 610 */           retL *= 10L;
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 615 */     return retL;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] setRmComp(byte[] record, int position, int len, long value) {
/* 621 */     for (int i = len - 1; i >= 0; i--) {
/* 622 */       int ii = (int)value % 10;
/* 623 */       record[position + i - 1] = (byte)ii;
/* 624 */       value /= 10L;
/*     */     } 
/*     */     
/* 627 */     return record;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final BigInteger formatAsBigInt(IFieldDetail field, Object value) {
/*     */     BigInteger v;
/* 633 */     if (value == null || value == CommonBits.NULL_VALUE) {
/* 634 */       v = BigInteger.ZERO;
/* 635 */     } else if (field.getDecimal() == 0 && value instanceof BigInteger) {
/* 636 */       v = checkPositive((BigInteger)value);
/* 637 */     } else if (value instanceof BigDecimal) {
/* 638 */       v = checkPositive(adjustForDecimal(field, (BigDecimal)value).toBigInteger());
/*     */     } else {
/* 640 */       String val = toNumberString(value);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 645 */       v = new BigInteger(checkValue(field, val));
/*     */     } 
/*     */     
/* 648 */     return v;
/*     */   }
/*     */   
/*     */   private BigInteger checkPositive(BigInteger v) throws RecordException {
/* 652 */     if (isPositive() && v.compareTo(BigInteger.ZERO) < 0) {
/* 653 */       throw new RecordException("Only positive numbers are allowed");
/*     */     }
/* 655 */     return v;
/*     */   }
/*     */ }

