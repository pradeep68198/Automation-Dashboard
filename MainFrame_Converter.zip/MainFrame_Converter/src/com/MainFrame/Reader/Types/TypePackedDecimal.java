/*     */ package com.MainFrame.Reader.Types;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypePackedDecimal
/*     */   extends TypeNum
/*     */ {
/*     */   public TypePackedDecimal() {
/*  68 */     super(false, true, true, false, true, false, false);
/*     */   }
/*     */   
/*     */   public TypePackedDecimal(boolean positive) {
/*  72 */     super(false, true, true, positive, true, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getField(byte[] record, int position, IFieldDetail field) {
/*  81 */     int pos = position - 1;
/*  82 */     int end = position + field.getLen() - 1;
/*  83 */     int min = Math.min(end, record.length);
/*  84 */     int fldLength = min - pos;
/*     */     
/*  86 */     String s = Conversion.getMainframePackedDecimal(record, pos, fldLength);
/*     */ 
/*     */ 
/*     */     
/*  90 */     return addDecimalPoint(s, field.getDecimal());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object value) {
/* 103 */     int pos = position - 1;
/* 104 */     int len = field.getLen();
/*     */     
/* 106 */     String val = checkValue(field, toNumberString(value));
/* 107 */     if (val.startsWith("-")) {
/* 108 */       val = val.substring(1) + "D";
/* 109 */     } else if (isPositive()) {
/* 110 */       val = val + "F";
/*     */     } else {
/* 112 */       val = val + "C";
/*     */     } 
/*     */ 
/*     */     
/* 116 */     Conversion.setBigInt(record, pos, len, new BigInteger(val, 16), true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     return record;
/*     */   }
/*     */ }

