
package com.MainFrame.Reader.Details;

import java.util.ArrayList;

public class CsvLine extends ListLine {


	public CsvLine(LayoutDetail layoutDetails, String s) {
		this(layoutDetails);
		
		setData(s);
	}


	public CsvLine(LayoutDetail layoutDetails) {
		super(layoutDetails);
		
		if (! layoutDetails.isCsvLayout()) {
			throw new RuntimeException("Layout must be a CsvLayout !!!");
		}
	}

	@Override
	public byte[] getData() {
		RecordDetail record = layout.getRecord( getPrefIdx());
		
		return record
				.getCsvByteParser()
					.formatFieldListByte(
						fields, record, record.getFieldTypes());
	}


	@Override
	public String getFullLine() {
		RecordDetail record = layout.getRecord( getPrefIdx());
		
		return record
				.getParser()
				.formatFieldList(
						fields, record, record.getFieldTypes());
	}
	
	@Override
	public void setData(String newVal) {
		RecordDetail record = layout.getRecord(getPrefIdx());

		fields = new ArrayList<Object>(
				record.getParser().getFieldList(newVal, record));
	}

	
	

	@Override
	public void setData(byte[] newVal) {
		RecordDetail record = layout.getRecord(getPrefIdx());

		fields = new ArrayList<Object>(
					record.getCsvByteParser().getFieldList(newVal, record));
	}


	@Override
	protected final int getAdj() {
		return 1;
	}


	private int getPrefIdx() {
		int idx = getPreferredLayoutIdx();
		if (idx < 0 || idx >= layout.getRecordCount()) {
			idx = 0;
		}
		return idx;
	}
}
