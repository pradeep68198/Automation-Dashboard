
package com.MainFrame.Reader.Details;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.MainFrame.Reader.Common.CommonBits;
import com.MainFrame.Reader.Common.Constants;
import com.MainFrame.Reader.Common.Conversion;
import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Common.IBasicFileSchema;
import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Common.RecordException;
import com.MainFrame.Reader.CsvParser.ICsvCharLineParser;
import com.MainFrame.Reader.CsvParser.ICsvDefinition;
import com.MainFrame.Reader.IO.builders.recordDeciders.SingleFieldDecider;
import com.MainFrame.Reader.CsvParser.CsvDefinition;
import com.MainFrame.Reader.CsvParser.ICsvByteLineParser;
import com.MainFrame.Reader.CsvParser.CsvParserManagerChar;
import com.MainFrame.Reader.CsvParser.CsvParserManagerByte;
import com.MainFrame.Reader.Option.IRecordPositionOption;
import com.MainFrame.Reader.Option.Options;
import com.MainFrame.Reader.Types.Type;
import com.MainFrame.Reader.Types.TypeManager;
import com.MainFrame.Reader.cgen.def.ILayoutDetails4gen;
import com.MainFrame.Reader.detailsBasic.CsvCharDetails;
import com.MainFrame.Reader.detailsBasic.IItemDetails;





public class LayoutDetail implements IBasicFileSchema, ILayoutDetails4gen {
	

	private String layoutName;
	private String description;
	private byte[] recordSep;
	private final int layoutType;
	private RecordDetail[] records;
	private boolean binary = false, binaryField=false;
	private String fontName = "";
	private String eolString;
	//private TypeManager typeManager;
	private final RecordDecider decider;

	private HashMap<String, IFieldDetail> fieldNameMap = null;
	private HashMap<String, IFieldDetail> recordFieldNameMap = null;
	private HashSet<String> duplicateFieldNames = null;
	
	private CsvCharDetails delimiter;
	private int fileStructure;

	private int recordCount;
	
	private boolean treeStructure = false;

	private final boolean multiByteCharset, csvLayout, headerTrailerRecords;
	
	private final byte spaceByte, initByte ;
	
	private final int maxPossibleLength, minPossibleLength;
	

	private Map<String, List<IItemDetails>> groupMap, groupFieldMap;
	
	
	public LayoutDetail(final String pLayoutName,
	        		   final RecordDetail[] pRecords,
	        		   final String pDescription,
	        		   final int pLayoutType,
	        		   final byte[] pRecordSep,
	        		   final String pEolIndicator,
	        		   final String pFontName,
	        		   final RecordDecider pRecordDecider,
	        		   final int pFileStructure) 
	{
		this(	pLayoutName, pRecords, pDescription, pLayoutType, pRecordSep, pEolIndicator, 
				pFontName, pRecordDecider, pFileStructure, null, false, -1);
	}
	
	public LayoutDetail(final String pLayoutName,
 		   final RecordDetail[] pRecords,
 		   final String pDescription,
 		   final int pLayoutType,
 		   final byte[] pRecordSep,
 		   final String pEolIndicator,
 		   final String pFontName,
 		   		 RecordDecider pRecordDecider,
 		   final int pFileStructure,
 		   final IRecordPositionOption rpOpt,
 		         boolean  initToSpaces,
 		         int recordLength) {
	    super();

        int i, j;
        boolean first = true;
        //int lastSize = -1;


	    this.layoutName    = pLayoutName;
		this.records       = pRecords;
		this.description   = pDescription;
		this.layoutType    = pLayoutType;
		this.recordSep     = pRecordSep;
		this.fontName      = pFontName;
		//this.decider       = pRecordDecider;
		this.fileStructure = CommonBits.translateFileStructureToNotAskFont(pFileStructure);
		this.recordCount   = pRecords.length;
//		this.setDecider(pRecordDecider);
		

		if (fontName == null) {
		    fontName = "";
		}
		this.multiByteCharset = Conversion.isMultiByte(fontName);
		byte[] t = Conversion.getBytes(" ", fontName);
		if (t.length == 1) {
			this.spaceByte = t[0];
		} else {
			this.spaceByte = 0;
		}
		
		initByte = initToSpaces? spaceByte: 0;

		while (recordCount > 0 && pRecords[recordCount - 1] == null) {
		    recordCount -= 1;
		}

		if (recordSep == null) {
			if ("".equals(fontName)) {
				recordSep = Constants.SYSTEM_EOL_BYTES;
			} else {
				recordSep = CommonBits.getEolBytes(null, "", fontName);
			}
			
			recordSep = CommonBits.getEolBytes(recordSep, pEolIndicator, fontName);
		}

		if (Constants.DEFAULT_STRING.equals(pEolIndicator)
		||  pRecordSep == null) {
		    eolString = System.getProperty("line.separator");
		    if (recordSep != null && recordSep.length < eolString.length()) {
		    	eolString = Conversion.toString(recordSep, pFontName);
		    }
		} else {
		    eolString = Conversion.toString(pRecordSep, pFontName);
		}

	    if (recordCount >= 1) {
	        int numFields;
	        for (j = 0; (! binaryField) && j < recordCount; j++) {
	            numFields =  pRecords[j].getFieldCount();
	            for (i = 0; (! binaryField) && i < numFields; i++) {
	            	binaryField = pRecords[j].isBinary(i);
	            }
	        }
	    }

		switch (pLayoutType) {
			case Constants.rtGroupOfBinaryRecords:
			case Constants.rtFixedLengthRecords:
			case Constants.rtBinaryRecord:
			    binary = true;
			break;
//			case Constants.rtBinaryRecord:
            case Constants.rtGroupOfRecords:
			case Constants.rtRecordLayout:
				binary = binaryField;
			break;
			default:
		}

		boolean csv = false;
		boolean hasFilePosRecords = false;
		
		delimiter = CsvCharDetails.newDelimDefinition("\\t", fontName);
		
	    for (j = 0; j < recordCount; j++) {
	    	RecordDetail record =  pRecords[j];
	    	hasFilePosRecords = hasFilePosRecords || record.getRecordPositionOption() != null;
	    	if ((record.getRecordType() == Constants.rtDelimitedAndQuote
			          || record.getRecordType() == Constants.rtDelimited)) {
	    		csv = true;
	    	}
	    	if (record.getFieldCount() > 0) {
		    	treeStructure = treeStructure || (record.getParentRecordIndex() >= 0);
		        CsvCharDetails recordDelimiter = record.getDelimiterDetails();
				if ((record.getRecordType() == Constants.rtDelimitedAndQuote
		          || record.getRecordType() == Constants.rtDelimited)
		        &&  (!delimiter.equals(recordDelimiter))) {
//		        	fixedLength = false;
		            if (first) {
		                delimiter = recordDelimiter;
		                first = false;
		            } else if (! delimiter.equals(recordDelimiter)) {
		                throw new RuntimeException(
		                        	"only one field delimiter may be used in a Detail-Group "
		                        +   "you have used \'" + delimiter
		                        +   "\' and \'"
		                        +  recordDelimiter.jrDefinition() + "\'"
		                );
		            }
		        }
	    	}
	    }
		

	    //List<E>
	    int maxSize = 0;
	    int minSize = recordCount > 0 ? Integer.MAX_VALUE: 0;
		for (i = 0; i < recordCount; i++) {
			maxSize = java.lang.Math.max(maxSize, records[i].getLength());
			minSize = java.lang.Math.min(minSize, records[i].getMinumumPossibleLength());
		}
		maxPossibleLength = recordLength>= 0 ? recordLength : maxSize;
		minPossibleLength = minSize;

	    this.headerTrailerRecords = hasFilePosRecords;
	    csvLayout = csv;
	    
//	    this.setDecider(pRecordDecider);
		if (pRecordDecider != null && pRecordDecider instanceof IRecordDeciderX) {
			if (pRecordDecider instanceof SingleFieldDecider) {
				try {
					pRecordDecider = (RecordDecider) ((SingleFieldDecider) pRecordDecider).clone();
				} catch (CloneNotSupportedException e) {
				}
			}
			((IRecordDeciderX) pRecordDecider).setLayout(this);
		}
		this.decider       = pRecordDecider;
	}


	
	public FieldDetail getField(final int layoutIdx, final int fieldIdx) {
		return records[layoutIdx].getField(fieldIdx);
	}

	
	
	public String[] getFieldDescriptions(final int layoutIdx, int columnsToSkip) {
	    if (layoutIdx >= recordCount) {
	        return null;
	    }
	    RecordDetail rec = records[layoutIdx];
		String[] ret = new String[rec.getFieldCount() - columnsToSkip];
		int i, idx;

		for (i = 0; i < rec.getFieldCount() - columnsToSkip; i++) {
		    idx = getAdjFieldNumber(layoutIdx, i + columnsToSkip);
			ret[i] = rec.getField(idx).getDescription();
			if (ret[i] == null || "".equals(ret[i])) {
			    ret[i] = rec.getField(idx).getName();
			}
		}

		return ret;
	}


	
	public String getDescription() {
		return description;
	}


	
	public String getLayoutName() {
		return layoutName;
	}

	/**
	 
	 * @deprecated use getRecordsAsList or getRecord instead
	 */
	public RecordDetail[] getRecords() {
		return records;
	}
	
	public List<RecordDetail> getRecordsAsList() {
		return Collections.unmodifiableList(
						Arrays.asList(records)
		);
	}

	
	public void addRecord(RecordDetail record) {
	    if (recordCount >= records.length) {
	    	RecordDetail[] temp = records;
	        records = new RecordDetail[recordCount + 5];
	        System.arraycopy(temp, 0, records, 0, temp.length);
	        recordCount = temp.length;
	    }
	    records[recordCount] = record;
	    recordCount += 1;
	}


	
	public RecordDetail getRecord(int recordNum) {
	    if (recordNum < 0 || records.length == 0) {
	        return null;
	    }
		return records[recordNum];
	}

	
	public RecordDetail getRecord(String recordName) {
		if (recordName == null) {
			throw new RuntimeException("Record name can not be null");
		}
		for (RecordDetail rec : records) {
			 if (recordName.equalsIgnoreCase(rec.getRecordName())) {
				 return rec;
			 }
		}
		throw new RuntimeException("Record: " + recordName + " was not found");
	}
	
	
	public int getRecordCount() {
		return recordCount;
	}


	
	public int getLayoutType() {
		return layoutType;
	}



	
	public byte[] getRecordSep() {
		return recordSep;
	}


	
    public boolean isBinary() {
        return binary ;
    }


	@Override
	public boolean useByteRecord() {
		
		switch (fileStructure) {
		case Constants.IO_BIN_TEXT:
		case Constants.IO_FIXED_LENGTH:
			return true;
		}
		return binary;
	}

	
	public final boolean hasHeaderTrailerRecords() {
		return headerTrailerRecords;
	}
	
	public SpecialRecordIds getPositionRecordId() {
		int h=-1, m=-1, t=-1;
		for (int i = 0; i < recordCount; i++) {
			if (getRecord(i).getRecordPositionOption() == Options.RP_FIRST_RECORD_IN_FILE) {
				h = i;
			} else if (getRecord(i).getRecordPositionOption() == Options.RP_MIDDLE_RECORDS) {
				m = i;
			} else if (getRecord(i).getRecordPositionOption() == Options.RP_LAST_RECORD_IN_FILE) {
				t = i;
			}
		}	
		return new SpecialRecordIds(h, m, t);
	}
	
    public final boolean hasBinaryField() {
		return binaryField;
	}

    
    public String getFontName() {
        return fontName;
    }

    

//    @Override
//	public String getQuote() {
//		return records[0].getQuote();
//	}
//

	@Override
	public CsvCharDetails getQuoteDetails() {
		return records[0].getQuoteDefinition();
	}

	
    public String getEolString() {
        return eolString;
    }


    
    public int getMaximumRecordLength() {
    	return maxPossibleLength;
//        int i;
//        int maxSize = 0;
//		for (i = 0; i < recordCount; i++) {
//			maxSize = java.lang.Math.max(maxSize, records[i].getLength());
//		}
//
//		return maxSize;
    }

    public int getMinimumRecordLength() {
    	return minPossibleLength;
//        int i;
//        int maxSize = 0;
//		for (i = 0; i < recordCount; i++) {
//			maxSize = java.lang.Math.max(maxSize, records[i].getLength());
//		}
//
//		return maxSize;
    }

    
    public int getFileStructure() {
        int ret;// = fileStructure;

        if (fileStructure == Constants.IO_NAME_1ST_LINE &&  isBinCSV()) {
        	ret = Constants.IO_BIN_NAME_1ST_LINE;
        } else if (fileStructure > Constants.IO_TEXT_LINE) {
        	ret = fileStructure;
        } else if (fileStructure == Constants.IO_TEXT_LINE) {
			ret = checkTextType();
        } else if (getLayoutType() == Constants.rtGroupOfBinaryRecords
               &&  recordCount > 1) {
		    ret = Constants.IO_BINARY_IBM_4680;
		} else if (isBinary()) {
		    ret = Constants.IO_FIXED_LENGTH;
		} else if ( isBinCSV()) {
			ret = Constants.IO_BIN_TEXT;
		} else {
			ret = checkTextType();
		}
       //System.out.println(" ~~ getFileStructure " + fileStructure + " " + ret);

		return ret;
    }

    private int checkTextType() {
    	int ret = fileStructure;
    	if ( isBinCSV()) {
			ret = Constants.IO_BIN_TEXT;
		} else if (multiByteCharset) {
    		return Constants.IO_UNICODE_TEXT;
		} else if (fontName != null && ! "".equals(fontName) && ! fontName.equals(Conversion.getDefaultSingleByteCharacterset())){
		    ret = Constants.IO_TEXT_LINE;
		} else {
			ret = Constants.IO_BIN_TEXT;
		}

    	return ret;
	}
    
    public int getRecordIndex(String recordName) {
        int ret = Constants.NULL_INTEGER;
        int i;

        if (recordName != null) {
            for (i = 0; i < recordCount; i++) {
                if (recordName.equalsIgnoreCase(records[i].getRecordName())) {
                    ret = i;
                    break;
                }
            }
        }
        return ret;
    }


    
    public RecordDecider getDecider() {
        return decider;
    }


//    /**
//	 * @param decider the decider to set
//	 */
//	protected final void setDecider(RecordDecider decider) {
//		this.decider = decider;
//		
//		if (decider != null && decider instanceof IRecordDeciderX) {
//			((IRecordDeciderX) decider).setLayout(this);
//		}
//	}


	
    @Deprecated 
    public Object getField(final byte[] record, int type, IFieldDetail field) {

    	//System.out.print(" ---> getField ~ 1");
        if (field.isFixedFormat()) {
            return TypeManager.getSystemTypeManager().getType(type) //field.getType())
					.getField(record, field.getPos(), field);
        }
        return getCsvField(record, type, field);
     }
    
    
    @Deprecated 
    public final Object getCsvField(final byte[] record, int type, IFieldDetail field) {
        if (isBinCSV()) {
        	//System.out.print(" 3 ");
        	ICsvByteLineParser byteLineParser = CsvParserManagerByte.getInstance().get(field.getRecord().getRecordStyle());
        	String value = byteLineParser.getField(field.getPos() - 1, record, 
        			new CsvDefinition(delimiter, field.getQuoteDefinition()));

        	return formatField(field,  type, value);
        } else {
	        return formatCsvField(field,  type, Conversion.toString(record, field.getFontName()));
        }  	
    }

   
    @Deprecated 
    public final Object formatCsvField(IFieldDetail field,  int type, String value) {
        ICsvCharLineParser parser = CsvParserManagerChar.getInstance().get(field.getRecord().getRecordStyle());
        String val = parser.getField(field.getPos() - 1,
        		value,
        		new CsvDefinition(delimiter, field.getQuoteDefinition()));

        return formatField(field,  type, val);
    }


    private Object formatField(IFieldDetail field,  int type, String value) {

        //System.out.print(" ~ " + delimiter + " ~ " + new String(record));

        if (value != null && ! "".equals(value)) {
        	byte[] rec = Conversion.getBytes(value, field.getFontName());
            FieldDetail fldDef
        		= new FieldDetail(field.getName(), "", type,
        		        		   field.getDecimal(), field.getFontName(),
        		        		   field.getFormat(), field.getParamater());

            updateRecordInfo(field, fldDef);

            fldDef.setPosLen(1, rec.length);

//            System.out.println(" ~ " + TypeManager.getSystemTypeManager().getType(type)
//					.getField(Conversion.getBytes(value, font),
//					          1,
//					          fldDef));
            return TypeManager.getSystemTypeManager().getType(type)
					.getField(rec,
					          1,
					          fldDef);
        }
        //System.out.println();

        return "";
    }

	
	public void updateRecordInfo(IFieldDetail field, FieldDetail fldDef) {
		
		fldDef.setRecord(field.getRecord());
	}

    
    @Deprecated
    public byte[] setField(byte[] record, IFieldDetail field, Object value)
    {
        return setField(record, field.getType(), field, value);
    }

    
    @Deprecated
    public byte[] setField(byte[] record, int type, IFieldDetail field, Object value)
    {
        if (field.isFixedFormat()) {
            record = TypeManager.getSystemTypeManager().getType(type)
				.setField(record, field.getPos(), field, value);
        } else  {
            record = setCsvField(record, type, field, value);
        }
        //System.out.println(" ---> setField ~ Done");
        return record;
    }

    public byte[] setCsvField(byte[] record, int type, IFieldDetail field, Object value) {
        

        Type typeVal = TypeManager.getSystemTypeManager().getType(type);
        String s = typeVal.formatValueForRecord(field, value.toString());
        //System.out.println(" ---> setField ~ " + delimiter + " ~ " + s + " ~ " + new String(record));
        CsvDefinition csvDefinition = new CsvDefinition(
        		delimiter, field.getQuoteDefinition(), ICsvDefinition.NORMAL_SPLIT, -1, field.getFontName(), false);
        		
        		//delimiter, field.getQuoteDefinition());
    	ICsvByteLineParser byteLineParser = CsvParserManagerByte.getInstance()
    			.get(field.getRecord().getRecordStyle(), isBinCSV());
    	record = byteLineParser.setFieldByteLine(
					field.getPos() - 1,
        		typeVal.getFieldType(),
        		record,
        		csvDefinition, 
        		s);
//       if  (isBinCSV()) {
//         	//record = (new BinaryCsvParser(delimiter.asByte())).updateValue(record, field, s);
//        	ICsvByteLineParser byteLineParser = CsvParserManagerByte.getInstance().get(field.getRecord().getRecordStyle());
//        	record = byteLineParser.setFieldByteLine(
// 					field.getPos() - 1,
//            		typeVal.getFieldType(),
//            		record,
//            		csvDefinition, 
//            		s);
//        } else {
//            ICsvCharLineParser parser = CsvParserManagerChar.getInstance().get(field.getRecord().getRecordStyle());
//			String font = field.getFontName();
// 			String newLine = parser.setField(
// 					field.getPos() - 1,
//            		typeVal.getFieldType(),
//            		Conversion.toString(record, font),
//            		csvDefinition, 
//            		s);
//
//            record = Conversion.getBytes(newLine, font);
//        }
        
        //System.out.println(" ---> setField ~ Done");
        return record;
    }

    
    public IFieldDetail getFieldFromName(String fieldName) {
    	//IFieldDetail ret = null;
    	String key = fieldName.toUpperCase();

    	buildFieldNameMap();

    	return fieldNameMap.get(key);
     }
    
    public Set<String> getDuplicateFieldNames() {
    	buildFieldNameMap();
    	return duplicateFieldNames;
    }

    private void buildFieldNameMap() {

    	if (fieldNameMap == null) {
    		int i, j, k, size;
    		IFieldDetail fld;
    		String name, nameTmp;

    		size = 0;
    		for (i = 0; i < recordCount; i++) {
    		    size += records[i].getFieldCount();
    		}
    		size = Math.max(16, (size * 4) / 3 + 4);

    		fieldNameMap = new HashMap<String, IFieldDetail>(size);
    		recordFieldNameMap  = new HashMap<String, IFieldDetail>(size);
    		duplicateFieldNames = new HashSet<String>(10);

    		for (i = 0; i < recordCount; i++) {
     			for (j = 0; j < records[i].getFieldCount(); j++) {
    			    fld = records[i].getField(j);
    			    nameTmp = fld.getName();
    			    name = nameTmp;
    			    nameTmp = nameTmp + "~";
    			    k = 1;
    			    while (fieldNameMap.containsKey(name.toUpperCase())) {
    			    	name = nameTmp + k++;
    			    }
			    	String ucFieldName;
    			    if (k > 1 && ! duplicateFieldNames.contains((ucFieldName = fld.getName().toUpperCase()))) {
    			    	IFieldDetail iFieldDetail = fieldNameMap.get(ucFieldName);
    			    	if (fld.getPos() != iFieldDetail.getPos()
    			  		|| fld.getLen() != iFieldDetail.getLen()
    			  		|| fld.getDecimal() != iFieldDetail.getDecimal()
    			  		|| fld.getType() != iFieldDetail.getType()
    			    	|| fld.getFormat() != iFieldDetail.getFormat()
    			    	|| (fld.getParamater() != null && ! fld.getParamater().equals(iFieldDetail.getParamater()))) {
    			    		duplicateFieldNames.add(ucFieldName);
    			    	}
    			    }
    			    fld.setLookupName(name);
					fieldNameMap.put(name.toUpperCase(), fld);
    				recordFieldNameMap.put(
    						records[i].getRecordName() + "." + name.toUpperCase(),
    						fld);
    			}
    			records[i].setNumberOfFieldsAdded(0);
    		}
     	} else if (this.isBuildLayout()) {
     		int j;
     		IFieldDetail fld;

       		for (int i = 0; i < recordCount; i++) {
       			if (records[i].getNumberOfFieldsAdded() > 0) {
       				for (j = 1; j <=  records[i].getFieldCount(); j++) {
       	   			    fld = records[i].getField(records[i].getFieldCount() - j);
//       	   			    System.out.println("Adding ... " + (records[i].getFieldCount() - j)
//       	   			    		+ " " + fld.getName());
        				fieldNameMap.put(fld.getName().toUpperCase(), fld);
        				recordFieldNameMap.put(
        						records[i].getRecordName() + "." + fld.getName().toUpperCase(),
        						fld);

      				}
       	    		records[i].setNumberOfFieldsAdded(0);
      			}
       		}

    	}
    }

	
    @Override
	public CsvCharDetails getDelimiterDetails() {
        return delimiter;
    }




	
    public byte[] getDelimiterBytes() {
        return delimiter.asBytes();
    }


   
    public void setDelimiter(String delimiter) {
    	CsvCharDetails delim = CsvCharDetails.newDelimDefinition(delimiter, fontName);
    	if (this.records != null) {
    		for (int i=0; i < records.length; i++) {
    			records[i].setDelimiter(delim);
    		}
    	}
		this.delimiter = delim;
	}


	
    public FieldDetail getAdjField(int layoutIdx, int fieldIdx) {
        return getRecord(layoutIdx)
                       .getField(getAdjFieldNumber(layoutIdx, fieldIdx));
    }


    
    public int getAdjFieldNumber(int recordIndex, int inColumn) {

	    int ret = inColumn;

	    //System.out.println("~~ " + inColumn + " " + ret + " "
	    //        + layout.getRecord(layoutIndex).getRecordName() + " " + layout.getRecord(layoutIndex).getFieldCount());

	    if (ret > 0 && getFileStructure() == Constants.IO_XML_BUILD_LAYOUT) {
	        int len = getRecord(recordIndex).getFieldCount();

            if (ret > len - 3) {
                ret -= len - 3;
            } else {
                ret += 2;
            }
	    }
	    return ret;
    }

    public int getUnAdjFieldNumber(int recordIndex, int inColumn) {

	    int ret = inColumn;

	    if (ret > 0 && getFileStructure() == Constants.IO_XML_BUILD_LAYOUT) {
	        int len = getRecord(recordIndex).getFieldCount();

            if (ret < 3) {
                ret += len - 3;
            } else {
                ret -= 2;
            }
	    }
	    return ret;
    }

    
    public Map<String, IFieldDetail> getFieldNameMap() {
    	buildFieldNameMap();
		return new HashMap<String, IFieldDetail>(fieldNameMap);
	}

    
	public Map<String, IFieldDetail> getRecordFieldNameMap() {
		buildFieldNameMap();
		return new HashMap<String, IFieldDetail>(recordFieldNameMap);
	}

	
	public List<IItemDetails> getCobolGroupItems(String cobolGroupName) {
		updateCobolMaps();
		return cobolGroupName == null ? null : groupMap.get(cobolGroupName.toUpperCase());
	}

	
	public List<IItemDetails> getCobolItems(String cobolName) {
		updateCobolMaps();
		return cobolName == null ? null : groupFieldMap.get(cobolName.toUpperCase());
	}

	private void updateCobolMaps() {
		if (groupMap == null) {
			groupMap = new HashMap<String, List<IItemDetails>>();
			groupFieldMap = new HashMap<String, List<IItemDetails>>();
			
			for (int i = 0; i < recordCount; i++) {
				records[i].updateNameCobolItemMap(groupMap, groupFieldMap);
			}
		}
	}

	
	public final byte getSpaceByte() {
		return spaceByte;
	}


	
	public final byte getInitByte() {
		return initByte;
	}

	@Override
	public final boolean isCsvLayout() {
		return csvLayout;
	}


	
    public final boolean isXml() {
        return fileStructure == Constants.IO_XML_USE_LAYOUT
            || fileStructure == Constants.IO_XML_BUILD_LAYOUT;
    }

    
    public final boolean isOkToAddAttributes() {
    	return fileStructure == Constants.IO_XML_BUILD_LAYOUT;
    }

    
    public final boolean isBuildLayout() {
    	return fileStructure == Constants.IO_XML_BUILD_LAYOUT
    	    || fileStructure == Constants.IO_NAME_1ST_LINE;
    }


	
	public final boolean hasTreeStructure() {
		return treeStructure;
	}

	public boolean isBinCSV() {
		return	   delimiter.isBin() || getQuoteDetails().isBin();
	}


	
	public final IFieldDetail getGroupField(String...fieldNames) {
		if (fieldNames == null || fieldNames.length == 0) {
			return null;
		}

		List<IFieldDetail> fldsFound = new ArrayList<IFieldDetail>();
		int idx = getRecordIndex(fieldNames[0]);
		if (idx >= 0 && fieldNames.length > 0) {
			return records[idx].getGroupFieldX(1, fieldNames);
		} else {
			String fldName = fieldNames[fieldNames.length-1];
			for (RecordDetail r : records) {
				fldsFound.addAll(r.getGroupFields(fieldNames));
			}
			switch (fldsFound.size()) {
			case 0: break;
			case 1: 
				return fldsFound.get(0);
			default:
				IFieldDetail fld = RecordDetail.checkForFldMatch(fldsFound, fieldNames);
				if (fld == null) {
					throw new RecordException("Found multiple fields named " + fldName + "; there should be only one");
				} else {
					return fld;
				}
			}
		}
		

		StringBuilder b = new StringBuilder();
		for (String s : fieldNames) {
			b.append('.').append(s);
		}
		throw new RecordException("No Field Found: " + b);
	}
//	
//	private IFieldDetail checkFld(IFieldDetail fld, IFieldDetail newFld, String fldName) {
//		if ( fld == null) {
//			return newFld;
//		} else if (newFld == null) {
//			return fld;
//		} else {
//			throw new RuntimeException("Found multiple fields named " + fldName + "; there should be only one");
//		}
//
//	}
}

