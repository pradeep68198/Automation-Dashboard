
package com.MainFrame.Reader.Details;

import java.util.Iterator;

import com.MainFrame.Reader.Common.AbstractFieldValue;
import com.MainFrame.Reader.Details.fieldValue.FieldValue;


public class FieldIterator implements Iterable<AbstractFieldValue>, Iterator<AbstractFieldValue> {

	private final AbstractLine line;
	private int fieldNo = 0;
	private final int recordNo;
	private final RecordDetail recordDef;


	public FieldIterator(AbstractLine line, int recordNum) {
		super();
		this.line = line;
		this.recordNo = recordNum;

		this.recordDef = line.getLayout().getRecord(recordNum);
		
		toNextField();
	}

	
	public AbstractFieldValue getFieldValue(int fieldNumber) {
		return new FieldValue(line, recordNo, fieldNumber);
	}

	
	public int getFieldCount() {
		return recordDef.getFieldCount();
	}

	
	@Override
	public boolean hasNext() {
		return fieldNo < recordDef.getFieldCount();
	}

	
	@Override
	public AbstractFieldValue next() {
		AbstractFieldValue ret =  new FieldValue(line, recordNo, fieldNo++);
		toNextField();
		return ret;
	}
	
	private void toNextField() {
		while (fieldNo < recordDef.getFieldCount()
		   && ! line.isFieldInLine(recordDef.getField(fieldNo))) {
			fieldNo += 1;
		}
	}

	
	@Override
	public void remove() {
		throw new RuntimeException("Remove is not supported");
	}

	
	@Override
	public Iterator<AbstractFieldValue> iterator() {
		return new FieldIterator(line, recordNo);
	}



}
