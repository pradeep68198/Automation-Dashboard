
package com.MainFrame.Reader.Details;

public class SpecialRecordIds {
	public final int headerId, middleId, trailerId;

	protected SpecialRecordIds(int headerId, int middleId, int trailerId) {
		super();
		this.headerId = headerId;
		this.middleId = middleId;
		this.trailerId = trailerId;
	}
	
}
