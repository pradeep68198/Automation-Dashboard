package com.MainFrame.Reader.Details.Item;

import java.util.*;
import com.MainFrame.Reader.Common.*;
import com.MainFrame.Reader.Types.*;
import com.MainFrame.Reader.External.base.*;
import com.MainFrame.Convert2xml.def.*;
import com.MainFrame.Reader.External.Def.*;
import com.MainFrame.Reader.detailsBasic.*;
import com.MainFrame.Reader.cgen.def.*;
import com.MainFrame.Reader.cgen.impl.*;

public class ItemCopyJr extends ItemCopy
{
    final boolean excludeFillers;
    ArrayList<FieldDetail> fields;
    private FieldDetail lastFiller;
    private FieldDetail lastField;
    private final TypeManager.CharsetType charsetType;
    private final boolean optermizeType;
    
    public ItemCopyJr(final boolean includeFillers, final TypeManager.CharsetType charsetType, final boolean optermizeType) {
        this.fields = new ArrayList<FieldDetail>();
        this.excludeFillers = !includeFillers;
        this.charsetType = charsetType;
        this.optermizeType = optermizeType;
    }
    
    @Override
    public FieldDetail createField(final FieldCreatorHelper fieldHelper, final int level, final IItemJr itm, final ArrayIndexDtls arrayIndexDtls, final DependingOnDtls dependOnParentDtls, final int basePos) {
        final String fieldName = itm.getFieldName();
        final String fldName = fieldHelper.createFieldName(fieldName, arrayIndexDtls.toIndexStr());
        int type = this.fix(itm.getType());
        if (this.optermizeType) {
            type = TypeManager.getInstance().getShortType(type, itm.getStorageLength(), this.charsetType);
        }
        FieldDetail fd;
        if (itm.getChildItems() != null && itm.getChildItems().size() > 0) {
            fd = this.createField(fieldHelper, 0, dependOnParentDtls, level, itm, arrayIndexDtls, fldName, basePos);
        }
        else if (this.excludeFillers && (fieldName == null || fieldName.length() == 0 || "filler".equalsIgnoreCase(fieldName))) {
            fd = this.createField(fieldHelper, type, dependOnParentDtls, level, itm, arrayIndexDtls, fldName, basePos);
            if (this.lastFiller == null || this.lastFiller.getEnd() < fd.getEnd()) {
                this.lastFiller = fd;
            }
        }
        else {
            fd = this.createField(fieldHelper, type, dependOnParentDtls, level, itm, arrayIndexDtls, fldName, basePos);
            this.fields.add(fd);
            if (this.lastField == null || this.lastField.getEnd() < fd.getEnd()) {
                this.lastField = fd;
            }
        }
        return fd;
    }
    
    private FieldDetail createField(final FieldCreatorHelper fieldHelper, final int type, final DependingOnDtls dependOnParentDtls, final int level, final IItemJr itm, final ArrayIndexDtls arrayIndexDtls, final String fieldName, final int basePos) {
        final FieldDetail fd = FieldDetail.newFixedWidthField(fieldName, type, basePos + this.fix(itm.getPosition()), this.fix(itm.getStorageLength()), fieldHelper.calculateDecimalSize(type, itm.getPicture(), itm.getScale()), fieldHelper.getFont());
        if (level > 1 && fieldHelper.getGroupNameSize() > level) {
            fd.setGroupName(fieldHelper.getGroupName(level - 1));
        }
        fd.setDependingOnDtls(dependOnParentDtls);
        if (arrayIndexDtls.inArray && itm instanceof ItemDtl) {
            final ItemDtl cobolItem = (ItemDtl)itm;
            fd.setCobolItem((IItemDetails)cobolItem);
            cobolItem.getArrayDefinition().setField((IIndex)arrayIndexDtls, fd);
        }
        return fd;
    }
    
    private int fix(final int val) {
        return (val == Integer.MIN_VALUE) ? 0 : val;
    }
    
    @Override
    public IArrayExtended createArray(final IItemJr item, final ArrayIndexDtls idxDtls) {
        return (IArrayExtended)((idxDtls.getNumberOfIndexs() > 0) ? new ArrayFieldDefinition1(idxDtls.toIndexSizeArray()) : null);
    }
    
    public FieldDetail[] getFields() {
        if (this.lastFiller != null) {
            if (this.lastField == null || this.lastFiller.getEnd() > this.lastField.getEnd()) {
                this.fields.add(this.lastFiller);
            }
            this.lastFiller = null;
        }
        return this.fields.toArray(new FieldDetail[this.fields.size()]);
    }
}