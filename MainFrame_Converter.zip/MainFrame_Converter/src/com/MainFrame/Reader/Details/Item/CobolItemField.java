package com.MainFrame.Reader.Details.Item;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.fieldValue.LineFieldCreator;
import com.MainFrame.Reader.detailsBasic.IItemDetails;



public class CobolItemField {

	public final IItemDetails cobolItem;
	private com.MainFrame.Reader.Details.fieldValue.IFieldValue  fieldValue;
	private final AbstractLine line;
	
	



	public CobolItemField(AbstractLine line, IItemDetails cobolItem) {
		super();
		this.line = line;
		this.cobolItem = cobolItem;
	}



	public com.MainFrame.Reader.Details.fieldValue.IFieldValue  getFieldValue() {
		IFieldDetail field = cobolItem.getFieldDefinition();
		if (fieldValue == null && field != null) {
			fieldValue = LineFieldCreator.getInstance().newFieldValue(line, field);
		}
		return fieldValue;
	}



	
	public IItemDetails getCobolItem() {
		return cobolItem;
	}


}
