
package com.MainFrame.Reader.Details;

import com.MainFrame.Reader.Common.CommonBits;
import com.MainFrame.Reader.Common.Conversion;



public class DefaultLineProvider implements LineProvider {


    public AbstractLine getLine(LayoutDetail recordDescription) {
    	if (recordDescription.isCsvLayout() 
    	&& (! recordDescription.isBinCSV())
    	&& CommonBits.useCsvLine()) {
			return new CsvLine(recordDescription);
		}
        return new Line(recordDescription);
    }

    
    public AbstractLine getLine(LayoutDetail recordDescription, String linesText) {
    	if (recordDescription.isCsvLayout() 
    	&& (! recordDescription.isBinCSV())
    	&& CommonBits.useCsvLine()) {
			return new CsvLine(recordDescription, linesText);
		}
        return new Line(recordDescription, linesText);
    }


   
    public AbstractLine getLine(LayoutDetail recordDescription, byte[] lineBytes) {
		if (recordDescription.isCsvLayout() 
		&& (! recordDescription.isBinCSV())
		&& CommonBits.useCsvLine()) {
			return new CsvLine(recordDescription, Conversion.toString(lineBytes, recordDescription.getFontName()));
		}

        return new Line(recordDescription, lineBytes);
    }
}
