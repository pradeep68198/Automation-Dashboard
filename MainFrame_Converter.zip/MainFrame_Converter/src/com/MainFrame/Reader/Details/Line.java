
package com.MainFrame.Reader.Details;

import java.math.BigInteger;
import java.util.Arrays;

import com.MainFrame.Reader.Common.Constants;
import com.MainFrame.Reader.Common.Conversion;
import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Common.RecordException;
import com.MainFrame.Reader.Details.fieldValue.LineFieldCreator;
import com.MainFrame.Reader.Types.Type;
import com.MainFrame.Reader.Types.TypeChar;
import com.MainFrame.Reader.Types.TypeManager;
import com.MainFrame.Reader.Types.TypeNum;


public class Line extends BasicLine implements IGetByteData {

	static LineProvider defaultProvider = new DefaultLineProvider();
	private static final LineFieldCreator FIELD_VALUE_CREATOR = LineFieldCreator.getInstance();

	byte[] data;

	int preferredLayoutAlt = Constants.NULL_INTEGER;
	private boolean newRecord   = false;


	
	public Line(final LayoutDetail group) {
		super(defaultProvider, group);

		newRecord = true;
		data = NULL_RECORD;
	}



	
	public Line(final LayoutDetail group, final String rec) {
		super(defaultProvider, group);

		data = Conversion.getBytes(rec, group.getFontName());
	}


	
	public Line(final LayoutDetail group, final byte[] rec) {
		super(defaultProvider, group);

		layout = group;

		data = rec;
	}


	
	public Line(final LayoutDetail group, final byte[] buf,
	        	final int start, final int recordLen) {
		super(defaultProvider, group);

		data = new byte[Math.max(0, recordLen)];

		layout = group;

		if (recordLen > 0) {
		    System.arraycopy(buf, start, data, 0, recordLen);
		}
	}


	
	@Override
	public final void replace(final byte[] rec, final int start, final int len) {

		System.arraycopy(rec, start, data, 0,
					java.lang.Math.min(len, data.length));
		super.preferredLayoutAlt = Constants.NULL_INTEGER;
		super.preferredLayout = Constants.NULL_INTEGER;
		clearOdBuffers();
	}





	
	public String getFieldText(final int recordIdx, final int fieldIdx) {

		try {
			if (fieldIdx == Constants.FULL_LINE) {
				return getFullLine();
			}

		    FieldDetail field = layout.getField(recordIdx, fieldIdx);
			return getField(Type.ftChar, field).toString();

		} catch (final Exception ex) {
			return "";
		}
	}

	
	public String getFullLine() {
	    String s;

	    if ("".equals(layout.getFontName())) {
	        s = new String(data);
	    } else {
	        try {
	            s = new String(data, layout.getFontName());
	        } catch (Exception e) {
	            s = new String(data);
            }
	    }

	    return s;
	}


	public byte[] getFieldBytes(final int recordIdx, final int fieldIdx) {
	    return getFieldBytes(layout.getField(recordIdx, fieldIdx));
	}

	public byte[] getFieldBytes(IFieldDetail field) {
	    int len = field.getLen();
	    if (field.getType() == Type.ftCharRestOfRecord) {
	    	len = data.length - field.calculateActualPosition(this);
	    }

	    return getData(field.calculateActualPosition(this), len);
	}

	
	@Override
	public int getPreferredLayoutIdx() {
		int ret = preferredLayout;

		if (ret == Constants.NULL_INTEGER) {
			ret = getPreferredLayoutIdxAlt();

			if (ret < 0) {
				for (int i=0; i< layout.getRecordCount(); i++) {
					if (this.data.length == layout.getRecord(i).getLength()) {
						ret = i;
						preferredLayout = i;
						break;
					}
				}
			}
		}

		return ret;
	}




	
	private void adjustLengthIfNecessary(final IFieldDetail field, final int recordIdx) {

		if (field == null) {
		} else if (field.calculateActualEnd(this) > data.length) {
			RecordDetail record = layout.getRecord(recordIdx);
			if (record == null) {
			} else if (record.hasDependingOn()) {
				int end = Math.max(field.calculateActualEnd(this), layout.getRecord(recordIdx).getMinumumPossibleLength());

				if (field != null) {
					ensureCapacity(end);
				}
			} else {
				adjustLength(recordIdx);
			}
		}
	}



	
	public final void ensureCapacity(int end) {
		if (end > data.length) {
		    newRecord(Math.max(end, layout.getMinimumRecordLength()));
		    if (writeLayout >= 0
		    && writeLayout < layout.getRecordCount()
		    && layout.getRecord(writeLayout).getLength() < end) {
		    	writeLayout = -1;
		    }
		}
	}


	
	private void adjustLength(final int recordIdx) {

		RecordDetail pref = layout.getRecord(recordIdx);
		int newSize = pref.getLength(); //field.getEnd();

		if (newSize != data.length && ! pref.hasDependingOn()) {
			if (newRecord) {
				this.writeLayout = recordIdx;
				this.preferredLayoutAlt = recordIdx;
				this.preferredLayout = recordIdx;
			}

			newRecord(newSize);
		}
	}


	
	private void newRecord(int newSize) {
//		byte[] sep = layout.getRecordSep();
		byte[] rec = new byte[newSize];
		int len = Math.min(rec.length, data.length);

		newRecord = false;
		System.arraycopy(data, 0, rec, 0, len);
		
		if (len < rec.length && layout.getInitByte() != 0) {
			Arrays.fill(rec, len, rec.length, layout.getInitByte());
		}
		
//		if ((layout.getLayoutType() == Constants.rtGroupOfBinaryRecords)
//				&& sep != null && sep.length > 0) {
//			System.arraycopy(sep, 0, rec, newSize - sep.length, sep.length);
//		}

		data = rec;
	}

	public byte[] getData(int start, int len) {
	    byte[] temp = getData();
	    byte[] ret;
	    int tempLen = Math.min(len, temp.length - start + 1);

	    if (temp.length < start || tempLen < 1) {
	        return null;
	    }

	    ret = new byte[tempLen];
	    System.arraycopy(temp, start - 1, ret, 0, tempLen);

	    return ret;
	}


	
	@Override
	public byte[] getData() {

		if (newRecord && (writeLayout >= 0)) {
			adjustLength(writeLayout);
		}
		return data;
	}

	
	@Override
	public void setData(byte[] data) {
		replaceDataValue(data);
	}



	private void replaceDataValue(byte[] data) {
		this.data = data;
		super.preferredLayoutAlt = Constants.NULL_INTEGER;
		super.preferredLayout = Constants.NULL_INTEGER;
		clearOdBuffers();
	}



	public final void setData(String newVal) {
		replaceDataValue(Conversion.getBytes(newVal, layout.getFontName()));
	}


    
    @SuppressWarnings("deprecation")
	public Object getField(int type, IFieldDetail field) {

    	//System.out.print(" ---> getField ~ 1");
        if (field.isFixedFormat()) {
            int position = field.calculateActualPosition(this);
           
			return TypeManager.getSystemTypeManager().getType(type) //field.getType())
					.getField(this.getData(), position, field);
        }

        return layout.getCsvField(this.getData(), type, field);
    }



    
   
    public void setField(int type, IFieldDetail field, Object value) {
    	
        if (field.isFixedFormat()) {
            int pos = field.calculateActualPosition(this);
//            if (pos < 0) {
//            	pos = field.calculateActualPosition(this);
//            }
            
//            if (field.calculateActualEnd(this) == 101) {
//            	 System.out.println("~~ " + field.calculateActualEnd(this));
//            }
            ensureCapacity(pos + field.getLen() - 1);
//            System.out.println("~~ " + field.calculateActualEnd(this));
			data = TypeManager.getSystemTypeManager().getType(type)
				.setField(getData(), pos, field, value);
			
			super.checkForOdUpdate(field);
        } else  {
            data = layout.setCsvField(getData(), type, field, value);
        }
    }


  
    public void setFieldText(final int recordIdx, final int fieldIdx, String value) {

        FieldDetail field = layout.getField(recordIdx, fieldIdx);

        adjustLengthIfNecessary(field, recordIdx);
        setField(Type.ftChar, field, value);
    }

   
	public String setFieldHex(final int recordIdx, final int fieldIdx,
	        String val) {
		FieldDetail field = layout.getField(recordIdx, fieldIdx);
		adjustLengthIfNecessary(field, recordIdx);
 	 	return setFieldHex(field, val);
	}
	 
	public String setFieldHex(IFieldDetail field, String val) {
	    String ret = null;

	    ensureCapacity(field.calculateActualEnd(this));

        try {
            int i, j;
            BigInteger value = new BigInteger(val, Type.BASE_16);
            byte[] bytes = value.toByteArray();

            j = field.calculateActualEnd(this) - 1;
            int start = field.calculateActualPosition(this) - 1;
            int en = Math.max(0, bytes.length - (val.length() + 1) / 2);
			for (i = bytes.length - 1; i >= en && j >= start; i--) {
                data[j--] = bytes[i];
            }
            for (i = j; i >= start; i--) {
                data[i] = 0;
            }
            super.checkForOdUpdate(field);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RecordException("Error saving Hex value: {0}", e.getMessage());
        }
        return ret;
	}
	
	public void setFieldToByte(IFieldDetail field, byte val) {
		
	    ensureCapacity(field.calculateActualEnd(this));

        
        int en = field.calculateActualEnd(this);
        for (int i = field.calculateActualPosition(this) - 1; i < en; i++) {
        	data[i] = val;
        }
        super.checkForOdUpdate(field);
	}

	
	public Object clone() {
		return lineProvider.getLine(layout, data.clone());
	}
	
	
	@Override
	public boolean isDefined(IFieldDetail field) {
		if (this.data == null || data.length <= field.getPos() || ! super.isFieldInLine(field)) {
			return false;
		}
		boolean ret = false;
		Type t = TypeManager.getInstance().getType(field.getType());
		if (t instanceof TypeNum) {
			ret = ((TypeNum) t).isDefined(this, data, field);
		} else {
			int pos = field.calculateActualPosition(this);
			ret = ! TypeChar.isHexZero(data, pos, field.getLen());
		}
		return ret;
	}




	@Override
	public final com.MainFrame.Reader.Details.fieldValue.IFieldValue  getFieldValue(IFieldDetail field) {
		return FIELD_VALUE_CREATOR.newFieldValue(this, field);
	}

	@Override
	public final com.MainFrame.Reader.Details.fieldValue.IFieldValue  getFieldValue(int recordIdx, int fieldIdx) {
		FieldDetail field = layout.getField(recordIdx, fieldIdx);
		return FIELD_VALUE_CREATOR.newFieldValue(this, field);
	}
}