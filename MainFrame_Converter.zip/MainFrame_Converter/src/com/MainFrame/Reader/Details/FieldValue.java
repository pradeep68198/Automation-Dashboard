package com.MainFrame.Reader.Details;

import com.MainFrame.Reader.Common.IFieldDetail;



@Deprecated
public class FieldValue extends com.MainFrame.Reader.Details.fieldValue.FieldValue {

	
	@Deprecated
	public FieldValue(AbstractLine line, IFieldDetail fieldDetails) {
		super(line, fieldDetails);
	}

	
	@Deprecated
public FieldValue(AbstractLine line, int recordIndex, int fieldIndex) {
		super(line, recordIndex, fieldIndex);
	}

}
