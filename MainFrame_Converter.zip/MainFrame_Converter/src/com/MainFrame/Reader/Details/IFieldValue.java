
package com.MainFrame.Reader.Details;

import com.MainFrame.Reader.Common.AbstractFieldValue;


/**
 
 * @deprecated use either AbstractFieldValue or {@link com.MainFrame.Reader.Details.fieldValue.IFieldValue }
 *
 */
public interface IFieldValue extends AbstractFieldValue {

	public abstract void setToHighValues();

	public abstract void setToLowValues();

	public abstract void setHex(String s);

	public abstract boolean isFieldPresent();

	
	public abstract boolean isHighValues();

	
	public abstract boolean isLowValues();

	
	
	public abstract boolean isSpaces();
	
	
	
	public abstract boolean isByteRecord();
	
	
	public abstract boolean isFieldInRecord();

	
	public void setToSpaces();
}
