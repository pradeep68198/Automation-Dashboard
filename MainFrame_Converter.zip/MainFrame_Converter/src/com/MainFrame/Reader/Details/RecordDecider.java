
package com.MainFrame.Reader.Details;


public interface RecordDecider {

    
    public abstract int getPreferedIndex(AbstractLine line);
}
