
package com.MainFrame.Reader.Details;

import com.MainFrame.Reader.Common.Constants;
import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Types.Type;
import com.MainFrame.Reader.detailsSelection.RecordSelection;

public abstract class BasicLine extends BaseLine {

	protected static final byte[] NULL_RECORD = new byte[0];
	protected LineProvider lineProvider;
	protected int preferredLayoutAlt = Constants.NULL_INTEGER;
	protected int preferredLayout = Constants.NULL_INTEGER;
	protected int writeLayout = Constants.NULL_INTEGER;

	public BasicLine(LineProvider defaultProvider, LayoutDetail linesLayout) {
		super();

		lineProvider = defaultProvider;
		layout = linesLayout;
	}


	
	public final String getFieldHex(final int recordIdx, final int fieldIdx) {

		try {
			IFieldDetail field = layout.getField(recordIdx, fieldIdx);

			return getField(Type.ftHex, field).toString();

		} catch (final Exception ex) {
			return "";
		}
	}


	/**
	
	 * @deprecated was for use in the RecordEditor, do not use in JRecord
	 */
	@Override
	public void setLayout(final LayoutDetail pLayout) {
		this.layout = pLayout;
		preferredLayoutAlt = Constants.NULL_INTEGER;
	}


	
	@Override
	public int getPreferredLayoutIdxAlt() {
		if (preferredLayoutAlt == Constants.NULL_INTEGER) {
			int defaultIdx = Constants.NULL_INTEGER;
			int i = 0;
			int defCount = -1;
			//RecordDetail rec;
			RecordSelection sel;
			int size = layout.getRecordCount();

			if (size == 1) {
			    preferredLayoutAlt = 0;
			} else if (layout.getDecider() != null) {
			    preferredLayoutAlt = layout.getDecider().getPreferedIndex(this);
			}


	    	//System.out.println();
			while ((i < size) && (preferredLayoutAlt == Constants.NULL_INTEGER)) {
				sel = layout.getRecord(i).getRecordSelection();
				switch (sel.isSelected(this)) {
				case DEFAULT:
					if (sel.size() > defCount) {
						defaultIdx = i;
						defCount = sel.size();
					}
					break;

				case YES:
					preferredLayoutAlt = i;
					break;
					
				case NO:
				}

				i += 1;
			}
			if (preferredLayoutAlt == Constants.NULL_INTEGER) {
				preferredLayoutAlt = defaultIdx;
			}
		}

		return preferredLayoutAlt;
	}



	
	public void setRecordIdxForOutput(int recordIdx) {
		setWriteLayout(recordIdx);
	}

	
	public void setWriteLayout(final int pWriteLayout) {
		this.preferredLayoutAlt = pWriteLayout;
		this.writeLayout = pWriteLayout;
	}

	
	public Object getField(final int recordIdx, final int fieldIdx) {
		try {
			if (fieldIdx == Constants.FULL_LINE) {
		        return getFullLine();
			}

			return getField(layout.getField(recordIdx, fieldIdx));

		} catch (final Exception ex) {
			ex.printStackTrace();
			return "";
		}
	}

	
	public Object getField(String fieldName) {
		IFieldDetail fld = layout.getFieldFromName(fieldName);

	   	if (fld == null) {
	   		return null;
	   	}

	   	return getField(fld);
	}


   
	public boolean isRebuildTreeRequired() {
		return false;
	}

	
	public void setField(String fieldName, Object value) {
		IFieldDetail fld = layout.getFieldFromName(fieldName);

		if (fld != null) {
			setField(fld, value);
		}
	}

	 
    public final void setField(IFieldDetail field, Object value)
    {
        setField(field.getType(), field, value);
    }
    
   
    protected abstract void setField(int type, IFieldDetail field, Object value);

	
	public void setField(final int recordIdx, final int fieldIdx, Object val) {

	    IFieldDetail field = layout.getField(recordIdx, fieldIdx);

	    //adjustLengthIfNecessary(field, recordIdx);

	   	setField(field, val);
	}
	
	
	protected final void checkForOdUpdate(IFieldDetail field) {
		if (field != null) {
			for (int i = 0; i < layout.getRecordCount(); i++) {
				layout.getRecord(i).checkForSizeFieldUpdate(this, field);
			}		
		}
	}
	
	protected final void clearOdBuffers() {
		for (int i = 0; i < layout.getRecordCount(); i++) {
			layout.getRecord(i).clearOdBuffers(this);
		}		
	}

	
    public void setLineProvider(LineProvider pLineProvider) {
        this.lineProvider = pLineProvider;
    }
    
	
	public final boolean isDefined(int recIdx, int fldIdx) {
		return isDefined(layout.getRecord(recIdx).getField(fldIdx));
	}
	
}