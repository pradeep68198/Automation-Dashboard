
package com.MainFrame.Reader.Details;

import com.MainFrame.Reader.Common.IGetData;


public interface IGetByteData extends IGetData {
	public abstract void setData(byte[] data);
}