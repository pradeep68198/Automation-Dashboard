
package com.MainFrame.Reader.Details;

import java.util.ArrayList;
import java.util.List;

import com.MainFrame.Reader.Common.Constants;
import com.MainFrame.Reader.Common.Conversion;
import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Common.XmlConstants;

public abstract class ListLine extends BaseLine {

	protected List<Object> fields = new ArrayList<Object>();
	protected int preferredLayout = Constants.NULL_INTEGER;
	protected boolean newRecord;
	protected boolean rebuildRequired = false;


	public ListLine(LayoutDetail layoutDetails) {
		super();
		
		layout = layoutDetails;
	    newRecord = false;
	    preferredLayout = 0;
	}

	
	public byte[] getData() {
	    return null;
	}

	
	public byte[] getData(int start, int len) {
	    return null;
	}

	
	public Object getField(int typeId, IFieldDetail field) {
	    return getFieldRaw(preferredLayout, field.getPos() - getAdj());
	}
	
	

	
	public Object getField(int recordIdx, int fieldIdx) {
    	int idx = getFieldNumber(recordIdx, fieldIdx);

        if (fields.size() > idx && idx >= 0) {
        	//if (newRecord) System.out.println("Get (New) : " + fieldIdx + " " + fields.get(fieldIdx));
//        	System.out.println(fields.get(idx));
            return fields.get(idx);
        } else if (fieldIdx == Constants.FULL_LINE) {
        	return getFullLine();
        }
//        System.out.println();
        //if (newRecord) System.out.println("Get (New) : " + fieldIdx + " null");
        return null;
    }

	private Object getFieldRaw(int recordIdx, int fieldIdx) {
	
	    if (fields.size() > fieldIdx && fieldIdx >= 0) {
	    	//if (newRecord) System.out.println("Get (New) : " + fieldIdx + " " + fields.get(fieldIdx));
	        return fields.get(fieldIdx);
	    }
	    //if (newRecord) System.out.println("Get (New) : " + fieldIdx + " null");
	    return null;
	}

	
	public Object getField(String fieldName) {
	    try {
	    	return getField(preferredLayout,
	    			layout.getRecord(preferredLayout).getFieldIndex(fieldName));
	    } catch (Exception e) {
			return null;
		}
	}

	
	public byte[] getFieldBytes(int recordIdx, int fieldIdx) {
	    return null;
	}

	
	public String getFieldHex(int recordIdx, int fieldIdx) {
	    return null;
	}

	
	public String getFieldText(int recordIdx, int fieldIdx) {
	    String s = "";
	    Object o;
	
	    if (fieldIdx < fields.size()
	    && (o = fields.get(fieldIdx)) != null) {
	        s = o.toString();
	    }
	    return s;
	}

	
	@Override
	public int getPreferredLayoutIdx() {
	    return preferredLayout;
	}

	
	@Override
	public int getPreferredLayoutIdxAlt() {
	    return preferredLayout;
	}

	
	public void replace(byte[] rec, int start, int len) {
		throw new RuntimeException("replace not implemented for ListLine !!!");
	}

	
	public void setData(String newVal) {
		throw new RuntimeException("setData not implemented for ListLine !!!");
	}

	
	public void setField(IFieldDetail field, Object value) {
		if (field == null && (value == null || "".equals(value.toString()))) return;
		setRawField(preferredLayout, field.getPos() - getAdj(), value);
	}

	protected abstract int getAdj();
	
	
	public void setField(int recordIdx, int fieldIdx, Object val) {
		setRawField(recordIdx, getFieldNumber(recordIdx, fieldIdx), val);
	}
	
	protected int getFieldNumber(int recordIdx, int fieldIdx) {
		return fieldIdx;
	}

	public void setRawField(int recordIdx, int fieldIdx, Object val)
			{

    	int endFieldNum = XmlConstants.END_INDEX; //layout.getRecordIndex(XmlConstants.END_ELEMENT);
        for (int i = fields.size(); i <= fieldIdx; i++) {
            fields.add(null);
        }

        if (val != null || fields.get(fieldIdx) != null) {
        	rebuildRequired = (fieldIdx == 0) || (fieldIdx == endFieldNum) || newRecord;
//        	if (newRecord) {
//    			preferredLayout = fieldIdx;
//    			fields.set(XmlConstants.NAME_INDEX, layout.getRecord(recordIdx).getRecordName());
//    			fields.set(endFieldNum, "True");
//    			newRecord = false;
//    			rebuildRequired = true;
//    		}

        	fields.set(fieldIdx, val);

        	if (val != null && fieldIdx == XmlConstants.NAME_INDEX) {
        		int idx = layout.getRecordIndex(val.toString());
        		if (idx >= 0) {
        			preferredLayout = idx;
        		}
        	}
        }
    }

	
	public void setField(String fieldName, Object value) {
	    setField(getFieldFromName(fieldName), value);
	}


	
	public String setFieldHex(int recordIdx, int fieldIdx, String val) 	{
	    return ""; //super.setFieldHex(recordIdx, fieldIdx, val);
	}

	
	public void setFieldText(int recordIdx, int fieldIdx, String value) {
		setField(recordIdx, fieldIdx, value);
	}

	
	public void setWriteLayout(int pWriteLayout) {
		preferredLayout = pWriteLayout;
		fields.set(XmlConstants.NAME_INDEX, layout.getRecord(preferredLayout).getRecordName());
	}

	
	public void setLayout(final LayoutDetail pLayout) {
	//		System.out.print("set layout >> " + fields.get(0)
	//				+ " " + layout.getRecord(preferredLayout).getRecordName()
	//				+ " " + preferredLayout);
			preferredLayout = pLayout.getRecordIndex(layout.getRecord(preferredLayout).getRecordName());
	//		System.out.println(" " + preferredLayout + " --> " + pLayout.getRecord(preferredLayout).getRecordName());
			this.layout = pLayout;
		}

	
	public void setLineProvider(LineProvider pLineProvider) {
	}


	protected final FieldDetail getFieldFromName(String fieldName) {
		FieldDetail fldDef = null;
		if (preferredLayout >= 0) {
			fldDef = layout.getRecord(preferredLayout).getField(fieldName);
		}
		return fldDef;
	}
	
	@Override
	public boolean isDefined(IFieldDetail fld) {
		return isDefined(0, fld.getPos() - getAdj());
	}
	
	@Override
	public boolean isDefined(int rec, int pos) {
		return fields != null 
			&& pos < fields.size() 
			&& fields.get(pos) != null;
	}

	@Override
	public void setData(byte[] newVal) {
		setData(Conversion.toString(newVal, layout.getFontName()));
	}
}