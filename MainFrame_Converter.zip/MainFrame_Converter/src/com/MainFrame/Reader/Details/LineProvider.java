
package com.MainFrame.Reader.Details;





public interface LineProvider {

    public abstract AbstractLine getLine(LayoutDetail recordDescription);


    
    public abstract AbstractLine getLine(LayoutDetail recordDescription, String linesText);

    
    public abstract AbstractLine getLine(LayoutDetail recordDescription, byte[] lineBytes);
}