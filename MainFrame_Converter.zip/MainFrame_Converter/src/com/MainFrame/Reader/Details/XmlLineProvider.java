
package com.MainFrame.Reader.Details;


public class XmlLineProvider implements LineProvider {

	
	public AbstractLine getLine(LayoutDetail recordDescription) {
		return new XmlLine(recordDescription, -1);
	}

	
	public AbstractLine getLine(LayoutDetail recordDescription, String linesText) {
		return getLine(recordDescription);
	}

	
	public AbstractLine getLine(LayoutDetail recordDescription, byte[] lineBytes) {
		return getLine(recordDescription);
	}

}
