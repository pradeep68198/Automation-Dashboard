package com.MainFrame.Reader.Details.fieldValue;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Details.Line;
import com.MainFrame.Reader.Types.smallBin.ITypeBinaryExtendedNumeric;
import com.MainFrame.Reader.cgen.def.IArrayAnyDimension;

public class ArrayFieldValueSmallBin extends FieldValueSmallBin implements IArrayFieldValue {

	final IArrayAnyDimension array;
	ArrayFieldValueSmallBin(Line theLine, IFieldDetail field, ITypeBinaryExtendedNumeric type, IArrayAnyDimension array) {
		super(theLine, field, type);
		this.array = array;
	}

	
	@Override
	public IFieldValue setIndex(int... indexs) {
		field = array.getField(indexs);
		return this;
	}

}
