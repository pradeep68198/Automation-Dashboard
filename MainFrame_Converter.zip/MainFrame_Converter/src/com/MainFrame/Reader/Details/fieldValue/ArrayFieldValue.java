package com.MainFrame.Reader.Details.fieldValue;

import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.cgen.def.IArrayAnyDimension;

public class ArrayFieldValue extends FieldValue implements IArrayFieldValue {

	final IArrayAnyDimension array;
	ArrayFieldValue(AbstractLine theLine,  IArrayAnyDimension array) {
		super(theLine, array.getFirstField());
		this.array = array;
	}

	
	@Override
	public IFieldValue setIndex(int... indexs) {
		field = array.getField(indexs);
		return this;
	}

}
