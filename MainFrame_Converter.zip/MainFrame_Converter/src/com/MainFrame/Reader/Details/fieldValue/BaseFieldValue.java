
package com.MainFrame.Reader.Details.fieldValue;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.MainFrame.Reader.Common.AbstractFieldValue;
import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.External.base.ExternalConversion;
import com.MainFrame.Reader.Types.Type;
import com.MainFrame.Reader.Types.TypeManager;


public abstract class BaseFieldValue  {

	protected IFieldDetail field;


	
	public BaseFieldValue(IFieldDetail fieldDetails) {
		field = fieldDetails;
	}

	
	public final BigDecimal asBigDecimal() {
		Object ret = getValue();

		if (ret == null) {
			return null;
		} else if (ret instanceof BigDecimal) {
			return (BigDecimal) ret;
		} else {
			return new BigDecimal(ret.toString());
		}
	}

	
	public final BigInteger asBigInteger() {
		Object ret = getValue();

		if (ret == null) {
			return null;
		} else if (ret instanceof BigInteger) {
			return (BigInteger) ret;
		} else {
			return new BigInteger(ret.toString());
		}
	}

	
	public final double asDouble() {
		Object ret = getValue();

		if (ret == null) {
			return 0;
		} else if (ret instanceof Number) {
			return ((Number) ret).doubleValue();
		} else {
			return Double.parseDouble(ret.toString());
		}
	}


	
	public final float asFloat() {
		Object ret = getValue();

		if (ret == null) {
			return 0;
		} else if (ret instanceof Number) {
			return ((Number) ret).floatValue();
		} else {
			return Float.parseFloat(ret.toString());
		}
	}

	
	public final long asLong() {
		Object ret = getValue();

		if (ret == null) {
			return 0;
		} else if (ret instanceof Number) {
			return ((Number) ret).longValue();
		} else {
			String s = ret.toString();
			if (s.trim().length() == 0) {
				return 0;
			}
			if (s.indexOf(".") >= 0) {
				return new BigDecimal(s).longValue();
			}
			return Long.parseLong(s);
		}
	}


	
	public final int asInt() {
		return (int) asLong();
	}



	
	public final boolean asBoolean() {
		Object ret = getValue();

		if (ret == null) {
			return false;
		} else if (ret instanceof Boolean) {
			return ((Boolean) ret).booleanValue();
		} else {
			return Boolean.parseBoolean(ret.toString());
		}
	}


	
	@Override
	public final String toString() {
		return asString();
	}


	public final String asString() {
		Object ret = getValue();

		if (ret == null) {
			return "";
		}
		return ret.toString();
	}

	
	protected abstract Object getValue(); 

	
	
	public final void set(AbstractFieldValue value) {
		set(value.asString());
	}

	
	public final void set(boolean value) {
		set(Boolean.valueOf(value));
	}


	
	public final void set(double value) {
		set(Double.valueOf(value));
	}

	
	public final void set(float value) {
		set(Float.valueOf(value));
	}

	
	public final void set(long value) {
		set(Long.valueOf(value));
	}

	
	public abstract void set(Object value);

	
	public final String getTypeName() {
		return ExternalConversion.getTypeAsString(0, getFieldDetail().getType());
	}

	
	public final boolean isNumeric() {
		return getType().isNumeric();
	}

	
	public final boolean isBinary() {
		return getType().isBinary();
	}
	

	private Type getType() {
		return TypeManager.getInstance().getType(getFieldDetail().getType());
	}

	
	public IFieldDetail getFieldDetail() {
		return field;
	}
}
