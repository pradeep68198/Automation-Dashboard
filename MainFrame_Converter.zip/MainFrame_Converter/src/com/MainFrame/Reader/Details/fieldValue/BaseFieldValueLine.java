
package com.MainFrame.Reader.Details.fieldValue;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Common.RecordException;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.Line;
import com.MainFrame.Reader.External.base.ExternalConversion;
import com.MainFrame.Reader.Types.Type;
import com.MainFrame.Reader.Types.TypeManager;

public abstract class BaseFieldValueLine implements IFieldValueUpdLine {

	protected Line theLine; 
	protected IFieldDetail field;

	protected BaseFieldValueLine(Line line, IFieldDetail fieldDetails) {
		this.theLine = line;
		this.field = fieldDetails;
	}

	
	@Override
	public final boolean isLowValues() {
		return checkFor((byte) 0);
	}



	
	@Override
	public final boolean isHighValues() {
		return checkFor((byte) -1);
	}
	
	
	
	@Override
	public final boolean isSpaces() {
		return checkFor(theLine.getLayout().getSpaceByte());
	}

	private boolean checkFor(byte b) {
		byte[] bytes = theLine.getFieldBytes(field);
		
		if (bytes == null) {
			return b == 0;
		} 
		for (int i = 0; i < bytes.length; i++) {
			if (bytes[i] != b) {
				return false;
			}
		}
		
		return true;
	}

	
	@Override
	public final void setHex(String val) {
		theLine.setFieldHex(field, val); 
	}

	
	@Override
	public final void setToLowValues() {
		theLine.setFieldToByte(field, (byte) 0);
	}
	
	@Override
	public void setToSpaces() {
		setFieldToByte(theLine.getLayout().getSpaceByte());
	}


	protected void setFieldToByte(byte val) {
		theLine.setFieldToByte(field, val);
	}



	@Override
	public final void setToHighValues() {
		theLine.setFieldToByte(field, (byte) 0xFF);
	}



	@Override
	public final int asInt() {
		return (int) asLong();
	}
	

	@Override
	public String asHex() {
		return theLine.getField(Type.ftHex, field).toString();
	}


	@Override
	public boolean asBoolean() {
		return false;
	}


	@Override
	public final boolean isFieldInRecord() {
		return theLine.isFieldInLine(field);
	}
	
	@Override
	public final boolean isFieldPresent() {	
		return this.theLine.isDefined(field);
	}

	
	@Override
	public final boolean isByteRecord() {
		return true;
	}

	
	@Override
	public final String asString() {
		return asBigDecimal().toString();
//		Object fieldVal = theLine.getField(field);
//		return fieldVal == null ? "" : fieldVal.toString();
	}

	
	public final boolean isNumeric() {
		return getType().isNumeric();
	}

	
	public final boolean isBinary() {
		return getType().isBinary();
	}
	

	private Type getType() {
		return TypeManager.getInstance().getType(getFieldDetail().getType());
	}

	
	public final IFieldDetail getFieldDetail() {
		return field;
	}

	
	public final String getTypeName() {
		return ExternalConversion.getTypeAsString(0, getFieldDetail().getType());
	}
	
	@Override
	public void set(boolean value) {
		throw new RecordException("Can not assign boolean to numeric value");
	}

	
	public BaseFieldValueLine setLine(Line theLine) {
		this.theLine = theLine;
		return this;
	}

	
	@Override
	public IFieldValueUpdLine setLine(AbstractLine line) {
		this.theLine = (Line) line;
		return this;
	}

}
