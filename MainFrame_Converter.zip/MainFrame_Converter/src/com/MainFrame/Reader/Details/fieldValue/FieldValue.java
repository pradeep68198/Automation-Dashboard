
package com.MainFrame.Reader.Details.fieldValue;

import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.BaseLine;
import com.MainFrame.Reader.Details.Line;
import com.MainFrame.Reader.Types.Type;

public class FieldValue extends BaseFieldValue implements IFieldValueUpdLine {

	private AbstractLine theLine;
	//final IFieldDetail field;
	final int recordNum;
	final int fieldNum;;

	
	public FieldValue(AbstractLine line, IFieldDetail fieldDetails) {
		super(fieldDetails);
		theLine = line;
		recordNum = -1;
		fieldNum = -1;
	}

	
	public FieldValue(AbstractLine line, int recordIndex, int fieldIndex) {
		super(null);
		theLine = line;
		recordNum = recordIndex;
		fieldNum = fieldIndex;
	}

	
	@SuppressWarnings("deprecation")
	protected Object getValue() {
		if (recordNum >= 0) {
			return theLine.getField(recordNum, fieldNum);
		}
		if (field == null) {
			return null;
		}
		return theLine.getField(field);
	}
	
	public boolean isFieldInRecord() {
		
		IFieldDetail fld = getField();
		if (fld == null) { return false; }
		return theLine.isFieldInLine(fld);
//		IFieldDetail fld = field;
//		
//		if (recordNum >= 0) {
//			fld = theLine.getLayout().getField(recordNum, fieldNum);
//		}
//		
//		boolean ret = fld != null;
//		DependingOnDtls depOn;
//		
//		if (fld != null && fld instanceof FieldDetail) { 
//			depOn = ((FieldDetail) fld).getDependingOnDtls();
//			
//			try {
//				while (depOn != null) {
//					if (depOn.index >= theLine.getFieldValue(depOn.dependingOn.getVariableName()).asInt()) {
//						return false;
//					}
//					depOn = depOn.parent;
//				}
//			} catch (Exception e) {
//				ret = false;
//			}
//		}
//		
//		return ret;
	}

	private IFieldDetail getField() {
		IFieldDetail fld = field;
		
		if (recordNum >= 0) {
			fld = theLine.getLayout().getField(recordNum, fieldNum);
		}
		return fld;
	}

	
	@SuppressWarnings("deprecation")
	@Override
	public String asHex() {
		IFieldDetail fld = getField();
		if (theLine instanceof BaseLine) {
			return ((BaseLine) theLine).getField(Type.ftHex, fld).toString();
		}
		return theLine.getLayout().getField(theLine.getData(),
				Type.ftHex,
				fld).toString();
	}

	
	@SuppressWarnings("deprecation")
	@Override
	public void set(Object value) {
		if (recordNum >= 0) {
			theLine.setField(recordNum, fieldNum, value);
		} else if (field == null) {
			throw new RuntimeException("Unknown Field !!!");
		} else {
			theLine.setField(field, value);
		}
	}

	
	@Override
	public boolean isFieldPresent() {
		
		if (recordNum >= 0) {
			return this.theLine.isDefined(recordNum, fieldNum);
		}
		if (field == null) {
			return false;
		} 
		
		return this.theLine.isDefined(field);
	}


	
	@Override
	public IFieldDetail getFieldDetail() {
		if (field != null) {
			return field;
		}
		return theLine.getLayout().getRecord(recordNum).getField(fieldNum);
	}
	
	@Override
	public boolean isByteRecord() {
		return theLine instanceof Line;
	}
	
	
	@Override
	public boolean isLowValues() {
		return false;
	}
	
	@Override
	public boolean isHighValues() {
		return false;
	}
	

	@SuppressWarnings("deprecation")
	@Override
	public boolean isSpaces() {
		IFieldDetail fld = getField();
		String s;
		if (theLine instanceof BaseLine) {
			s = ((BaseLine) theLine).getField(Type.ftCharNoTrim, fld).toString();
		} else {
			s =  theLine.getLayout().getField(theLine.getData(),
					Type.ftChar,
					fld).toString();
		}
		for (int i = s.length()-1; i >= 0; i--) {
			if (s.charAt(i) != ' ') return false;
		}
		
		return s.length() > 0;// || fld.isFixedFormat();
	}
	
	@Override
	public void setHex(String s) {
		if (theLine instanceof Line) {
			((Line)theLine).setFieldHex(field, s);
			return;
		}

		throwError();
	}
	
	
	@Override
	public void setToLowValues() {
		setFieldToByte((byte) 0);
	}

	
	@Override
	public void setToHighValues() {
		setFieldToByte((byte) 0xFF);
	}
	
	
	@SuppressWarnings("deprecation")
	@Override
	public void setToSpaces() {
//		if (theLine instanceof Line) {
//			((Line)theLine).setFieldToByte(field, theLine.getLayout().getSpaceByte());
//			return;
//		}
		
		FieldDetail charField;
		if (field.isFixedFormat()) {
			charField = FieldDetail.newFixedWidthField(field.getName(), Type.ftChar, 
					field.getPos(), field.getLen(), 0, field.getFontName());
		} else {
			charField = FieldDetail.newCsvField(field.getName(), Type.ftChar, 
					field.getPos(), 0, field.getFontName());
		}
		theLine.setField(charField, " ");
	}

 

	protected void setFieldToByte(byte val) {
		if (theLine instanceof Line) {
			((Line)theLine).setFieldToByte(field, val);
			return;
		}
		throwError();
	}
	
	private void throwError() {
		String s = "";
		if (theLine != null) {
			s = theLine.getClass().getName();
		}
		
		throw new RuntimeException("Operation is not supported for a " + s);
	}
	
	
	public final FieldValue setField(IFieldDetail field) {
		super.field = field;
		return this;
	}

	
	@Override
	public IFieldValueUpdLine setLine(Line line) {
		theLine = line;
		return this;
	}

	
	@Override
	public IFieldValueUpdLine setLine(AbstractLine line) {
		theLine = line;
		return this;
	}	
}
