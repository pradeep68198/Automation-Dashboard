
package com.MainFrame.Reader.Details.fieldValue;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.Line;

public class FieldValueLine extends FieldValue {

	private Line theLine; 

	protected FieldValueLine(Line line, IFieldDetail fieldDetails) {
		super(line, fieldDetails);
		theLine = line;
	}

	protected FieldValueLine(Line line, int recordIndex, int fieldIndex) {
		super(line, line.getLayout().getField(recordIndex, fieldIndex));
		theLine = line;
	}

	
	@Override
	public boolean isLowValues() {
		return checkFor((byte) 0);
	}

	
	@Override
	public boolean isHighValues() {
		return checkFor((byte) -1);
	}
	
	
	
	@Override
	public boolean isSpaces() {
		return checkFor(theLine.getLayout().getSpaceByte());
	}

	private boolean checkFor(byte b) {
		byte[] bytes = theLine.getFieldBytes(field);
		
		if (bytes == null) {
			return b == 0;
		} 
		for (int i = 0; i < bytes.length; i++) {
			if (bytes[i] != b) {
				return false;
			}
		}
		
		return true;
	}

	
	@Override
	public void setHex(String val) {
		theLine.setFieldHex(field, val); 
	}


	
	@Override
	public void setToSpaces() {
		setFieldToByte(theLine.getLayout().getSpaceByte());
	}


	protected void setFieldToByte(byte val) {
		theLine.setFieldToByte(field, val);
	}

	
	@Override
	public IFieldValueUpdLine setLine(Line line) {
		theLine = line;
		return super.setLine(line);
	}

	
	@Override
	public IFieldValueUpdLine setLine(AbstractLine line) {
		theLine = (Line) line;
		return super.setLine(line);
	}

}
