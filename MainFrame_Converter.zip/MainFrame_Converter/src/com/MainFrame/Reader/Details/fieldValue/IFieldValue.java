package com.MainFrame.Reader.Details.fieldValue;




@SuppressWarnings("deprecation")
public interface IFieldValue extends com.MainFrame.Reader.Details.IFieldValue {
	public abstract void setToHighValues();

	public abstract void setToLowValues();

	public abstract void setHex(String s);

	public abstract boolean isFieldPresent();

	
	public abstract boolean isHighValues();

	
	public abstract boolean isLowValues();

	
	
	public abstract boolean isSpaces();
	
	
	
	public abstract boolean isByteRecord();
	
	
	public abstract boolean isFieldInRecord();
}
