package com.MainFrame.Reader.Details.fieldValue;

import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.Line;

public interface IFieldValueUpdLine extends IFieldValue {
	public IFieldValueUpdLine setLine(Line line);
	public IFieldValueUpdLine setLine(AbstractLine line);
}
