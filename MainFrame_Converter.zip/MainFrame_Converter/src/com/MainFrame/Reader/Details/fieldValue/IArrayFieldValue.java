package com.MainFrame.Reader.Details.fieldValue;

import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.Line;

public interface IArrayFieldValue {// extends IFieldValueUpdLine {
	public IFieldValueUpdLine setLine(Line line);
	public IFieldValueUpdLine setLine(AbstractLine line);
	public IFieldValue setIndex(int... indexs);
}
