
package com.MainFrame.Reader.Details;



public interface IRecordDeciderX extends RecordDecider {

	
	public abstract void setLayout(LayoutDetail layout);
}
