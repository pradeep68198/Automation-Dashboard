
package com.MainFrame.Reader.Details;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Common.IGetFieldByName;

public class LayoutGetFieldByName implements IGetFieldByName {
   	final LayoutDetail layout;
	final RecordDetail rec;

	public LayoutGetFieldByName(LayoutDetail l, RecordDetail rec) {
		super();
		this.rec = rec;
		this.layout = l;
	}
	
	
	@Override
	public IFieldDetail getField(String fieldName) {
		IFieldDetail ret = rec.getField(fieldName);
		if (ret == null) {
			ret = layout.getFieldFromName(fieldName);
		}
		return ret;
	}
}

