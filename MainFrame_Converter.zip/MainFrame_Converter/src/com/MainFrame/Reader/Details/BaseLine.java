
package com.MainFrame.Reader.Details;

import com.MainFrame.Reader.Common.FieldDetail;
import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Details.fieldValue.FieldValue;
import com.MainFrame.Reader.External.Def.DependingOnDtls;

public abstract class BaseLine implements AbstractLine {

	protected LayoutDetail layout;


	
	@Override
    public final Object getField(IFieldDetail field) {
        return getField(field.getType(), field);
    }

    
    public abstract Object getField(int type, IFieldDetail field);

//	@Override
	public com.MainFrame.Reader.Details.fieldValue.IFieldValue  getFieldValue(IFieldDetail field) {
		return new FieldValue(this, field);
	}

	@Override
	public  com.MainFrame.Reader.Details.fieldValue.IFieldValue  getFieldValue(int recordIdx, int fieldIdx) {
		return new FieldValue(this, recordIdx, fieldIdx);
	}

	
	@Override
	public final com.MainFrame.Reader.Details.fieldValue.IFieldValue  getFieldValue(String fieldName) {
		IFieldDetail fieldFromName = layout.getFieldFromName(fieldName);
		
		if (fieldFromName == null) {
			throw new RuntimeException("Field: \"" + fieldName +"\" does not exist !!!");
		}
		
		return  getFieldValue(fieldFromName);
	}



	
	@Override
	public com.MainFrame.Reader.Details.fieldValue.IFieldValue  getFieldValueIfExists(String fieldName) {
		return  getFieldValue(layout.getFieldFromName(fieldName));
	}

	
	@Override public final FieldIterator getFieldIterator(String recordName) {
		int recordNumber = layout.getRecordIndex(recordName);
		if (recordNumber < 0) {
			throw new RuntimeException("Record: " + recordName + " does not exist in layout");
		}
		return new FieldIterator(this, recordNumber);
	}


	
	@Override public final FieldIterator getFieldIterator(int recordNumber) {
		return new FieldIterator(this, recordNumber);
	}
	
	
	
	@Override public final boolean isFieldInLine(IFieldDetail field) {
		if (field == null) { return false; }
		if ( field instanceof FieldDetail) { 
			DependingOnDtls dependingOnDtls = ((FieldDetail) field).getDependingOnDtls();
			if (dependingOnDtls != null) {
				DependingOnDtls[] tree = dependingOnDtls.getTree();
				for (int i = 0; i < tree.length; i++){
					dependingOnDtls = tree[i];
//		        	if (dependingOnDtls.dependingOn == null || dependingOnDtls.dependingOn.getField() == null) {
//		        		System.out.print('*');
//		        	}
		            Object v;
					//try {
						v = this.getField(dependingOnDtls.dependingOn.getField());
//					} catch (Exception e) {
//						System.out.println();
//						e.printStackTrace();
//						throw new RuntimeException(e);
//					}      
		            
		            String s;
		            if (v == null || ((s= v.toString()).length() == 0))  {
		            	return false;
		            }
		            
					int count = Integer.parseInt(s);
		
		            if (dependingOnDtls.index >= count) {
		                return false;
		            }
		        }
			}
		}
        return true;
	}

	
	public LayoutDetail getLayout() {
	    return layout;
	}
}
