
package com.MainFrame.Reader.Details;



public class XmlLine extends ListLine {

    

	//private static LineProvider defaultProvider = new DefaultLineProvider();

	//private LayoutDetail layout;

	private boolean useField4Index = true;

	public XmlLine(LayoutDetail layoutDetails, int recordIdx) {
		super(layoutDetails);
	    layout = layoutDetails;
	    newRecord = recordIdx < 0;
	    preferredLayout = recordIdx;

	    fields.add("");

	    if (newRecord) {
	    	fields.add("True");
	    }
	}
	
	
	public Object clone() {
        Object ret = null;

        try { ret = super.clone(); } catch (Exception e) {}

        if (! (ret instanceof XmlLine)) {
        	XmlLine line = new XmlLine(layout, preferredLayout);
        	for (int i = 0; i < fields.size(); i++) {
//        		Object o = fields.get(i);
//        		if (o != null
//        		&& ! (o instanceof String
//        		   || o instanceof Boolean
//        		   || o instanceof BigInteger
//        		   || o instanceof BigDecimal)) {
//					   o = o.toString();
//				}
        		try {
        			line.setRawField(preferredLayout, i, fields.get(i));
        		} catch (Exception e) {
				}
        	}
        	ret = line;
        }

        return ret;
	}




	public String getFullLine() {
	    return "";
	}



    protected int getFieldNumber(int recordIdx, int fieldIdx) {
       	int idx = fieldIdx;

        //   	System.out.print("getField " + recordIdx + " " + fieldIdx);
           	if (useField4Index && recordIdx < layout.getRecordCount()
           	&& fieldIdx < layout.getRecord(recordIdx).getFieldCount()
       	&& fieldIdx >= 0
           	&& layout.getRecord(recordIdx).getField(fieldIdx).getPos() >= 0) {
           		idx = layout.getRecord(recordIdx).getField(fieldIdx).getPos();
           	}
           	return idx;
    }

  
	public boolean isRebuildTreeRequired() {
		boolean ret = rebuildRequired;
		return ret;
	}


	
	public final void setUseField4Index(boolean useField4Index) {
		this.useField4Index = useField4Index;
	}
	

	@Override
	protected final int getAdj() {
		return 0;
	}

}
