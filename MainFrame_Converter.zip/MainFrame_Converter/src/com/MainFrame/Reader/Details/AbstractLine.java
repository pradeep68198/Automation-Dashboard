
package com.MainFrame.Reader.Details;

import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Common.ILineFieldNames;


public interface AbstractLine extends ILineFieldNames {
   
    public abstract void replace(final byte[] rec, final int start,
            final int len);

   
    public abstract String getFieldText(final int recordIdx, final int fieldIdx);

   
    public abstract String getFullLine();

    
    public abstract String getFieldHex(final int recordIdx, final int fieldIdx);

    
    public abstract byte[] getFieldBytes(final int recordIdx, final int fieldIdx);


  
    public abstract int getPreferredLayoutIdxAlt();

    public abstract byte[] getData(int start, int len);

    
    public abstract byte[] getData();

    
    public abstract void setData(String newVal);
    
    public abstract void setData(byte[] newVal);

    
    public abstract void setLayout(final LayoutDetail pLayout);

    
    public abstract LayoutDetail getLayout();

    
    public abstract void setWriteLayout(final int pWriteLayout);

    /**
    
     * @deprecated for use in JRecord
     */
    public abstract void setLineProvider(LineProvider pLineProvider);

    /**
     
     *
     * @deprecated for use in JRecord, otherwise use {@link AbstractLine#getFieldValue(int, int)}
     */
    public abstract Object getField(final int recordIdx, final int fieldIdx);


    public abstract com.MainFrame.Reader.Details.fieldValue.IFieldValue  getFieldValue(final int recordIdx, final int fieldIdx);

    public abstract com.MainFrame.Reader.Details.fieldValue.IFieldValue getFieldValue(String fieldName);
    
    public abstract com.MainFrame.Reader.Details.fieldValue.IFieldValue getFieldValue(IFieldDetail field);

    /**
    
     *
     * @deprecated use {@link AbstractLine#getFieldValue(IFieldDetail)}.set(..)
     */
    public abstract void setField(String fieldName, Object value);

    /**
    
     *
     * @deprecated for use in JRecord, use {@link AbstractLine#getFieldValue(int, int)}.set(..)
     */
    public abstract void setField(final int recordIdx, final int fieldIdx,
            Object val);

    /**
     
     *
     * @deprecated for use in JRecord, use {@link AbstractLine#getFieldValue(IFieldDetail)}.set(..)
     */
    public abstract void setField(IFieldDetail field, Object value);

   
    public abstract void setFieldText(final int recordIdx, final int fieldIdx,
            String value);

    public abstract String setFieldHex(final int recordIdx, final int fieldIdx,
            String val);

//     was RecordEditor related but The RecordEditor has its own AbstractLine
//    
//    
//    public abstract boolean isRebuildTreeRequired();

   
    public abstract FieldIterator getFieldIterator(String recordName);

    public abstract FieldIterator getFieldIterator(int recordNumber);

    
    public boolean isDefined(int rec, int fldNum);

    
    
    public boolean isDefined(IFieldDetail fld);

	

	boolean isFieldInLine(IFieldDetail fd);
}