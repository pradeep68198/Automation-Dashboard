package com.MainFrame.Reader.Option;

public interface IOptionType {
  String getName();
}

