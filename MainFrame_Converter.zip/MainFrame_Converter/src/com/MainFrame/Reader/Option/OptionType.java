/*    */ package com.MainFrame.Reader.Option;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptionType
/*    */   implements IRecordPositionOption
/*    */ {
/* 30 */   public static final OptionType REQUIRED = new OptionType("Required");
/*    */   public final String name;
/*    */   
/*    */   public OptionType(String name) {
/* 34 */     this.name = name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 41 */     return this.name;
/*    */   }
/*    */ }

