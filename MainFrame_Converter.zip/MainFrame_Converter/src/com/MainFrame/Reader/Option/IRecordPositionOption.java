package com.MainFrame.Reader.Option;

public interface IRecordPositionOption extends IOptionType {}


