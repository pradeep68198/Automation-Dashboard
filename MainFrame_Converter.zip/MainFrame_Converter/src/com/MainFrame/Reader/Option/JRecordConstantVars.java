/*     */ package com.MainFrame.Reader.Option;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JRecordConstantVars
/*     */ {
/*  42 */   public static final JRecordConstantVars INSTANCE = new JRecordConstantVars();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public final int FMT_MAINFRAME = 1;
/*  50 */   public final int FMT_FUJITSU = 2;
/*  51 */   public final int FMT_BIG_ENDIAN = 3;
/*  52 */   public final int FMT_FS2000 = 5;
/*     */   
/*  54 */   public final int FMT_FS2000_BE = 9;
/*     */   
/*  56 */   public final int FMT_MAINFRAME_COMMA_DECIMAL = 31;
/*  57 */   public final int FMT_FUJITSU_COMMA_DECIMAL = 32;
/*     */   
/*  59 */   public final int FMT_GNU_COBOL = 4;
/*  60 */   public final int FMT_GNU_COBOL_MVS = 6;
/*  61 */   public final int FMT_GNU_COBOL_MF = 7;
/*     */   
/*  63 */   public final int FMT_GNU_COBOL_BE = 8;
/*  64 */   public final int FMT_GNU_COBOL_BE_MVS = 10;
/*  65 */   public final int FMT_GNU_COBOL_BE_MF = 11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public final int SPLIT_NONE = 0;
/*  72 */   public final int SPLIT_REDEFINE = 1;
/*  73 */   public final int SPLIT_01_LEVEL = 2;
/*  74 */   public final int SPLIT_HIGHEST_REPEATING = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public final int IO_STANDARD_TEXT_FILE = 1;
/*     */   
/*  82 */   public final int IO_FIXED_LENGTH_RECORDS = 2;
/*  83 */   public final int IO_BINARY_IBM_4680 = 3;
/*  84 */   public final int IO_VB = 4;
/*  85 */   public final int IO_VB_DUMP = 5;
/*  86 */   public final int IO_VB_DUMP2 = 14;
/*  87 */   public final int IO_VB_FUJITSU = 7;
/*  88 */   public final int IO_VB_GNU_COBOL = 8;
/*  89 */   public final int IO_BIN_TEXT = 9;
/*  90 */   public final int IO_FIXED_LENGTH_CHAR = 10;
/*  91 */   public final int IO_VBS = 12;
/*     */ 
/*     */ 
/*     */   
/*  95 */   public final int IO_CONTINOUS_NO_LINE_MARKER = 11;
/*     */   
/*  97 */   public final int IO_CSV = 44;
/*  98 */   public final int IO_BIN_CSV = 45;
/*  99 */   public final int IO_UNICODE_CSV = 46;
/*     */   
/* 101 */   public final int IO_CSV_NAME_1ST_LINE = 47;
/* 102 */   public final int IO_BIN_CSV_NAME_1ST_LINE = 48;
/* 103 */   public final int IO_UNICODE_CSV_NAME_1ST_LINE = 49;
/*     */   
/* 105 */   public final int IO_NAME_1ST_LINE = 51;
/* 106 */   public final int IO_BIN_NAME_1ST_LINE = 54;
/* 107 */   public final int IO_UNICODE_NAME_1ST_LINE = 55;
/*     */   
/* 109 */   public final int IO_STANDARD_UNICODE_TEXT_FIL = 90;
/*     */   
/* 111 */   public final int IO_UNICODE_TEXT = 90;
/* 112 */   public final int IO_FIXED_LENGTH = 2;
/* 113 */   public final int IO_TEXT_LINE = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public final int RO_LEAVE_ASIS = 0;
/* 122 */   public final int RO_MINUS_TO_UNDERSCORE = 1;
/* 123 */   public final int RO_CAMEL_CASE = 2;
/*     */ }

