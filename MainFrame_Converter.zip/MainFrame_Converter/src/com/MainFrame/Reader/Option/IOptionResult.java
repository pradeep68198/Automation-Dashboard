package com.MainFrame.Reader.Option;

public interface IOptionResult {}

