/*    */ package com.MainFrame.Reader.Option;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptionResult
/*    */   implements IOptionResult
/*    */ {
/* 30 */   public static final OptionResult NO = new OptionResult("no");
/* 31 */   public static final OptionResult YES = new OptionResult("yes");
/* 32 */   public static final OptionResult UNKOWN = new OptionResult("unknown");
/*    */   public final String name;
/*    */   
/*    */   public OptionResult(String name) {
/* 36 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public static OptionResult get(boolean b) {
/* 41 */     return b ? YES : NO;
/*    */   }
/*    */ }

