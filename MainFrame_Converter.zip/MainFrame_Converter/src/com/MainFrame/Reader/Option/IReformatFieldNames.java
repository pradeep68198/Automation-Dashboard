package com.MainFrame.Reader.Option;

public interface IReformatFieldNames {
  public static final int RO_LEAVE_ASIS = 0;
  
  public static final int RO_UNDERSCORE = 1;
  
  public static final int RO_CAMEL_CASE = 2;
}

