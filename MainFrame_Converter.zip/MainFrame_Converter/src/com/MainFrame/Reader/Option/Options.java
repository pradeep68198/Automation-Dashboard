/*    */ package com.MainFrame.Reader.Option;
/*    */ 
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Options
/*    */ {
/* 32 */   public static final IRecordPositionOption RP_FIRST_RECORD_IN_FILE = new OptionType("First");
/* 33 */   public static final IRecordPositionOption RP_MIDDLE_RECORDS = new OptionType("Middle");
/* 34 */   public static final IRecordPositionOption RP_LAST_RECORD_IN_FILE = new OptionType("Last");
/*    */   
/* 36 */   public static final OptionMap<IRecordPositionOption> recordPositionMap = new OptionMap<IRecordPositionOption>((IOptionType[])new IRecordPositionOption[] { RP_FIRST_RECORD_IN_FILE, RP_MIDDLE_RECORDS, RP_LAST_RECORD_IN_FILE });
/*    */ 
/*    */ 
/*    */   
/*    */   public static class OptionMap<OT extends IOptionType>
/*    */   {
/* 42 */     final TreeMap<String, OT> map = new TreeMap<String, OT>();
/*    */     
/*    */     @SafeVarargs
/*    */     private OptionMap(IOptionType... iOptionType) {
/* 46 */       for (IOptionType t : iOptionType) {
/* 47 */         this.map.put(t.toString().toLowerCase(), (OT) t);
/*    */       }
/*    */     }
/*    */     
/*    */     public IOptionType get(String name) {
/* 52 */       if (name == null) {
/* 53 */         return null;
/*    */       }
/*    */       
/* 56 */       return (IOptionType)this.map.get(name.toLowerCase());
/*    */     }
/*    */   }
/*    */ }

