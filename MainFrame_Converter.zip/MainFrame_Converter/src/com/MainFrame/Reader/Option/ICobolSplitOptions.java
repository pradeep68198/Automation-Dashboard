package com.MainFrame.Reader.Option;

public interface ICobolSplitOptions {
  public static final int SPLIT_NONE = 0;
  
  public static final int SPLIT_REDEFINE = 1;
  
  public static final int SPLIT_01_LEVEL = 2;
  
  public static final int SPLIT_TOP_LEVEL = 3;
  
  public static final int SPLIT_HIGHEST_REPEATING = 4;
}


