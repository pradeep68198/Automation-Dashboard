/*     */ package com.MainFrame.Reader.ExternalRecordSelection;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExternalGroupSelection<fs extends ExternalSelection>
/*     */   implements ExternalSelection
/*     */ {
/*     */   private ArrayList<fs> items;
/*  33 */   private int type = 2;
/*     */ 
/*     */   
/*     */   public static ExternalGroupSelection<ExternalSelection> newAnd(ExternalSelection... selections) {
/*  37 */     ExternalGroupSelection<ExternalSelection> ret = new ExternalGroupSelection<ExternalSelection>(selections.length);
/*     */     
/*  39 */     ret.addAll(selections);
/*     */     
/*  41 */     return ret;
/*     */   }
/*     */   
/*     */   public static ExternalGroupSelection<ExternalSelection> newOr(ExternalSelection... selections) {
/*  45 */     ExternalGroupSelection<ExternalSelection> ret = new ExternalGroupSelection<ExternalSelection>(selections.length);
/*  46 */     ret.type = 3;
/*     */     
/*  48 */     ret.addAll(selections);
/*     */     
/*  50 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ExternalGroupSelection() {
/*  56 */     this.items = new ArrayList<fs>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ExternalGroupSelection(int size) {
/*  62 */     this.items = new ArrayList<fs>(size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(fs e) {
/*  71 */     return this.items.add(e);
/*     */   }
/*     */   
/*     */   private void addAll(fs... selections) {
/*  75 */     for (fs sel : selections) {
/*  76 */       this.items.add(sel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public fs get(int index) {
/*  85 */     return this.items.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  93 */     return this.items.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/* 101 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(int type) {
/* 109 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 114 */     return this.items.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getElementCount() {
/* 120 */     int count = 0;
/*     */     
/* 122 */     for (ExternalSelection s : this.items) {
/* 123 */       count += s.getElementCount();
/*     */     }
/* 125 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public fs set(int idx, fs selection) {
/* 136 */     return this.items.set(idx, selection);
/*     */   }
/*     */ }

