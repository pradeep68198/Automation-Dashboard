/*    */ package com.MainFrame.Reader.ExternalRecordSelection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamLine<Selection extends ExternalSelection>
/*    */ {
/* 46 */   private static final StreamLine<ExternalSelection> externalStreamLine = new StreamLine();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Selection streamLine(Selection sel) {
/* 55 */     if (sel instanceof ExternalGroupSelection) {
/*    */       
/* 57 */       ExternalGroupSelection<Selection> grp = (ExternalGroupSelection<Selection>)sel;
/* 58 */       if (grp.size() == 1) {
/* 59 */         return streamLine(grp.get(0));
/*    */       }
/* 61 */       for (int i = 0; i < grp.size(); i++)
/*    */       {
/* 63 */         grp.set(i, streamLine(grp.get(i)));
/*    */       }
/*    */     } 
/*    */     
/* 67 */     return sel;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StreamLine<ExternalSelection> getExternalStreamLine() {
/* 74 */     return externalStreamLine;
/*    */   }
/*    */ }

