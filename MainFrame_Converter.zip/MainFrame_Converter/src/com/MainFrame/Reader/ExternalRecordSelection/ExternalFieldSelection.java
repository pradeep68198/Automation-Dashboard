/*     */ package com.MainFrame.Reader.ExternalRecordSelection;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExternalFieldSelection
/*     */   implements ExternalSelection
/*     */ {
/*     */   public static final String EQUALS_OPERATOR = "=";
/*     */   private String fieldName;
/*     */   private String fieldValue;
/*  34 */   private String booleanOp = ""; private String operator = "=";
/*     */   
/*     */   private boolean caseSensitive = true;
/*  37 */   private static final String[] VALID_OPS = Constants.VALID_COMPARISON_OPERATORS;
/*     */   
/*     */   public static ExternalFieldSelection newFieldSelection(boolean caseSensitive, String name, String value) {
/*  40 */     ExternalFieldSelection r = new ExternalFieldSelection(name, value);
/*  41 */     r.setCaseSensitive(caseSensitive);
/*  42 */     return r;
/*     */   }
/*     */   
/*     */   public static ExternalFieldSelection newFieldSelection(boolean caseSensitive, String name, String op, String value) {
/*  46 */     ExternalFieldSelection r = new ExternalFieldSelection(name, value, op);
/*  47 */     r.setCaseSensitive(caseSensitive);
/*  48 */     return r;
/*     */   }
/*     */   
/*     */   public static ExternalFieldSelection newFieldSelection(String name, String value) {
/*  52 */     ExternalFieldSelection r = new ExternalFieldSelection(name, value);
/*  53 */     return r;
/*     */   }
/*     */   
/*     */   public static ExternalFieldSelection newFieldSelection(String name, String op, String value) {
/*  57 */     ExternalFieldSelection r = new ExternalFieldSelection(name, value, op);
/*  58 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ExternalFieldSelection() {}
/*     */ 
/*     */   
/*     */   public ExternalFieldSelection(String name, String value) {
/*  67 */     this.fieldName = name;
/*  68 */     this.fieldValue = value;
/*     */   }
/*     */   
/*     */   public ExternalFieldSelection(String name, String value, String op) {
/*  72 */     this.fieldName = name;
/*  73 */     this.fieldValue = value;
/*  74 */     if (op != null) {
/*  75 */       for (int i = 0; i < VALID_OPS.length; i++) {
/*  76 */         if (VALID_OPS[i].equalsIgnoreCase(op)) {
/*  77 */           this.operator = op;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(ExternalFieldSelection fs) {
/*  86 */     this.fieldName = fs.fieldName;
/*  87 */     this.fieldValue = fs.fieldValue;
/*  88 */     this.booleanOp = fs.booleanOp;
/*  89 */     this.operator = fs.operator;
/*  90 */     this.caseSensitive = fs.caseSensitive;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldName() {
/*  96 */     return this.fieldName;
/*     */   }
/*     */   
/*     */   public void setFieldName(String fieldName) {
/* 100 */     this.fieldName = fieldName;
/*     */   }
/*     */   
/*     */   public String getRawFieldValue() {
/* 104 */     return this.fieldValue;
/*     */   }
/*     */   
/*     */   public String getFieldValue() {
/* 108 */     if (isCaseSensitive() || this.fieldValue == null) {
/* 109 */       return this.fieldValue;
/*     */     }
/* 111 */     return this.fieldValue.toLowerCase();
/*     */   }
/*     */   
/*     */   public void setFieldValue(String fieldValue) {
/* 115 */     this.fieldValue = fieldValue;
/*     */   }
/*     */   
/*     */   public String getOperator() {
/* 119 */     return this.operator;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOperator(String operator) {
/* 124 */     this.operator = null;
/* 125 */     if (operator != null) {
/* 126 */       this.operator = operator.trim();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getBooleanOp() {
/* 131 */     return this.booleanOp;
/*     */   }
/*     */   
/*     */   public void setBooleanOp(String booleanOp) {
/* 135 */     this.booleanOp = booleanOp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/* 144 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 150 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getElementCount() {
/* 159 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCaseSensitive() {
/* 167 */     return this.caseSensitive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExternalFieldSelection setCaseSensitive(boolean caseSensitive) {
/* 175 */     this.caseSensitive = caseSensitive;
/* 176 */     return this;
/*     */   }
/*     */ }

