package com.MainFrame.Reader.occursDepending;

import com.MainFrame.Reader.Common.AbstractIndexedLine;
import com.MainFrame.Reader.Common.IFieldDetail;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.External.Def.DependingOnDtls;


public interface IOccursDependingPositionCalculation {

	public int calculateActualPosition(AbstractIndexedLine line, DependingOnDtls dependingOnDtls, int pos);

	public void checkForSizeFieldUpdate(AbstractLine line, IFieldDetail fld);

	public void clearBuffers(AbstractLine line);
}
