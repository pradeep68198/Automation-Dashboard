package com.MainFrame.Reader.Common;

import com.MainFrame.Reader.External.Def.DependingOnDtls;
import com.MainFrame.Reader.detailsBasic.CsvCharDetails;

public interface AbstractRecord {
  CsvCharDetails getQuoteDefinition();
  
  int getParentRecordIndex();
  
  int getRecordStyle();
  
  int getSourceIndex();
  
  int calculateActualPosition(AbstractIndexedLine paramAbstractIndexedLine, DependingOnDtls paramDependingOnDtls, int paramInt);
}
