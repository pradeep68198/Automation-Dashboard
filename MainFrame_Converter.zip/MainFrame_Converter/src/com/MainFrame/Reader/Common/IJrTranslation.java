package com.MainFrame.Reader.Common;

public interface IJrTranslation {
  public static final int ST_MESSAGE = 2;
  
  public static final int ST_ERROR = 14;
  
  String convert(int paramInt, String paramString);
  
  String convertMsg(int paramInt, String paramString, Object... paramVarArgs);
}

