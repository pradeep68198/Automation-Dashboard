package com.MainFrame.Reader.Common;

public interface IEmptyTest {
  boolean isEmpty();
}

