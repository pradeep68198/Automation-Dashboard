package com.MainFrame.Reader.Common;

import com.MainFrame.Reader.detailsBasic.CsvCharDetails;

public interface IBasicFileSchema {
  int getFileStructure();
  
  boolean isBinary();
  
  boolean useByteRecord();
  
  String getFontName();
  
  CsvCharDetails getDelimiterDetails();
  
  CsvCharDetails getQuoteDetails();
  
  int getMaximumRecordLength();
}

