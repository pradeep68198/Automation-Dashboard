package com.MainFrame.Reader.Common;

public interface ILineFieldNames extends AbstractIndexedLine {
  Object getField(String paramString);
  
  AbstractFieldValue getFieldValue(String paramString);
  
  AbstractFieldValue getFieldValueIfExists(String paramString);
}

