package com.MainFrame.Reader.Common;

public class Messages {
  public static final String INVALID_INDEX_MSG = "Invalid Index Supplied {0} Should be between {1} and {2}";
}
