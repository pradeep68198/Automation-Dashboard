/*     */ package com.MainFrame.Reader.Common;
/*     */ 
/*     */ import com.MainFrame.Reader.detailsBasic.CsvCharDetails;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicFileSchema
/*     */   implements IBasicFileSchema
/*     */ {
/*     */   public static final int FT_BINARY_FILE = 2;
/*     */   public static final int FT_BINARY_CSV_FILE = 3;
/*     */   public static final int FT_OTHER = 4;
/*     */   private final int fileStructure;
/*     */   private final int maximumRecordLength;
/*     */   private final int layoutType;
/*     */   private final String charset;
/*     */   private final CsvCharDetails delimiter;
/*     */   private final CsvCharDetails quote;
/*     */   
/*     */   public static BasicFileSchema newCsvSchema(int fileStructure, boolean binary, String charset, String delimiter, String quote) {
/*  64 */     int layoutType = 4;
/*  65 */     if (binary) {
/*  66 */       layoutType = 3;
/*     */     }
/*  68 */     return new BasicFileSchema(fileStructure, 2147483647, layoutType, charset, delimiter, quote);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BasicFileSchema newFixedSchema(int fileStructure) {
/*  77 */     return newFixedSchema(fileStructure, true, 80, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BasicFileSchema newFixedSchema(int fileStructure, boolean binary, int recordLength, String charset) {
/*  91 */     int layoutType = 4;
/*  92 */     if (binary) {
/*  93 */       layoutType = 2;
/*     */     }
/*  95 */     return new BasicFileSchema(fileStructure, recordLength, layoutType, charset, "", "");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BasicFileSchema(int fileStructure, int maximumRecordLength, int layoutType, String charset, String delimiter, String quote) {
/* 101 */     this.fileStructure = fileStructure;
/* 102 */     this.maximumRecordLength = maximumRecordLength;
/* 103 */     this.layoutType = layoutType;
/* 104 */     this.charset = charset;
/* 105 */     this.delimiter = CsvCharDetails.newDelimDefinition(delimiter, charset);
/* 106 */     this.quote = CsvCharDetails.newQuoteDefinition(quote, charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFileStructure() {
/* 114 */     return this.fileStructure;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBinary() {
/* 122 */     return (this.layoutType == 2 || this.layoutType == 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean useByteRecord() {
/* 146 */     return isBinary();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFontName() {
/* 154 */     return this.charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsvCharDetails getDelimiterDetails() {
/* 161 */     return this.delimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CsvCharDetails getQuoteDetails() {
/* 167 */     return this.quote;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximumRecordLength() {
/* 191 */     return this.maximumRecordLength;
/*     */   }
/*     */ }

