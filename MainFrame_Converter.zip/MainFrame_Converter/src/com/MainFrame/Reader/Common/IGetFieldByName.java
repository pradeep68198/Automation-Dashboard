package com.MainFrame.Reader.Common;

public interface IGetFieldByName {
  IFieldDetail getField(String paramString);
}

