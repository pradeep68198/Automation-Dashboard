/*    */ package com.MainFrame.Reader.Common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TranslateXmlChars
/*    */ {
/*    */   public static String replaceXmlCharsStr(String in) {
/* 31 */     return replaceXmlChars(new StringBuilder(in)).toString();
/*    */   }
/*    */   
/*    */   public static StringBuilder replaceXmlChars(StringBuilder in) {
/* 35 */     replace(in, "&", "&amp;");
/* 36 */     replace(in, "<", "&lt;");
/* 37 */     replace(in, ">", "&gt;");
/* 38 */     replace(in, "\"", "&quot;");
/*    */ 
/*    */     
/* 41 */     return in;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void replace(StringBuilder in, String from, String to) {
/* 53 */     int fromLen = from.length();
/*    */     
/* 55 */     int start = in.indexOf(from, 0);
/* 56 */     while (start >= 0) {
/* 57 */       in.replace(start, start + fromLen, to);
/* 58 */       start = in.indexOf(from, start + to.length());
/*    */     } 
/*    */   }
/*    */ }

