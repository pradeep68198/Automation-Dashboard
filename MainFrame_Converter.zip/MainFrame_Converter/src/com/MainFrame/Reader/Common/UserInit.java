/*    */ package com.MainFrame.Reader.Common;
/*    */ 
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserInit
/*    */ {
/*    */   static {
/* 34 */     Properties properties = PropertyManager.getProperties();
/* 35 */     String init = "init.";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 43 */     for (int i = 0; i < 32; i++) {
/* 44 */       String var = init + i;
/* 45 */       if (properties.containsKey(var))
/*    */         try {
/* 47 */           String className = properties.getProperty(var);
/* 48 */           Class<?> c = Class.forName(className);
/* 49 */           if (c != null) {
/* 50 */             Object o = c.newInstance();
/*    */             
/* 52 */             if (o instanceof Runnable) {
/* 53 */               ((Runnable)o).run();
/*    */             }
/*    */           } 
/* 56 */         } catch (Exception exception) {} 
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void init() {}
/*    */ }

