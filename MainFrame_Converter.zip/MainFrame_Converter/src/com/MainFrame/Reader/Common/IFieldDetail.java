package com.MainFrame.Reader.Common;

import com.MainFrame.Reader.Option.IOptionResult;
import com.MainFrame.Reader.Option.IOptionType;
import com.MainFrame.Reader.detailsBasic.CsvCharDetails;
import com.MainFrame.Reader.detailsBasic.IItemDetails;

public interface IFieldDetail {
  IFieldDetail setPosLen(int paramInt1, int paramInt2);
  
  IFieldDetail setPosOnly(int paramInt);
  
  int getDecimal();
  
  int getLen();
  
  String getName();
  
  String getLookupName();
  
  void setLookupName(String paramString);
  
  int getPos();
  
  int getType();
  
  String getDescription();
  
  @Deprecated
  int getEnd();
  
  boolean isFixedFormat();
  
  String getFontName();
  
  int getFormat();
  
  String getParamater();
  
  CsvCharDetails getQuoteDefinition();
  
  AbstractRecord getRecord();
  
  void setNameType(String paramString, int paramInt);
  
  Object getDefaultValue();
  
  void setDefaultValue(Object paramObject);
  
  IOptionResult getOption(IOptionType paramIOptionType);
  
  int calculateActualPosition(AbstractIndexedLine paramAbstractIndexedLine);
  
  int calculateActualEnd(AbstractIndexedLine paramAbstractIndexedLine);
  
  IItemDetails getCobolItem();
}

