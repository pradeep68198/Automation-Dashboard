/*     */ package com.MainFrame.Reader.Common;
/*     */ 
/*     */ import com.MainFrame.Reader.External.Def.DependingOnDtls;
/*     */ import com.MainFrame.Reader.Option.IOptionResult;
/*     */ import com.MainFrame.Reader.Option.IOptionType;
/*     */ import com.MainFrame.Reader.Option.OptionResult;
/*     */ import com.MainFrame.Reader.Option.OptionType;
/*     */ import com.MainFrame.Reader.detailsBasic.CsvCharDetails;
/*     */ import com.MainFrame.Reader.detailsBasic.IItemDetails;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldDetail
/*     */   implements IFieldDetail
/*     */ {
/*  61 */   private static final AbstractRecord DEFAULT_RECORD = new AbstractRecord()
/*     */     {
/*     */ 
/*     */       
/*     */       public int getParentRecordIndex()
/*     */       {
/*  67 */         return 0;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public CsvCharDetails getQuoteDefinition() {
/*  73 */         return CsvCharDetails.DEFAULT_QUOTE;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int getRecordStyle() {
/*  80 */         return 0;
/*     */       }
/*     */       
/*     */       public int getSourceIndex() {
/*  84 */         return 0;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int calculateActualPosition(AbstractIndexedLine line, DependingOnDtls dependingOnDtls, int pos) {
/*  92 */         return pos;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private int pos;
/*     */   
/*     */   private int len;
/*     */   
/*     */   private int end;
/*     */   
/*     */   private String name;
/*     */   
/*     */   private String lookupName;
/* 106 */   private AbstractRecord record = DEFAULT_RECORD; private final String description; private int type; private final int decimal; private final String fontName; private final int format;
/*     */   private final String paramater;
/* 108 */   private Object defaultValue = null;
/* 109 */   private String groupName = "";
/*     */   private boolean occursDependingOnValue = false;
/* 111 */   private DependingOnDtls dependingOnDtls = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IItemDetails cobolItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldDetail(String pName, String pDescription, int pType, int pDecimal, String pFont, int pFormat, String pParamater) {
/* 134 */     this.name = pName;
/* 135 */     this.lookupName = pName;
/* 136 */     this.type = pType;
/* 137 */     this.decimal = pDecimal;
/* 138 */     this.fontName = pFont;
/* 139 */     this.format = pFormat;
/* 140 */     this.paramater = pParamater;
/*     */     
/* 142 */     if (pDescription == null) {
/* 143 */       this.description = "";
/*     */     } else {
/* 145 */       this.description = pDescription;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IFieldDetail setPosLen(int pPosition, int pLength) {
/* 159 */     this.pos = pPosition;
/* 160 */     this.len = pLength;
/* 161 */     this.end = this.pos + this.len - 1;
/*     */     
/* 163 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldDetail setPosOnly(int pPosition) {
/* 172 */     this.pos = pPosition;
/* 173 */     this.len = -121;
/* 174 */     this.end = -121;
/*     */     
/* 176 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getDecimal() {
/* 190 */     return this.decimal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLen() {
/* 203 */     return this.len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 216 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getLookupName() {
/* 228 */     return this.lookupName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setLookupName(String lookupName) {
/* 236 */     this.lookupName = lookupName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPos() {
/* 245 */     return this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int calculateActualPosition(AbstractIndexedLine line) {
/* 256 */     return this.record.calculateActualPosition(line, this.dependingOnDtls, this.pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int calculateActualEnd(AbstractIndexedLine line) {
/* 267 */     return calculateActualPosition(line) + this.len - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/* 276 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 285 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEnd() {
/* 294 */     return this.end;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFixedFormat() {
/* 307 */     return (this.end != -121);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFontName() {
/* 320 */     return this.fontName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFormat() {
/* 332 */     return this.format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParamater() {
/* 344 */     return this.paramater;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsvCharDetails getQuoteDefinition() {
/* 366 */     return this.record.getQuoteDefinition();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractRecord getRecord() {
/* 375 */     return this.record;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRecord(AbstractRecord record) {
/* 387 */     this.record = record;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNameType(String newName, int newType) {
/* 399 */     this.name = newName;
/* 400 */     this.type = newType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getDefaultValue() {
/* 413 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultValue(Object defaultValue) {
/* 426 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getGroupName() {
/* 434 */     return this.groupName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setGroupName(String groupName) {
/* 442 */     this.groupName = groupName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isOccursDependingOnValue() {
/* 450 */     return this.occursDependingOnValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOccursDependingOnValue(boolean occursDependingOnValue) {
/* 458 */     this.occursDependingOnValue = occursDependingOnValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DependingOnDtls getDependingOnDtls() {
/* 466 */     return this.dependingOnDtls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setDependingOnDtls(DependingOnDtls dependingOnDtls) {
/* 474 */     this.dependingOnDtls = dependingOnDtls;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IOptionResult getOption(IOptionType type) {
/* 480 */     if (type == OptionType.REQUIRED) {
/* 481 */       return (IOptionResult)OptionResult.YES;
/*     */     }
/* 483 */     return (IOptionResult)OptionResult.UNKOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final FieldDetail newFixedWidthField(String pName, int pType, int pos, int len, int pDecimal, String pFont) {
/* 493 */     FieldDetail r = new FieldDetail(pName, "", pType, pDecimal, pFont, 0, "");
/*     */     
/* 495 */     r.setPosLen(pos, len);
/*     */     
/* 497 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final FieldDetail newCsvField(String pName, int pType, int pos, int pDecimal, String pFont) {
/* 506 */     FieldDetail r = new FieldDetail(pName, "", pType, pDecimal, pFont, 0, "");
/*     */     
/* 508 */     r.setPosOnly(pos);
/* 509 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IItemDetails getCobolItem() {
/* 518 */     return this.cobolItem;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCobolItem(IItemDetails cobolItem) {
/* 526 */     this.cobolItem = cobolItem;
/*     */   }
/*     */ }

