package com.MainFrame.Reader.Common;

public interface AbstractRecordX<FieldDefinition extends IFieldDetail> extends AbstractRecord, IGetFieldByName {
  FieldDefinition getField(int paramInt);
  
  int getFieldCount();
  
  FieldDefinition getField(String paramString);
  
  IFieldDetail getGroupField(String... paramVarArgs);
}

