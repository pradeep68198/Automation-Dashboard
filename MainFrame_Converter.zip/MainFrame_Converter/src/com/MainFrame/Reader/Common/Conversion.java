/*      */ package com.MainFrame.Reader.Common;
/*      */ 
/*      */ import java.math.BigInteger;
/*      */ import java.nio.charset.Charset;
/*      */ import java.text.NumberFormat;
/*      */ import java.util.Arrays;
/*      */ import java.util.Locale;
public final class Conversion
{
    public static final Conversion.HoldEbcidicFlag DEFAULT_CHARSET_DETAILS;
    private static String defaultSingleByteCharacterset;
    private static boolean alwaysUseDefaultSingByteCharset;
    private static final char[] TAB_ARRAY;
    private static Conversion.HoldEbcidicFlag holdEbcidicFlag;
    public static final String DEFAULT_ASCII_CHARSET;
    public static final boolean IS_DEFAULT_CHARSET_SINGLE_BYTE_EBCIDIC;
    private static final String VALUE_IS_TO_BIG_FOR_FIELD = "Value is to big for field {0} > {1} {2} ~ {3} {4}";
    private static final byte BYTE_NO_BIT_SET = 0;
    private static final byte BYTE_ALL_BITS_SET = -1;
    public static final int EBCDIC_ZONED_POSITIVE_DIFF = 16;
    public static final int EBCDIC_ZONED_NEGATIVE_DIFF = 25;
    private static char positive0EbcdicZoned;
    private static char negative0EbcdicZoned;
    private static final char decimalChar = '.';
    
    public static byte[] getBytes(final String str, final String fontname) {
        if (str == null) {
            return null;
        }
        if (fontname != null && fontname.length() > 0) {
            try {
                return str.getBytes(fontname);
            }
            catch (Exception ex) {}
        }
        return str.getBytes();
    }
    
    public static String getString(final byte[] record, final int start, final int fin, final String fontName) {
        String s = "";
        if (fin - start > 0) {
            if (fontName == null || fontName.length() == 0) {
                s = new String(record, start, fin - start);
            }
            else {
                try {
                    s = new String(record, start, fin - start, fontName);
                }
                catch (Exception e) {
                    s = new String(record, start, fin - start);
                }
            }
        }
        return s;
    }
    
    public static final String toString(final byte[] record, final String fontName) {
        String s = "";
        try {
            if (fontName == null || fontName.length() == 0) {
                s = new String(record);
            }
            else {
                try {
                    s = new String(record, fontName);
                }
                catch (Exception e) {
                    s = new String(record);
                }
            }
        }
        catch (Exception ex) {}
        return s;
    }
    
    public static String fromZoned(final String numZoned) {
        String sign = "";
        String ret;
        if (numZoned == null || (ret = numZoned.trim()).length() == 0 || ret.equals("-")) {
            return "";
        }
        char lastChar = ret.charAt(ret.length() - 1);
        final char ucLastChar = Character.toUpperCase(lastChar);
        switch (ucLastChar) {
            case 'A':
            case 'B':
            case 'C':
            case 'D':
            case 'E':
            case 'F':
            case 'G':
            case 'H':
            case 'I': {
                lastChar = (char)(ucLastChar - '\u0010');
                break;
            }
            case 'J':
            case 'K':
            case 'L':
            case 'M':
            case 'N':
            case 'O':
            case 'P':
            case 'Q':
            case 'R': {
                sign = "-";
                lastChar = (char)(ucLastChar - '\u0019');
                break;
            }
            default: {
                if (lastChar == Conversion.positive0EbcdicZoned) {
                    lastChar = '0';
                    break;
                }
                if (lastChar == Conversion.negative0EbcdicZoned) {
                    lastChar = '0';
                    sign = "-";
                    break;
                }
                break;
            }
        }
        ret = sign + ret.substring(0, ret.length() - 1) + lastChar;
        return ret;
    }
    
    public static String getDecimal(final byte[] record, final int start, final int fin) {
        return getDecimalSB(record, start, fin).toString();
    }
    
    public static StringBuilder getDecimalSB(final byte[] record, final int start, final int fin) {
        final StringBuilder ret = new StringBuilder(3 + Math.max(0, 2 * (fin - start)));
        for (int i = start; i < fin; ++i) {
            final int b = 0xFF & record[i];
            final String s = Integer.toHexString(b);
            if (s.length() == 1) {
                ret.append('0');
            }
            ret.append(s);
        }
        return ret;
    }
    
    public static String getBitField(final byte[] record, final int start, final int fin) {
        final StringBuffer ret = new StringBuffer("");
        for (int i = start; i < fin; ++i) {
            String conv = Integer.toBinaryString(toPostiveByte(record[i]));
            if (conv.length() < 8) {
                conv = "00000000".substring(conv.length()) + conv;
            }
            ret.append(conv);
        }
        return ret.toString();
    }
    
    public static String getPostiveBinary(final byte[] record, final int start, final int fin) {
        long l = 0L;
        for (int i = fin - 1; i >= start; --i) {
            l <<= 8;
            l |= (record[i] & 0xFF);
        }
        return Long.toString(l);
    }
    
    public static BigInteger getLittleEndianBigInt(final byte[] record, final int start, final int fin) {
        final int len = fin - start;
        final byte[] bytes = new byte[len];
        for (int i = 0; i < len; ++i) {
            bytes[i] = record[start + len - i - 1];
        }
        return new BigInteger(bytes);
    }
    
    public static String getBinaryInt(final byte[] record, final int start, final int fin) {
        return getLittleEndianBigInt(record, start, fin).toString();
    }
    
    public static String getMainframePackedDecimal(final byte[] record, final int start, final int len) {
        final StringBuilder hex = getDecimalSB(record, start, start + len);
        String ret = "0";
        if (hex.length() > 0) {
            switch (hex.charAt(hex.length() - 1)) {
                case 'D':
                case 'd': {
                    hex.insert(0, '-');
                }
                case 'A':
                case 'B':
                case 'C':
                case 'E':
                case 'F':
                case 'a':
                case 'b':
                case 'c':
                case 'e':
                case 'f': {
                    hex.setLength(hex.length() - 1);
                    break;
                }
            }
            ret = hex.toString();
        }
        return ret;
    }
    
    public static BigInteger getBigInt(final byte[] record, final int start, final int len) {
        final byte[] bytes = new byte[len];
        System.arraycopy(record, start, bytes, 0, len);
        return new BigInteger(bytes);
    }
    
    public static BigInteger getPositiveBigInt(final byte[] record, final int start, final int len) {
        final byte[] bytes = new byte[len + 1];
        bytes[0] = 0;
        System.arraycopy(record, start, bytes, 1, len);
        return new BigInteger(bytes);
    }
    
    private static int toPostiveByte(final byte b) {
        if (b < 0) {
            return 256 + b;
        }
        return b;
    }
    
    public static String toZoned(final String num) {
        if (num == null) {
            return "";
        }
        String ret = num.trim();
        if (num.equals("") || num.equals("-") || num.equals("+")) {
            return "";
        }
        char lastChar = ret.substring(ret.length() - 1).charAt(0);
        if (lastChar >= '0') {
            if (lastChar <= '9') {
                if (num.startsWith("-")) {
                    if (lastChar == '0') {
                        lastChar = Conversion.negative0EbcdicZoned;
                    }
                    else {
                        lastChar += '\u0019';
                    }
                    ret = ret.substring(1, ret.length() - 1) + lastChar;
                }
                else {
                    if (num.startsWith("+")) {
                        ret = ret.substring(1);
                    }
                    if (lastChar == '0') {
                        lastChar = Conversion.positive0EbcdicZoned;
                    }
                    else {
                        lastChar += '\u0010';
                    }
                    ret = ret.substring(0, ret.length() - 1) + lastChar;
                }
            }
        }
        return ret;
    }
    
    public static void setLong(final byte[] record, final int pos, final int len, long val, final boolean isPositive) {
        checkLength(val, len, isPositive);
        for (int i = pos + len - 1; i >= pos; --i) {
            record[i] = (byte)(val & 0xFFL);
            val >>= 8;
        }
    }
    
    public static void setBigInt(final byte[] record, final int pos, final int len, final BigInteger val, final boolean isPositive) {
        byte[] bytes = val.toByteArray();
        if (bytes.length > len) {
            if (!isPositive || bytes.length != len + 1 || bytes[0] != 0) {
                throw new RecordException("Value is to big for field {0} > {1} {2} ~ {3} {4}", new Object[] { isPositive, pos, bytes.length, len, bytes[0] });
            }
            final byte[] tmp = new byte[len];
            System.arraycopy(bytes, 1, tmp, 0, len);
            bytes = tmp;
        }
        byte sb = 0;
        if (val.signum() < 0) {
            sb = -1;
        }
        for (int i = pos; i < pos + len - bytes.length + 1; ++i) {
            record[i] = sb;
        }
        System.arraycopy(bytes, 0, record, pos + len - bytes.length, bytes.length);
    }
    
    public static void setBigIntLE(final byte[] record, final int pos, final int len, final BigInteger val, final boolean isPositive) {
        final byte[] bytes = val.toByteArray();
        if (bytes.length <= len) {
            final int base = pos + bytes.length - 1;
            byte fill = 0;
            if (val.signum() < 0) {
                fill = -1;
            }
            Arrays.fill(record, base, pos + len, fill);
            for (int i = 0; i < bytes.length; ++i) {
                record[base - i] = bytes[i];
            }
        }
        else {
            if (!isPositive || bytes.length != len + 1 || bytes[0] != 0) {
                throw new RecordException("Value is to big for field {0} > {1} {2} ~ {3} {4}", new Object[] { isPositive, pos, bytes.length, len, bytes[0] });
            }
            final int base = pos + len - 1;
            for (int i = 0; i < len; ++i) {
                record[base - i] = bytes[i + 1];
            }
        }
    }
    
    public static void setLongLow2High(final byte[] record, final int pos, final int len, long val, final boolean isPositive) {
        checkLength(val, len, isPositive);
        for (int i = pos; i <= pos + len - 1; ++i) {
            record[i] = (byte)(val & 0xFFL);
            val >>= 8;
        }
    }
    
    public static void checkLength(final long val, final int length, final boolean isPositive) {
        if (length == 8) {
            return;
        }
        long t = (val >= 0L) ? val : (-(val + 1L));
        if (val != Long.MAX_VALUE) {
            final int m = length * 8;
            if (isPositive) {
                t >>= m;
            }
            else {
                t >>= m - 1;
            }
        }
        if (t != 0L) {
            throw new RecordException("Field is to big: " + val + " ~ " + t);
        }
    }
    
    public static final String numTrim(final String s) {
        return numTrim(s, '.');
    }
    
    public static final String numTrim(String s, final char decimalCharacter) {
    	int i = 0;
    	/*      */ 
    	/*      */     
    	/*  752 */     String pref = "";
    	/*      */     
    	/*  754 */     s = s.trim();
    	/*  755 */     if (s.startsWith("-")) {
    	/*  756 */       pref = "-";
    	/*  757 */       s = s.substring(1);
    	/*  758 */     } else if (s.startsWith("+")) {
    	/*  759 */       s = s.substring(1);
    	/*      */     } 
    	/*      */     
    	/*  762 */     if (s.length() == 0) {
    	/*  763 */       return s;
    	/*      */     }
    	/*      */     
    	/*  766 */     int ch = s.charAt(0);
    	/*  767 */     int len = s.length() - 1;
    	/*  768 */     while (i < len && (ch == 32 || ch == 48)) {
    	/*  769 */       i++;
    	/*  770 */       ch = s.charAt(i);
    	/*      */     } 
    	/*      */ 
    	/*      */     
    	/*  774 */     if (i > 0) {
    	/*      */       
    	/*  776 */       if (s.charAt(i) == decimalCharacter) {
    	/*  777 */         i--;
    	/*      */       }
    	/*  779 */       s = s.substring(i);
    	/*      */     } 
    	/*      */     
    	/*  782 */     if (decimalCharacter != ',' && s.indexOf(",") >= 0) {
    	/*  783 */       StringBuffer b = new StringBuffer(s.length());
    	/*  784 */       int e = s.length();
    	/*      */       
    	/*  786 */       for (i = 0; i < e; i++) {
    	/*  787 */         char chr = s.charAt(i);
    	/*  788 */         if (chr != ',') {
    	/*  789 */           b.append(chr);
    	/*      */         }
    	/*      */       } 
    	/*  792 */       s = b.toString();
    	/*      */     } 
    	/*      */     
    	/*  795 */     return pref + s.trim();
    }
     
    public static final boolean isInt(final String s) {
        boolean ret = false;
        final String ss = s.trim();
        final int len = ss.length();
        int firstIndex = 0;
        if (len > 0) {
            final char first = ss.charAt(firstIndex);
            if (first == '+' || first == '-') {
                if (len == 1) {
                    return false;
                }
                ++firstIndex;
            }
            for (int i = firstIndex; i < len; ++i) {
                if (!Character.isDigit(ss.charAt(i))) {
                    return false;
                }
            }
            ret = true;
        }
        return ret;
    }
    
    public static final String getCopyBookId(final String fileName) {
        String lCopyBook = fileName;
        int pos = lCopyBook.lastIndexOf(Constants.FILE_SEPERATOR);
        if ("\\".equals(Constants.FILE_SEPERATOR) || "/".equals(Constants.FILE_SEPERATOR)) {
            pos = Math.max(lCopyBook.lastIndexOf("/"), lCopyBook.lastIndexOf("\\"));
        }
        if (pos < 0) {
            pos = lCopyBook.lastIndexOf("/");
        }
        if (pos >= 0) {
            lCopyBook = lCopyBook.substring(pos + 1);
        }
        pos = lCopyBook.indexOf(46);
        if (pos >= 0) {
            lCopyBook = lCopyBook.substring(0, pos);
        }
        return lCopyBook;
    }
    
    public static final StringBuilder replace(final String in, final String from, final String to) {
        return replace(new StringBuilder(in), from, to);
    }
    
    public static final StringBuilder replace(final StringBuilder in, final String from, final String to) {
        final int fromLen = from.length();
        for (int start = in.indexOf(from, 0); start >= 0; start = in.indexOf(from, start + to.length())) {
            in.replace(start, start + fromLen, to);
        }
        return in;
    }
    
    public static byte[] getCsvDelimBytes(String s, final String font, final char defaultChar) {
        byte[] ret = null;
        if (s != null) {
            if (isHexDefinition(s)) {
                ret = new byte[] { getByteFromHexString(s) };
            }
            else {
                s = decodeCsvField(s, font, defaultChar);
                ret = getBytes(s, font);
            }
        }
        return ret;
    }
    
    public static boolean isHexDefinition(final String s) {
        return s.length() > 1 && (s.charAt(0) == 'x' || s.charAt(0) == 'X');
    }
    
    public static byte getByteFromHexString(final String s) {
        final int len = s.length();
        final int end = s.endsWith("'") ? (len - 1) : len;
        final int st = (s.length() > 1 && s.charAt(1) == '\'') ? 2 : 1;
        final int b = Integer.parseInt(s.substring(st, end), 16);
        return (byte)b;
    }
    
    public static final String decodeCsvField(String pDelim, final String fontName, final char defaultChar) {
        String delimiter = pDelim;
        if (pDelim == null || (pDelim = pDelim.trim()).equalsIgnoreCase("<tab>") || pDelim.equalsIgnoreCase("<default>") || "\\t".equals(pDelim)) {
            delimiter = "\t";
        }
        else if (pDelim.length() != 0 && delimiter.length() != 1 && !pDelim.startsWith("x'")) {
            if (!pDelim.startsWith("X'")) {
                if (pDelim.equalsIgnoreCase("<space>")) {
                    delimiter = " ";
                }
                else {
                   delimiter = decodeCharStr(pDelim, fontName, defaultChar);
                }
            }
        }
        return delimiter;
    }
    
    public static String decodeCharStr(String charId, final String font, final char defaultChar) {
        final int charLength = charId.length();
        if (charLength != 1) {
            if ("<tab>".equalsIgnoreCase(charId) || "<default>".equalsIgnoreCase(charId) || "\\t".equals(charId)) {
                charId = "\t";
            }
            else if ("<space>".equalsIgnoreCase(charId)) {
                charId = " ";
            }
            else if (charLength > 1 && charLength < 7) {
                charId = new String(decodeChar(charId, font, defaultChar));
            }
        }
        return charId;
    }
    
    public static String encodeCharStr(String delim) {
        if ("\t".equals(delim)) {
            delim = "<Tab>";
        }
        else if ("\t".equals(" ")) {
            delim = "<Space>";
        }
        return delim;
    }
    
    public static char[] decodeChar(String charId, final String font, final char defaultChar) {
        char[] ch = charId.toCharArray();
        final int charLength = charId.length();
        Label_0296: {
            switch (charLength) {
                case 0: {
                    throw new RuntimeException("A char string must have a length > 0");
                }
                case 1: {
                    break;
                }
                default: {
                    final char ch2 = charId.charAt(0);
                    final char ch3 = charId.charAt(1);
                    switch (ch2) {
                        case '<': {
                            if ("<tab>".equalsIgnoreCase(charId)) {
                                ch = Conversion.TAB_ARRAY;
                                break Label_0296;
                            }
                            if ("<default>".equalsIgnoreCase(charId)) {
                                ch = new char[] { defaultChar };
                                break Label_0296;
                            }
                            if ("<space>".equalsIgnoreCase(charId)) {
                                ch = new char[] { ' ' };
                                break Label_0296;
                            }
                            break Label_0296;
                        }
                        case '\\': {
                            if (ch3 == 'u' || ch3 == 'U') {
                                ch = new char[] { (char)Integer.parseInt(charId.substring(2), 16) };
                                break Label_0296;
                            }
                            if (ch3 == 't' || ch3 == 'T') {
                                ch = Conversion.TAB_ARRAY;
                                break Label_0296;
                            }
                            break Label_0296;
                        }
                        case 'X':
                        case 'x': {
                            final int end = charId.endsWith("'") ? (charLength - 1) : charLength;
                            if (ch3 == '\'') {
                                charId = charId.substring(2, end);
                            }
                            else {
                                charId = charId.substring(1, end);
                            }
                            final byte[] bytes = { (byte)Integer.parseInt(charId, 16) };
                            ch = toString(bytes, font).toCharArray();
                            break Label_0296;
                        }
                    }
                    break;
                }
            }
        }
        return ch;
    }
    
    public static byte long2byte(final long i) {
        return (byte)i;
    }
    
    public static char getDecimalchar() {
        return '.';
    }
    
    public static NumberFormat getNumberformat() {
        return NumberFormat.getNumberInstance(Locale.US);
    }
    
    public static boolean isHtml(final String s) {
        if (s == null) {
            return false;
        }
        final String field2check = s.trim().toLowerCase();
        return field2check.indexOf(60) >= 0 && (field2check.startsWith("<html>") || field2check.indexOf("<h1>") >= 0 || field2check.indexOf("<h0>") >= 0 || field2check.indexOf("<h2>") >= 0 || field2check.indexOf("<b>") >= 0 || field2check.indexOf("<i>") >= 0 || field2check.indexOf("<em>") >= 0 || field2check.indexOf("<li>") >= 0);
    }
    
    public static String padFront(final String val, final int size, final char ch) {
        return getCharArray(size, ch) + val;
    }
    
    public static final char[] getCharArray(final int size, final char ch) {
        final char[] c = new char[size];
        Arrays.fill(c, ch);
        return c;
    }
    
    public static final String getDefaultSingleByteCharacterset() {
        return Conversion.defaultSingleByteCharacterset;
    }
    
    public static final void setDefaultSingleByteCharacterset(final String defaultSingleByteCharacterset) {
        if (Charset.isSupported(defaultSingleByteCharacterset) && !new Conversion.HoldEbcidicFlag(defaultSingleByteCharacterset).isMultiByte) {
            Conversion.defaultSingleByteCharacterset = defaultSingleByteCharacterset;
        }
    }
    
    public static final boolean isAlwaysUseDefaultSingByteCharset() {
        return Conversion.alwaysUseDefaultSingByteCharset;
    }
    
    public static final void setAlwaysUseDefaultSingByteCharset(final boolean alwaysUseDefaultSingByteCharset) {
        Conversion.alwaysUseDefaultSingByteCharset = alwaysUseDefaultSingByteCharset;
    }
    
    public static boolean isEbcidic(final String charset) {
        return getHold(charset).isEbcdic;
    }
    
    public static boolean isSingleByteEbcidic(final String charset) {
        return getHold(charset).isSingleByteEbcidic;
    }
    
    public static boolean isSingleByte(final String fontName) {
        return !getHold(fontName).isMultiByte;
    }
    
    public static boolean isMultiByte(final String fontName) {
        return getHold(fontName).isMultiByte;
    }
    
    private static Conversion.HoldEbcidicFlag getHold(final String charset) {
        Conversion.HoldEbcidicFlag hold = Conversion.holdEbcidicFlag;
        if (charset == null || charset.length() == 0) {
            hold = Conversion.DEFAULT_CHARSET_DETAILS;
        }
        else if (!charset.equalsIgnoreCase(hold.charset)) {
            hold = (Conversion.holdEbcidicFlag = new Conversion.HoldEbcidicFlag(charset));
        }
        return hold;
    }
    
    public static void setDefaultEbcidicCharacterset(final String charset) {
        if (getHold(charset).isEbcdic) {
            final byte[] b = { -64, -48 };
            final String s = toString(b, charset);
            if (s.length() == 2) {
                Conversion.positive0EbcdicZoned = s.charAt(0);
                Conversion.negative0EbcdicZoned = s.charAt(1);
            }
        }
    }
    
    public static char getPositive0EbcdicZoned() {
        return Conversion.positive0EbcdicZoned;
    }
    
    public static char getNegative0EbcdicZoned() {
        return Conversion.negative0EbcdicZoned;
    }
    
    static {
        DEFAULT_CHARSET_DETAILS = new Conversion.HoldEbcidicFlag("");
        Conversion.defaultSingleByteCharacterset = "";
        Conversion.alwaysUseDefaultSingByteCharset = false;
        TAB_ARRAY = new char[] { '\t' };
        Conversion.holdEbcidicFlag = Conversion.DEFAULT_CHARSET_DETAILS;
        IS_DEFAULT_CHARSET_SINGLE_BYTE_EBCIDIC = Conversion.DEFAULT_CHARSET_DETAILS.isSingleByteEbcidic;
        Conversion.positive0EbcdicZoned = '{';
        Conversion.negative0EbcdicZoned = '}';
        String asciiCharSet = "";
        try {
            if (Conversion.DEFAULT_CHARSET_DETAILS.isEbcdic) {
                asciiCharSet = "cp1252";
                Conversion.defaultSingleByteCharacterset = Conversion.DEFAULT_CHARSET_DETAILS.charset;
                if (Conversion.DEFAULT_CHARSET_DETAILS.isMultiByte) {
                    Conversion.defaultSingleByteCharacterset = "CP037";
                }
            }
            else if (Conversion.DEFAULT_CHARSET_DETAILS.isMultiByte) {
                asciiCharSet = "cp1252";
                setDefaultSingleByteCharacterset("cp1252");
            }
            else {
                Conversion.defaultSingleByteCharacterset = "";
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        DEFAULT_ASCII_CHARSET = asciiCharSet;
    }
    
    public static final class HoldEbcidicFlag
    {
        public final String charset;
        public final boolean isSingleByteEbcidic;
        public final boolean isMultiByte;
        public final boolean isEbcdic;
        
        public HoldEbcidicFlag(final String charset) {
            if (charset == null || charset.length() == 0) {
                this.charset = Charset.defaultCharset().name();
            }
            else {
                this.charset = charset;
            }
            this.isMultiByte = isMultiByteI(charset);
            final byte[] b = Conversion.getBytes("0", charset);
            this.isEbcdic = (b != null && b.length == 1 && b[0] == -16);
            this.isSingleByteEbcidic = (this.isEbcdic && !this.isMultiByte);
        }
        
        private static boolean isMultiByteI(final String fontName) {
            float f = 2.0f;
            if (fontName == null || fontName.length() == 0) {
                f = Charset.defaultCharset().newEncoder().maxBytesPerChar();
            }
            else if (Charset.isSupported(fontName)) {
                f = Charset.forName(fontName).newEncoder().maxBytesPerChar();
            }
            return f > 1.0f;
        }
    }
}