/*    */ package com.MainFrame.Reader.Common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecordException
/*    */   extends RuntimeException
/*    */ {
/*    */   public RecordException(boolean x, String msg) {
/* 46 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RecordException(boolean x, String msg, Throwable exception) {
/* 52 */     super(msg, exception);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RecordException(String msg) {
/* 59 */     super(BasicJrTranslation.getTrans().convert(14, msg));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RecordException(String msg, String parm) {
/* 66 */     this(msg, new Object[] { parm });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RecordException(String msg, Object[] parms) {
/* 73 */     super(BasicJrTranslation.getTrans().convertMsg(14, msg, parms));
/*    */   }
/*    */ 
/*    */   
/*    */   public RecordException(String msg, Throwable exception) {
/* 78 */     super(BasicJrTranslation.getTrans().convert(14, msg), exception);
/*    */   }
/*    */   
/*    */   public RecordException(String msg, Object[] parms, Throwable exception) {
/* 82 */     super(BasicJrTranslation.getTrans().convertMsg(14, msg, parms), exception);
/*    */   }
/*    */ }

