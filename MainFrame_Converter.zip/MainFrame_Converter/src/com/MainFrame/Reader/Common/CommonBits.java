/*     */ package com.MainFrame.Reader.Common;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonBits
/*     */ {
/*     */   public static final int LT_XML = 1;
/*     */   public static final int LT_TEXT = 2;
/*     */   public static final int LT_BYTE = 3;
/*  36 */   public static final String LINE_SEPARATOR = System.getProperty("line.separator");
/*  37 */   private static final char[] EMPTY_CHAR_ARRAY = new char[0];
/*  38 */   public static final String NULL_STRING = new String(EMPTY_CHAR_ARRAY, 0, 0);
/*  39 */   public static final Object NULL_VALUE = NULL_STRING;
/*  40 */   private static byte[] EBCDIC_EOL_BYTES = new byte[] { 21 };
/*     */   
/*  42 */   private static int defaultCobolTextFormat = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean dropCopybookFromFieldNames = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean useCsvLine = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getEolBytes(byte[] defaultEolBytes, String eolDesc, String charset) {
/*  60 */     byte[] recordSep = defaultEolBytes;
/*     */     
/*  62 */     if ("<crlf>".equals(eolDesc)) {
/*  63 */       recordSep = Constants.CRLF_BYTES;
/*  64 */     } else if (defaultEolBytes == null || "default".equals(eolDesc) || "".equals(eolDesc)) {
/*  65 */       recordSep = Constants.SYSTEM_EOL_BYTES;
/*  66 */     } else if ("<cr>".equals(eolDesc)) {
/*  67 */       recordSep = Constants.CR_BYTES;
/*  68 */     } else if ("<lf>".equals(eolDesc)) {
/*  69 */       recordSep = Constants.LF_BYTES;
/*     */     } 
/*  71 */     if (charset != null && !"".equals(charset) && Charset.isSupported(charset)) {
/*     */       try {
/*  73 */         byte[] newLineBytes = Conversion.getBytes("\n", charset);
/*  74 */         if (newLineBytes.length == 1 && newLineBytes[0] == EBCDIC_EOL_BYTES[0]) {
/*  75 */           recordSep = EBCDIC_EOL_BYTES;
/*  76 */         } else if ("<crlf>".equals(eolDesc)) {
/*  77 */           recordSep = Conversion.getBytes("\r\n", charset);
/*  78 */         } else if (eolDesc == null || "default".equals(eolDesc) || "".equals(eolDesc)) {
/*  79 */           recordSep = Conversion.getBytes(LINE_SEPARATOR, charset);
/*  80 */         } else if ("<cr>".equals(eolDesc)) {
/*  81 */           recordSep = newLineBytes;
/*  82 */         } else if ("<lf>".equals(eolDesc)) {
/*  83 */           recordSep = Conversion.getBytes("\r", charset);
/*  84 */         } else if (defaultEolBytes == null) {
/*  85 */           recordSep = newLineBytes;
/*     */         } 
/*  87 */       } catch (Exception e) {
/*  88 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*  91 */     return recordSep;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEolString(String eolDesc, String charset) {
/* 101 */     String recordSep = eolDesc;
/*     */     
/* 103 */     if ("<crlf>".equals(eolDesc)) {
/* 104 */       recordSep = "\r\n";
/* 105 */     } else if (eolDesc == null || "default".equals(eolDesc) || "".equals(eolDesc)) {
/* 106 */       recordSep = LINE_SEPARATOR;
/* 107 */     } else if ("<cr>".equals(eolDesc)) {
/* 108 */       recordSep = "\n";
/* 109 */     } else if ("<lf>".equals(eolDesc)) {
/* 110 */       recordSep = "\r";
/*     */     } 
/* 112 */     if (charset != null && !"".equals(charset) && Charset.isSupported(charset)) {
/*     */       try {
/* 114 */         byte[] newLineBytes = Conversion.getBytes("\n", charset);
/* 115 */         if (newLineBytes.length == 1 && newLineBytes[0] == EBCDIC_EOL_BYTES[0]) {
/* 116 */           recordSep = "\n";
/*     */         }
/* 118 */       } catch (Exception e) {
/* 119 */         e.printStackTrace();
/*     */       } 
/*     */     }
/* 122 */     return recordSep;
/*     */   }
/*     */   
/*     */   public static final boolean useCsvLine() {
/* 126 */     return useCsvLine;
/*     */   }
/*     */   
/*     */   public static final void setUseCsvLine(boolean useCsvLine) {
/* 130 */     CommonBits.useCsvLine = useCsvLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int getDefaultCobolTextFormat() {
/* 137 */     return defaultCobolTextFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void setDefaultCobolTextFormat(int defaultCobolTextFormat) {
/* 144 */     CommonBits.defaultCobolTextFormat = defaultCobolTextFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isDropCopybookFromFieldNames() {
/* 151 */     return dropCopybookFromFieldNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void setDropCopybookFromFieldNames(boolean dropCopybookFromFieldNames) {
/* 159 */     CommonBits.dropCopybookFromFieldNames = dropCopybookFromFieldNames;
/*     */   }
/*     */   
/*     */   public static boolean areFieldNamesOnTheFirstLine(int fileStructure) {
/* 163 */     boolean ret = false;
/* 164 */     switch (fileStructure) {
/*     */       case 47:
/*     */       case 48:
/*     */       case 49:
/*     */       case 51:
/*     */       case 54:
/*     */       case 55:
/* 171 */         ret = true; break;
/*     */     } 
/* 173 */     return ret;
/*     */   }
/*     */   
/*     */   public static boolean isEmbeddedCrSupported(int fileStructure) {
/* 177 */     boolean ret = false;
/* 178 */     switch (fileStructure) {
/*     */       case 44:
/*     */       case 45:
/*     */       case 47:
/*     */       case 48:
/*     */       case 49:
/* 184 */         ret = true; break;
/*     */     } 
/* 186 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFontRequired(int fileStructure) {
/* 192 */     boolean ret = false;
/* 193 */     switch (fileStructure) {
/*     */       case 35:
/*     */       case 36:
/*     */       case 37:
/*     */       case 38:
/* 198 */         ret = true; break;
/*     */     } 
/* 200 */     return ret;
/*     */   }
/*     */   
/*     */   public static int translateFileStructureToNotAskFont(int fileStructure) {
/* 204 */     int ret = fileStructure;
/* 205 */     switch (fileStructure) { case 35:
/* 206 */         ret = 2; break;
/* 207 */       case 36: ret = 10; break;
/* 208 */       case 37: ret = 9; break;
/* 209 */       case 38: ret = 90; break; }
/*     */     
/* 211 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getLineType(int fileStructure) {
/* 216 */     switch (fileStructure) {
/*     */       case 61:
/*     */       case 62:
/* 219 */         return 1;
/*     */       case 10:
/*     */       case 36:
/*     */       case 38:
/*     */       case 46:
/*     */       case 49:
/*     */       case 55:
/*     */       case 90:
/* 227 */         return 2;
/*     */     } 
/* 229 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean checkFor(byte[] buffer, int pos, byte[] search) {
/* 235 */     if (search == null || pos < search.length - 1 || pos >= buffer.length || search.length == 0) {
/* 236 */       return false;
/*     */     }
/*     */     
/* 239 */     int bufferStart = pos - search.length + 1;
/* 240 */     for (int i = 0; i < search.length; i++) {
/* 241 */       if (search[i] != buffer[bufferStart + i]) {
/* 242 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 246 */     return true;
/*     */   }
/*     */ }
