/*    */ package com.MainFrame.Reader.Common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecordRunTimeException
/*    */   extends RuntimeException
/*    */ {
/*    */   public RecordRunTimeException(String msg) {
/* 36 */     super(BasicJrTranslation.getTrans().convert(14, msg));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RecordRunTimeException(String msg, String parm) {
/* 43 */     this(msg, new Object[] { parm });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RecordRunTimeException(String msg, Object[] parms) {
/* 50 */     super(BasicJrTranslation.getTrans().convertMsg(14, msg, parms));
/*    */   }
/*    */   
/*    */   protected RecordRunTimeException(boolean v, String msg) {
/* 54 */     super(msg);
/*    */   }
/*    */ }

