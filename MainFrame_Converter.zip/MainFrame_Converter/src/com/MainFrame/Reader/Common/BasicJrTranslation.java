/*    */ package com.MainFrame.Reader.Common;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasicJrTranslation
/*    */   implements IJrTranslation
/*    */ {
/* 33 */   private static IJrTranslation trans = new BasicJrTranslation();
/*    */ 
/*    */ 
/*    */   
/*    */   public final String convertMsg(int type, String s, Object... params) {
/* 38 */     return MessageFormat.format(convert(type, s), params);
/*    */   }
/*    */ 
/*    */   
/*    */   public final String convert(int type, String s) {
/* 43 */     if (s == null || "".equals(s)) return s;
/*    */     
/* 45 */     return s;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static IJrTranslation getTrans() {
/* 52 */     return trans;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setTrans(IJrTranslation trans) {
/* 59 */     BasicJrTranslation.trans = trans;
/*    */   }
/*    */ }

