/*     */ package com.MainFrame.Reader.Common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Constants
/*     */ {
/*     */   public static final int NULL_INTEGER = -121;
/*     */   public static final int KEY_INDEX = -765;
/*     */   public static final int FULL_LINE = -101;
/*     */   public static final int NUMBER_OF_COPYBOOK_SOURCES = 16;
/*     */   public static final byte BYTE_LF = 10;
/*     */   public static final byte BYTE_CR = 13;
/*  52 */   public static final String LINE_SEPERATOR = System.getProperty("line.separator");
/*     */   
/*  54 */   public static final byte[] CRLF_BYTES = new byte[] { 13, 10 };
/*  55 */   public static final byte[] LF_BYTES = new byte[] { 10 };
/*  56 */   public static final byte[] CR_BYTES = new byte[] { 13 };
/*  57 */   public static final byte[] SYSTEM_EOL_BYTES = LINE_SEPERATOR.getBytes();
/*     */   
/*     */   public static final int rtBinaryRecord = 0;
/*     */   
/*     */   public static final int rtRecordLayout = 1;
/*     */   
/*     */   public static final int rtDelimited = 2;
/*     */   
/*     */   public static final int rtDelimitedAndQuote = 3;
/*     */   
/*     */   public static final int RT_XML = 6;
/*     */   
/*     */   public static final int rtGroupOfRecords = 9;
/*     */   
/*     */   public static final int rtGroupOfBinaryRecords = 10;
/*     */   
/*     */   public static final int rtFixedLengthRecords = 11;
/*     */   
/*     */   public static final int rtProtoRecord = 1;
/*     */   
/*     */   public static final int FORMAT_DEFAULT = 0;
/*     */   
/*     */   public static final int IO_DEFAULT = 0;
/*     */   
/*     */   public static final int IO_STANDARD_TEXT_FILE = 1;
/*     */   
/*     */   public static final int IO_TEXT_LINE = 1;
/*     */   
/*     */   public static final int IO_FIXED_LENGTH_RECORDS = 2;
/*     */   
/*     */   public static final int IO_FIXED_LENGTH = 2;
/*     */   
/*     */   public static final int IO_BINARY_IBM_4680 = 3;
/*     */   
/*     */   public static final int IO_VB = 4;
/*     */   
/*     */   public static final int IO_VB_DUMP = 5;
/*     */   
/*     */   public static final int IO_VB_FUJITSU = 7;
/*     */   
/*     */   public static final int IO_VB_GNU_COBOL = 8;
/*     */   
/*     */   public static final int IO_VB_OPEN_COBOL = 8;
/*     */   
/*     */   public static final int IO_BIN_TEXT = 9;
/*     */   
/*     */   public static final int IO_FIXED_LENGTH_CHAR = 10;
/*     */   
/*     */   public static final int IO_CONTINOUS_NO_LINE_MARKER = 11;
/*     */   
/*     */   public static final int IO_VBS = 12;
/*     */   
/*     */   public static final int IO_VB_DUMP2 = 14;
/*     */   
/*     */   public static final int IO_UNKOWN_FORMAT = 21;
/*     */   
/*     */   public static final int IO_WIZARD = 22;
/*     */   
/*     */   public static final int IO_MICROFOCUS = 31;
/*     */   
/*     */   public static final int IO_FIXED_BYTE_ENTER_FONT = 35;
/*     */   
/*     */   public static final int IO_FIXED_CHAR_ENTER_FONT = 36;
/*     */   
/*     */   public static final int IO_TEXT_BYTE_ENTER_FONT = 37;
/*     */   
/*     */   public static final int IO_TEXT_CHAR_ENTER_FONT = 38;
/*     */   
/*     */   public static final int IO_CSV = 44;
/*     */   
/*     */   public static final int IO_BIN_CSV = 45;
/*     */   
/*     */   public static final int IO_UNICODE_CSV = 46;
/*     */   
/*     */   public static final int IO_CSV_NAME_1ST_LINE = 47;
/*     */   
/*     */   public static final int IO_BIN_CSV_NAME_1ST_LINE = 48;
/*     */   
/*     */   public static final int IO_UNICODE_CSV_NAME_1ST_LINE = 49;
/*     */   
/*     */   public static final int IO_NAME_1ST_LINE = 51;
/*     */   
/*     */   public static final int IO_GENERIC_CSV = 52;
/*     */   
/*     */   public static final int IO_BIN_NAME_1ST_LINE = 54;
/*     */   
/*     */   public static final int IO_UNICODE_NAME_1ST_LINE = 55;
/*     */   
/*     */   public static final int IO_XML_USE_LAYOUT = 61;
/*     */   
/*     */   public static final int IO_XML_BUILD_LAYOUT = 62;
/*     */   
/*     */   public static final int IO_STANDARD_UNICODE_TEXT_FILE = 90;
/*     */   
/*     */   public static final int IO_UNICODE_TEXT = 90;
/*     */   public static final int IO_PROTO_DELIMITED = 71;
/*     */   public static final int IO_PROTO_SINGLE_MESSAGE = 72;
/*     */   public static final int IO_PROTO_SD_DELIMITED = 73;
/*     */   public static final int IO_PROTO_SD_SINGLE_MESSAGE = 74;
/*     */   public static final int IO_PROTO_TEXT = 75;
/*     */   public static final int IO_PROTO_JSON = 76;
/*     */   public static final int IO_THRIFT_FILE = 81;
/*     */   public static final int IO_AVRO_FILE = 91;
/*     */   public static final int IO_GETTEXT_PO = 101;
/*     */   public static final int IO_TIP = 102;
/*     */   @Deprecated
/*     */   public static final int DEFAULT_IO = 0;
/*     */   @Deprecated
/*     */   public static final int TEXT_LINE_IO = 1;
/*     */   @Deprecated
/*     */   public static final int FIXED_LENGTH_IO = 2;
/*     */   @Deprecated
/*     */   public static final int BINARY_IO = 3;
/*     */   @Deprecated
/*     */   public static final int VB_LINE_IO = 4;
/*     */   @Deprecated
/*     */   public static final int VB_DUMP_LINE_IO = 5;
/*     */   @Deprecated
/*     */   public static final int VB_FUJ_LINE_IO = 7;
/*     */   @Deprecated
/*     */   public static final int NAME_1ST_LINE_IO = 51;
/*     */   public static final String DEFAULT_STRING = "default";
/*     */   public static final String CRLF_STRING = "<crlf>";
/*     */   public static final String CR_STRING = "<cr>";
/*     */   public static final String LF_STRING = "<lf>";
/* 182 */   public static final String FILE_SEPERATOR = System.getProperty("file.separator");
/*     */   
/*     */   public static final String RECORD_NAME = "Record";
/*     */   
/*     */   public static final String SUB_RECORD_NAME = "SR";
/*     */   
/*     */   public static final String TXT_EXTENSION = ".Txt";
/*     */   
/*     */   public static final String XML_EXTENSION = ".Xml";
/*     */   
/*     */   public static final String RE_XML_RECORD = "RECORD";
/*     */   
/*     */   public static final String RE_XML_RECORDS = "RECORDS";
/*     */   
/*     */   public static final String RE_XML_FIELD = "FIELD";
/*     */   
/*     */   public static final String RE_XML_FIELDS = "FIELDS";
/*     */   
/*     */   public static final String RE_XML_TST_FIELD = "TSTFIELD";
/*     */   
/*     */   public static final String RE_XML_TST_FIELDS = "TSTFIELDS";
/*     */   
/*     */   public static final String RE_XML_AND_FIELDS = "AND";
/*     */   
/*     */   public static final String RE_XML_OR_FIELDS = "OR";
/*     */   public static final String RE_XML_TRUE = "TRUE";
/*     */   public static final String RE_XML_COPYBOOK = "COPYBOOK";
/*     */   public static final String RE_XML_COBOL_ITEMS = "ITEMS";
/*     */   public static final String RE_XML_JRECORD_NAMING = "JRecNaming";
/*     */   public static final String RE_XML_KEEP_FILLER = "KeepFiller";
/*     */   public static final String RE_XML_DROP_COPYBOOK_FROM_FIELD = "DropCopybook";
/*     */   public static final String RE_XML_COBOL_DIALECT = "DIALECT";
/*     */   public static final String RE_XML_COPYBOOK_PREF = "CopybookPref";
/*     */   public static final String RE_XML_DELIMITER = "DELIMITER";
/*     */   public static final String RE_XML_DESCRIPTION = "DESCRIPTION";
/*     */   public static final String RE_XML_FONTNAME = "FONTNAME";
/*     */   public static final String RE_XML_FILESTRUCTURE = "FILESTRUCTURE";
/*     */   public static final String RE_XML_LISTCHAR = "LIST";
/*     */   public static final String RE_XML_PARENT = "PARENT";
/*     */   public static final String RE_XML_QUOTE = "QUOTE";
/*     */   public static final String RE_XML_RECORDNAME = "RECORDNAME";
/*     */   public static final String RE_XML_RECORDLENTH = "RECORDLENGTH";
/*     */   public static final String RE_XML_RECORDTYPE = "RECORDTYPE";
/*     */   public static final String RE_XML_EMBEDDED_CR = "EMBEDDEDCR";
/*     */   public static final String RE_XML_INIT_SPACES = "INITSPACES";
/*     */   public static final String RE_XML_RECORDSEP = "RecSep";
/*     */   public static final String RE_XML_STYLE = "STYLE";
/*     */   public static final String RE_XML_SYSTEMNAME = "SYSTEMNAME";
/*     */   public static final String RE_XML_DEFAULTREC = "DEFAULTRECORD";
/*     */   public static final String RE_XML_TESTFIELD = "TESTFIELD";
/*     */   public static final String RE_XML_TESTVALUE = "TESTVALUE";
/*     */   public static final String RE_XML_LINE_NO_FIELD_NAME = "LINE_NO_FIELD_NAMES";
/*     */   public static final String RE_XML_NAME = "NAME";
/*     */   public static final String RE_XML_VALUE = "VALUE";
/*     */   public static final String RE_XML_OPERATOR = "OPERATOR";
/*     */   public static final String RE_XML_DEFAULT = "DEFAULT";
/*     */   public static final String RE_XML_COBOLNAME = "COBOLNAME";
/*     */   public static final String RE_XML_GROUP_NAMES = "GROUPNAMES";
/*     */   public static final String RE_XML_PARAMETER = "PARAMETER";
/*     */   public static final String RE_XML_CELLFORMAT = "CELLFORMAT";
/*     */   public static final String RE_XML_POS = "POSITION";
/*     */   public static final String RE_XML_LENGTH = "LENGTH";
/*     */   public static final String RE_XML_TYPE = "TYPE";
/*     */   public static final String RE_XML_DECIMAL = "DECIMAL";
/*     */   public static final String STARTS_WITH = "Starts With";
/*     */   public static final String DOES_NOT_CONTAIN = "Doesn't Contain";
/*     */   public static final String CONTAINS = "Contains";
/*     */   public static final String EMPTY = "Is Empty";
/*     */   public static final String NUM_EQ = "= (Numeric)";
/*     */   public static final String NUM_GT = "> (Numeric)";
/*     */   public static final String NUM_GE = ">= (Numeric)";
/*     */   public static final String NUM_LT = "< (Numeric)";
/*     */   public static final String NUM_LE = "<= (Numeric)";
/*     */   public static final String TEXT_EQ = "= (Text)";
/*     */   public static final String TEXT_GT = "> (Text)";
/*     */   public static final String TEXT_GE = ">= (Text)";
/*     */   public static final String TEXT_LT = "< (Text)";
/*     */   public static final String TEXT_LE = "<= (Text)";
/*     */   public static final String NUM_NE = "<> (Numeric)";
/*     */   public static final String TEXT_NE = "<> (Text)";
/*     */   public static final String REG_EXP = "Regular Expression";
/* 263 */   public static final String[] VALID_COMPARISON_OPERATORS = new String[] { "=", "eq", "!=", "<>", "ne", ">", "gt", ">=", "ge", "<", "lt", "<=", "le", "Starts With", "Doesn't Contain", "Contains", "= (Numeric)", "> (Numeric)", ">= (Numeric)", "< (Numeric)", "<= (Numeric)", "= (Text)", "> (Text)", ">= (Text)", "< (Text)", "<= (Text)", "<> (Numeric)", "<> (Text)", "Is Empty" };
/*     */ }

