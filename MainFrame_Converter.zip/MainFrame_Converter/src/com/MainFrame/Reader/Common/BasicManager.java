/*     */ package com.MainFrame.Reader.Common;
public class BasicManager<managedClass>
{
    private final int invalidIndex;
    private final int systemEntries;
    private final int userRangeStart;
    private managedClass[] objects;
    private int userSize;
    private int used;
    
    public BasicManager(final int numberOfSystemEntries, final int startOfUserRange, final managedClass[] initialArray) {
        this.used = 0;
        this.systemEntries = numberOfSystemEntries;
        this.invalidIndex = this.systemEntries - 1;
        this.userSize = initialArray.length - numberOfSystemEntries;
        this.userRangeStart = startOfUserRange;
        if (this.userSize < 0) {
            this.userSize = 0;
        }
        this.objects = initialArray;
    }
    
    public void register(final int classId, final managedClass obj) {
        final int idx = this.getIndex(classId);
        if (idx == this.invalidIndex) {
            throw new RecordRunTimeException("Invalid Index Supplied {0} Should be between {1} and {2}", new Object[] { classId, this.userRangeStart, this.userRangeStart + this.userSize });
        }
        if (idx > this.used) {
            this.used = idx;
        }
        this.objects[idx] = obj;
    }
    
    public managedClass get(final int id) {
        return (managedClass)this.objects[this.getIndex(id)];
    }
    
    protected final int getIndex(final int key) {
        int idx = this.invalidIndex;
        if (key >= 0 && key < this.systemEntries) {
            idx = key;
        }
        else if (key >= this.userRangeStart && key < this.userRangeStart + this.userSize) {
            idx = key - this.userRangeStart + this.systemEntries;
        }
        return idx;
    }
    
    public int getKey(final int index) {
        int key = index;
        if (key >= this.systemEntries) {
            key = index - this.systemEntries + this.userRangeStart;
        }
        return key;
    }
    
    public int getNumberOfEntries() {
        return this.objects.length;
    }
    
    public int getNumberUsed() {
        return this.used;
    }
    
    public int getUserSize() {
        return this.userSize;
    }
}