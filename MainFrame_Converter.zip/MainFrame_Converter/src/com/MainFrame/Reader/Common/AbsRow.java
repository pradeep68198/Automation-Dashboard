package com.MainFrame.Reader.Common;

public interface AbsRow {
  Object getField(int paramInt);
}

