/*    */ package com.MainFrame.Reader.Common;
/*    */ 
/*    */ public class ByteArray
/*    */ {
/*    */   private byte[] bytes;
/*  6 */   int size = 0;
/*    */   
/*    */   public ByteArray() {
/*  9 */     this.bytes = new byte[10];
/*    */   }
/*    */   
/*    */   public ByteArray(int size) {
/* 13 */     this.bytes = new byte[size];
/*    */   }
/*    */   public ByteArray add(byte b) {
/* 16 */     checkSize(this.size + 1);
/* 17 */     this.bytes[this.size++] = b;
/* 18 */     return this;
/*    */   }
/*    */   
/*    */   public ByteArray add(byte[] b) {
/* 22 */     checkSize(this.size + b.length);
/* 23 */     System.arraycopy(b, 0, this.bytes, this.size, b.length);
/* 24 */     this.size += b.length;
/*    */     
/* 26 */     return this;
/*    */   }
/*    */   
/*    */   public void clear() {
/* 30 */     this.size = 0;
/*    */   }
/*    */   
/*    */   public int length() {
/* 34 */     return this.size;
/*    */   }
/*    */   
/*    */   protected void checkSize(int newArraySize) {
/* 38 */     if (this.bytes.length < newArraySize) {
/* 39 */       int l = newArraySize + Math.max(5, newArraySize / 5);
/* 40 */       byte[] tmp = new byte[l];
/* 41 */       System.arraycopy(this.bytes, 0, tmp, 0, this.bytes.length);
/* 42 */       this.bytes = tmp;
/*    */     } 
/*    */   }
/*    */   public byte[] toByteArray() {
/* 46 */     byte[] ret = new byte[this.size];
/* 47 */     System.arraycopy(this.bytes, 0, ret, 0, this.size);
/* 48 */     return ret;
/*    */   }
/*    */ }
