/*    */ package com.MainFrame.Reader.Common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasicKeyedField
/*    */   implements AbsRow
/*    */ {
/*    */   public int key;
/*    */   public String name;
/* 43 */   public Boolean valid = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getField(int fldNum) {
/* 49 */     switch (fldNum) { case 0:
/* 50 */         return Integer.valueOf(this.key);
/* 51 */       case 1: return this.name;
/* 52 */       case 3: return this.valid; }
/* 53 */      return null;
/*    */   }
/*    */ }

