/*     */ package com.MainFrame.Reader.Common;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyManager
/*     */ {
/*     */   private static final int SIZE_OF_FILE_URL_PREFIX = 9;
/*  39 */   private static Properties properties = null;
/*     */ 
/*     */   
/*     */   public static Properties getProperties() {
/*  43 */     if (properties == null) {
/*  44 */       properties = readProperties(getDirectory() + "/JRecord.properties");
/*     */     }
/*  46 */     return properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getDirectory() {
/*  53 */     String baseDirectory = "/home/bm/RecordEdit/HSQLDB/lib";
/*     */     
/*  55 */     URL o = PropertyManager.class.getClassLoader().getResource("net/sf/JRecord/Common/PropertyManager.class");
/*     */     
/*  57 */     if (o != null) {
/*  58 */       String dir = o.toString();
/*     */       
/*  60 */       if (dir.startsWith("jar:")) {
/*  61 */         int pos = dir.indexOf('!');
/*     */         
/*  63 */         baseDirectory = dir.substring(9, pos);
/*  64 */         pos = baseDirectory.lastIndexOf('/');
/*  65 */         if (pos >= 0) {
/*  66 */           baseDirectory = baseDirectory.substring(0, pos);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  72 */     return baseDirectory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Properties readProperties(String name) {
/*  83 */     Properties ret = new Properties();
/*     */     
/*  85 */     File f = new File(name);
/*     */ 
/*     */ 
/*     */     
/*  89 */     if (f.exists()) {
/*  90 */       FileInputStream fs = null;
/*     */       try {
/*  92 */         fs = new FileInputStream(f);
/*  93 */         ret.load(fs);
/*  94 */       } catch (Exception exception) {
/*     */       
/*     */       } finally {
/*  97 */         if (fs != null) {
/*     */           try {
/*  99 */             fs.close();
/* 100 */           } catch (IOException iOException) {}
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 106 */     return ret;
/*     */   }
/*     */ }

