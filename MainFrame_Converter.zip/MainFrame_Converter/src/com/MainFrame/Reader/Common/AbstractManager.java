package com.MainFrame.Reader.Common;

public interface AbstractManager
{
    int getNumberOfEntries();
    
    String getManagerName();
    
    int getKey(final int p0);
    
    String getName(final int p0);
}