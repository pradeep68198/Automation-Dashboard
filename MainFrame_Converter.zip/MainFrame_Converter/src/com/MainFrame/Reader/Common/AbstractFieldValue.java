package com.MainFrame.Reader.Common;

import java.math.BigDecimal;
import java.math.BigInteger;

public interface AbstractFieldValue {
  String asString();
  
  long asLong();
  
  int asInt();
  
  double asDouble();
  
  float asFloat();
  
  boolean asBoolean();
  
  BigInteger asBigInteger();
  
  BigDecimal asBigDecimal();
  
  String asHex();
  
  void set(AbstractFieldValue paramAbstractFieldValue);
  
  void set(Object paramObject);
  
  void set(long paramLong);
  
  void set(double paramDouble);
  
  void set(float paramFloat);
  
  void set(boolean paramBoolean);
  
  IFieldDetail getFieldDetail();
  
  boolean isBinary();
  
  boolean isNumeric();
  
  String getTypeName();
}
