/*    */ package com.MainFrame.Reader.Common;


public abstract class BasicNamedManager<managedClass> extends BasicManager<managedClass> implements AbstractManager
{
    private String[] names;
    private String mgrName;
    
    public BasicNamedManager(final String managerName, final int numberOfSystemEntries, final int startOfUserRange, final Object[] objects) {
        super(numberOfSystemEntries, startOfUserRange, (managedClass[])objects);
        this.names = new String[super.getNumberOfEntries()];
        this.mgrName = managerName;
    }
    
    public String getManagerName() {
        return this.mgrName;
    }
    
    public final void register(final int id, final managedClass parser) {
        this.register(id, "", parser);
    }
    
    public void register(final int id, final String name, final Object object) {
        super.register(id, (managedClass)object);
        this.names[id] = name;
    }
    
    public String getName(final int id) {
        return this.names[id];
    }
}