package com.MainFrame.Reader.Common;

public interface IGetData {
  byte[] getData();
}

