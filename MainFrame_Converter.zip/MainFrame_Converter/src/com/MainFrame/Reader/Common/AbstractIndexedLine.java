package com.MainFrame.Reader.Common;

public interface AbstractIndexedLine {
  Object getField(int paramInt1, int paramInt2);
  
  Object getField(IFieldDetail paramIFieldDetail);
  
  int getPreferredLayoutIdx();
  
  void setField(int paramInt1, int paramInt2, Object paramObject);
  
  void setField(IFieldDetail paramIFieldDetail, Object paramObject);
}

