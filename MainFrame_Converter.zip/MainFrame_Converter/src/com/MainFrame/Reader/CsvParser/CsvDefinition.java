/*     */ package com.MainFrame.Reader.CsvParser;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.detailsBasic.CsvCharDetails;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsvDefinition
/*     */   implements ICsvDefinition
/*     */ {
/*     */   private static final byte UNDEFINED = -121;
/*     */   private static final byte NO = 1;
/*     */   private static final byte YES = 2;
/*     */   private final CsvCharDetails delimiter;
/*     */   private final CsvCharDetails quote;
/*     */   private final String charset;
/*     */   private final int delimiterOrganisation;
/*     */   private final int numberOfFields;
/*     */   private final boolean embeddedCR;
/*  49 */   private byte singleByteFont = -121;
/*     */ 
/*     */ 
/*     */   
/*     */   public CsvDefinition(String delimiter, String quote) {
/*  54 */     this(delimiter, quote, 1, -1, Conversion.DEFAULT_ASCII_CHARSET, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public CsvDefinition(CsvCharDetails delimiter, CsvCharDetails quote) {
/*  59 */     this(delimiter, quote, 1, -1, delimiter.getFont(), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsvDefinition(CsvCharDetails delimiter, CsvCharDetails quote, boolean embeddedCR) {
/*  67 */     this(delimiter, quote, 1, -1, "", embeddedCR);
/*     */   }
/*     */ 
/*     */   
/*     */   public CsvDefinition(String delimiter, String quote, int delimiterOrganisation, boolean embeddedCR) {
/*  72 */     this(delimiter, quote, delimiterOrganisation, -1, "", embeddedCR);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CsvDefinition(String delimiter, String quote, int delimiterOrganisation, int numberOfFields, String charset, boolean embeddedCR) {
/*  78 */     this(CsvCharDetails.newDelimDefinition(delimiter, charset), CsvCharDetails.newQuoteDefinition(quote, charset), delimiterOrganisation, numberOfFields, charset, embeddedCR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsvDefinition(CsvCharDetails delimiter, CsvCharDetails quote, int delimiterOrganisation, int numberOfFields, String charset, boolean embeddedCR) {
/*  85 */     this.delimiter = delimiter;
/*  86 */     this.quote = quote;
/*  87 */     this.delimiterOrganisation = delimiterOrganisation;
/*  88 */     this.numberOfFields = numberOfFields;
/*  89 */     this.charset = charset;
/*  90 */     this.embeddedCR = embeddedCR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsvCharDetails getDelimiterDetails() {
/* 113 */     return this.delimiter;
/*     */   }
/*     */ 
/*     */   
/*     */   public CsvCharDetails getQuoteDefinition() {
/* 118 */     return this.quote;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDelimiterOrganisation() {
/* 126 */     return this.delimiterOrganisation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFieldCount() {
/* 135 */     return this.numberOfFields;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFontName() {
/* 144 */     return this.charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSingleByteFont() {
/* 155 */     if (this.singleByteFont == -121) {
/*     */       try {
/* 157 */         this.singleByteFont = 2;
/* 158 */         if (Conversion.isMultiByte(this.charset)) {
/* 159 */           this.singleByteFont = 1;
/*     */         }
/* 161 */       } catch (Exception e) {
/* 162 */         e.printStackTrace();
/*     */       } 
/*     */     }
/* 165 */     return (this.singleByteFont == 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmbeddedNewLine() {
/* 170 */     return this.embeddedCR;
/*     */   }
/*     */ }

