package com.MainFrame.Reader.CsvParser;

import com.MainFrame.Reader.detailsBasic.CsvCharDetails;

public interface ICsvDefinition {
  public static final int NORMAL_SPLIT = 1;
  
  public static final int SEP_FOR_EVERY_FIELD = 2;
  
  public static final int SEP_FOR_EVERY_FIELD_PLUS_END = 3;
  
  CsvCharDetails getDelimiterDetails();
  
  CsvCharDetails getQuoteDefinition();
  
  int getDelimiterOrganisation();
  
  int getFieldCount();
  
  String getFontName();
  
  boolean isSingleByteFont();
  
  boolean isEmbeddedNewLine();
}

