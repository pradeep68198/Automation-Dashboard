/*     */ package com.MainFrame.Reader.CsvParser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsvParser
/*     */ {
/*     */   public List<String> getLine(int fieldNumber, ICharIterator dataSource, ICsvDefinition lineDef) {
/*  47 */     List<String> ret = new ArrayList<String>();
/*     */     
/*  49 */     StringBuilder field = null;
/*     */ 
/*     */     
/*  52 */     int quoteIdx = 0;
/*  53 */     boolean inQuotes = false;
/*  54 */     boolean lastCharDelim = true;
/*  55 */     boolean lastCharQuote = false;
/*     */ 
/*     */     
/*  58 */     String delimiter = getDelimFromCsvDef(lineDef);
/*  59 */     String quote = lineDef.getQuoteDefinition().asString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     if (delimiter == null || delimiter.length() != 1) {
/*  66 */       throw new RuntimeException("Invalid field delimiter: " + delimiter);
/*     */     }
/*     */     
/*  69 */     char delim = delimiter.charAt(0);
/*     */     
/*  71 */     field = new StringBuilder("");
/*  72 */     lastCharDelim = true;
/*  73 */     while (dataSource.hasNext()) {
/*  74 */       char ch = dataSource.get();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  79 */       if (ch == delim && (!inQuotes || lastCharQuote)) {
/*     */         
/*  81 */         ret.add(field.toString());
/*  82 */         field = new StringBuilder();
/*  83 */         quoteIdx = 0;
/*  84 */       } else if (ch == quote.charAt(quoteIdx++) && quoteIdx >= quote.length()) {
/*  85 */         if (lastCharDelim) {
/*  86 */           inQuotes = true;
/*  87 */           lastCharQuote = false;
/*  88 */         } else if (lastCharQuote) {
/*  89 */           lastCharQuote = false;
/*  90 */           field.append(quote);
/*     */         } else {
/*  92 */           lastCharQuote = true;
/*     */         } 
/*     */       } else {
/*  95 */         if (lastCharQuote) {
/*  96 */           field.append(quote);
/*  97 */           lastCharQuote = false;
/*     */         } 
/*     */         
/* 100 */         field.append(ch);
/* 101 */         lastCharQuote = false;
/*     */       } 
/* 103 */       lastCharDelim = false;
/*     */     } 
/*     */ 
/*     */     
/* 107 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getDelimFromCsvDef(ICsvDefinition lineDef) {
/* 116 */     String delimiter = lineDef.getDelimiterDetails().asString();
/* 117 */     return delimiter;
/*     */   }
/*     */ }

