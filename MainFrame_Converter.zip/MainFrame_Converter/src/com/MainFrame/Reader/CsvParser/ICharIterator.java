package com.MainFrame.Reader.CsvParser;

public interface ICharIterator {
  boolean hasNext();
  
  char get();
}

