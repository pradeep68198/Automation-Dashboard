/*     */ package com.MainFrame.Reader.CsvParser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import com.MainFrame.Reader.Common.ByteArray;
/*     */ import com.MainFrame.Reader.Common.CommonBits;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BasicCsvByteLineParserExtended
/*     */   extends BaseCsvByteLineParser
/*     */ {
/*  58 */   public static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*     */   
/*  60 */   private static BasicCsvByteLineParserExtended instance = new BasicCsvByteLineParserExtended(false);
/*     */   
/*     */   public final int delimiterOrganisation;
/*     */   
/*     */   final boolean textFieldsInQuotes;
/*     */   
/*     */   public BasicCsvByteLineParserExtended(boolean quoteInColumnNames) {
/*  67 */     this(quoteInColumnNames, 1, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicCsvByteLineParserExtended(boolean quoteInColumnNames, int delimiterOrganisation) {
/*  73 */     this(quoteInColumnNames, delimiterOrganisation, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicCsvByteLineParserExtended(boolean quoteInColumnNames, int delimiterOrganisation, boolean allowReturnInFields, boolean textFieldsInQuotes) {
/*  79 */     super(quoteInColumnNames, allowReturnInFields);
/*  80 */     this.delimiterOrganisation = delimiterOrganisation;
/*  81 */     this.textFieldsInQuotes = textFieldsInQuotes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] formatField(String s, int fieldType, ICsvDefinition lineDef) {
/* 106 */     byte[] ret = EMPTY_BYTE_ARRAY;
/* 107 */     if (s != null && s.length() > 0) {
/* 108 */       ret = formatField(Conversion.getBytes(s, lineDef.getFontName()), fieldType, lineDef);
/*     */     }
/* 110 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] formatField(byte[] ret, int fieldType, ICsvDefinition lineDef) {
/* 116 */     String fontname = lineDef.getFontName();
/* 117 */     byte[] quote = lineDef.getQuoteDefinition().asBytes();
/* 118 */     if (quote != null && quote.length > 0 && ret != null && ret.length > 0) {
/* 119 */       byte[] delim = getDelimFromCsvDef(lineDef);
/* 120 */       byte[] cr = Conversion.getBytes("\n", fontname);
/* 121 */       byte[] lf = Conversion.getBytes("\r", fontname);
/*     */       
/* 123 */       if (this.textFieldsInQuotes && fieldType != 21) {
/* 124 */         ret = encodeField(ret, quote, delim, cr, lf);
/*     */       } else {
/* 126 */         for (int i = 0; i < ret.length; i++) {
/* 127 */           if (CommonBits.checkFor(ret, i, delim) || 
/* 128 */             CommonBits.checkFor(ret, i, quote) || 
/* 129 */             CommonBits.checkFor(ret, i, cr) || 
/* 130 */             CommonBits.checkFor(ret, i, lf)) {
/* 131 */             ret = encodeField(ret, quote, delim, cr, lf);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 137 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] encodeField(byte[] ret, byte[] quote, byte[] delim, byte[] cr, byte[] lf) {
/* 143 */     ByteArray newFld = new ByteArray(ret.length + 10);
/* 144 */     int ql = quote.length - 1;
/* 145 */     int dl = delim.length - 1;
/* 146 */     newFld.add(quote);
/*     */     
/* 148 */     for (int j = 0; j < ret.length; j++) {
/* 149 */       if (CommonBits.checkFor(ret, j + dl, delim)) {
/* 150 */         newFld.add(delim);
/* 151 */         j += dl;
/* 152 */       } else if (CommonBits.checkFor(ret, j + ql, quote)) {
/* 153 */         newFld.add(quote).add(quote);
/* 154 */         j += ql;
/* 155 */       } else if (CommonBits.checkFor(ret, j, cr)) {
/* 156 */         newFld.add(cr);
/* 157 */       } else if (CommonBits.checkFor(ret, j, lf)) {
/* 158 */         newFld.add(lf);
/*     */       } else {
/* 160 */         newFld.add(ret[j]);
/*     */       } 
/*     */     } 
/* 163 */     newFld.add(quote);
/* 164 */     return newFld.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BasicCsvByteLineParserExtended getInstance() {
/* 174 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getFieldCount(byte[] line, ICsvDefinition lineDef) {
/* 187 */     byte[][] fields = splitBytes(line, lineDef, 0, new BasicLineParserHelper(line, lineDef));
/*     */     
/* 189 */     if (fields == null) {
/* 190 */       return 0;
/*     */     }
/*     */     
/* 193 */     return fields.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getField(int fieldNumber, byte[] line, ICsvDefinition lineDef) {
/* 202 */     String[] fields = split(line, lineDef, fieldNumber);
/*     */     
/* 204 */     if (fields == null || fields.length <= fieldNumber || fields[fieldNumber] == null) {
/* 205 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     return fields[fieldNumber];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<String> getFieldList(byte[] line, ICsvDefinition csvDefinition) {
/* 231 */     String[] fields = split(line, csvDefinition, 0);
/* 232 */     if (fields == null) {
/* 233 */       return new ArrayList<String>(1);
/*     */     }
/*     */     
/* 236 */     return Arrays.asList(fields);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] setFieldByteLine(int fieldNumber, int fieldType, byte[] line, ICsvDefinition lineDef, String newValue) {
/* 247 */     byte[][] fields = splitBytes(line, lineDef, fieldNumber, new BasicLineParserHelper(line, lineDef));
/*     */     
/* 249 */     if (fields == null || fields.length == 0) {
/* 250 */       fields = initArray(fieldNumber + 1);
/*     */     }
/*     */     
/* 253 */     fields[fieldNumber] = formatField(newValue, fieldType, lineDef);
/*     */     
/* 255 */     return formatFieldArray(fields, lineDef);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[][] initArray(int count) {
/* 264 */     byte[][] ret = new byte[count][];
/*     */     
/* 266 */     for (int i = 0; i < count; i++) {
/* 267 */       ret[i] = EMPTY_BYTE_ARRAY;
/*     */     }
/*     */     
/* 270 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] split(byte[] line, ICsvDefinition lineDefinition, int min) {
/* 285 */     byte[][] values = splitBytes(line, lineDefinition, min);
/* 286 */     String[] ret = new String[values.length];
/* 287 */     String fontName = lineDefinition.getFontName();
/*     */     
/* 289 */     for (int i = 0; i < values.length; i++) {
/* 290 */       ret[i] = (values[i] == null || (values[i]).length == 0) ? "" : Conversion.toString(values[i], fontName);
/*     */     }
/*     */     
/* 293 */     return ret;
/*     */   }
/*     */   
/*     */   public final byte[][] splitBytes(byte[] line, ICsvDefinition lineDefinition, int min) {
/* 297 */     return splitBytes(line, lineDefinition, min, new StandardLineParserHelper(line, lineDefinition));
/*     */   }
/*     */   
/*     */   private final byte[][] splitBytes(byte[] line, ICsvDefinition lineDefinition, int min, IParseLineHelper parseHelper) {
/* 301 */     byte[] delimiter = getDelimFromCsvDef(lineDefinition);
/* 302 */     if (delimiter == null || line == null || delimiter.length == 0)
/*     */     {
/* 304 */       return (byte[][])null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 309 */     int idx = 0;
/*     */     
/* 311 */     byte[] quote = lineDefinition.getQuoteDefinition().asBytes();
/*     */ 
/*     */     
/* 314 */     int count = 1;
/* 315 */     int delimLengthm1 = delimiter.length - 1;
/* 316 */     for (int i = 0; i < line.length; i++) {
/* 317 */       if (CommonBits.checkFor(line, i, delimiter)) {
/* 318 */         count++;
/* 319 */         i += delimLengthm1;
/*     */       } 
/*     */     } 
/*     */     
/* 323 */     byte[][] temp = new byte[Math.max(count, min)][];
/*     */ 
/*     */     
/* 326 */     if (!isQuote(quote)) {
/* 327 */       int start = 0;
/*     */       
/* 329 */       for (int j = 0; j < line.length; j++) {
/* 330 */         if (CommonBits.checkFor(line, j, delimiter)) {
/* 331 */           if (j == start) {
/* 332 */             temp[idx++] = EMPTY_BYTE_ARRAY;
/*     */           } else {
/* 334 */             temp[idx++] = extract(line, start, j);
/*     */           } 
/* 336 */           j += delimLengthm1;
/* 337 */           start = j + 1;
/*     */         } 
/*     */       } 
/* 340 */       if (line.length > start) {
/* 341 */         temp[idx++] = extract(line, start, line.length);
/*     */       }
/*     */     } else {
/* 344 */       int start = parseHelper.start();
/* 345 */       parseHelper.setDetails(count, min);
/*     */       
/* 347 */       for (int j = start; j < line.length; j++) {
/* 348 */         if (CommonBits.checkFor(line, j, delimiter) && parseHelper
/* 349 */           .isQuote(j)) {
/* 350 */           j = parseHelper.newField(j);
/* 351 */         } else if (CommonBits.checkFor(line, j + quote.length - 1, quote)) {
/* 352 */           j = parseHelper.quote(j);
/*     */         } else {
/* 354 */           parseHelper.normalChar(j);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 394 */       temp = parseHelper.fields();
/* 395 */       idx = parseHelper.fieldCount();
/*     */     } 
/*     */     
/* 398 */     byte[][] ret = temp;
/* 399 */     int newLength = Math.max(idx, min + 1);
/* 400 */     if (newLength != temp.length) {
/* 401 */       ret = new byte[newLength][];
/* 402 */       System.arraycopy(temp, 0, ret, 0, idx);
/*     */ 
/*     */ 
/*     */       
/* 406 */       for (int j = idx; j < newLength; j++) {
/* 407 */         ret[j] = EMPTY_BYTE_ARRAY;
/*     */       }
/*     */     } 
/*     */     
/* 411 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] extract(byte[] line, int start, int i) {
/* 521 */     byte[] fld = new byte[i - start];
/* 522 */     System.arraycopy(line, start, fld, 0, i - start);
/* 523 */     return fld;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean isQuote(byte[] quote) {
/* 531 */     return (quote != null && quote.length > 0);
/*     */   }
/*     */   
/*     */   private static interface IParseLineHelper {
/*     */     void setDetails(int param1Int1, int param1Int2);
/*     */     
/*     */     int start();
/*     */     
/*     */     int fieldCount();
/*     */     
/*     */     boolean isQuote(int param1Int);
/*     */     
/*     */     int newField(int param1Int);
/*     */     
/*     */     int quote(int param1Int);
/*     */     
/*     */     void normalChar(int param1Int);
/*     */     
/*     */     byte[][] fields(); }
/*     */   
/*     */   private abstract class BaseLineParserHelper implements IParseLineHelper {
/*     */     final byte[] line;
/*     */     final byte[] delimiter;
/*     */     final byte[] quote;
/*     */     final int delimLengthm1;
/*     */     final int start;
/*     */     ByteArray buf;
/*     */     byte[][] temp;
/*     */     boolean inQuote;
/* 560 */     int idx = 0;
/* 561 */     int quotePos = -11;
/*     */     
/*     */     private BaseLineParserHelper(byte[] line, ICsvDefinition csvDef) {
/* 564 */       this.line = line;
/* 565 */       this.delimiter = BasicCsvByteLineParserExtended.this.getDelimFromCsvDef(csvDef);
/* 566 */       this.quote = csvDef.getQuoteDefinition().asBytes();
/*     */       
/* 568 */       this.delimLengthm1 = this.delimiter.length - 1;
/*     */       
/* 570 */       if (this.quote == null || this.quote.length == 0) {
/* 571 */         this.inQuote = false;
/* 572 */         this.start = 0;
/*     */       } else {
/* 574 */         this.inQuote = CommonBits.checkFor(line, this.quote.length - 1, this.quote);
/* 575 */         this.start = this.inQuote ? this.quote.length : 0;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final int fieldCount() {
/* 582 */       return this.idx;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean isQuote(int pos) {
/* 588 */       return (this.quotePos == pos - this.quote.length || !this.inQuote);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setDetails(int fldCount, int min) {
/* 594 */       this.buf = new ByteArray(Math.max(20, this.line.length / Math.max(1, fldCount)));
/* 595 */       this.temp = new byte[Math.max(fldCount, min)][];
/*     */     }
/*     */   }
/*     */   
/*     */   private class BasicLineParserHelper extends BaseLineParserHelper {
/*     */     int fldStart;
/*     */     
/*     */     private BasicLineParserHelper(byte[] line, ICsvDefinition csvDef) {
/* 603 */       super(line, csvDef);
/* 604 */       this.fldStart = 0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int start() {
/* 610 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int newField(int pos) {
/* 616 */       if (pos == this.fldStart) {
/* 617 */         this.temp[this.idx++] = BasicCsvByteLineParserExtended.EMPTY_BYTE_ARRAY;
/*     */       } else {
/* 619 */         this.temp[this.idx++] = BasicCsvByteLineParserExtended.this.extract(this.line, this.fldStart, pos);
/*     */       } 
/* 621 */       pos += this.delimLengthm1;
/* 622 */       this.inQuote = CommonBits.checkFor(this.line, pos + this.quote.length, this.quote);
/* 623 */       this.fldStart = pos + 1;
/* 624 */       if (this.inQuote) {
/* 625 */         pos += this.quote.length;
/*     */       }
/* 627 */       return pos;
/*     */     }
/*     */ 
/*     */     
/*     */     public int quote(int pos) {
/* 632 */       if (this.quotePos < pos - this.quote.length) {
/* 633 */         this.quotePos = pos;
/*     */       }
/* 635 */       return pos + this.quote.length - 1;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void normalChar(int pos) {}
/*     */ 
/*     */     
/*     */     public byte[][] fields() {
/* 644 */       if (this.line.length > this.fldStart) {
/* 645 */         this.temp[this.idx++] = BasicCsvByteLineParserExtended.this.extract(this.line, this.fldStart, this.line.length);
/*     */       }
/*     */       
/* 648 */       return this.temp;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class StandardLineParserHelper
/*     */     extends BaseLineParserHelper
/*     */   {
/*     */     private StandardLineParserHelper(byte[] line, ICsvDefinition csvDef) {
/* 657 */       super(line, csvDef);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final int start() {
/* 663 */       return this.start;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int newField(int pos) {
/* 669 */       if (this.buf.length() == 0) {
/* 670 */         this.temp[this.idx++] = BasicCsvByteLineParserExtended.EMPTY_BYTE_ARRAY;
/*     */       } else {
/* 672 */         this.temp[this.idx++] = this.buf.toByteArray();
/*     */       } 
/* 674 */       pos += this.delimLengthm1;
/*     */       
/* 676 */       this.buf.clear();
/* 677 */       this.inQuote = CommonBits.checkFor(this.line, pos + this.quote.length, this.quote);
/* 678 */       if (this.inQuote) {
/* 679 */         pos += this.quote.length;
/*     */       }
/* 681 */       return pos;
/*     */     }
/*     */ 
/*     */     
/*     */     public int quote(int pos) {
/* 686 */       if (this.quotePos < pos - this.quote.length) {
/* 687 */         this.quotePos = pos;
/*     */       } else {
/* 689 */         this.buf.add(this.quote);
/*     */       } 
/* 691 */       return pos + this.quote.length - 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public void normalChar(int pos) {
/* 696 */       if (this.quotePos == pos - this.quote.length) {
/* 697 */         this.buf.add(this.quote);
/*     */       }
/*     */       
/* 700 */       this.buf.add(this.line[pos]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public byte[][] fields() {
/* 707 */       if (this.buf.length() > 0) {
/* 708 */         this.temp[this.idx++] = this.buf.toByteArray();
/*     */       }
/* 710 */       return this.temp;
/*     */     }
/*     */   }
/*     */ }

