/*     */ package com.MainFrame.Reader.CsvParser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ import com.MainFrame.Reader.Common.IFieldDetail;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryCsvParser
/*     */ {
/*  51 */   private static final byte[] NULL_BYTES = new byte[0];
/*  52 */   private int lastPos = 0;
/*  53 */   private int currPos = 0;
/*     */   private final byte look4;
/*  55 */   private int foundAt = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BinaryCsvParser(byte delimiter) {
/*  70 */     this.look4 = delimiter;
/*     */   }
/*     */   
/*     */   private void getPos(byte[] record, int pos) {
/*  74 */     int i = 0;
/*     */     
/*  76 */     this.lastPos = 0;
/*  77 */     this.currPos = 0;
/*  78 */     this.foundAt = 0;
/*  79 */     while (this.foundAt < pos && i < record.length) {
/*  80 */       if (record[i] == this.look4) {
/*  81 */         this.lastPos = this.currPos;
/*  82 */         this.currPos = i + 1;
/*  83 */         this.foundAt++;
/*     */       } 
/*  85 */       i++;
/*     */     } 
/*  87 */     if (this.foundAt == pos) {
/*  88 */       this.currPos--;
/*     */     } else {
/*  90 */       this.foundAt++;
/*  91 */       this.lastPos = this.currPos;
/*  92 */       this.currPos = record.length;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int countTokens(byte[] record) {
/* 102 */     int count = 1;
/*     */     
/* 104 */     if (record != null) {
/* 105 */       for (int i = 0; i < record.length; i++) {
/* 106 */         if (record[i] == this.look4) {
/* 107 */           count++;
/*     */         }
/*     */       } 
/*     */     }
/* 111 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue(byte[] record, IFieldDetail field) {
/* 121 */     return getValue(record, field.getPos(), field.getFontName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue(byte[] record, int pos, String font) {
/* 133 */     String ret = null;
/*     */     
/*     */     try {
/* 136 */       getPos(record, pos);
/*     */ 
/*     */       
/* 139 */       if (this.foundAt == pos) {
/* 140 */         ret = Conversion.getString(record, this.lastPos, Math.min(record.length, this.currPos), font);
/*     */       }
/* 142 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 146 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFieldList(byte[] line, String font) {
/* 157 */     ArrayList<String> ret = new ArrayList<String>();
/* 158 */     int start = 0;
/*     */     
/* 160 */     for (int i = 0; i < line.length; i++) {
/* 161 */       if (line[i] == this.look4) {
/* 162 */         ret.add(Conversion.getString(line, start, i, font));
/* 163 */         start = i + 1;
/*     */       } 
/*     */     } 
/* 166 */     ret.add(Conversion.getString(line, start, line.length, font));
/*     */     
/* 168 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] updateValue(byte[] record, IFieldDetail field, String value) {
/* 174 */     byte[] ret = record;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 179 */       byte[] temp = Conversion.getBytes(value, field.getFontName());
/* 180 */       getPos(record, field.getPos());
/*     */       
/* 182 */       if (this.foundAt == field.getPos()) {
/* 183 */         int currLen = this.currPos - this.lastPos;
/* 184 */         if (currLen == temp.length) {
/* 185 */           System.arraycopy(temp, 0, ret, this.lastPos, temp.length);
/*     */         } else {
/* 187 */           byte[] old = record;
/* 188 */           ret = new byte[record.length + temp.length - currLen];
/*     */           
/* 190 */           if (this.lastPos > 0) {
/* 191 */             System.arraycopy(old, 0, ret, 0, this.lastPos);
/*     */           }
/*     */           
/* 194 */           System.arraycopy(temp, 0, ret, this.lastPos, temp.length);
/* 195 */           if (this.currPos < old.length)
/*     */           {
/* 197 */             System.arraycopy(old, this.currPos, ret, this.lastPos + temp.length, old.length - this.currPos);
/*     */           }
/*     */         } 
/*     */       } else {
/* 201 */         byte[] old = record;
/* 202 */         int dif = field.getPos() - this.foundAt;
/* 203 */         if (field.getPos() == 1) {
/* 204 */           dif--;
/*     */         }
/*     */         
/* 207 */         ret = new byte[this.currPos + temp.length + dif];
/*     */         
/* 209 */         System.arraycopy(old, 0, ret, 0, this.currPos);
/* 210 */         for (int i = dif - 1; i >= 0; i--) {
/* 211 */           ret[old.length + i + 0] = this.look4;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 216 */         System.arraycopy(temp, 0, ret, old.length + dif, temp.length);
/*     */       }
/*     */     
/*     */     }
/* 220 */     catch (Exception e) {
/* 221 */       e.printStackTrace();
/* 222 */       return record;
/*     */     } 
/* 224 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] formatFieldList(List<String> fields, String font) {
/* 236 */     if (fields == null || fields.size() == 0) {
/* 237 */       return NULL_BYTES;
/*     */     }
/* 239 */     int size = countListSize(0, fields);
/* 240 */     int charSize = 1;
/* 241 */     if (Conversion.isMultiByte(font)) {
/* 242 */       charSize = 2;
/*     */     }
/*     */     
/* 245 */     byte[] sep = { this.look4 };
/* 246 */     byte[] b = Conversion.getBytes(fields.get(0), font);
/* 247 */     byte[] ret = copyTo(0, new byte[size * charSize + fields.size() - 1], b);
/* 248 */     int pos = b.length;
/*     */     
/* 250 */     for (int i = 1; i < fields.size(); i++) {
/* 251 */       b = Conversion.getBytes(fields.get(i), font);
/* 252 */       ret = copyTo(pos++, ret, sep);
/* 253 */       ret = copyTo(pos, ret, b);
/* 254 */       pos += b.length;
/*     */     } 
/*     */     
/* 257 */     if (pos < ret.length) {
/* 258 */       byte[] t = new byte[pos];
/* 259 */       System.arraycopy(ret, 0, t, 0, pos);
/* 260 */       ret = t;
/*     */     } 
/* 262 */     return ret;
/*     */   }
/*     */   
/*     */   private byte[] copyTo(int pos, byte[] to, byte[] from) {
/* 266 */     if (pos + from.length > to.length) {
/* 267 */       byte[] t = new byte[(pos + from.length + 6) * 6 / 5];
/*     */       
/* 269 */       System.arraycopy(to, 0, t, 0, pos - 1);
/* 270 */       to = t;
/*     */     } 
/* 272 */     System.arraycopy(from, 0, to, pos, from.length);
/* 273 */     return to;
/*     */   }
/*     */ 
/*     */   
/*     */   private int countListSize(int start, List<String> fields) {
/* 278 */     int size = 0;
/* 279 */     for (int i = fields.size() - 1; i >= start; i--) {
/* 280 */       size += ((String)fields.get(i)).length();
/*     */     }
/*     */     
/* 283 */     return size;
/*     */   }
/*     */ }
