/*     */ package com.MainFrame.Reader.CsvParser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import com.MainFrame.Reader.Common.ByteArray;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseCsvByteLineParser
/*     */   implements ICsvByteLineParser
/*     */ {
/*  44 */   private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*     */   
/*     */   private final boolean quoteInColNames;
/*     */ 
/*     */   
/*     */   public BaseCsvByteLineParser(boolean quoteInColumnNames, boolean allowReturnInFields) {
/*  50 */     this.quoteInColNames = quoteInColumnNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isQuoteInColumnNames() {
/*  59 */     return this.quoteInColNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getColumnNames(byte[] line, ICsvDefinition lineDef) {
/*  70 */     ArrayList<String> ret = new ArrayList<String>();
/*     */ 
/*     */     
/*  73 */     byte[] quote = lineDef.getQuoteDefinition().asBytes();
/*  74 */     byte delim = lineDef.getDelimiterDetails().asByte();
/*  75 */     String fontname = lineDef.getFontName();
/*  76 */     int start = 0;
/*     */     
/*  78 */     if (this.quoteInColNames && quote != null && quote.length > 0) {
/*  79 */       byte q = quote[0];
/*  80 */       for (int i = 0; i < line.length; i++) {
/*  81 */         if (line[i] == delim) {
/*  82 */           ret.add(extractColName(line, q, fontname, start, i - 1));
/*  83 */           start = i + 1;
/*     */         } 
/*     */       } 
/*  86 */       if (start < line.length) {
/*  87 */         ret.add(extractColName(line, q, fontname, start, line.length));
/*     */       }
/*     */     } else {
/*  90 */       for (int i = 0; i < line.length; i++) {
/*  91 */         if (line[i] == delim) {
/*  92 */           ret.add(Conversion.getString(line, start, i, fontname));
/*  93 */           start = i + 1;
/*     */         } 
/*     */       } 
/*  96 */       if (start < line.length) {
/*  97 */         ret.add(Conversion.getString(line, start, line.length, fontname));
/*     */       }
/*     */     } 
/*     */     
/* 101 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   private String extractColName(byte[] line, byte q, String fontname, int start, int end) {
/* 106 */     if (line[start] == q) {
/* 107 */       start++;
/*     */     }
/* 109 */     if (line[end] == q) {
/* 110 */       end--;
/*     */     }
/*     */     
/* 113 */     String s = "";
/* 114 */     if (end > start) {
/* 115 */       s = Conversion.getString(line, start, end, fontname);
/*     */     }
/* 117 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final byte[] getDelimFromCsvDef(ICsvDefinition lineDef) {
/* 132 */     return lineDef.getDelimiterDetails().asBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getColumnNameByteLine(List<String> names, ICsvDefinition lineDef) {
/* 143 */     ByteArray buf = new ByteArray(names.size() * 8);
/* 144 */     byte[] currDelim = EMPTY_BYTE_ARRAY;
/* 145 */     byte[] quote = lineDef.getQuoteDefinition().asBytes();
/* 146 */     byte[] delim = getDelimFromCsvDef(lineDef);
/* 147 */     String fontname = lineDef.getFontName();
/*     */     
/* 149 */     if (this.quoteInColNames) {
/* 150 */       for (int i = 0; i < names.size(); i++) {
/* 151 */         buf.add(currDelim)
/* 152 */           .add(quote)
/* 153 */           .add(Conversion.getBytes(names.get(i), fontname))
/* 154 */           .add(quote);
/* 155 */         currDelim = delim;
/*     */       } 
/*     */     } else {
/* 158 */       for (int i = 0; i < names.size(); i++) {
/* 159 */         buf.add(currDelim)
/* 160 */           .add(Conversion.getBytes(names.get(i), fontname));
/* 161 */         currDelim = delim;
/*     */       } 
/*     */     } 
/*     */     
/* 165 */     return buf.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] formatFieldListByte(List<? extends Object> fields, ICsvDefinition lineDef, int[] fieldTypes) {
/* 198 */     if (fields == null || fields.size() == 0) {
/* 199 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/*     */     
/* 202 */     byte[][] flds = new byte[fields.size()][];
/* 203 */     String fontname = lineDef.getFontName();
/*     */     
/* 205 */     int min = 0;
/* 206 */     if (fieldTypes != null) {
/* 207 */       min = Math.min(fieldTypes.length, flds.length);
/* 208 */       for (int j = 0; j < min; j++) {
/* 209 */         flds[j] = formatField(toBytes(fields.get(j), fontname), fieldTypes[j], lineDef);
/*     */       }
/*     */     } 
/* 212 */     for (int i = min; i < flds.length; i++) {
/* 213 */       flds[i] = formatField(toBytes(fields.get(i), fontname), 0, lineDef);
/*     */     }
/* 215 */     return formatFieldArray(flds, lineDef);
/*     */   }
/*     */ 
/*     */   
/*     */   private byte[] toBytes(Object o, String fontname) {
/* 220 */     if (o == null) return EMPTY_BYTE_ARRAY; 
/* 221 */     return Conversion.getBytes(o.toString(), fontname);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final byte[] formatFieldArray(byte[][] fields, ICsvDefinition lineDef) {
/* 234 */     if (fields == null || fields.length == 0) {
/* 235 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/* 237 */     int size = 0;
/* 238 */     byte[] delimiter = lineDef.getDelimiterDetails().asBytes();
/*     */     
/* 240 */     for (byte[] s : fields) {
/* 241 */       if (s != null) {
/* 242 */         size += s.length + delimiter.length;
/*     */       }
/*     */     } 
/* 245 */     ByteArray buf = new ByteArray(size);
/* 246 */     buf.add(fields[0]);
/*     */     
/* 248 */     for (int i = 1; i < fields.length; i++) {
/* 249 */       buf.add(delimiter);
/* 250 */       if (fields[i] != null) {
/* 251 */         buf.add(fields[i]);
/*     */       }
/*     */     } 
/*     */     
/* 255 */     if (lineDef.getDelimiterOrganisation() != 1 && lineDef.getFieldCount() > 0) {
/* 256 */       int en = lineDef.getFieldCount();
/* 257 */       if (lineDef.getDelimiterOrganisation() == 3) {
/* 258 */         en++;
/*     */       }
/*     */       
/* 261 */       for (int j = fields.length; j < en; j++) {
/* 262 */         buf.add(delimiter);
/*     */       }
/*     */     } 
/*     */     
/* 266 */     return buf.toByteArray();
/*     */   }
/*     */   
/*     */   protected abstract byte[] formatField(byte[] paramArrayOfbyte, int paramInt, ICsvDefinition paramICsvDefinition);
/*     */ }
