/*     */ package com.MainFrame.Reader.CsvParser;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BasicCsvLineParserExtended
/*     */   extends BasicCsvLineParser
/*     */ {
/*  50 */   private static BasicCsvLineParserExtended instance = new BasicCsvLineParserExtended(false);
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicCsvLineParserExtended(boolean quoteInColumnNames) {
/*  55 */     super(quoteInColumnNames);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicCsvLineParserExtended(boolean quoteInColumnNames, int delimiterOrganisation) {
/*  61 */     super(quoteInColumnNames, delimiterOrganisation);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicCsvLineParserExtended(boolean quoteInColumnNames, int delimiterOrganisation, boolean allowReturnInFields, boolean textFieldsInQuotes) {
/*  67 */     super(quoteInColumnNames, delimiterOrganisation, allowReturnInFields, textFieldsInQuotes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean endOfField(int startAt, String s, String quote) {
/*  76 */     int ql = quote.length();
/*  77 */     int pos = s.length();
/*  78 */     int i = 0;
/*     */ 
/*     */ 
/*     */     
/*  82 */     while ((pos > ql || (startAt > 0 && pos == ql)) && s
/*  83 */       .substring(pos - ql, pos).equals(quote)) {
/*  84 */       pos -= ql;
/*  85 */       i++;
/*     */     } 
/*     */     
/*  88 */     return (startAt + s.length() > ql * i && i % 2 == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void update4quote(String[] fields, int fieldNumber, String quote) {
/*  94 */     if (isQuote(quote) && fields[fieldNumber]
/*  95 */       .startsWith(quote) && fields[fieldNumber]
/*  96 */       .endsWith(quote)) {
/*  97 */       String v = "";
/*     */       
/*  99 */       if (fields[fieldNumber].length() >= quote.length() * 2) {
/* 100 */         int quoteLength = quote.length();
/* 101 */         v = fields[fieldNumber].substring(quoteLength, fields[fieldNumber]
/* 102 */             .length() - quoteLength);
/*     */         
/* 104 */         v = Conversion.replace(v, quote + quote, quote).toString();
/*     */       } 
/* 106 */       fields[fieldNumber] = v;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected String formatField(String s, int fieldType, ICsvDefinition lineDef) {
/* 112 */     String quote = lineDef.getQuoteDefinition().asString();
/* 113 */     if (s == null) {
/* 114 */       s = "";
/* 115 */     } else if (quote != null && quote.length() > 0 && ((this.textFieldsInQuotes && fieldType != 21) || s
/*     */       
/* 117 */       .indexOf(getDelimFromCsvDef(lineDef)) >= 0 || s
/* 118 */       .indexOf(quote) >= 0 || s
/* 119 */       .startsWith(quote) || s
/* 120 */       .indexOf('\n') >= 0 || s.indexOf('\r') >= 0)) {
/* 121 */       s = quote + Conversion.replace(s, quote, quote + quote).append(quote).toString();
/*     */     } 
/* 123 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BasicCsvLineParserExtended getInstance() {
/* 132 */     return instance;
/*     */   }
/*     */ }

