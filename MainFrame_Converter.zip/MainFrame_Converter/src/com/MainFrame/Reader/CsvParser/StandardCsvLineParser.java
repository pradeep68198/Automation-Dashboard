/*     */ package com.MainFrame.Reader.CsvParser;



import java.util.*;

public class StandardCsvLineParser extends BaseCsvLineParser
{
    private boolean textFieldsInQuotes;
    
    public StandardCsvLineParser() {
        super(false, false);
        this.textFieldsInQuotes = false;
    }
    
    public StandardCsvLineParser(final boolean putTextFieldsInQuotes) {
        super(false, false);
        this.textFieldsInQuotes = false;
        this.textFieldsInQuotes = putTextFieldsInQuotes;
    }
    
    public StandardCsvLineParser(final boolean putTextFieldsInQuotes, final boolean quoteInColumnNames) {
        this(putTextFieldsInQuotes, quoteInColumnNames, false);
    }
    
    public StandardCsvLineParser(final boolean putTextFieldsInQuotes, final boolean quoteInColumnNames, final boolean imbeddedCr) {
        super(quoteInColumnNames, imbeddedCr);
        this.textFieldsInQuotes = false;
        this.textFieldsInQuotes = putTextFieldsInQuotes;
    }
    
    public String getField(final int fieldNumber, final String line, final ICsvDefinition lineDef) {
        final String[] lineVals = this.split(fieldNumber, line, lineDef);
        String ret = lineVals[1];
        if (ret == null) {
            ret = "";
        }
        return ret;
    }
    
    public List<String> getFieldList(final String line, final ICsvDefinition csvDefinition) {
        final ArrayList<String> fields = new ArrayList<String>();
        String[] lineVals;
        for (lineVals = this.split(0, line, csvDefinition); !"".equals(lineVals[2]); lineVals = this.split(1, lineVals[2], csvDefinition)) {
            fields.add(lineVals[1]);
        }
        fields.add(lineVals[1]);
        return fields;
    }
    
    public String getField2(final int fieldNumber, final String line, final ICsvDefinition lineDef) {
        final String[] lineVals = this.split(fieldNumber, line, lineDef);
        return lineVals[1];
    }
    
    public String setField(final int fieldNumber, final int fieldType, final String line, final ICsvDefinition lineDef, final String newValue) {
        final String[] lineVals = this.split(fieldNumber, line, lineDef);
        String s = newValue;
        if (newValue == null) {
            s = "";
        }
        final String delimiter = super.getDelimFromCsvDef(lineDef);
        final String quote = lineDef.getQuoteDefinition().asString();
        int quoteLength = 1;
        if (quote != null && quote.length() > 0) {
            quoteLength = quote.length();
        }
        if (quote != null && quote.length() > 0 && (s.indexOf(delimiter) >= 0 || s.indexOf(10) >= 0 || s.indexOf(13) >= 0 || s.indexOf(quote) >= 0 || (this.textFieldsInQuotes && fieldType != 21))) {
            final StringBuffer b = new StringBuffer(s);
            int pos;
            for (int i = 0; (pos = b.indexOf(quote, i)) >= 0; i = pos + quoteLength * 2) {
                b.insert(pos, quote);
            }
            s = quote + b.toString() + quote;
        }
        return lineVals[0] + s + lineVals[2];
    }
    
    protected String formatField(String s, final int fieldType, final ICsvDefinition lineDef) {
        if (s == null) {
            s = "";
        }
        else {
            final String delimiter = super.getDelimFromCsvDef(lineDef);
            final String quote = lineDef.getQuoteDefinition().asString();
            int quoteLength = 1;
            if (quote != null && quote.length() > 0) {
                quoteLength = quote.length();
            }
            if (quote != null && quote.length() > 0 && (s.indexOf(delimiter) >= 0 || s.indexOf(10) >= 0 || s.indexOf(13) >= 0 || s.indexOf(quote) >= 0 || (this.textFieldsInQuotes & fieldType != 21))) {
                final StringBuffer b = new StringBuffer(s);
                int pos;
                for (int i = 0; (pos = b.indexOf(quote, i)) >= 0; i = pos + quoteLength * 2) {
                    b.insert(pos, quote);
                }
                s = quote + b.toString() + quote;
            }
        }
        return s;
    }
    
    private String[] split(final int fieldNumber, final String line, final ICsvDefinition lineDef) {
        final String[] ret = { null, null, "" };
        final StringBuilder pre = new StringBuilder("");
        StringBuilder field = null;
        boolean inQuotes = false;
        boolean lastCharDelim = true;
        boolean lastCharQuote = false;
        int currFieldNumber = 0;
        int i = 0;
        final String delimiter = super.getDelimFromCsvDef(lineDef);
        final String quote = lineDef.getQuoteDefinition().asString();
        int quoteLength = 1;
        if (quote != null && quote.length() > 0) {
            quoteLength = quote.length();
        }
        while (i < line.length() && currFieldNumber < fieldNumber) {
            final String s = line.substring(i, Math.min(i + quoteLength, line.length()));
            final String sCh = line.substring(i, i + 1);
            if (s.equals(quote)) {
                if (lastCharDelim) {
                    inQuotes = true;
                    lastCharQuote = false;
                }
                else {
                    lastCharQuote = !lastCharQuote;
                }
                i += quoteLength;
                pre.append(quote);
                lastCharDelim = false;
            }
            else {
                pre.append(sCh);
                lastCharDelim = false;
                if (sCh.equals(delimiter) && (!inQuotes || lastCharQuote)) {
                    lastCharDelim = true;
                    ++currFieldNumber;
                    lastCharQuote = false;
                    inQuotes = false;
                }
                ++i;
            }
        }
        if (i < line.length()) {
            field = new StringBuilder("");
            lastCharDelim = true;
            while (i < line.length()) {
                final String s = line.substring(i, Math.min(i + quoteLength, line.length()));
                final String sCh = line.substring(i, i + 1);
                if (sCh.equals(delimiter)) {
                    if (!inQuotes) {
                        break;
                    }
                    if (lastCharQuote) {
                        break;
                    }
                }
                if (s.equals(quote)) {
                    if (lastCharDelim) {
                        inQuotes = true;
                        lastCharQuote = false;
                    }
                    else if (lastCharQuote) {
                        lastCharQuote = false;
                        field.append(quote);
                    }
                    else {
                        lastCharQuote = true;
                    }
                    i += quoteLength;
                }
                else {
                    if (lastCharQuote) {
                        field.append(quote);
                        lastCharQuote = false;
                    }
                    field.append(sCh);
                    lastCharQuote = false;
                    ++i;
                }
                lastCharDelim = false;
            }
            ret[0] = pre.toString();
            ret[1] = field.toString();
            ret[2] = line.substring(i);
        }
        else {
            for (i = currFieldNumber; i < fieldNumber; ++i) {
                pre.append(delimiter);
            }
            ret[0] = pre.toString();
            ret[2] = "";
        }
        return ret;
    }
}