/*    */ package com.MainFrame.Reader.CsvParser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParserManager
/*    */   extends CsvParserManagerChar
/*    */ {
/* 11 */   private static ParserManager instance = new ParserManager();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ParserManager getInstance() {
/* 20 */     return instance;
/*    */   }
/*    */ }

