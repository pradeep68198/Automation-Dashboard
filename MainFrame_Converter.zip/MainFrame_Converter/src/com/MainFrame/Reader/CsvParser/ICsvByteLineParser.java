package com.MainFrame.Reader.CsvParser;

import java.util.List;

public interface ICsvByteLineParser
{
    boolean isQuoteInColumnNames();
    
    String getField(final int p0, final byte[] p1, final ICsvDefinition p2);
    
    byte[] setFieldByteLine(final int p0, final int p1, final byte[] p2, final ICsvDefinition p3, final String p4);
    
    List<String> getFieldList(final byte[] p0, final ICsvDefinition p1);
    
    List<String> getColumnNames(final byte[] p0, final ICsvDefinition p1);
    
    byte[] getColumnNameByteLine(final List<String> p0, final ICsvDefinition p1);
    
    byte[] formatFieldListByte(final List<?> p0, final ICsvDefinition p1, final int[] p2);
}
