package com.MainFrame.Reader.CsvParser;

import java.util.List;

public interface ICsvCharLineParser {
  boolean isQuoteInColumnNames();
  
  String getField(int paramInt, String paramString, ICsvDefinition paramICsvDefinition);
  
  String setField(int paramInt1, int paramInt2, String paramString1, ICsvDefinition paramICsvDefinition, String paramString2);
  
  List<String> getFieldList(String paramString, ICsvDefinition paramICsvDefinition);
  
  List<String> getColumnNames(String paramString, ICsvDefinition paramICsvDefinition);
  
  String getColumnNameLine(List<String> paramList, ICsvDefinition paramICsvDefinition);
  
  int getFileStructure(ICsvDefinition paramICsvDefinition, boolean paramBoolean1, boolean paramBoolean2);
  
  String formatFieldList(List<? extends Object> paramList, ICsvDefinition paramICsvDefinition, int[] paramArrayOfint);
}

