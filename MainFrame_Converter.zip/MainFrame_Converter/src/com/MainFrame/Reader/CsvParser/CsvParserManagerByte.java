	/*     */ package com.MainFrame.Reader.CsvParser;
/*     */ 
/*     */ import com.MainFrame.Reader.Common.*;
public class CsvParserManagerByte extends BasicNamedManager<ICsvByteLineParser> implements ICsvParserIds
{
    private static CsvParserManagerByte instance;
    private ICsvByteLineParser[] normalParsers;
    
    public CsvParserManagerByte() {
        super("Byte Csv_Parsers", 50, 50, (Object[])new ICsvByteLineParser[50]);
        this.normalParsers = new ICsvByteLineParser[50];
        this.register(0, "Extended Basic Parser", (Object)BasicCsvByteLineParserExtended.getInstance());
        this.register(1, "Parser - Matching Quotes", (Object)BasicCsvByteLineParserExtended.getInstance());
        this.register(2, "Parser - Quotes based on field Type", (Object)new BasicCsvByteLineParserExtended(false, 1, false, true));
        this.register(3, "X-Basic Parser Column names in quotes", (Object)new BasicCsvByteLineParserExtended(true));
        this.register(4, "Parser - Matching Quotes Column names in quotes", (Object)new BasicCsvByteLineParserExtended(true));
        this.register(5, "Parser - Quotes based on field Type, Column names in quotes", (Object)new BasicCsvByteLineParserExtended(true, 1, false, true));
        this.register(6, "X-Basic - Delimiter all fields", (Object)new BasicCsvByteLineParserExtended(false, 2));
        this.register(7, "X-Basic - Delimiter all fields + 1", (Object)new BasicCsvByteLineParserExtended(false, 3));
        this.register(8, "X-Basic - Embedded Cr", (Object)new BasicCsvByteLineParserExtended(false, 1, true, false));
        this.register(9, "Standard - Embedded Cr", (Object)new BasicCsvByteLineParserExtended(false, 1, true, false));
        this.register(10, "X-Basic - Embedded Cr Column names in quotes", (Object)new BasicCsvByteLineParserExtended(true, 1, true, false));
        this.register(11, "Standard - Embedded Cr Column names in quotes", (Object)new BasicCsvByteLineParserExtended(true, 1, true, false));
        this.register(12, "Std - Embedded Cr Col names/Txt Fields in quotes", (Object)new BasicCsvByteLineParserExtended(true, 1, true, true));
        this.register(13, "X-Basic - Text fields in quotes", (Object)new BasicCsvByteLineParserExtended(false, 1, false, true));
        this.register(14, "Basic Parser", (Object)BasicCsvByteLineParserExtended.getInstance());
        this.register(15, "Basic Parser - Quotes based on field Type", (Object)new BasicCsvByteLineParserExtended(false, 1, false, true));
    }
    
    public static CsvParserManagerByte getInstance() {
        if (CsvParserManagerByte.instance == null) {
            CsvParserManagerByte.instance = new CsvParserManagerByte();
        }
        return CsvParserManagerByte.instance;
    }
    
    public ICsvByteLineParser get(final int id) {
        if (id < 0 || id >= super.getNumberOfEntries()) {
            return (ICsvByteLineParser)super.get(0);
        }
        return (ICsvByteLineParser)super.get(id);
    }
    
    public ICsvByteLineParser get(int id, final boolean binCsv) {
        if (id < 0 || id >= super.getNumberOfEntries()) {
            id = 0;
        }
        if (!binCsv) {
            if (this.normalParsers[id] == null) {
                final Object p = CsvParserManagerChar.getInstance().get(id);
                if (p instanceof ICsvByteLineParser) {
                    this.normalParsers[id] = (ICsvByteLineParser)p;
                }
            }
            final ICsvByteLineParser r = this.normalParsers[id];
            if (r != null) {
                return r;
            }
        }
        return (ICsvByteLineParser)super.get(id);
    }
    
    static {
        CsvParserManagerByte.instance = null;
    }
}