/*     */ package com.MainFrame.Reader.CsvParser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicCsvLineParser
/*     */   extends BaseCsvLineParser
/*     */ {
/*  51 */   private static BasicCsvLineParser instance = new BasicCsvLineParser(false);
/*     */   
/*     */   public final int delimiterOrganisation;
/*     */   protected final boolean textFieldsInQuotes;
/*     */   
/*     */   public BasicCsvLineParser(boolean quoteInColumnNames) {
/*  57 */     this(quoteInColumnNames, 1, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicCsvLineParser(boolean quoteInColumnNames, int delimiterOrganisation) {
/*  63 */     this(quoteInColumnNames, delimiterOrganisation, false, false);
/*     */   }
/*     */   
/*     */   public BasicCsvLineParser(boolean quoteInColumnNames, int delimiterOrganisation, boolean allowReturnInFields, boolean textFieldsInQuotes) {
/*  67 */     super(quoteInColumnNames, allowReturnInFields);
/*  68 */     this.delimiterOrganisation = delimiterOrganisation;
/*  69 */     this.textFieldsInQuotes = textFieldsInQuotes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getFieldCount(String line, ICsvDefinition lineDef) {
/*  81 */     String[] fields = split(line, lineDef, 0);
/*     */     
/*  83 */     if (fields == null) {
/*  84 */       return 0;
/*     */     }
/*     */     
/*  87 */     return fields.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getField(int fieldNumber, String line, ICsvDefinition lineDef) {
/*  96 */     String[] fields = split(line, lineDef, fieldNumber);
/*     */     
/*  98 */     if (fields == null || fields.length <= fieldNumber || fields[fieldNumber] == null) {
/*  99 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 103 */     update4quote(fields, fieldNumber, lineDef.getQuoteDefinition().asString());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     return fields[fieldNumber];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<String> getFieldList(String line, ICsvDefinition csvDefinition) {
/* 125 */     String[] fields = split(line, csvDefinition, 0);
/* 126 */     if (fields == null) {
/* 127 */       return new ArrayList<String>(1);
/*     */     }
/* 129 */     String quote = csvDefinition.getQuoteDefinition().asString();
/* 130 */     ArrayList<String> ret = new ArrayList<String>(fields.length);
/* 131 */     for (int i = 0; i < fields.length; i++) {
/* 132 */       update4quote(fields, i, quote);
/* 133 */       ret.add(fields[i]);
/*     */     } 
/*     */     
/* 136 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void update4quote(String[] fields, int fieldNumber, String quote) {
/* 141 */     if (isQuote(quote) && fields[fieldNumber]
/* 142 */       .startsWith(quote) && fields[fieldNumber]
/* 143 */       .endsWith(quote)) {
/* 144 */       String v = "";
/*     */       
/* 146 */       if (fields[fieldNumber].length() >= quote.length() * 2) {
/* 147 */         int quoteLength = quote.length();
/* 148 */         v = fields[fieldNumber].substring(quoteLength, fields[fieldNumber]
/* 149 */             .length() - quoteLength);
/*     */       } 
/*     */       
/* 152 */       fields[fieldNumber] = v;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String setField(int fieldNumber, int fieldType, String line, ICsvDefinition lineDef, String newValue) {
/* 163 */     String[] fields = split(line, lineDef, fieldNumber);
/*     */     
/* 165 */     if (fields == null || fields.length == 0) {
/* 166 */       fields = initArray(fieldNumber + 1);
/*     */     }
/*     */     
/* 169 */     fields[fieldNumber] = formatField(newValue, fieldType, lineDef);
/*     */     
/* 171 */     return formatFieldArray(fields, lineDef);
/*     */   }
/*     */   
/*     */   protected String formatField(String s, int fieldType, ICsvDefinition lineDef) {
/* 175 */     String quote = lineDef.getQuoteDefinition().asString();
/* 176 */     if (s == null) {
/* 177 */       s = "";
/* 178 */     } else if (quote != null && quote.length() > 0 && ((this.textFieldsInQuotes && fieldType != 21) || s
/*     */       
/* 180 */       .indexOf(getDelimFromCsvDef(lineDef)) >= 0 || s
/*     */       
/* 182 */       .startsWith(quote) || s
/* 183 */       .indexOf('\n') >= 0 || s.indexOf('\r') >= 0)) {
/* 184 */       s = quote + s + quote;
/*     */     } 
/* 186 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] initArray(int count) {
/* 194 */     String[] ret = new String[count];
/*     */     
/* 196 */     for (int i = 0; i < count; i++) {
/* 197 */       ret[i] = "";
/*     */     }
/*     */     
/* 200 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] split(String line, ICsvDefinition lineDefinition, int min) {
/* 216 */     String delimiter = getDelimFromCsvDef(lineDefinition);
/* 217 */     if (delimiter == null || line == null || ""
/* 218 */       .equals(delimiter)) {
/* 219 */       return null;
/*     */     }
/*     */     
/* 222 */     int i = 0;
/*     */ 
/*     */ 
/*     */     
/* 226 */     boolean keep = true;
/* 227 */     String quote = lineDefinition.getQuoteDefinition().asString();
/*     */     
/* 229 */     StringTokenizer tok = new StringTokenizer(line, delimiter, true);
/* 230 */     int len = tok.countTokens();
/* 231 */     String[] temp = new String[Math.max(len, min)];
/*     */ 
/*     */     
/* 234 */     if (!isQuote(quote)) {
/* 235 */       while (tok.hasMoreElements()) {
/* 236 */         temp[i] = tok.nextToken();
/*     */ 
/*     */         
/* 239 */         if (delimiter.equals(temp[i])) {
/* 240 */           if (keep) {
/* 241 */             temp[i++] = "";
/*     */           }
/*     */           
/* 244 */           keep = true; continue;
/*     */         } 
/* 246 */         keep = false;
/* 247 */         i++;
/*     */       } 
/*     */ 
/*     */       
/* 251 */       if (i < temp.length) {
/* 252 */         temp[i] = "";
/*     */       }
/*     */     } else {
/* 255 */       StringBuffer buf = null;
/*     */       
/* 257 */       boolean building = false;
/* 258 */       while (tok.hasMoreElements()) {
/* 259 */         String s = tok.nextToken();
/* 260 */         if (building) {
/* 261 */           buf.append(s);
/* 262 */           if (endOfField(buf.length(), s, quote)) {
/*     */             
/* 264 */             temp[i++] = buf.toString();
/* 265 */             building = false;
/*     */             
/* 267 */             keep = false;
/*     */           }  continue;
/* 269 */         }  if (delimiter.equals(s)) {
/* 270 */           if (keep) {
/* 271 */             temp[i++] = "";
/*     */           }
/* 273 */           keep = true; continue;
/* 274 */         }  if (s.startsWith(quote) && 
/* 275 */           !endOfField(0, s, quote)) {
/* 276 */           buf = new StringBuffer(s);
/* 277 */           building = true;
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 282 */         temp[i++] = s;
/* 283 */         keep = false;
/*     */       } 
/*     */       
/* 286 */       if (building)
/*     */       {
/*     */ 
/*     */         
/* 290 */         temp[i++] = buf.toString();
/*     */       }
/*     */     } 
/*     */     
/* 294 */     String[] ret = temp;
/* 295 */     int newLength = Math.max(i, min + 1);
/* 296 */     if (newLength != temp.length) {
/* 297 */       ret = new String[newLength];
/* 298 */       System.arraycopy(temp, 0, ret, 0, i);
/*     */ 
/*     */ 
/*     */       
/* 302 */       for (int j = i; j < newLength; j++) {
/* 303 */         ret[j] = "";
/*     */       }
/*     */     } 
/*     */     
/* 307 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean endOfField(int startsAt, String s, String quote) {
/* 315 */     return (startsAt + s.length() > quote.length() && s.endsWith(quote));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean isQuote(String quote) {
/* 324 */     return (quote != null && quote.length() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BasicCsvLineParser getInstance() {
/* 332 */     return instance;
/*     */   }
/*     */ }

