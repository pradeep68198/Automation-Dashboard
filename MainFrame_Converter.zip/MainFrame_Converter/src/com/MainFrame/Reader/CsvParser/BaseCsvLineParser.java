/*     */ package com.MainFrame.Reader.CsvParser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import com.MainFrame.Reader.Common.Conversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseCsvLineParser
/*     */   implements ICsvCharLineParser, ICsvByteLineParser
/*     */ {
/*     */   private final boolean quoteInColNames;
/*     */   private final boolean allowReturnInFields;
/*     */   
/*     */   public BaseCsvLineParser(boolean quoteInColumnNames, boolean allowReturnInFields) {
/*  51 */     this.quoteInColNames = quoteInColumnNames;
/*  52 */     this.allowReturnInFields = allowReturnInFields;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isQuoteInColumnNames() {
/*  60 */     return this.quoteInColNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getColumnNames(String line, ICsvDefinition lineDef) {
/*  71 */     ArrayList<String> ret = new ArrayList<String>();
/*     */ 
/*     */     
/*  74 */     StringTokenizer tok = new StringTokenizer(line, getDelimFromCsvDef(lineDef), false);
/*     */     
/*  76 */     String quote = lineDef.getQuoteDefinition().asString();
/*     */     
/*  78 */     if (this.quoteInColNames && quote != null && quote.length() > 0) {
/*  79 */       while (tok.hasMoreElements()) {
/*  80 */         String s = tok.nextToken();
/*  81 */         if (s.startsWith(quote)) {
/*  82 */           s = s.substring(1);
/*     */         }
/*  84 */         if (s.endsWith(quote)) {
/*  85 */           s = s.substring(0, s.length() - 1);
/*     */         }
/*  87 */         ret.add(s);
/*     */       } 
/*     */     } else {
/*  90 */       while (tok.hasMoreElements()) {
/*  91 */         ret.add(tok.nextToken());
/*     */       }
/*     */     } 
/*     */     
/*  95 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getDelimFromCsvDef(ICsvDefinition lineDef) {
/* 109 */     return lineDef.getDelimiterDetails().asString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnNameLine(List<String> names, ICsvDefinition lineDef) {
/* 120 */     StringBuilder buf = new StringBuilder();
/* 121 */     String currDelim = "";
/* 122 */     String quote = lineDef.getQuoteDefinition().asString();
/* 123 */     String delim = getDelimFromCsvDef(lineDef);
/*     */     
/* 125 */     if (this.quoteInColNames) {
/* 126 */       for (int i = 0; i < names.size(); i++) {
/* 127 */         buf.append(currDelim)
/* 128 */           .append(quote)
/* 129 */           .append(names.get(i))
/* 130 */           .append(quote);
/* 131 */         currDelim = delim;
/*     */       } 
/*     */     } else {
/* 134 */       for (int i = 0; i < names.size(); i++) {
/* 135 */         buf.append(currDelim)
/* 136 */           .append(names.get(i));
/* 137 */         currDelim = delim;
/*     */       } 
/*     */     } 
/*     */     
/* 141 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFileStructure(ICsvDefinition csvDefinition, boolean namesOnFirstLine, boolean bin) {
/* 146 */     int ret = -121;
/* 147 */     String quote = csvDefinition.getQuoteDefinition().asString();
/*     */     
/* 149 */     if ((csvDefinition.isEmbeddedNewLine() || this.allowReturnInFields) && quote != null && quote
/* 150 */       .length() > 0) {
/* 151 */       ret = 44;
/* 152 */       if (bin) {
/* 153 */         ret = 45;
/* 154 */       } else if (!csvDefinition.isSingleByteFont()) {
/* 155 */         ret = 46;
/*     */       } 
/*     */       
/* 158 */       if (namesOnFirstLine) {
/* 159 */         ret += 3;
/*     */       }
/*     */     } 
/* 162 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String formatFieldList(List<? extends Object> fields, ICsvDefinition lineDef, int[] fieldTypes) {
/* 174 */     if (fields == null || fields.size() == 0) {
/* 175 */       return "";
/*     */     }
/*     */     
/* 178 */     String[] flds = new String[fields.size()];
/*     */     
/* 180 */     int min = 0;
/* 181 */     if (fieldTypes != null) {
/* 182 */       min = Math.min(fieldTypes.length, flds.length);
/* 183 */       for (int j = 0; j < min; j++) {
/* 184 */         flds[j] = formatField(toString(fields.get(j)), fieldTypes[j], lineDef);
/*     */       }
/*     */     } 
/* 187 */     for (int i = min; i < flds.length; i++) {
/* 188 */       flds[i] = formatField(toString(fields.get(i)), 1, lineDef);
/*     */     }
/* 190 */     return formatFieldArray(flds, lineDef);
/*     */   }
/*     */   
/*     */   private String toString(Object o) {
/* 194 */     String s = "";
/* 195 */     if (o != null) {
/* 196 */       s = o.toString();
/*     */     }
/* 198 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String formatFieldArray(String[] fields, ICsvDefinition lineDef) {
/* 211 */     if (fields == null || fields.length == 0) {
/* 212 */       return "";
/*     */     }
/* 214 */     StringBuffer buf = new StringBuffer(fields[0]);
/* 215 */     String delimiter = getDelimFromCsvDef(lineDef);
/* 216 */     for (int i = 1; i < fields.length; i++) {
/* 217 */       buf.append(delimiter);
/* 218 */       if (fields[i] != null) {
/* 219 */         buf.append(fields[i]);
/*     */       }
/*     */     } 
/*     */     
/* 223 */     if (lineDef.getDelimiterOrganisation() != 1 && lineDef.getFieldCount() > 0) {
/* 224 */       int en = lineDef.getFieldCount();
/* 225 */       if (lineDef.getDelimiterOrganisation() == 3) {
/* 226 */         en++;
/*     */       }
/*     */       
/* 229 */       for (int j = fields.length; j < en; j++) {
/* 230 */         buf.append(delimiter);
/*     */       }
/*     */     } 
/*     */     
/* 234 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract String formatField(String paramString, int paramInt, ICsvDefinition paramICsvDefinition);
/*     */   
/*     */   public String getField(int fieldNumber, byte[] line, ICsvDefinition csvDefinition) {
/* 241 */     return getField(fieldNumber, toString(line, csvDefinition), csvDefinition);
/*     */   }
/*     */   
/*     */   protected String toString(byte[] line, ICsvDefinition csvDefinition) {
/* 245 */     return Conversion.toString(line, csvDefinition.getFontName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] setFieldByteLine(int fieldNumber, int fieldType, byte[] line, ICsvDefinition csvDefinition, String newValue) {
/* 252 */     String fontname = csvDefinition.getFontName();
/* 253 */     return Conversion.getBytes(
/* 254 */         setField(fieldNumber, fieldType, Conversion.toString(line, fontname), csvDefinition, newValue), fontname);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFieldList(byte[] line, ICsvDefinition csvDefinition) {
/* 260 */     return getFieldList(toString(line, csvDefinition), csvDefinition);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getColumnNames(byte[] line, ICsvDefinition csvDefinition) {
/* 265 */     return getColumnNames(toString(line, csvDefinition), csvDefinition);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getColumnNameByteLine(List<String> names, ICsvDefinition csvDefinition) {
/* 270 */     return Conversion.getBytes(
/* 271 */         getColumnNameLine(names, csvDefinition), csvDefinition
/* 272 */         .getFontName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] formatFieldListByte(List<? extends Object> fields, ICsvDefinition csvDefinition, int[] fieldTypes) {
/* 278 */     return Conversion.getBytes(
/* 279 */         formatFieldList(fields, csvDefinition, fieldTypes), csvDefinition
/* 280 */         .getFontName());
/*     */   }
/*     */ }
