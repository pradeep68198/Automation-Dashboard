/*     */ package com.MainFrame.Reader.CsvParser;
import com.MainFrame.Reader.Common.*;

public class CsvParserManagerChar extends BasicNamedManager<ICsvCharLineParser> implements ICsvParserIds
{
    private static final boolean USE_NEW_CSV_PARSERS = true;
    private static CsvParserManagerChar instance;
    
    public CsvParserManagerChar() {
        this(true);
    }
    
    private CsvParserManagerChar(final boolean newformat) {
        super("Csv_Parsers", 50, 50, (Object[])new ICsvCharLineParser[50]);
        this.defineNewParsers();
    }
    
    private void defineNewParsers() {
        this.register(0, "Extended Basic Parser", (Object)BasicCsvLineParserExtended.getInstance());
        this.register(1, "Parser - Matching Quotes", (Object)new StandardCsvLineParser());
        this.register(2, "Parser - Quotes based on field Type", (Object)new BasicCsvLineParserExtended(false, 1, false, true));
        this.register(3, "X-Basic Parser Column names in quotes", (Object)new BasicCsvLineParserExtended(true));
        this.register(4, "Parser - Matching Quotes Column names in quotes", (Object)new StandardCsvLineParser(false, true));
        this.register(5, "Parser - Quotes based on field Type, Column names in quotes", (Object)new StandardCsvLineParser(true, true));
        this.register(6, "X-Basic - Delimiter all fields", (Object)new BasicCsvLineParserExtended(false, 2));
        this.register(7, "X-Basic - Delimiter all fields + 1", (Object)new BasicCsvLineParserExtended(false, 3));
        this.register(8, "X-Basic - Embedded Cr", (Object)new BasicCsvLineParserExtended(false, 1, true, false));
        this.register(9, "Standard - Embedded Cr", (Object)new StandardCsvLineParser(false, true, true));
        this.register(10, "X-Basic - Embedded Cr Column names in quotes", (Object)new BasicCsvLineParserExtended(true, 1, true, false));
        this.register(11, "Standard - Embedded Cr Column names in quotes", (Object)new StandardCsvLineParser(false, true, true));
        this.register(12, "Std - Embedded Cr Col names/Txt Fields in quotes", (Object)new StandardCsvLineParser(true, true, true));
        this.register(13, "X-Basic - Text fields in quotes", (Object)new BasicCsvLineParserExtended(false, 1, false, true));
        this.register(14, "Basic Parser", (Object)BasicCsvLineParser.getInstance());
        this.register(15, "Basic Parser - Quotes based on field Type", (Object)new StandardCsvLineParser(true));
    }
    
    public ICsvCharLineParser get(final int id) {
        if (id < 0 || id >= super.getNumberOfEntries()) {
            return (ICsvCharLineParser)super.get(0);
        }
        return (ICsvCharLineParser)super.get(id);
    }
    
    public static final boolean isUseNewCsvParsers() {
        return true;
    }
    
    public static CsvParserManagerChar getInstance() {
        if (CsvParserManagerChar.instance == null) {
            CsvParserManagerChar.instance = new CsvParserManagerChar(true);
        }
        return CsvParserManagerChar.instance;
    }
    
    static {
        CsvParserManagerChar.instance = null;
    }
}