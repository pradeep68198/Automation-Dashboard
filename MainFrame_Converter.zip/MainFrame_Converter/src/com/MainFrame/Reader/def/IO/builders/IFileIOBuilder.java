package com.MainFrame.Reader.def.IO.builders;



public interface IFileIOBuilder extends IIOBuilder {
	
	public abstract IFileIOBuilder setFileOrganization(int fileOrganization);

	public abstract IFileIOBuilder setFont(String font);

	
	public IFileIOBuilder setDefaultFont(String font);
	
//	
//	public IFileIOBuilder setDefaultFileOrganization(int fileOrganization);
}
