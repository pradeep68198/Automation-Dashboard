
package com.MainFrame.Reader.def.IO.builders;

import java.io.IOException;

import com.MainFrame.Reader.Details.AbstractLine;


public interface INewLineCreator {

	public abstract AbstractLine newLine() throws IOException;

}
