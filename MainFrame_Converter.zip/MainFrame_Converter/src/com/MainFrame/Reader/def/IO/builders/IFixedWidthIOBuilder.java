
package com.MainFrame.Reader.def.IO.builders;

import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;


public interface IFixedWidthIOBuilder extends IIOBuilder {

	
	public abstract IFixedWidthIOBuilder setFileOrganization(int fileOrganization);
	
	
	public abstract IFixedWidthIOBuilder setFont(String font);

	

	
	public abstract IFixedWidthIOBuilder setRecordSelection(String recordName, ExternalSelection selectionCriteria);


	
	public abstract IDefineFixedFieldsByPosition defineFieldsByPosition();

	
	public abstract IDefineFixedFieldsByLength defineFieldsByLength();
}
