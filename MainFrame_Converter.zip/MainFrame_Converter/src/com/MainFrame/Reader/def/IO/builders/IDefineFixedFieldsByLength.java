
package com.MainFrame.Reader.def.IO.builders;


public interface IDefineFixedFieldsByLength {

	
	public IDefineFixedFieldsByLength addFieldByLength(String name, int type, int length, int decimal);
	
	
	public IDefineFixedFieldsByLength skipBytes(int numberOfBytes);
	
	
	public IFixedWidthIOBuilder endOfRecord();
}
