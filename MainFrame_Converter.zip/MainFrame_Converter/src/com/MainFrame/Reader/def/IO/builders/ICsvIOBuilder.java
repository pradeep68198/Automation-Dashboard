
package com.MainFrame.Reader.def.IO.builders;


public interface ICsvIOBuilder extends IIOBuilder {

	
	public abstract ICsvIOBuilder setFileOrganization(int fileOrganization);
	


	
	public abstract ICsvIOBuilder setFont(String font);

	
	public abstract ICsvIOBuilder setParser(int csvParser);

//	public abstract ICsvIOBuilder setRecordSelection(String recordName, ExternalSelection selectionCriteria);


	
	public abstract IDefineCsvFields defineFields();


	
	public abstract ICsvIOBuilder setDelimiter(String val);


	
	public abstract ICsvIOBuilder setQuote(String val);
}
