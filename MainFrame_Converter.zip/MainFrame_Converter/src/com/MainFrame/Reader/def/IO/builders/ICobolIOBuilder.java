
package com.MainFrame.Reader.def.IO.builders;

import com.MainFrame.Reader.Details.RecordDecider;
import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
import com.MainFrame.Reader.Log.AbsSSLogger;
import com.MainFrame.Reader.Option.IRecordPositionOption;


public interface ICobolIOBuilder extends IIOBuilder, Icb2xmlLoadOptions {

	
	@Override public abstract ICobolIOBuilder setFileOrganization(int fileOrganization);

	@Override public abstract ICobolIOBuilder setSplitCopybook(int splitCopybook);

	public abstract ICobolIOBuilder setDialect(int dialect);

	@Override public abstract ICobolIOBuilder setFont(String font);

	@Override public abstract ICobolIOBuilder setRecordPositionCode(String recordName, IRecordPositionOption positionOption);

	@Override public abstract ICobolIOBuilder setRecordSelection(String recordName, ExternalSelection selectionCriteria);
	
	@Override public abstract ICobolIOBuilder setRecordParent(String recordName, String parentName);

	@Override public abstract ICobolIOBuilder setRecordDecider(RecordDecider recordDecider);
	
	@Override public abstract ICobolIOBuilder setRecordLength(int recordLength);

	
	public abstract ICobolIOBuilder setCopybookFileFormat(int copybookFileFormat);
	
	@Override public abstract ICobolIOBuilder setInitToSpaces(boolean initToSpaces);


	
	public abstract ICobolIOBuilder setLog(AbsSSLogger log);

	
	public abstract ICobolIOBuilder setDropCopybookNameFromFields(boolean dropCopybookNameFromFields);
	
	
	public abstract ICobolIOBuilder setStackSize(int stacksize);
	
	
	public abstract ICobolIOBuilder setKeepFillers(boolean keepFillers);
	
	
	public abstract ICobolIOBuilder setOptimizeTypes(boolean optimize);
	

}