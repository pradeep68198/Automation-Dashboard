
package com.MainFrame.Reader.def.IO.builders;

import java.io.InputStream;
import java.io.Reader;


public interface ICobolCopybookIOProvider {

	
	public abstract ICobolIOBuilder newIOBuilder(
			String copybookFileame);

	
	public abstract ICobolIOBuilder newIOBuilder(
			InputStream cobolCopybookStream, String copybookName);

	public abstract ICobolIOBuilder newIOBuilder(
			Reader copybookReader, String copybookName);

	
	public abstract ICobolMultiCopybookIOBuilder newMultiCopybookIOBuilder(String copybookname);

}