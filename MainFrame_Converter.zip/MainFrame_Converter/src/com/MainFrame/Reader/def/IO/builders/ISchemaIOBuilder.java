
package com.MainFrame.Reader.def.IO.builders;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.MainFrame.Reader.ByteIO.IByteRecordReader;
import com.MainFrame.Reader.ByteIO.IByteRecordWriter;
import com.MainFrame.Reader.Details.AbstractLine;
import com.MainFrame.Reader.Details.LayoutDetail;
import com.MainFrame.Reader.IO.AbstractLineReader;
import com.MainFrame.Reader.IO.AbstractLineWriter;



public interface ISchemaIOBuilder extends INewLineCreator {

	
	public abstract AbstractLine newLine() throws IOException;

	
	public abstract AbstractLine newLine(byte[] data) throws IOException;

	
	public abstract LayoutDetail getLayout() throws	IOException;

	
	public abstract AbstractLineReader newReader(String filename)
			throws FileNotFoundException, IOException;

	
	public abstract AbstractLineReader newReader(InputStream datastream)
			throws IOException;

	
	public abstract AbstractLineReader newReader(IByteRecordReader byteReader)
			throws IOException;

	
	
	public abstract AbstractLineWriter newWriter(String filename)
			throws FileNotFoundException, IOException;

	
	public abstract AbstractLineWriter newWriter(OutputStream datastream)
			throws IOException;

	
	public abstract AbstractLineWriter newWriter(IByteRecordWriter writer)
			throws IOException;

}
