package com.MainFrame.Reader.def.IO.builders.recordDeciders;

import com.MainFrame.Reader.Details.IRecordDeciderX;

public interface ISingleFieldDeciderBuilder {

	
	ISingleFieldDeciderBuilder setCaseSensitive(boolean caseSensitive);
	
	
	ISingleFieldDeciderBuilder addRecord(String recordTypeValue, String recordName);
	
	
	IRecordDeciderX build();
}
