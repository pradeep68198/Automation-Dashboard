
package com.MainFrame.Reader.def.IO.builders;

import com.MainFrame.Reader.Details.RecordDecider;
import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
import com.MainFrame.Reader.Log.AbsSSLogger;
import com.MainFrame.Reader.Option.IRecordPositionOption;



public interface Icb2xmlIOBuilder extends IIOBuilder, Icb2xmlLoadOptions {

	@Override public abstract Icb2xmlIOBuilder setFileOrganization(int fileOrganization);

	@Override  public abstract Icb2xmlIOBuilder setSplitCopybook(int splitCopybook);

	@Override public abstract Icb2xmlIOBuilder setFont(String font);

	@Override public abstract Icb2xmlIOBuilder setRecordSelection(String recordName, ExternalSelection selectionCriteria);

	@Override public abstract Icb2xmlIOBuilder setRecordPositionCode(String recordName, IRecordPositionOption positionOption);
	
	@Override public abstract Icb2xmlIOBuilder setRecordParent(String recordName, String parentName);
	
	@Override public abstract Icb2xmlIOBuilder setRecordDecider(RecordDecider recordDecider);

	
	public abstract Icb2xmlIOBuilder setLog(AbsSSLogger log);

	
	public abstract Icb2xmlIOBuilder setDropCopybookNameFromFields(boolean dropCopybookNameFromFields);
	
	
	public abstract Icb2xmlIOBuilder setKeepFillers(boolean keepFillers);

}