
package com.MainFrame.Reader.def.IO.builders;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import com.MainFrame.Reader.External.ExternalRecord;


public interface IIOCopybookProvider {

	
	public abstract IFileIOBuilder newIOBuilder(String schemaFileName);

	
	public abstract IFileIOBuilder newIOBuilder(
			InputStream schemaStream, String schemaName);
	
	
	public abstract IFileIOBuilder newIOBuilder(
			Reader xmlReader, String copybookName);


	
	public abstract IIOCopybookProvider setIndentXml(boolean indentXml);

	
	public abstract void export(String fileName, ExternalRecord schema) 
	throws XMLStreamException, UnsupportedEncodingException, FactoryConfigurationError, IOException;

	
	public abstract void export(OutputStream outStream, ExternalRecord schema) 
	throws XMLStreamException, UnsupportedEncodingException, FactoryConfigurationError, IOException;

	
	public abstract void export(Writer writer, ExternalRecord schema)
	throws XMLStreamException, UnsupportedEncodingException, FactoryConfigurationError;

	
	public abstract void export(XMLStreamWriter writer, ExternalRecord schema)  throws XMLStreamException ;

	
}