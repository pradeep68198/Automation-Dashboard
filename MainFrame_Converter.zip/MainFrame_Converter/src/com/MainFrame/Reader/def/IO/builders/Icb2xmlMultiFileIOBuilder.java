
package com.MainFrame.Reader.def.IO.builders;

import java.io.InputStream;

import com.MainFrame.Reader.Details.RecordDecider;
import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
import com.MainFrame.Reader.Log.AbsSSLogger;
import com.MainFrame.Reader.Option.IRecordPositionOption;


public interface Icb2xmlMultiFileIOBuilder extends  Icb2xmlIOBuilder {

	
	@Override public abstract Icb2xmlMultiFileIOBuilder setFileOrganization(int fileOrganization);

	@Override public abstract Icb2xmlMultiFileIOBuilder setSplitCopybook(int splitCopybook);

	@Override public abstract Icb2xmlMultiFileIOBuilder setFont(String font);

	@Override public abstract Icb2xmlMultiFileIOBuilder setRecordSelection(String recordName, ExternalSelection selectionCriteria);
	
	@Override public abstract Icb2xmlMultiFileIOBuilder setRecordParent(String recordName, String parentName);

	@Override public abstract Icb2xmlMultiFileIOBuilder setLog(AbsSSLogger log);

	@Override public abstract Icb2xmlMultiFileIOBuilder setDropCopybookNameFromFields(boolean dropCopybookNameFromFields);
	
	@Override public abstract Icb2xmlMultiFileIOBuilder setInitToSpaces(boolean initToSpaces);
	
	@Override public abstract Icb2xmlMultiFileIOBuilder setRecordDecider(RecordDecider recordDecider);


	
	public abstract Icb2xmlMultiFileIOBuilder addCopyBook(String fileName);
	
	
	public abstract Icb2xmlMultiFileIOBuilder addCopyBook(InputStream inStream,
			String copybookName);

	
	public abstract Icb2xmlMultiFileIOBuilder setRecordSelectionCurrentCopybook(	ExternalSelection recordSelection);


	@Override public abstract Icb2xmlMultiFileIOBuilder setRecordPositionCode(
			String recordName, IRecordPositionOption positionOption);

	
	public abstract Icb2xmlMultiFileIOBuilder setStartingPosition(int position) ;

	
	public abstract Icb2xmlMultiFileIOBuilder setStartingPositionToField(String recordName, String fieldName);

}
