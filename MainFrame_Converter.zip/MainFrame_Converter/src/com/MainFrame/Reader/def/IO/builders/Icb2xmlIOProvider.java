
package com.MainFrame.Reader.def.IO.builders;

import java.io.InputStream;

public interface Icb2xmlIOProvider {

	
	public abstract Icb2xmlIOBuilder newIOBuilder(
			String copybookFileame);

	
	public abstract Icb2xmlIOBuilder newIOBuilder(
			InputStream cobolCopybookStream, String copybookName);

	
	public abstract Icb2xmlMultiFileIOBuilder newMultiCopybookIOBuilder(String copybookname);

}