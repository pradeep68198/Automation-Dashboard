
package com.MainFrame.Reader.def.IO.builders;



public interface IDefineCsvFields {
	
	public IDefineCsvFields addCsvField(String name, int type, int decimal);

	
	public ICsvIOBuilder endOfRecord();
}
