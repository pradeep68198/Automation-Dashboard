
package com.MainFrame.Reader.def.IO.builders;

import java.io.InputStream;
import java.io.Reader;

import com.MainFrame.Reader.Details.RecordDecider;
import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
import com.MainFrame.Reader.Log.AbsSSLogger;
import com.MainFrame.Reader.Option.IRecordPositionOption;


public interface ICobolMultiCopybookIOBuilder extends  ICobolIOBuilder {

	
	@Override public abstract ICobolMultiCopybookIOBuilder setFileOrganization(int fileOrganization);

	@Override public abstract ICobolMultiCopybookIOBuilder setSplitCopybook(int splitCopybook);

	@Override public abstract ICobolMultiCopybookIOBuilder setDialect(int dialect);

	@Override public abstract ICobolMultiCopybookIOBuilder setFont(String font);


	@Override public abstract ICobolMultiCopybookIOBuilder setRecordPositionCode(
			String recordName, IRecordPositionOption positionOption);

	@Override public abstract ICobolMultiCopybookIOBuilder setRecordSelection(String recordName, ExternalSelection selectionCriteria);
	
	@Override public abstract ICobolMultiCopybookIOBuilder setRecordParent(String recordName, String parentName);

	@Override public abstract ICobolMultiCopybookIOBuilder setRecordDecider(RecordDecider recordDecider);

	@Override public abstract ICobolMultiCopybookIOBuilder setCopybookFileFormat(int copybookFileFormat);

	@Override public abstract ICobolMultiCopybookIOBuilder setLog(AbsSSLogger log);

	@Override public abstract ICobolMultiCopybookIOBuilder setDropCopybookNameFromFields(boolean dropCopybookNameFromFields);
	
	@Override public abstract ICobolMultiCopybookIOBuilder setInitToSpaces(boolean initToSpaces);

	
	public abstract ICobolMultiCopybookIOBuilder addCopyBook(String fileName);
	
	
	public abstract ICobolMultiCopybookIOBuilder addCopyBook(InputStream inStream, String copybookName);

	
	public abstract ICobolMultiCopybookIOBuilder addCopyBook(Reader reader, String copybookName);

	
	public abstract ICobolMultiCopybookIOBuilder setRecordSelectionCurrentCopybook(	ExternalSelection recordSelection);
	
	@Override public abstract ICobolMultiCopybookIOBuilder setKeepFillers(boolean keepFillers);

	

	
	public abstract ICobolMultiCopybookIOBuilder setStartingPosition(int position) ;


	@Override ICobolMultiCopybookIOBuilder setRecordLength(int recordLength);

	
	@Override ICobolMultiCopybookIOBuilder setStackSize(int stacksize);

	
	public abstract ICobolMultiCopybookIOBuilder setStartingPositionToField(String recordName, String fieldName);

}
