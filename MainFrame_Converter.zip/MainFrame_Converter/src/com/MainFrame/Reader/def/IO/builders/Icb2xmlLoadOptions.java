
package com.MainFrame.Reader.def.IO.builders;

import com.MainFrame.Reader.Details.RecordDecider;
import com.MainFrame.Reader.ExternalRecordSelection.ExternalSelection;
import com.MainFrame.Reader.Option.IRecordPositionOption;




public interface Icb2xmlLoadOptions {


//	public abstract Icb2xmlLoadOptions setFileOrganization(int fileOrganization);

	
	public abstract Icb2xmlLoadOptions setSplitCopybook(int splitCopybook);


//	public abstract Icb2xmlLoadOptions setFont(String font);
//
	

	
	public abstract Icb2xmlLoadOptions setRecordSelection(String recordName, ExternalSelection selectionCriteria);
	
	
	public abstract Icb2xmlLoadOptions setRecordLength(int recordLength);

	
	public abstract Icb2xmlLoadOptions setRecordDecider(RecordDecider recordDecider);
	
	
	public abstract Icb2xmlLoadOptions setRecordParent(String recordName, String parentName);

//	public abstract Icb2xmlLoadOptions setCopybookFileFormat(int copybookFileFormat);


	
	public abstract Icb2xmlLoadOptions setDropCopybookNameFromFields(boolean dropCopybookNameFromFields);

	
	public abstract Icb2xmlLoadOptions setRecordPositionCode(
			String recordName,
			IRecordPositionOption positionOption);
	
	
	public abstract Icb2xmlLoadOptions setInitToSpaces(boolean initToSpaces);
}