package com.MainFrame.Reader.def.IO.builders.recordDeciders;

import com.MainFrame.Reader.Details.RecordDecider;


public interface IRecordDeciderBuilder {

	
	ISingleFieldDeciderBuilder singleFieldDeciderBuilder(String recordTypeFieldName, boolean allowOtherRecordTypeValues);

	
	ISingleFieldDeciderBuilder singleFieldDeciderBuilder(String recordTypeFieldName, String defaultRecordName);

}