
package com.MainFrame.Reader.def.IO.builders;


public interface IDefineFixedFieldsByPosition {

	
	
	public IDefineFixedFieldsByPosition addFieldByPosition(String name, int type, int pos, int decimal);
	
	
	public IDefineFixedFieldsByPosition skipFieldPosition(int pos);

	
	public IFixedWidthIOBuilder endOfRecord(int recordLength);
}
