
package com.MainFrame.Reader.def.IO.builders;

import java.io.IOException;

import com.MainFrame.Reader.External.ExternalRecord;



public interface IIOBuilder extends ISchemaIOBuilder{


	
	
	public abstract IIOBuilder setFileOrganization(int fileOrganization);

	public abstract IIOBuilder setFont(String font);
	
	
	public abstract ExternalRecord getExternalRecord() throws IOException;

	
	

}