/*     */ package com.MainFrame.Reader.Numeric;
/*     */ 
/*     */ import com.MainFrame.Convert2xml.def.BasicNumericDefinition;
/*     */ import com.MainFrame.Convert2xml.def.NumericDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericNumericDefinition
/*     */   implements NumericDefinition, Convert
/*     */ {
/*     */   public static final int PIC9 = 0;
/*     */   public static final int BINARY = 2;
/*     */   public static final int COMP_0 = 2;
/*     */   public static final int COMP_1 = 3;
/*     */   public static final int COMP_2 = 4;
/*     */   public static final int COMP_3 = 5;
/*     */   public static final int COMP_4 = 6;
/*     */   public static final int COMP_5 = 7;
/*     */   public static final int COMP_6 = 8;
/*     */   public static final int COMP_7 = 9;
/*     */   public static final int COMP_8 = 10;
/*     */   private int[] compSizesUsed;
/*     */   private int[] syncSizesUsed;
/*     */   private int[] syncDigitsAvailable;
/*     */   private int[] digitsAvailable;
/*     */   private int[] positiveDigitsAvailable;
/*     */   private int[] positiveSyncDigitsAvailable;
/*     */   private int[] syncPos;
/*     */   private int[] posTypes;
/*     */   private int[] types;
/*  78 */   private int floatSync = 4;
/*  79 */   private int doubleSync = 8;
/*     */ 
/*     */   
/*     */   private final int identifier;
/*     */   
/*     */   private final int binId;
/*     */   
/*     */   private String name;
/*     */   
/*  88 */   private int defaultVbFileStructure = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericNumericDefinition(int id, int binaryId, String encodingName, int[] sizes, int[] syncSizes, int[] syncPosition, int[] stdTypes, int[] positiveTypes, int floatSyncAt, int doubleSyncAt) {
/*  97 */     int[] tmpPositive = new int[sizes.length];
/*     */     
/*  99 */     this.compSizesUsed = new int[sizes.length];
/*     */ 
/*     */ 
/*     */     
/* 103 */     this.identifier = id;
/* 104 */     this.binId = binaryId;
/* 105 */     this.types = stdTypes;
/* 106 */     this.posTypes = positiveTypes;
/* 107 */     if (this.posTypes == null) {
/* 108 */       this.posTypes = this.types;
/*     */     }
/*     */     
/* 111 */     this.name = encodingName;
/*     */     
/* 113 */     this.syncPos = BasicNumericDefinition.DEFAULT_SYNC;
/* 114 */     if (syncPosition != null) {
/* 115 */       this.syncPos = syncPosition;
/*     */     }
/*     */     
/* 118 */     this.digitsAvailable = new int[sizes.length]; int i;
/* 119 */     for (i = 0; i < sizes.length; i++) {
/* 120 */       this.compSizesUsed[i] = sizes[i];
/*     */       
/* 122 */       int idx = Math.min(BasicNumericDefinition.MAX_COMP_SIZE.length, sizes[i]) - 1;
/* 123 */       this.digitsAvailable[i] = BasicNumericDefinition.MAX_COMP_SIZE[idx];
/* 124 */       tmpPositive[i] = BasicNumericDefinition.MAX_POSITIVE_COMP_SIZE[idx];
/*     */     } 
/*     */     
/* 127 */     int[] tmpSyncPositive = tmpPositive;
/* 128 */     this.syncSizesUsed = this.compSizesUsed;
/* 129 */     if (syncSizes != null) {
/* 130 */       this.syncSizesUsed = new int[syncSizes.length];
/* 131 */       this.syncDigitsAvailable = new int[syncSizes.length];
/* 132 */       tmpPositive = new int[syncSizes.length];
/* 133 */       for (i = 0; i < syncSizes.length; i++) {
/* 134 */         this.syncSizesUsed[i] = syncSizes[i];
/*     */         
/* 136 */         int idx = Math.min(BasicNumericDefinition.MAX_COMP_SIZE.length, this.syncSizesUsed[i]) - 1;
/* 137 */         this.syncDigitsAvailable[i] = BasicNumericDefinition.MAX_COMP_SIZE[idx];
/* 138 */         tmpSyncPositive[i] = BasicNumericDefinition.MAX_POSITIVE_COMP_SIZE[idx];
/*     */       } 
/*     */     } 
/*     */     
/* 142 */     this.positiveDigitsAvailable = this.digitsAvailable;
/* 143 */     if (this.posTypes != this.types) {
/* 144 */       this.positiveDigitsAvailable = tmpPositive;
/* 145 */       this.positiveSyncDigitsAvailable = tmpSyncPositive;
/*     */     } 
/*     */     
/* 148 */     this.floatSync = floatSyncAt;
/* 149 */     this.doubleSync = doubleSyncAt;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 153 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBinarySize(String usage, int numDigits, boolean positive, boolean sync) {
/* 158 */     int storageLength = numDigits;
/* 159 */     boolean pos = positive;
/* 160 */     switch (getTypeCode(usage, positive)) {
/*     */       case 17:
/* 162 */         storageLength = 4;
/*     */         break;
/*     */       case 18:
/* 165 */         storageLength = 8;
/*     */         break;
/*     */       case 31:
/*     */       case 33:
/* 169 */         storageLength = numDigits / 2 + 1;
/*     */         break;
/*     */       case 11:
/* 172 */         storageLength = numDigits / 2;
/*     */         break;
/*     */       case 37:
/* 175 */         storageLength = numDigits + 1;
/*     */         break;
/*     */       case 23:
/*     */       case 39:
/* 179 */         pos = false;
/*     */       
/*     */       case 15:
/*     */       case 16:
/*     */       case 35:
/*     */       case 36:
/* 185 */         if (sync) {
/* 186 */           storageLength = getBinSizes(numDigits, pos, this.syncSizesUsed, this.syncDigitsAvailable, this.positiveSyncDigitsAvailable); break;
/*     */         } 
/* 188 */         storageLength = getBinSizes(numDigits, pos, this.compSizesUsed, this.digitsAvailable, this.positiveDigitsAvailable);
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 201 */     System.out.println(" >> SL " + usage + " " + numDigits + " " + positive + " " + 
/* 202 */         getTypeCode(usage, positive) + " >> " + storageLength);
/* 203 */     return storageLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int getBinSizes(int numDigits, boolean positive, int[] compSizes, int[] digits, int[] positiveDigits) {
/* 210 */     int storageLength = compSizes[compSizes.length - 1];
/* 211 */     for (int i = 0; i < digits.length - 1; i++) {
/* 212 */       if (digits[i] >= numDigits || (positive && positiveDigits[i] >= numDigits)) {
/*     */         
/* 214 */         storageLength = compSizes[Math.max(0, i)];
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 219 */     return storageLength;
/*     */   }
/*     */   
/*     */   public int getSyncAt(String usage, int actualLength) {
/* 223 */     int syncOn = 1;
/* 224 */     if (isBinaryInt(usage))
/* 225 */     { switch (actualLength) { case 1:
/* 226 */           syncOn = this.syncPos[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 241 */           return syncOn;case 2: syncOn = this.syncPos[1]; return syncOn;case 3: case 4: syncOn = this.syncPos[2]; return syncOn; }  syncOn = this.syncPos[3]; } else { switch (getTypeCode(usage, false)) { case 17: syncOn = this.floatSync; break;case 18: syncOn = this.doubleSync; break; }  }  return syncOn;
/*     */   }
/*     */ 
/*     */   
/*     */   public int chkStorageLength(int storageLength, String usage) {
/* 246 */     int ret = storageLength;
/* 247 */     if (storageLength == 0) {
/* 248 */       switch (getTypeCode(usage, false)) {
/*     */         case 17:
/* 250 */           ret = 10;
/*     */           break;
/*     */         case 18:
/* 253 */           ret = 18;
/*     */           break;
/*     */       } 
/*     */     }
/* 257 */     return ret;
/*     */   }
/*     */   
/*     */   private boolean isBinaryInt(String usage) {
/* 261 */     boolean ret = false;
/* 262 */     switch (getTypeCode(usage, false)) {
/*     */       case 15:
/*     */       case 16:
/*     */       case 23:
/*     */       case 35:
/*     */       case 36:
/*     */       case 39:
/* 269 */         ret = true;
/*     */         break;
/*     */     } 
/* 272 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIdentifier() {
/* 283 */     return this.identifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBinaryIdentifier() {
/* 293 */     return this.binId;
/*     */   }
/*     */ 
/*     */   
/*     */   public NumericDefinition getNumericDefinition() {
/* 298 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeIdentifier(String usage, String picture, boolean signed, boolean signSeperate, String signPosition) {
/* 304 */     int code = getBinCode(usage);
/* 305 */     int ret = 0;
/*     */     
/* 307 */     picture = picture.toUpperCase();
/* 308 */     if (code >= 0) {
/* 309 */       ret = getTypeCode(code, !signed);
/* 310 */     } else if (picture.indexOf('Z') >= 0 || picture
/* 311 */       .indexOf('-') >= 0 || picture
/* 312 */       .indexOf('+') >= 0 || picture
/* 313 */       .indexOf('.') >= 0) {
/* 314 */       ret = 6;
/*     */     } else {
/* 316 */       ret = CommonCode.commonTypeChecks(this.identifier, usage, picture, signed, signSeperate, signPosition);
/*     */     } 
/*     */     
/* 319 */     return ret;
/*     */   }
/*     */   
/*     */   public int getTypeCode(String usage, boolean positive) {
/* 323 */     return getTypeCode(getBinCode(usage), positive);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTypeCode(int code, boolean positive) {
/* 328 */     int ret = this.types[code];
/* 329 */     if (positive) {
/* 330 */       ret = this.posTypes[code];
/*     */     }
/*     */     
/* 333 */     return ret;
/*     */   }
/*     */   
/*     */   protected final int getBinCode(String usage) {
/* 337 */     int ret = 0;
/* 338 */     if ("computational".equalsIgnoreCase(usage)) {
/* 339 */       ret = 2;
/* 340 */     } else if ("computational-1".equalsIgnoreCase(usage)) {
/* 341 */       ret = 3;
/* 342 */     } else if ("computational-2".equalsIgnoreCase(usage)) {
/* 343 */       ret = 4;
/* 344 */     } else if ("computational-3".equalsIgnoreCase(usage) || "packed-decimal".equalsIgnoreCase(usage)) {
/* 345 */       ret = 5;
/* 346 */     } else if ("computational-4".equalsIgnoreCase(usage)) {
/* 347 */       ret = 6;
/* 348 */     } else if ("computational-5".equalsIgnoreCase(usage)) {
/* 349 */       ret = 7;
/* 350 */     } else if ("computational-6".equalsIgnoreCase(usage)) {
/* 351 */       ret = 8;
/* 352 */     } else if ("computational-7".equalsIgnoreCase(usage)) {
/* 353 */       ret = 9;
/* 354 */     } else if ("computational-8".equalsIgnoreCase(usage)) {
/* 355 */       ret = 10;
/* 356 */     } else if ("binary".equalsIgnoreCase(usage)) {
/* 357 */       ret = 2;
/*     */     } 
/*     */     
/* 360 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFileStructure(boolean multipleRecordLengths, boolean binary) {
/* 368 */     if (multipleRecordLengths && binary) {
/* 369 */       return this.defaultVbFileStructure;
/*     */     }
/* 371 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Convert setDefaultVbFileStructure(int defaultFileStructure) {
/* 378 */     this.defaultVbFileStructure = defaultFileStructure;
/* 379 */     return this;
/*     */   }
/*     */ }

