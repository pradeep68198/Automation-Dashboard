/*     */ package com.MainFrame.Reader.Numeric;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import com.MainFrame.Reader.Common.PropertyManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadConversion
/*     */ {
/*  37 */   private static final int[] STANDARD_TYPES = new int[] { 41, 46, 35, 17, 18, 31, 35, 15 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   private static HashMap<String, Integer> typeConversion = new HashMap<String, Integer>();
/*     */   
/*     */   static {
/*  45 */     typeConversion.put("be", Integer.valueOf(35));
/*  46 */     typeConversion.put("be+", Integer.valueOf(39));
/*  47 */     typeConversion.put("le", Integer.valueOf(15));
/*  48 */     typeConversion.put("le+", Integer.valueOf(23));
/*  49 */     typeConversion.put("pbe", Integer.valueOf(36));
/*  50 */     typeConversion.put("ple", Integer.valueOf(16));
/*  51 */     typeConversion.put("pd", Integer.valueOf(31));
/*  52 */     typeConversion.put("pd+", Integer.valueOf(33));
/*  53 */     typeConversion.put("ppd", Integer.valueOf(11));
/*  54 */     typeConversion.put("f", Integer.valueOf(17));
/*  55 */     typeConversion.put("d", Integer.valueOf(18));
/*  56 */     typeConversion.put("mvszd", Integer.valueOf(32));
/*     */     
/*  58 */     typeConversion.put("zd9", Integer.valueOf(46));
/*  59 */     typeConversion.put("zd", Integer.valueOf(41));
/*  60 */     typeConversion.put("rm", Integer.valueOf(37));
/*  61 */     typeConversion.put("rmp", Integer.valueOf(38));
/*     */   }
/*     */   
/*  64 */   private Properties properties = PropertyManager.getProperties();
/*  65 */   private String propConversion = "CnvCode.";
/*     */   
/*     */   public Convert getConversion(int idx) {
/*  68 */     Convert ret = null;
/*     */     
/*  70 */     if (this.properties != null && this.properties.containsKey(this.propConversion + idx)) {
/*     */       try {
/*  72 */         int code = Integer.parseInt(this.properties.getProperty(this.propConversion + idx));
/*  73 */         int binaryId = getIntProperty("CnvBinaryId." + idx, 3);
/*  74 */         int floatSync = getIntProperty("CnvFloatSync." + idx, 4);
/*  75 */         int doubleSync = getIntProperty("CnvDoubleSync." + idx, 8);
/*     */         
/*  77 */         String name = this.properties.getProperty("CnvName." + idx);
/*     */ 
/*     */         
/*  80 */         int[] sizes = getIntArray("CnvSizes." + idx);
/*  81 */         int[] syncSizes = getIntArray("CnvSyncSizes." + idx);
/*  82 */         int[] syncPos = getIntArray("CnvSyncPosition." + idx);
/*     */         
/*  84 */         int[] stdTypes = getTypes("CnvType." + idx, STANDARD_TYPES);
/*  85 */         int[] positiveTypes = getTypes("CnvPositiveType." + idx, stdTypes);
/*     */         
/*  87 */         ret = new GenericNumericDefinition(code, binaryId, name, sizes, syncSizes, syncPos, stdTypes, positiveTypes, floatSync, doubleSync);
/*     */       
/*     */       }
/*  90 */       catch (Exception e) {
/*  91 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  96 */     return ret;
/*     */   }
/*     */   
/*     */   private int getIntProperty(String name, int defaultValue) {
/* 100 */     int ret = defaultValue;
/* 101 */     String s = this.properties.getProperty(name);
/*     */     
/* 103 */     if (s != null && s.length() > 0) {
/* 104 */       ret = Integer.parseInt(s.trim());
/*     */     }
/*     */     
/* 107 */     return ret;
/*     */   }
/*     */   
/*     */   private int[] getIntArray(String name) {
/* 111 */     int[] ret = null;
/* 112 */     StringTokenizer tok = new StringTokenizer(this.properties.getProperty(name), ",");
/* 113 */     int count = tok.countTokens();
/*     */     
/* 115 */     if (count > 0) {
/* 116 */       int i = 0;
/* 117 */       ret = new int[count];
/* 118 */       String s = "";
/* 119 */       while (tok.hasMoreElements()) {
/* 120 */         ret[i] = -1;
/*     */         try {
/* 122 */           s = tok.nextToken();
/* 123 */           ret[i] = Integer.parseInt(s.trim());
/* 124 */         } catch (Exception e) {
/* 125 */           System.out.println("Invalid Integer :" + s + ", in " + name);
/*     */         } 
/* 127 */         i++;
/*     */       } 
/*     */     } 
/* 130 */     return ret;
/*     */   }
/*     */   
/*     */   private int[] getTypes(String name, int[] base) {
/* 134 */     int[] ret = base;
/*     */     
/*     */     try {
/* 137 */       StringTokenizer tok = new StringTokenizer(this.properties.getProperty(name), ",");
/* 138 */       int count = tok.countTokens();
/*     */       
/* 140 */       if (count > 0) {
/* 141 */         int i = 0;
/* 142 */         ret = new int[Math.max(count, base.length)];
/* 143 */         String s = "";
/*     */         
/* 145 */         for (int j = 0; j < base.length; j++) {
/* 146 */           ret[j] = base[j];
/*     */         }
/*     */         
/* 149 */         while (tok.hasMoreElements()) {
/* 150 */           s = tok.nextToken();
/*     */           
/* 152 */           if (s != null && typeConversion.containsKey(s.toLowerCase())) {
/* 153 */             ret[i] = ((Integer)typeConversion.get(s.toLowerCase())).intValue();
/*     */           }
/*     */           
/* 156 */           i++;
/*     */         } 
/*     */       } 
/* 159 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 162 */     return ret;
/*     */   }
/*     */ }

