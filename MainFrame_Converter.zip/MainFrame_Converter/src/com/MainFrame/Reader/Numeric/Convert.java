package com.MainFrame.Reader.Numeric;

import com.MainFrame.Convert2xml.def.IBasicDialect;
import com.MainFrame.Convert2xml.def.NumericDefinition;

public interface Convert extends ICopybookDialects, IBasicDialect {
  NumericDefinition getNumericDefinition();
  
  int getTypeIdentifier(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, String paramString3);
  
  int getIdentifier();
  
  int getBinaryIdentifier();
  
  int getFileStructure(boolean paramBoolean1, boolean paramBoolean2);
  
  String getName();
}

