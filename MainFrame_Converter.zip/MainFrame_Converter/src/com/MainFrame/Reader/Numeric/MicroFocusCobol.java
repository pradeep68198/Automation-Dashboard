/*    */ package com.MainFrame.Reader.Numeric;
/*    */ 
/*    */ import com.MainFrame.Convert2xml.def.BasicNumericDefinition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MicroFocusCobol
/*    */   extends GenericNumericDefinition
/*    */ {
/* 33 */   private static final int[] BIN_SIZES_1_TO_8 = new int[] { 1, 2, 3, 4, 5, 6, 7, 8 };
/*    */   
/* 35 */   private static final int[] BIN_SIZES_1248 = new int[] { 1, 2, 4, 8 };
/* 36 */   private static final int[] BIN_SIZES_1244 = new int[] { 1, 2, 4, 4 };
/*    */   
/* 38 */   private static final int[] STANDARD_TYPES = new int[] { 41, 35, 35, 17, 18, 31, 35, 15 };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   private static final int[] POSITIVE_TYPES = new int[] { 22, 39, 39, 17, 18, 33, 39, 23 };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   private static int[] COMP5_DIGITS = new int[] { BasicNumericDefinition.MAX_COMP_SIZE[0], BasicNumericDefinition.MAX_COMP_SIZE[1], BasicNumericDefinition.MAX_COMP_SIZE[3], BasicNumericDefinition.MAX_COMP_SIZE[7] };
/*    */ 
/*    */ 
/*    */   
/* 56 */   private static int[] COMP5_POSITIVE_SIZES = new int[] { BasicNumericDefinition.MAX_POSITIVE_COMP_SIZE[0], BasicNumericDefinition.MAX_POSITIVE_COMP_SIZE[1], BasicNumericDefinition.MAX_POSITIVE_COMP_SIZE[3], BasicNumericDefinition.MAX_POSITIVE_COMP_SIZE[7] };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MicroFocusCobol() {
/* 62 */     super(21, 3, "Microfocus Cobol", BIN_SIZES_1_TO_8, BIN_SIZES_1248, BIN_SIZES_1244, STANDARD_TYPES, POSITIVE_TYPES, 4, 8);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getBinarySize(String usage, int numDigits, boolean positive, boolean sync) {
/*    */     int ret;
/* 71 */     if (getBinCode(usage) == 7) {
/* 72 */       ret = getBinSizes(numDigits, positive, BIN_SIZES_1248, COMP5_DIGITS, COMP5_POSITIVE_SIZES);
/*    */     } else {
/* 74 */       ret = super.getBinarySize(usage, numDigits, positive, sync);
/*    */     } 
/*    */     
/* 77 */     return ret;
/*    */   }
/*    */ }

