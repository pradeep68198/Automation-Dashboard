/*     */ package com.MainFrame.Reader.Numeric;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import com.MainFrame.Reader.Common.AbstractManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConversionManager
/*     */   implements AbstractManager
/*     */ {
/*  55 */   private static final int[] MAINFRAME_BIN_SIZES = new int[] { 2, 4, 8 };
/*  56 */   private static final int[] BIN_SIZES_1248 = new int[] { 1, 2, 4, 8 };
/*     */   
/*  58 */   private static final int[] BIN_SIZES_1_TO_8 = new int[] { 1, 2, 3, 4, 5, 6, 7, 8 };
/*  59 */   private static final int[] NO_SYNC = new int[] { 1, 1, 1, 1 };
/*  60 */   private static int[] MAINFRAME_SYNC = new int[] { 2, 2, 4, 4 };
/*  61 */   private static final int[] FS2000_SYNC = new int[] { 2, 2, 4, 8 };
/*     */ 
/*     */ 
/*     */   
/*  65 */   private static ConversionManager instance = null;
/*  66 */   private ArrayList<Convert> conversions = new ArrayList<Convert>();
/*  67 */   private HashMap<Integer, Convert> conversionsMap = new HashMap<Integer, Convert>(30);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConversionManager() {
/*  74 */     Convert mainframeConverter = (new BasicConvert(1, "Mainframe", 1, MAINFRAME_BIN_SIZES, MAINFRAME_SYNC, true, 4, 4)).setDefaultVbFileStructure(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     Convert fujitsuConverter = (new GnuCobol(2, "Fujitsu", MAINFRAME_BIN_SIZES, MAINFRAME_SYNC, 4, 8)).setDefaultVbFileStructure(7);
/*     */     
/*  82 */     registerConverter(new BasicConvert(0, "Intel", 0, MAINFRAME_BIN_SIZES, false));
/*  83 */     registerConverter(mainframeConverter);
/*  84 */     registerConverter(fujitsuConverter);
/*  85 */     registerConverter(new BasicConvert(3, "Big-Endian (Old)", 3, MAINFRAME_BIN_SIZES, false));
/*     */     
/*  87 */     registerConverter(new GnuCobol(4, "GNU Cobol Little Endian (Intel)", BIN_SIZES_1248, BIN_SIZES_1248));
/*  88 */     registerConverter(new GnuCobol(5, "GNU Cobol bs2000 Little Endian (Intel)", MAINFRAME_BIN_SIZES, FS2000_SYNC));
/*  89 */     registerConverter(new GnuCobol(6, "GNU Cobol MVS Little Endian (Intel)", MAINFRAME_BIN_SIZES, FS2000_SYNC));
/*  90 */     registerConverter(new GnuCobol(7, "GNU Cobol Micro Focus (Intel)", BIN_SIZES_1_TO_8, NO_SYNC, 1, 1));
/*     */     
/*  92 */     registerConverter(new OpenCobolBE(8, "GNU Cobol Big Endian", BIN_SIZES_1248, BIN_SIZES_1248));
/*  93 */     registerConverter(new OpenCobolBE(9, "GNU Cobol bs2000 Big Endian", MAINFRAME_BIN_SIZES, FS2000_SYNC));
/*  94 */     registerConverter(new OpenCobolBE(10, "GNU Cobol MVS Big Endian", MAINFRAME_BIN_SIZES, FS2000_SYNC));
/*  95 */     registerConverter(new OpenCobolBE(11, "GNU Cobol Micro Focus Big E", BIN_SIZES_1_TO_8, NO_SYNC, 1, 1));
/*     */ 
/*     */     
/*  98 */     registerConverter(new CommaDecimal(31, mainframeConverter));
/*  99 */     registerConverter(new CommaDecimal(32, fujitsuConverter));
/*     */ 
/*     */     
/* 102 */     LoadConversion loader = new LoadConversion();
/*     */ 
/*     */     
/* 105 */     for (int i = 0; i < 32; i++) {
/* 106 */       Convert conv; if ((conv = loader.getConversion(i)) != null)
/*     */       {
/* 108 */         registerConverter(conv);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getManagerName() {
/* 127 */     return "BinFormat/Dialect";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfEntries() {
/* 136 */     return this.conversions.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Convert getConverter4code(int index) {
/* 145 */     return this.conversionsMap.get(Integer.valueOf(index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Convert getConverter(int index) {
/* 154 */     return this.conversions.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerConverter(Convert converter) {
/* 162 */     this.conversions.add(converter);
/* 163 */     this.conversionsMap.put(Integer.valueOf(converter.getIdentifier()), converter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKey(int idx) {
/* 172 */     return ((Convert)this.conversions.get(idx)).getIdentifier();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName(int idx) {
/* 180 */     return ((Convert)this.conversions.get(idx)).getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConversionManager getInstance() {
/* 188 */     if (instance == null) {
/* 189 */       instance = new ConversionManager();
/*     */     }
/* 191 */     return instance;
/*     */   }
/*     */   
/*     */   private static class GnuCobol extends BasicConvert {
/*     */     public GnuCobol(int id, String name, int[] binarySizes, int[] syncAt) {
/* 196 */       super(id, name, 3, binarySizes, syncAt, true, 4, 8);
/* 197 */       setDefaultVbFileStructure(8);
/*     */     }
/*     */     
/*     */     public GnuCobol(int id, String name, int[] binarySizes, int[] syncAt, int floatSync, int doubleSync) {
/* 201 */       super(id, name, 3, binarySizes, syncAt, true, floatSync, doubleSync);
/* 202 */       setDefaultVbFileStructure(8);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getTypeIdentifier(String usage, String picture, boolean signed, boolean signSeperate, String signPosition) {
/*     */       int iType;
/* 208 */       picture = picture.toUpperCase();
/* 209 */       if ("computational-5".equalsIgnoreCase(usage)) {
/* 210 */         iType = 15;
/* 211 */         if (!signed && !picture.startsWith("S")) {
/* 212 */           iType = 23;
/* 213 */           if (isPositiveIntAvailable()) {
/* 214 */             iType = 16;
/*     */           }
/*     */         } 
/*     */       } else {
/* 218 */         iType = super.getTypeIdentifier(usage, picture, signed, signSeperate, signPosition);
/*     */       } 
/* 220 */       return iType;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class OpenCobolBE extends BasicConvert {
/*     */     public OpenCobolBE(int id, String name, int[] binarySizes, int[] syncAt) {
/* 226 */       super(id, name, 3, binarySizes, syncAt, true, 4, 8);
/* 227 */       setDefaultVbFileStructure(8);
/*     */     }
/*     */     
/*     */     public OpenCobolBE(int id, String name, int[] binarySizes, int[] syncAt, int floatSync, int doubleSync) {
/* 231 */       super(id, name, 3, binarySizes, syncAt, true, floatSync, doubleSync);
/* 232 */       setDefaultVbFileStructure(8);
/*     */     }
/*     */   }
/*     */ }

