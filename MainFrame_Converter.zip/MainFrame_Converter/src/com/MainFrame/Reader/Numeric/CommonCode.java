/*     */ package com.MainFrame.Reader.Numeric;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonCode
/*     */ {
/*     */   public static int commonTypeChecks(int dialect, String usage, String picture, boolean signed, boolean signSeperate, String signPosition) {
/*  35 */     int iType = 0;
/*  36 */     if (signed || picture.startsWith("S")) {
/*  37 */       if (signSeperate) {
/*  38 */         boolean actualDecimal = (picture.indexOf('.') >= 0);
/*     */         
/*  40 */         iType = 10;
/*  41 */         if ("leading".equals(signPosition)) {
/*  42 */           iType = 9;
/*  43 */           if (actualDecimal) {
/*  44 */             iType = 44;
/*     */           }
/*  46 */         } else if (actualDecimal) {
/*  47 */           iType = 45;
/*     */         } 
/*     */       } else {
/*  50 */         iType = 46;
/*  51 */         switch (dialect) { case 1:
/*     */           case 31:
/*  53 */             iType = 32; break;
/*     */           case 2:
/*     */           case 32:
/*  56 */             iType = 41; break; }
/*     */       
/*     */       } 
/*     */     } else {
/*  60 */       iType = 22;
/*     */     } 
/*  62 */     return iType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean checkPicture(String pict, char validChar, char decimalChar, char altDecimal) {
/*  77 */     boolean check = false;
/*  78 */     boolean foundDot = false;
/*  79 */     boolean lastChSearch = (pict.charAt(0) == validChar);
/*  80 */     boolean lastCh9 = (pict.charAt(0) == '9');
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     for (int i = 1; i < pict.length(); i++) {
/*  99 */       char ch = pict.charAt(i);
/* 100 */       if (ch == '(') {
/* 101 */         if (!lastChSearch && !lastCh9) {
/* 102 */           return false;
/*     */         }
/*     */         
/* 105 */         check = true;
/*     */       } else {
/* 107 */         lastChSearch = false;
/* 108 */         lastCh9 = false;
/*     */         
/* 110 */         if (check) {
/* 111 */           check = (ch != ')');
/* 112 */         } else if (ch == validChar) {
/* 113 */           if (foundDot && validChar != '9') {
/* 114 */             return false;
/*     */           }
/* 116 */           lastChSearch = true;
/* 117 */         } else if (ch == decimalChar || ch == altDecimal) {
/* 118 */           if (foundDot) {
/* 119 */             return false;
/*     */           }
/* 121 */           foundDot = true;
/*     */         } else {
/* 123 */           switch (ch) { case '9':
/* 124 */               lastCh9 = true; break;
/*     */             case '+':
/*     */             case '-':
/* 127 */               if (i == pict.length() - 1)
/* 128 */                 break; default: return false; }
/*     */ 
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/* 134 */     return true;
/*     */   }
/*     */   
/*     */   public static final boolean checkPictureNumeric(String pict, char decimalChar) {
/* 138 */     boolean foundDot = false;
/* 139 */     boolean check = false;
/* 140 */     boolean minusAllowed = (pict.charAt(0) == '-');
/* 141 */     boolean plusAllowed = (pict.charAt(0) == '+');
/* 142 */     boolean leadingSign = (minusAllowed || plusAllowed);
/*     */     
/* 144 */     pict = pict.toUpperCase();
/*     */     
/* 146 */     for (int i = 0; i < pict.length(); i++) {
/* 147 */       char ch = pict.charAt(i);
/* 148 */       if (ch == '(') {
/* 149 */         check = true;
/* 150 */       } else if (ch == decimalChar) {
/* 151 */         if (foundDot) {
/* 152 */           return false;
/*     */         }
/* 154 */         foundDot = true;
/*     */       }
/* 156 */       else if (check) {
/* 157 */         check = (ch != ')');
/*     */       } else {
/* 159 */         switch (ch) {
/*     */           case '9':
/*     */           case 'Z':
/* 162 */             minusAllowed = false;
/* 163 */             plusAllowed = false; break;
/*     */           case ',':
/*     */           case '.':
/*     */           case 'V':
/*     */             break;
/*     */           case '+':
/* 169 */             if ((leadingSign || i != pict.length() - 1) && 
/* 170 */               !plusAllowed) return false; 
/*     */             break;
/*     */           case '-':
/* 173 */             if ((leadingSign || i != pict.length() - 1) && 
/* 174 */               !minusAllowed) return false; 
/*     */             break;
/*     */           case 'S':
/* 177 */             if (i > 0) return false;  break;
/*     */           default:
/* 179 */             return false;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/* 185 */     return true;
/*     */   }
/*     */ }

