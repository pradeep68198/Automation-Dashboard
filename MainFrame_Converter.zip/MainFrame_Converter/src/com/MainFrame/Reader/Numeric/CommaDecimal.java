/*     */ package com.MainFrame.Reader.Numeric;
/*     */ 
/*     */ import com.MainFrame.Convert2xml.def.NumericDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommaDecimal
/*     */   implements Convert
/*     */ {
/*     */   private final Convert baseConversion;
/*     */   private final int id;
/*     */   
/*     */   public CommaDecimal(int identifier, Convert baseConversion) {
/*  54 */     this.id = identifier;
/*  55 */     this.baseConversion = baseConversion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericDefinition getNumericDefinition() {
/*  64 */     return this.baseConversion.getNumericDefinition();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeIdentifier(String usage, String picture, boolean signed, boolean signSeperate, String signPosition) {
/*  75 */     picture = picture.toUpperCase();
/*     */     
/*  77 */     if (usage.indexOf("comp") < 0 && picture.length() > 2 && picture.indexOf(',') > 0)
/*     */     {
/*  79 */       if (picture.indexOf('9') >= 0 && (picture
/*  80 */         .startsWith("-") || picture.startsWith("+") || picture.startsWith("9")) && 
/*  81 */         CommonCode.checkPicture(picture, '9', ',', ',')) {
/*     */         
/*  83 */         if (picture.startsWith("-"))
/*  84 */           return 26; 
/*  85 */         if (picture.startsWith("9"))
/*  86 */           return 28; 
/*  87 */         if (picture.startsWith("+"))
/*  88 */           return 27; 
/*     */       } else {
/*  90 */         if ((picture.startsWith("-") && CommonCode.checkPicture(picture, '-', ',', ',')) || (picture
/*  91 */           .startsWith("Z") && CommonCode.checkPicture(picture, 'Z', ',', ',')))
/*     */         {
/*  93 */           return 42; } 
/*  94 */         if (picture.startsWith("+") && 
/*  95 */           CommonCode.checkPicture(picture, '+', ',', ','))
/*     */         {
/*  97 */           return 43; } 
/*     */       }  } 
/*  99 */     return this.baseConversion.getTypeIdentifier(usage, picture, signed, signSeperate, signPosition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIdentifier() {
/* 107 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBinaryIdentifier() {
/* 115 */     return this.baseConversion.getBinaryIdentifier();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFileStructure(boolean multipleRecordLengths, boolean binary) {
/* 125 */     return this.baseConversion.getFileStructure(multipleRecordLengths, binary);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 133 */     return this.baseConversion.getName() + " Decimal_Point=','";
/*     */   }
/*     */ }

