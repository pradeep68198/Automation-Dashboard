/*     */ package com.MainFrame.Reader.Numeric;
/*     */ 
/*     */ import com.MainFrame.Convert2xml.def.BasicNumericDefinition;
/*     */ import com.MainFrame.Convert2xml.def.NumericDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicConvert
/*     */   implements Convert
/*     */ {
/*     */   private final int identifier;
/*     */   private final int binId;
/*     */   private final boolean usePositiveInteger;
/*  45 */   private int defaultVbFileStructure = 0;
/*     */ 
/*     */   
/*     */   private NumericDefinition numericDefinition;
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */   
/*     */   public BasicConvert(int id, String name, int binaryId, int[] binarySizes, boolean usePositive) {
/*  55 */     this(id, name, binaryId, binarySizes, null, usePositive, 4, 8);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicConvert(int id, String binName, int binaryId, int[] binarySizes, int[] SynchronizeAt, boolean usePositive, int floatSynchronize, int doubleSynchronize) {
/*  61 */     this.name = binName;
/*  62 */     this.usePositiveInteger = usePositive;
/*     */     try {
/*  64 */       this.numericDefinition = (NumericDefinition)new BasicNumericDefinition(binName, binarySizes, SynchronizeAt, usePositive, floatSynchronize, doubleSynchronize);
/*     */     
/*     */     }
/*  67 */     catch (NoClassDefFoundError e) {
/*  68 */       System.out.println("Class Not Found: " + e.getMessage());
/*     */     } 
/*  70 */     this.identifier = id;
/*     */     
/*  72 */     this.binId = binaryId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeIdentifier(String usage, String picture, boolean signed, boolean signSeperate, String signPosition) {
/*  86 */     int lType = -121;
/*     */     
/*  88 */     picture = picture.toUpperCase();
/*  89 */     boolean positive = (!signed && !picture.startsWith("S"));
/*     */     
/*  91 */     if (picture.startsWith("-9(") || picture.startsWith("+++9") || picture.startsWith("+(2)9")) {
/*  92 */       lType = -121;
/*     */     }
/*  94 */     if ("computational".equalsIgnoreCase(usage) || "computational-4"
/*  95 */       .equalsIgnoreCase(usage) || "computational-5"
/*  96 */       .equalsIgnoreCase(usage) || "computational-6"
/*  97 */       .equalsIgnoreCase(usage) || "binary"
/*  98 */       .equalsIgnoreCase(usage))
/*  99 */     { if (this.binId == 1 || this.binId == 2 || this.binId == 3) {
/*     */ 
/*     */         
/* 102 */         lType = 35;
/* 103 */         if (positive) {
/* 104 */           lType = 39;
/* 105 */           if (this.usePositiveInteger) {
/* 106 */             lType = 36;
/*     */           }
/*     */         } 
/*     */       } else {
/* 110 */         lType = 15;
/* 111 */         if (positive) {
/* 112 */           lType = 23;
/* 113 */           if (this.usePositiveInteger) {
/* 114 */             lType = 16;
/*     */           }
/*     */         } 
/*     */       }  }
/* 118 */     else if ("computational-3".equalsIgnoreCase(usage) || "packed-decimal".equalsIgnoreCase(usage))
/* 119 */     { lType = 31;
/* 120 */       if (positive) {
/* 121 */         lType = 33;
/*     */       } }
/* 123 */     else if ("computational-1".equalsIgnoreCase(usage))
/* 124 */     { lType = 17; }
/* 125 */     else if ("computational-2".equalsIgnoreCase(usage))
/* 126 */     { lType = 18; }
/* 127 */     else { if (!CommonCode.checkPictureNumeric(picture, '.'))
/* 128 */         return 0; 
/* 129 */       if (picture.indexOf('9') >= 0 && (picture
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 134 */         .startsWith("-") || picture.startsWith("+") || picture.startsWith("9") || picture
/* 135 */         .endsWith("-") || picture.endsWith("+")) && 
/* 136 */         CommonCode.checkPicture(picture, '9', '.', 'V')) {
/*     */         
/* 138 */         if (picture.startsWith("-")) {
/* 139 */           lType = 7;
/* 140 */           if (picture.indexOf('V') >= 0) {
/* 141 */             lType = 9;
/*     */           
/*     */           }
/*     */         }
/* 145 */         else if (picture.startsWith("+")) {
/* 146 */           lType = 24;
/* 147 */           if (picture.indexOf('V') >= 0) {
/* 148 */             lType = 9;
/*     */           
/*     */           }
/*     */         }
/* 152 */         else if (picture.endsWith("-") || picture.endsWith("+")) {
/* 153 */           lType = 10;
/* 154 */           if (picture.indexOf('.') >= 0) {
/* 155 */             lType = 45;
/*     */           }
/* 157 */         } else if (picture.startsWith("9") && picture.indexOf('V') < 0) {
/* 158 */           lType = 25;
/*     */         } else {
/* 160 */           lType = chkRest(lType, usage, picture, signed, signSeperate, signPosition);
/*     */         } 
/*     */       } else {
/*     */         
/* 164 */         lType = chkRest(lType, usage, picture, signed, signSeperate, signPosition);
/*     */       }  }
/* 166 */      return lType;
/*     */   }
/*     */ 
/*     */   
/*     */   private int chkRest(int lType, String usage, String picture, boolean signed, boolean signSeperate, String signPosition) {
/* 171 */     if (picture.startsWith("+") && CommonCode.checkPicture(picture, '+', '.', 'V')) {
/* 172 */       lType = 29;
/* 173 */     } else if (picture.indexOf('Z') >= 0 || picture
/* 174 */       .indexOf('-') >= 0 || picture
/* 175 */       .indexOf('+') >= 0 || picture
/* 176 */       .indexOf('.') >= 0) {
/* 177 */       lType = 6;
/*     */     } else {
/* 179 */       lType = CommonCode.commonTypeChecks(this.identifier, usage, picture, signed, signSeperate, signPosition);
/*     */     } 
/*     */     
/* 182 */     return lType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIdentifier() {
/* 192 */     return this.identifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBinaryIdentifier() {
/* 201 */     return this.binId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPositiveIntAvailable() {
/* 209 */     return this.usePositiveInteger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericDefinition getNumericDefinition() {
/* 217 */     return this.numericDefinition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getName() {
/* 224 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFileStructure(boolean multipleRecordLengths, boolean binary) {
/* 232 */     if (multipleRecordLengths && binary) {
/* 233 */       return this.defaultVbFileStructure;
/*     */     }
/* 235 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Convert setDefaultVbFileStructure(int defaultFileStructure) {
/* 242 */     this.defaultVbFileStructure = defaultFileStructure;
/* 243 */     return this;
/*     */   }
/*     */ }

