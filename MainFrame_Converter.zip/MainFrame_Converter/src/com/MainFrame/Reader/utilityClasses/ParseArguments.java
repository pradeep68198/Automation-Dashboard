
package com.MainFrame.Reader.utilityClasses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;


public class ParseArguments {
	
	public static final String[] EMPTY_ARRAY = {}; 

//    private HashMap<String, String> argsMap = new HashMap<String, String>();
    private HashMap<String, List<String>> argsMapOfList = new HashMap<String, List<String>>();


  
    public ParseArguments(final String[] validArgs, final String[] args) {
    	this(validArgs, EMPTY_ARRAY, args);
    	
    }
    public ParseArguments(final String[] validSingleItemArgs, final String[] validMultiItemArgs,final String[] args) {

        int i;
        HashSet<String> valid = new HashSet<String>();
        HashSet<String> validMulti = new HashSet<String>();
        String currArg = null;
        StringBuilder currValue = new StringBuilder();
        String sep = "";

        for (i = 0; i < validSingleItemArgs.length; i++) {
            valid.add(validSingleItemArgs[i].toUpperCase());
        }
        for (i = 0; i < validMultiItemArgs.length; i++) {
        	validMulti.add(validMultiItemArgs[i].toUpperCase());
        }

        for (i = 0; i < args.length; i++) {
            if (args[i].startsWith("-")) {
            	updateMap(currArg, currValue.toString());
                
                currValue.setLength(0);;
                sep = "";
                currArg = args[i].toUpperCase();

                if (valid.contains(currArg)) {
                	if (argsMapOfList.containsKey(currArg)) {
                		System.out.println(" ** Only one " + args[i] + " argument is allowed !!!");
                		currArg = null;
                	}
                } else if (! validMulti.contains(currArg) ) {
                    currArg = null;
                    System.out.println(" ** Invalid Argument " + args[i]);
                }
            } else {
                currValue.append(sep).append(args[i]);
                sep = " ";
            }
        }
        updateMap(currArg, currValue.toString());
        
        System.out.println();
        System.out.println();
    }


    private void updateMap(String currArg, String currValue) {
        if (currArg != null) {
        	List<String> list = argsMapOfList.get(currArg);
        	if (list == null) {
        		list = new ArrayList<String>(5);
        	}
        	list.add(currValue);
            argsMapOfList.put(currArg, list);
        }
    }
    
    public String getArg(String arg) {
        return getArg(arg, null);//    /**
//     
//     public int getIntArg(String arg) throws Exception {
//         try {
//             return Integer.parseInt(getArg(arg));
//         } catch (Exception e) {
//             System.out.println();
//             System.out.println("Error processing integer argument " + arg
//                     + "  - " + e.getMessage());
//             System.out.println();
//             throw e;
//         }
//      }
 //
 //
//     /**
//      * Get a requested integer argument
//      *
//      * @param arg argument being requested
//      * @param defaultVal default value for the parameter
//      * @return Argment value
//       */
//     public int getIntArg(String arg, int defaultVal) {
//         try {
//             return Integer.parseInt(getArg(arg));
//         } catch (Exception e) {
//             return defaultVal;
//         }
//      }
 //
 //
//     /**
//      * Get a requested integer argument
//      *
//      * @param arg1 argument being requested
//      * @param arg2 argument being requested
//      * @param defaultVal default value for the parameter
//      * @return Argment value
//      */
//     public int get2IntArgs(String arg1, String arg2, int defaultVal) {
//         String strVal = getArg(arg1);
//         if (strVal != null && strVal.length() > 0) {
//             try {
//             	return Integer.parseInt(strVal);
//             } catch (Exception e) { }
//         }
//         
//         strVal = getArg(arg2);
//         if (strVal != null && strVal.length() > 0) {
//             try {
//             	return Integer.parseInt(strVal);
//             } catch (Exception e) { }
//         }
 //    
//         return defaultVal;
//      }
    }


   
    public String get2Args(String arg1, String arg2, String defaultValue) {
    	return getArg(arg1, getArg(arg2, defaultValue));
    }
    	 
   
    public String getArg(String arg, String defaultValue) {
        String ret = defaultValue;
        String key = arg.toUpperCase();
        
        if (argsMapOfList.containsKey(key)) {
            List<String> list = argsMapOfList.get(key);
            if (list.size() > 1) {
            	throw new RuntimeException("There where: " + list.size() + " objects in the list");
            }
			ret = list.get(0);
        }
        return ret;
    }
    
    public List<String> getArgList(String arg) {
    	return argsMapOfList.get(arg.toUpperCase());
    }
}
