
package com.MainFrame.Reader.utilityClasses;

import com.MainFrame.Reader.External.CobolCopybookLoader;
import com.MainFrame.Reader.External.CopybookLoader;
import com.MainFrame.Reader.External.ExternalRecord;
import com.MainFrame.Reader.External.RecordEditorXmlLoader;
import com.MainFrame.Reader.Log.TextLog;


public class SchemaLoader {

	
	public static ExternalRecord loadSchema(String schemaFileName, int split, String fontname, int binformat) 
	throws Exception  {
		
		CopybookLoader conv;
		if (schemaFileName.toLowerCase().endsWith(".xml")) {
			conv = new RecordEditorXmlLoader();
		} else {
			conv = new CobolCopybookLoader();	
		}
		
		return conv.loadCopyBook(schemaFileName, split, 0, fontname, binformat, 0, new TextLog()); 
	}
}
