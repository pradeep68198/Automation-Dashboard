
package com.MainFrame.Reader.utilityClasses;

import com.MainFrame.Reader.Common.Constants;



public class VbDetector {

	public final int NOT_A_KNOWN_VB = Constants.NULL_INTEGER;
	
	
}
